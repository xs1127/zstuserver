/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */  enum DriverError
/*    */ {
/* 35 */   NOT_SET(0);
/*    */ 
/*    */   private final int errorCode;
/*    */ 
/* 38 */   final int getErrorCode() { return this.errorCode; }
/*    */ 
/*    */   private DriverError(int paramInt)
/*    */   {
/* 42 */     this.errorCode = paramInt;
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.DriverError
 * JD-Core Version:    0.6.0
 */