/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Calendar;
/*     */ import microsoft.sql.DateTimeOffset;
/*     */ 
/*     */ final class Parameter
/*     */ {
/*     */   private TypeInfo typeInfo;
/*     */   private String typeDefinition;
/*     */   private int outScale;
/*     */   private String name;
/*     */   private DTV getterDTV;
/*     */   private DTV registeredOutDTV;
/*     */   private DTV setterDTV;
/*     */   private DTV inputDTV;
/*     */ 
/*     */   Parameter()
/*     */   {
/*  24 */     this.typeDefinition = null;
/*     */ 
/*  87 */     this.outScale = 4;
/*     */ 
/* 125 */     this.registeredOutDTV = null;
/* 126 */     this.setterDTV = null;
/* 127 */     this.inputDTV = null;
/*     */   }
/*     */ 
/*     */   TypeInfo getTypeInfo()
/*     */   {
/*  21 */     return this.typeInfo;
/*     */   }
/*     */ 
/*     */   boolean isOutput()
/*     */   {
/*  27 */     return null != this.registeredOutDTV;
/*     */   }
/*     */ 
/*     */   JDBCType getJdbcType()
/*     */     throws SQLServerException
/*     */   {
/*  34 */     return null != this.inputDTV ? this.inputDTV.getJdbcType() : JDBCType.UNKNOWN;
/*     */   }
/*     */ 
/*     */   private static JDBCType getSSPAUJDBCType(JDBCType paramJDBCType)
/*     */   {
/*  43 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()]) {
/*     */     case 1:
/*  45 */       return JDBCType.NCHAR;
/*     */     case 2:
/*  46 */       return JDBCType.NVARCHAR;
/*     */     case 3:
/*  47 */       return JDBCType.LONGNVARCHAR;
/*     */     case 4:
/*  48 */       return JDBCType.NCLOB;
/*  49 */     }return paramJDBCType;
/*     */   }
/*     */ 
/*     */   void registerForOutput(JDBCType paramJDBCType, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/*  59 */     if ((JDBCType.DATETIMEOFFSET == paramJDBCType) && (!paramSQLServerConnection.isKatmaiOrLater()))
/*     */     {
/*  61 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*     */     }
/*     */ 
/*  72 */     if (paramSQLServerConnection.sendStringParametersAsUnicode()) {
/*  73 */       paramJDBCType = getSSPAUJDBCType(paramJDBCType);
/*     */     }
/*  75 */     this.registeredOutDTV = new DTV();
/*  76 */     this.registeredOutDTV.setJdbcType(paramJDBCType);
/*     */ 
/*  78 */     if (null == this.setterDTV) {
/*  79 */       this.inputDTV = this.registeredOutDTV;
/*     */     }
/*  81 */     resetOutputValue();
/*     */   }
/*     */ 
/*     */   int getOutScale()
/*     */   {
/*  88 */     return this.outScale; } 
/*  89 */   void setOutScale(int paramInt) { this.outScale = paramInt;
/*     */   }
/*     */ 
/*     */   final Parameter cloneForBatch()
/*     */   {
/* 141 */     Parameter localParameter = new Parameter();
/* 142 */     localParameter.typeInfo = this.typeInfo;
/* 143 */     localParameter.typeDefinition = this.typeDefinition;
/* 144 */     localParameter.outScale = this.outScale;
/* 145 */     localParameter.name = this.name;
/* 146 */     localParameter.getterDTV = this.getterDTV;
/* 147 */     localParameter.registeredOutDTV = this.registeredOutDTV;
/* 148 */     localParameter.setterDTV = this.setterDTV;
/* 149 */     localParameter.inputDTV = this.inputDTV;
/* 150 */     return localParameter;
/*     */   }
/*     */ 
/*     */   final void skipValue(TDSReader paramTDSReader, boolean paramBoolean)
/*     */     throws SQLServerException
/*     */   {
/* 158 */     if (null == this.getterDTV)
/* 159 */       this.getterDTV = new DTV();
/* 160 */     deriveTypeInfo(paramTDSReader);
/* 161 */     this.getterDTV.skipValue(this.typeInfo, paramTDSReader, paramBoolean);
/*     */   }
/*     */ 
/*     */   final void skipRetValStatus(TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/* 170 */     StreamRetValue localStreamRetValue = new StreamRetValue();
/* 171 */     localStreamRetValue.setFromTDS(paramTDSReader);
/*     */   }
/*     */ 
/*     */   void clearInputValue()
/*     */   {
/* 177 */     this.setterDTV = null;
/* 178 */     this.inputDTV = this.registeredOutDTV;
/*     */   }
/*     */ 
/*     */   void resetOutputValue()
/*     */   {
/* 185 */     this.getterDTV = null;
/* 186 */     this.typeInfo = null;
/*     */   }
/*     */ 
/*     */   void deriveTypeInfo(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 191 */     if (null == this.typeInfo)
/* 192 */       this.typeInfo = TypeInfo.getInstance(paramTDSReader);
/*     */   }
/*     */ 
/*     */   void setFromReturnStatus(int paramInt, SQLServerConnection paramSQLServerConnection) throws SQLServerException
/*     */   {
/* 197 */     if (null == this.getterDTV) {
/* 198 */       this.getterDTV = new DTV();
/*     */     }
/* 200 */     this.getterDTV.setValue(null, JDBCType.INTEGER, new Integer(paramInt), JavaType.INTEGER, null, null, null, paramSQLServerConnection);
/*     */   }
/*     */ 
/*     */   void setValue(JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/* 214 */     if (((JDBCType.DATETIMEOFFSET == paramJDBCType) || (JavaType.DATETIMEOFFSET == paramJavaType)) && (!paramSQLServerConnection.isKatmaiOrLater()))
/*     */     {
/* 217 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*     */     }
/*     */ 
/* 228 */     if ((paramSQLServerConnection.sendStringParametersAsUnicode()) && ((JavaType.STRING == paramJavaType) || (JavaType.READER == paramJavaType) || (JavaType.CLOB == paramJavaType)))
/*     */     {
/* 233 */       paramJDBCType = getSSPAUJDBCType(paramJDBCType);
/*     */     }
/*     */ 
/* 236 */     DTV localDTV = new DTV();
/* 237 */     localDTV.setValue(paramSQLServerConnection.getDatabaseCollation(), paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger, paramSQLServerConnection);
/* 238 */     this.inputDTV = (this.setterDTV = localDTV);
/*     */   }
/*     */ 
/*     */   boolean isNull()
/*     */   {
/* 243 */     if (null != this.getterDTV) {
/* 244 */       return this.getterDTV.isNull();
/*     */     }
/* 246 */     return false;
/*     */   }
/*     */ 
/*     */   boolean isValueGotten()
/*     */   {
/* 251 */     return null != this.getterDTV;
/*     */   }
/*     */ 
/*     */   Object getValue(JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/* 257 */     if (null == this.getterDTV)
/* 258 */       this.getterDTV = new DTV();
/* 259 */     deriveTypeInfo(paramTDSReader);
/* 260 */     return this.getterDTV.getValue(paramJDBCType, this.outScale, paramInputStreamGetterArgs, paramCalendar, this.typeInfo, paramTDSReader);
/*     */   }
/*     */ 
/*     */   int getInt(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 265 */     Integer localInteger = (Integer)getValue(JDBCType.INTEGER, null, null, paramTDSReader);
/* 266 */     return null != localInteger ? localInteger.intValue() : 0;
/*     */   }
/*     */ 
/*     */   String getTypeDefinition(SQLServerConnection paramSQLServerConnection, TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/* 647 */     if (null == this.inputDTV) {
/* 648 */       return null;
/*     */     }
/* 650 */     this.inputDTV.executeOp(new GetTypeDefinitionOp(this, paramSQLServerConnection));
/* 651 */     return this.typeDefinition;
/*     */   }
/*     */ 
/*     */   void sendByRPC(TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/* 658 */     assert (null != this.inputDTV) : "Parameter was neither set nor registered";
/*     */ 
/* 660 */     this.inputDTV.sendByRPC(this.name, null, paramSQLServerConnection.getDatabaseCollation(), this.outScale, isOutput(), paramTDSWriter, paramSQLServerConnection);
/*     */ 
/* 678 */     if ((JavaType.INPUTSTREAM == this.inputDTV.getJavaType()) || (JavaType.READER == this.inputDTV.getJavaType()))
/*     */     {
/* 681 */       this.inputDTV = (this.setterDTV = null);
/*     */     }
/*     */   }
/*     */ 
/*     */   final class GetTypeDefinitionOp extends DTVExecuteOp
/*     */   {
/*     */     private static final String NVARCHAR_MAX = "nvarchar(max)";
/*     */     private static final String NVARCHAR_4K = "nvarchar(4000)";
/*     */     private static final String NTEXT = "ntext";
/*     */     private static final String VARCHAR_MAX = "varchar(max)";
/*     */     private static final String VARCHAR_8K = "varchar(8000)";
/*     */     private static final String TEXT = "text";
/*     */     private static final String VARBINARY_MAX = "varbinary(max)";
/*     */     private static final String VARBINARY_8K = "varbinary(8000)";
/*     */     private static final String IMAGE = "image";
/*     */     private final Parameter param;
/*     */     private final SQLServerConnection con;
/* 288 */     int scale = 0;
/*     */ 
/*     */     GetTypeDefinitionOp(Parameter paramSQLServerConnection, SQLServerConnection arg3)
/*     */     {
/* 294 */       this.param = paramSQLServerConnection;
/*     */       Object localObject;
/* 295 */       this.con = localObject;
/*     */     }
/*     */ 
/*     */     private void setTypeDefinition(DTV paramDTV)
/*     */     {
/* 300 */       switch (Parameter.1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramDTV.getJdbcType().ordinal()])
/*     */       {
/*     */       case 5:
/* 303 */         Parameter.access$002(this.param, SSType.TINYINT.toString());
/* 304 */         break;
/*     */       case 6:
/* 307 */         Parameter.access$002(this.param, SSType.SMALLINT.toString());
/* 308 */         break;
/*     */       case 7:
/* 311 */         Parameter.access$002(this.param, SSType.INTEGER.toString());
/* 312 */         break;
/*     */       case 8:
/* 315 */         Parameter.access$002(this.param, SSType.BIGINT.toString());
/* 316 */         break;
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/* 321 */         Parameter.access$002(this.param, SSType.FLOAT.toString());
/* 322 */         break;
/*     */       case 12:
/*     */       case 13:
/* 327 */         if (this.scale > 38) {
/* 328 */           this.scale = 38;
/*     */         }
/*     */ 
/* 334 */         Integer localInteger = paramDTV.getScale();
/* 335 */         if ((null != localInteger) && (this.scale < localInteger.intValue())) {
/* 336 */           this.scale = localInteger.intValue();
/*     */         }
/* 338 */         if ((this.param.isOutput()) && (this.scale < this.param.getOutScale())) {
/* 339 */           this.scale = this.param.getOutScale();
/*     */         }
/* 341 */         Parameter.access$002(this.param, "decimal(38," + this.scale + ")");
/* 342 */         break;
/*     */       case 14:
/*     */       case 15:
/* 346 */         Parameter.access$002(this.param, SSType.BIT.toString());
/* 347 */         break;
/*     */       case 16:
/*     */       case 17:
/* 351 */         Parameter.access$002(this.param, "varbinary(max)");
/* 352 */         break;
/*     */       case 18:
/*     */       case 19:
/* 357 */         if (("varbinary(max)" == this.param.typeDefinition) || ("image" == this.param.typeDefinition)) {
/*     */           break;
/*     */         }
/* 360 */         Parameter.access$002(this.param, "varbinary(8000)");
/* 361 */         break;
/*     */       case 20:
/* 365 */         Parameter.access$002(this.param, this.con.isKatmaiOrLater() ? SSType.DATE.toString() : SSType.DATETIME.toString());
/* 366 */         break;
/*     */       case 21:
/* 370 */         Parameter.access$002(this.param, this.con.sendTimeAsDatetime() ? SSType.DATETIME.toString() : SSType.TIME.toString());
/*     */ 
/* 375 */         break;
/*     */       case 22:
/* 380 */         Parameter.access$002(this.param, this.con.isKatmaiOrLater() ? SSType.DATETIME2.toString() : SSType.DATETIME.toString());
/*     */ 
/* 382 */         break;
/*     */       case 23:
/* 385 */         Parameter.access$002(this.param, SSType.DATETIMEOFFSET.toString());
/* 386 */         break;
/*     */       case 3:
/*     */       case 4:
/* 390 */         Parameter.access$002(this.param, "varchar(max)");
/* 391 */         break;
/*     */       case 1:
/*     */       case 2:
/* 396 */         if (("varchar(max)" == this.param.typeDefinition) || ("text" == this.param.typeDefinition)) {
/*     */           break;
/*     */         }
/* 399 */         Parameter.access$002(this.param, "varchar(8000)");
/* 400 */         break;
/*     */       case 24:
/*     */       case 25:
/* 404 */         Parameter.access$002(this.param, "nvarchar(max)");
/* 405 */         break;
/*     */       case 26:
/*     */       case 27:
/* 410 */         if (("nvarchar(max)" == this.param.typeDefinition) || ("ntext" == this.param.typeDefinition)) {
/*     */           break;
/*     */         }
/* 413 */         Parameter.access$002(this.param, "nvarchar(4000)");
/* 414 */         break;
/*     */       case 28:
/* 416 */         Parameter.access$002(this.param, SSType.XML.toString());
/* 417 */         break;
/*     */       default:
/* 420 */         if ($assertionsDisabled) break; throw new AssertionError("Unexpected JDBC type " + paramDTV.getJdbcType());
/*     */       }
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, String paramString)
/*     */       throws SQLServerException
/*     */     {
/* 427 */       if ((null != paramString) && (paramString.length() > 4000)) {
/* 428 */         paramDTV.setJdbcType(JDBCType.LONGNVARCHAR);
/*     */       }
/* 430 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Clob paramClob) throws SQLServerException
/*     */     {
/* 435 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Byte paramByte) throws SQLServerException
/*     */     {
/* 440 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Integer paramInteger) throws SQLServerException
/*     */     {
/* 445 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Time paramTime) throws SQLServerException
/*     */     {
/* 450 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Date paramDate) throws SQLServerException
/*     */     {
/* 455 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Timestamp paramTimestamp) throws SQLServerException
/*     */     {
/* 460 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, DateTimeOffset paramDateTimeOffset) throws SQLServerException
/*     */     {
/* 465 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Float paramFloat) throws SQLServerException
/*     */     {
/* 470 */       this.scale = 4;
/* 471 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Double paramDouble) throws SQLServerException
/*     */     {
/* 476 */       this.scale = 4;
/* 477 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, BigDecimal paramBigDecimal) throws SQLServerException
/*     */     {
/* 482 */       if (null != paramBigDecimal)
/*     */       {
/* 484 */         this.scale = paramBigDecimal.scale();
/*     */ 
/* 491 */         if (this.scale < 0) {
/* 492 */           this.scale = 0;
/*     */         }
/*     */       }
/* 495 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Long paramLong) throws SQLServerException
/*     */     {
/* 500 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Short paramShort) throws SQLServerException
/*     */     {
/* 505 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Boolean paramBoolean) throws SQLServerException
/*     */     {
/* 510 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, byte[] paramArrayOfByte) throws SQLServerException
/*     */     {
/* 515 */       if ((null != paramArrayOfByte) && (paramArrayOfByte.length > 8000)) {
/* 516 */         paramDTV.setJdbcType(paramDTV.getJdbcType().isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*     */       }
/* 518 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Blob paramBlob) throws SQLServerException
/*     */     {
/* 523 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, InputStream paramInputStream) throws SQLServerException
/*     */     {
/* 528 */       StreamSetterArgs localStreamSetterArgs = paramDTV.getStreamSetterArgs();
/*     */ 
/* 530 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*     */ 
/* 533 */       if ((JDBCType.CHAR == localJDBCType) || (JDBCType.VARCHAR == localJDBCType) || (JDBCType.BINARY == localJDBCType) || (JDBCType.VARBINARY == localJDBCType))
/*     */       {
/* 539 */         if (localStreamSetterArgs.getLength() > 8000L) {
/* 540 */           paramDTV.setJdbcType(localJDBCType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*     */         }
/* 544 */         else if (-1L == localStreamSetterArgs.getLength())
/*     */         {
/* 546 */           byte[] arrayOfByte = new byte[8001];
/* 547 */           BufferedInputStream localBufferedInputStream = new BufferedInputStream(paramInputStream, arrayOfByte.length);
/*     */ 
/* 549 */           int i = 0;
/*     */           try
/*     */           {
/* 553 */             localBufferedInputStream.mark(arrayOfByte.length);
/*     */ 
/* 555 */             i = localBufferedInputStream.read(arrayOfByte, 0, arrayOfByte.length);
/*     */ 
/* 557 */             if (-1 == i) {
/* 558 */               i = 0;
/*     */             }
/* 560 */             localBufferedInputStream.reset();
/*     */           }
/*     */           catch (IOException localIOException)
/*     */           {
/* 564 */             MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 565 */             Object[] arrayOfObject = { localIOException.toString() };
/* 566 */             SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject), "", true);
/*     */           }
/*     */ 
/* 569 */           paramDTV.setValue(localBufferedInputStream, JavaType.INPUTSTREAM);
/*     */ 
/* 575 */           if (i > 8000)
/* 576 */             paramDTV.setJdbcType(localJDBCType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*     */           else {
/* 578 */             localStreamSetterArgs.setLength(i);
/*     */           }
/*     */         }
/*     */       }
/* 582 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, Reader paramReader)
/*     */       throws SQLServerException
/*     */     {
/* 588 */       if ((JDBCType.NCHAR == paramDTV.getJdbcType()) || (JDBCType.NVARCHAR == paramDTV.getJdbcType()))
/*     */       {
/* 590 */         StreamSetterArgs localStreamSetterArgs = paramDTV.getStreamSetterArgs();
/*     */ 
/* 593 */         if (localStreamSetterArgs.getLength() > 4000L) {
/* 594 */           paramDTV.setJdbcType(JDBCType.LONGNVARCHAR);
/*     */         }
/* 598 */         else if (-1L == localStreamSetterArgs.getLength())
/*     */         {
/* 600 */           char[] arrayOfChar = new char[4001];
/* 601 */           BufferedReader localBufferedReader = new BufferedReader(paramReader, arrayOfChar.length);
/*     */ 
/* 603 */           int i = 0;
/*     */           try
/*     */           {
/* 607 */             localBufferedReader.mark(arrayOfChar.length);
/*     */ 
/* 609 */             i = localBufferedReader.read(arrayOfChar, 0, arrayOfChar.length);
/*     */ 
/* 611 */             if (-1 == i) {
/* 612 */               i = 0;
/*     */             }
/* 614 */             localBufferedReader.reset();
/*     */           }
/*     */           catch (IOException localIOException)
/*     */           {
/* 618 */             MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 619 */             Object[] arrayOfObject = { localIOException.toString() };
/* 620 */             SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject), "", true);
/*     */           }
/*     */ 
/* 623 */           paramDTV.setValue(localBufferedReader, JavaType.READER);
/*     */ 
/* 625 */           if (i > 4000)
/* 626 */             paramDTV.setJdbcType(JDBCType.LONGNVARCHAR);
/*     */           else {
/* 628 */             localStreamSetterArgs.setLength(i);
/*     */           }
/*     */         }
/*     */       }
/* 632 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */ 
/*     */     void execute(DTV paramDTV, SQLServerSQLXML paramSQLServerSQLXML) throws SQLServerException {
/* 636 */       setTypeDefinition(paramDTV);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.Parameter
 * JD-Core Version:    0.6.0
 */