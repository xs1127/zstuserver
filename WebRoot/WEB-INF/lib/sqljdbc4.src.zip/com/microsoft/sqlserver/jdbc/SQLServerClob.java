/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.sql.Clob;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public class SQLServerClob extends SQLServerClobBase
/*    */   implements Clob
/*    */ {
/* 17 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerClob");
/*    */ 
/*    */   @Deprecated
/*    */   public SQLServerClob(SQLServerConnection paramSQLServerConnection, String paramString)
/*    */   {
/* 27 */     super(paramSQLServerConnection, paramString, null == paramSQLServerConnection ? null : paramSQLServerConnection.getDatabaseCollation(), logger);
/*    */ 
/* 29 */     if (null == paramString)
/* 30 */       throw new NullPointerException(SQLServerException.getErrString("R_cantSetNull"));
/*    */   }
/*    */ 
/*    */   SQLServerClob(SQLServerConnection paramSQLServerConnection)
/*    */   {
/* 35 */     super(paramSQLServerConnection, "", paramSQLServerConnection.getDatabaseCollation(), logger);
/*    */   }
/*    */ 
/*    */   SQLServerClob(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo) throws SQLServerException, UnsupportedEncodingException
/*    */   {
/* 40 */     super(null, new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getSQLCollation(), logger);
/*    */   }
/*    */   final JDBCType getJdbcType() {
/* 43 */     return JDBCType.CLOB;
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerClob
 * JD-Core Version:    0.6.0
 */