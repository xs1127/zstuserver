/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ abstract class BaseInputStream extends InputStream
/*     */ {
/*     */   final boolean isAdaptive;
/*     */   final boolean isStreaming;
/*  26 */   private String parentLoggingInfo = "";
/*  27 */   private static int lastLoggingID = 0;
/*     */ 
/*  29 */   static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.InputStream");
/*     */   private String traceID;
/*  45 */   int streamPos = 0;
/*  46 */   int markedStreamPos = 0;
/*     */   TDSReaderMark currentMark;
/*     */   private ServerDTVImpl dtv;
/*     */   TDSReader tdsReader;
/*  50 */   int readLimit = 0;
/*  51 */   boolean isReadLimitSet = false;
/*     */ 
/*     */   abstract byte[] getBytes()
/*     */     throws SQLServerException;
/*     */ 
/*     */   private static synchronized int nextLoggingID()
/*     */   {
/*  28 */     return ++lastLoggingID;
/*     */   }
/*     */ 
/*     */   public final String toString()
/*     */   {
/*  33 */     if (this.traceID == null)
/*  34 */       this.traceID = (getClass().getName() + "ID:" + nextLoggingID());
/*  35 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   final void setLoggingInfo(String paramString) {
/*  39 */     this.parentLoggingInfo = paramString;
/*  40 */     if (logger.isLoggable(Level.FINER))
/*  41 */       logger.finer(toString());
/*     */   }
/*     */ 
/*     */   BaseInputStream(TDSReader paramTDSReader, boolean paramBoolean1, boolean paramBoolean2, ServerDTVImpl paramServerDTVImpl)
/*     */   {
/*  55 */     this.tdsReader = paramTDSReader;
/*  56 */     this.isAdaptive = paramBoolean1;
/*  57 */     this.isStreaming = paramBoolean2;
/*     */ 
/*  59 */     if (paramBoolean1)
/*  60 */       clearCurrentMark();
/*     */     else
/*  62 */       this.currentMark = paramTDSReader.mark();
/*  63 */     this.dtv = paramServerDTVImpl;
/*     */   }
/*     */ 
/*     */   final void clearCurrentMark()
/*     */   {
/*  68 */     this.currentMark = null;
/*  69 */     this.isReadLimitSet = false;
/*  70 */     if ((this.isAdaptive) && (this.isStreaming))
/*  71 */       this.tdsReader.stream();
/*     */   }
/*     */ 
/*     */   void closeHelper() throws IOException
/*     */   {
/*  76 */     if ((this.isAdaptive) && (null != this.dtv))
/*     */     {
/*  78 */       if (logger.isLoggable(Level.FINER))
/*  79 */         logger.finer(toString() + " closing the adaptive stream.");
/*  80 */       this.dtv.setPositionAfterStreamed(this.tdsReader);
/*     */     }
/*  82 */     this.currentMark = null;
/*  83 */     this.tdsReader = null;
/*  84 */     this.dtv = null;
/*     */   }
/*     */ 
/*     */   final void checkClosed()
/*     */     throws IOException
/*     */   {
/*  92 */     if (null == this.tdsReader)
/*  93 */       throw new IOException(SQLServerException.getErrString("R_streamIsClosed"));
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */   void setReadLimit(int paramInt)
/*     */   {
/* 109 */     if ((this.isAdaptive) && (paramInt > 0))
/*     */     {
/* 111 */       this.readLimit = paramInt;
/* 112 */       this.isReadLimitSet = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   void resetHelper()
/*     */     throws IOException
/*     */   {
/* 121 */     checkClosed();
/*     */ 
/* 123 */     if (null == this.currentMark)
/* 124 */       throw new IOException(SQLServerException.getErrString("R_streamWasNotMarkedBefore"));
/* 125 */     this.tdsReader.reset(this.currentMark);
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.BaseInputStream
 * JD-Core Version:    0.6.0
 */