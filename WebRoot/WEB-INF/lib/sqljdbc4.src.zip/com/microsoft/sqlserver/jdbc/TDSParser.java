/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ final class TDSParser
/*     */ {
/*  28 */   private static Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.TOKEN");
/*     */ 
/*     */   static void parse(TDSReader paramTDSReader, String paramString)
/*     */     throws SQLServerException
/*     */   {
/*  39 */     parse(paramTDSReader, new TDSTokenHandler(paramString));
/*     */   }
/*     */ 
/*     */   static void parse(TDSReader paramTDSReader, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException
/*     */   {
/*  44 */     boolean bool1 = logger.isLoggable(Level.FINEST);
/*     */ 
/*  47 */     boolean bool2 = true;
/*  48 */     while (bool2)
/*     */     {
/*  50 */       int i = paramTDSReader.peekTokenType();
/*     */ 
/*  52 */       if (bool1)
/*     */       {
/*  54 */         logger.finest(new StringBuilder().append(paramTDSReader.toString()).append(": ").append(paramTDSTokenHandler.logContext).append(": Processing ").append(-1 == i ? "EOF" : TDS.getTokenName(i)).toString());
/*     */       }
/*     */ 
/*  60 */       switch (i) {
/*     */       case 237:
/*  62 */         bool2 = paramTDSTokenHandler.onSSPI(paramTDSReader); break;
/*     */       case 173:
/*  63 */         bool2 = paramTDSTokenHandler.onLoginAck(paramTDSReader); break;
/*     */       case 227:
/*  64 */         bool2 = paramTDSTokenHandler.onEnvChange(paramTDSReader); break;
/*     */       case 121:
/*  65 */         bool2 = paramTDSTokenHandler.onRetStatus(paramTDSReader); break;
/*     */       case 172:
/*  66 */         bool2 = paramTDSTokenHandler.onRetValue(paramTDSReader); break;
/*     */       case 253:
/*     */       case 254:
/*     */       case 255:
/*  70 */         paramTDSReader.getCommand().checkForInterrupt();
/*  71 */         bool2 = paramTDSTokenHandler.onDone(paramTDSReader);
/*  72 */         break;
/*     */       case 170:
/*  74 */         bool2 = paramTDSTokenHandler.onError(paramTDSReader); break;
/*     */       case 171:
/*  75 */         bool2 = paramTDSTokenHandler.onInfo(paramTDSReader); break;
/*     */       case 169:
/*  76 */         bool2 = paramTDSTokenHandler.onOrder(paramTDSReader); break;
/*     */       case 129:
/*  77 */         bool2 = paramTDSTokenHandler.onColMetaData(paramTDSReader); break;
/*     */       case 209:
/*  78 */         bool2 = paramTDSTokenHandler.onRow(paramTDSReader); break;
/*     */       case 210:
/*  79 */         bool2 = paramTDSTokenHandler.onNBCRow(paramTDSReader); break;
/*     */       case 165:
/*  80 */         bool2 = paramTDSTokenHandler.onColInfo(paramTDSReader); break;
/*     */       case 164:
/*  81 */         bool2 = paramTDSTokenHandler.onTabName(paramTDSReader); break;
/*     */       case -1:
/*  83 */         paramTDSReader.getCommand().onTokenEOF();
/*  84 */         paramTDSTokenHandler.onEOF(paramTDSReader);
/*  85 */         bool2 = false;
/*  86 */         break;
/*     */       default:
/*  89 */         throwUnexpectedTokenException(paramTDSReader, paramTDSTokenHandler.logContext);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static void throwUnexpectedTokenException(TDSReader paramTDSReader, String paramString)
/*     */     throws SQLServerException
/*     */   {
/*  98 */     if (logger.isLoggable(Level.SEVERE))
/*  99 */       logger.severe(new StringBuilder().append(paramTDSReader.toString()).append(": ").append(paramString).append(": Encountered unexpected ").append(TDS.getTokenName(paramTDSReader.peekTokenType())).toString());
/* 100 */     paramTDSReader.throwInvalidTDSToken(TDS.getTokenName(paramTDSReader.peekTokenType()));
/*     */   }
/*     */ 
/*     */   static void ignoreLengthPrefixedToken(TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/* 106 */     paramTDSReader.readUnsignedByte();
/* 107 */     int i = paramTDSReader.readUnsignedShort();
/* 108 */     byte[] arrayOfByte = new byte[i];
/* 109 */     paramTDSReader.readBytes(arrayOfByte, 0, i);
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TDSParser
 * JD-Core Version:    0.6.0
 */