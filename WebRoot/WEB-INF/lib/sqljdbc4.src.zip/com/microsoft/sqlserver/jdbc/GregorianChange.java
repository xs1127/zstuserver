/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ 
/*     */ class GregorianChange
/*     */ {
/* 344 */   static final Date PURE_CHANGE_DATE = new Date(-9223372036854775808L);
/*     */ 
/* 349 */   static final Date STANDARD_CHANGE_DATE = new GregorianCalendar(Locale.US).getGregorianChange();
/*     */ 
/* 359 */   static final int DAYS_SINCE_BASE_DATE_HINT = DDC.daysSinceBaseDate(1583, 1, 1);
/*     */   static final int EXTRA_DAYS_TO_BE_ADDED;
/*     */ 
/*     */   static
/*     */   {
/* 380 */     GregorianCalendar localGregorianCalendar = new GregorianCalendar(Locale.US);
/* 381 */     localGregorianCalendar.clear();
/* 382 */     localGregorianCalendar.set(1, 1, 577738, 0, 0, 0);
/* 383 */     if (localGregorianCalendar.get(5) == 15)
/*     */     {
/* 395 */       EXTRA_DAYS_TO_BE_ADDED = 2;
/*     */     }
/*     */     else
/* 398 */       EXTRA_DAYS_TO_BE_ADDED = 0;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.GregorianChange
 * JD-Core Version:    0.6.0
 */