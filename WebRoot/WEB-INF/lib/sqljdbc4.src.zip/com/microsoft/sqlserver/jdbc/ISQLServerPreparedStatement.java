package com.microsoft.sqlserver.jdbc;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import microsoft.sql.DateTimeOffset;

public abstract interface ISQLServerPreparedStatement extends PreparedStatement, ISQLServerStatement
{
  public abstract void setDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset)
    throws SQLException;
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ISQLServerPreparedStatement
 * JD-Core Version:    0.6.0
 */