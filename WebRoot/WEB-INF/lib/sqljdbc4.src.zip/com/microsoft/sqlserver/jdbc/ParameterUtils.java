/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ final class ParameterUtils
/*     */ {
/*     */   static byte[] HexToBin(String paramString)
/*     */     throws SQLServerException
/*     */   {
/*  16 */     int i = paramString.length();
/*  17 */     char[] arrayOfChar = paramString.toCharArray();
/*  18 */     if (i % 2 != 0) {
/*  19 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_stringNotInHex"), null, false);
/*     */     }
/*  21 */     byte[] arrayOfByte = new byte[i / 2];
/*  22 */     for (int j = 0; j < i / 2; j++)
/*     */     {
/*  24 */       arrayOfByte[j] = (byte)((CharToHex(arrayOfChar[(2 * j)]) << 4) + CharToHex(arrayOfChar[(2 * j + 1)]));
/*     */     }
/*  26 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   static byte CharToHex(char paramChar)
/*     */     throws SQLServerException
/*     */   {
/*  34 */     int i = 0;
/*  35 */     if ((paramChar >= 'A') && (paramChar <= 'F'))
/*     */     {
/*  37 */       i = (byte)(paramChar - 'A' + 10);
/*     */     }
/*  39 */     else if ((paramChar >= 'a') && (paramChar <= 'f'))
/*     */     {
/*  41 */       i = (byte)(paramChar - 'a' + 10);
/*     */     }
/*  44 */     else if ((paramChar >= '0') && (paramChar <= '9'))
/*     */     {
/*  46 */       i = (byte)(paramChar - '0');
/*     */     }
/*     */     else
/*     */     {
/*  50 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_stringNotInHex"), null, false);
/*     */     }
/*     */ 
/*  53 */     return i;
/*     */   }
/*     */ 
/*     */   static int scanSQLForChar(char paramChar, String paramString, int paramInt)
/*     */   {
/*  83 */     int j = paramString.length();
/*     */ 
/*  85 */     label251: while (paramInt < j)
/*     */     {
/*     */       char c;
/*  87 */       switch (c = paramString.charAt(paramInt++))
/*     */       {
/*     */       case '/':
/*  90 */         if (paramInt == j) {
/*     */           continue;
/*     */         }
/*  93 */         if (paramString.charAt(paramInt) == '*') {
/*     */           do {
/*  95 */             paramInt++; if (paramInt >= j) break;
/*     */           }
/*  97 */           while ((paramString.charAt(paramInt) != '*') || (paramInt + 1 >= j) || (paramString.charAt(paramInt + 1) != '/'));
/*     */ 
/* 101 */           paramInt += 2;
/* 102 */           continue;
/*     */         }
/*     */ 
/* 107 */         if (paramString.charAt(paramInt) == '-')
/*     */         {
/*     */           continue;
/*     */         }
/*     */       case '-':
/* 112 */         if (paramString.charAt(paramInt) == '-') {
/*     */           do {
/* 114 */             paramInt++; if (paramInt >= j) break;
/*     */           }
/* 116 */           while ((paramString.charAt(paramInt) != '\n') && (paramString.charAt(paramInt) != '\r'));
/*     */ 
/* 118 */           paramInt++;
/* 119 */         }break;
/*     */       default:
/* 126 */         if (paramChar != c) continue;
/* 127 */         return paramInt - 1;
/*     */       case '[':
/* 131 */         c = ']';
/*     */       case '"':
/*     */       case '\'':
/* 134 */         int i = c;
/*     */         while (true) { if (paramInt >= j) break label251;
/* 137 */           if (paramString.charAt(paramInt++) != i)
/*     */             continue;
/* 139 */           if ((j == paramInt) || (paramString.charAt(paramInt) != i)) {
/*     */             break;
/*     */           }
/* 142 */           paramInt++;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 149 */     return j;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ParameterUtils
 * JD-Core Version:    0.6.0
 */