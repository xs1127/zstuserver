/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ final class AsciiFilteredUnicodeInputStream extends InputStream
/*      */ {
/*      */   private final Reader containedReader;
/*      */   private final Charset asciiCharSet;
/* 1106 */   private final byte[] bSingleByte = new byte[1];
/*      */ 
/*      */   static AsciiFilteredUnicodeInputStream MakeAsciiFilteredUnicodeInputStream(BaseInputStream paramBaseInputStream, Reader paramReader)
/*      */     throws SQLServerException
/*      */   {
/* 1076 */     if (BaseInputStream.logger.isLoggable(Level.FINER))
/* 1077 */       BaseInputStream.logger.finer(paramBaseInputStream.toString() + " wrapping in AsciiFilteredInputStream");
/* 1078 */     return new AsciiFilteredUnicodeInputStream(paramReader);
/*      */   }
/*      */ 
/*      */   private AsciiFilteredUnicodeInputStream(Reader paramReader)
/*      */     throws SQLServerException
/*      */   {
/* 1084 */     this.containedReader = paramReader;
/* 1085 */     this.asciiCharSet = Charset.forName("US-ASCII");
/*      */   }
/*      */ 
/*      */   public void close() throws IOException
/*      */   {
/* 1090 */     this.containedReader.close();
/*      */   }
/*      */ 
/*      */   public long skip(long paramLong) throws IOException
/*      */   {
/* 1095 */     return this.containedReader.skip(paramLong);
/*      */   }
/*      */ 
/*      */   public int available()
/*      */     throws IOException
/*      */   {
/* 1103 */     return 0;
/*      */   }
/*      */ 
/*      */   public int read()
/*      */     throws IOException
/*      */   {
/* 1109 */     int i = read(this.bSingleByte);
/* 1110 */     return -1 == i ? -1 : this.bSingleByte[0] & 0xFF;
/*      */   }
/*      */ 
/*      */   public int read(byte[] paramArrayOfByte) throws IOException
/*      */   {
/* 1115 */     return read(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */   }
/*      */ 
/*      */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */   {
/* 1120 */     char[] arrayOfChar = new char[paramInt2];
/* 1121 */     int i = this.containedReader.read(arrayOfChar);
/*      */ 
/* 1123 */     if (i > 0)
/*      */     {
/* 1125 */       if (i < paramInt2)
/* 1126 */         paramInt2 = i;
/* 1127 */       ByteBuffer localByteBuffer = this.asciiCharSet.encode(CharBuffer.wrap(arrayOfChar));
/* 1128 */       localByteBuffer.get(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/* 1130 */     return i;
/*      */   }
/*      */ 
/*      */   public boolean markSupported()
/*      */   {
/* 1135 */     return this.containedReader.markSupported();
/*      */   }
/*      */ 
/*      */   public void mark(int paramInt)
/*      */   {
/*      */     try
/*      */     {
/* 1142 */       this.containedReader.mark(paramInt);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1148 */       return;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void reset() throws IOException
/*      */   {
/* 1154 */     this.containedReader.reset();
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.AsciiFilteredUnicodeInputStream
 * JD-Core Version:    0.6.0
 */