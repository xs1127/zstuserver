/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */  enum StreamType
/*     */ {
/* 367 */   NONE(JDBCType.UNKNOWN, "None"), 
/* 368 */   ASCII(JDBCType.LONGVARCHAR, "AsciiStream"), 
/* 369 */   BINARY(JDBCType.LONGVARBINARY, "BinaryStream"), 
/* 370 */   CHARACTER(JDBCType.LONGVARCHAR, "CharacterStream"), 
/* 371 */   NCHARACTER(JDBCType.LONGNVARCHAR, "NCharacterStream"), 
/* 372 */   SQLXML(JDBCType.SQLXML, "SQLXML");
/*     */ 
/*     */   private final JDBCType jdbcType;
/*     */   private final String name;
/*     */ 
/* 376 */   JDBCType getJDBCType() { return this.jdbcType;
/*     */   }
/*     */ 
/*     */   private StreamType(JDBCType paramJDBCType, String paramString)
/*     */   {
/* 383 */     this.jdbcType = paramJDBCType;
/* 384 */     this.name = paramString;
/*     */   }
/*     */   public String toString() {
/* 387 */     return this.name;
/*     */   }
/*     */ 
/*     */   boolean convertsFrom(TypeInfo paramTypeInfo)
/*     */   {
/* 392 */     if (ASCII == this)
/*     */     {
/* 395 */       if (SSType.XML == paramTypeInfo.getSSType()) {
/* 396 */         return false;
/*     */       }
/*     */ 
/* 399 */       if ((null != paramTypeInfo.getSQLCollation()) && (!paramTypeInfo.getSQLCollation().supportsAsciiConversion())) {
/* 400 */         return false;
/*     */       }
/*     */     }
/* 403 */     return paramTypeInfo.getSSType().convertsTo(this.jdbcType);
/*     */   }
/*     */ 
/*     */   boolean convertsTo(TypeInfo paramTypeInfo)
/*     */   {
/* 409 */     if (ASCII == this)
/*     */     {
/* 412 */       if (SSType.XML == paramTypeInfo.getSSType()) {
/* 413 */         return false;
/*     */       }
/*     */ 
/* 416 */       if ((null != paramTypeInfo.getSQLCollation()) && (!paramTypeInfo.getSQLCollation().supportsAsciiConversion())) {
/* 417 */         return false;
/*     */       }
/*     */     }
/* 420 */     return this.jdbcType.convertsTo(paramTypeInfo.getSSType());
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamType
 * JD-Core Version:    0.6.0
 */