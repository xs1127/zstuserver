/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.text.MessageFormat;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ final class DataTypes
/*      */ {
/*      */   static final int SHORT_VARTYPE_MAX_CHARS = 4000;
/*      */   static final int SHORT_VARTYPE_MAX_BYTES = 8000;
/*      */   static final int NTEXT_MAX_CHARS = 1073741823;
/*      */   static final int IMAGE_TEXT_MAX_BYTES = 2147483647;
/*      */   static final int MAX_VARTYPE_MAX_CHARS = 1073741823;
/*      */   static final int MAX_VARTYPE_MAX_BYTES = 2147483647;
/*      */   private static Logger stmtDT;
/*      */   static final int MAXTYPE_LENGTH = 65535;
/*      */   static final int UNKNOWN_STREAM_LENGTH = -1;
/*      */ 
/*      */   static final void throwConversionError(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/* 1115 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
/* 1116 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 1117 */     SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject), null, true);
/*      */   }
/*      */ 
/*      */   static final long getCheckedLength(SQLServerConnection paramSQLServerConnection, JDBCType paramJDBCType, long paramLong, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/*      */     long l;
/* 1176 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*      */     {
/*      */     case 1:
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/* 1183 */       l = 1073741823L;
/* 1184 */       break;
/*      */     default:
/* 1188 */       l = 2147483647L;
/*      */     }
/*      */ 
/* 1192 */     if ((paramLong < (paramBoolean ? -1 : 0)) || (paramLong > l))
/*      */     {
/* 1194 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 1195 */       Object[] arrayOfObject = { Long.valueOf(paramLong) };
/* 1196 */       SQLServerException.makeFromDriverError(paramSQLServerConnection, null, localMessageFormat.format(arrayOfObject), null, false);
/*      */     }
/*      */ 
/* 1204 */     return paramLong;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.DataTypes
 * JD-Core Version:    0.6.0
 */