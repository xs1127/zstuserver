/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ final class TDSPacket
/*      */ {
/* 4658 */   final byte[] header = new byte[8];
/*      */   final byte[] payload;
/*      */   int payloadLength;
/*      */   volatile TDSPacket next;
/*      */ 
/*      */   public final String toString()
/*      */   {
/* 4664 */     return "TDSPacket(SPID:" + Util.readUnsignedShortBigEndian(this.header, 4) + " Seq:" + this.header[6] + ")";
/*      */   }
/*      */ 
/*      */   TDSPacket(int paramInt)
/*      */   {
/* 4670 */     this.payload = new byte[paramInt];
/* 4671 */     this.payloadLength = 0;
/* 4672 */     this.next = null;
/*      */   }
/*      */   final boolean isEOM() {
/* 4675 */     return 1 == (this.header[1] & 0x1);
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TDSPacket
 * JD-Core Version:    0.6.0
 */