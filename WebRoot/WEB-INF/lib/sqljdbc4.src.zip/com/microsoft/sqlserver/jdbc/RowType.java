/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */  enum RowType
/*    */ {
/* 19 */   ROW, 
/* 20 */   NBCROW, 
/* 21 */   UNKNOWN;
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.RowType
 * JD-Core Version:    0.6.0
 */