/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ final class SQLIdentifier
/*     */ {
/* 646 */   private String serverName = "";
/*     */ 
/* 650 */   private String databaseName = "";
/*     */ 
/* 654 */   private String schemaName = "";
/*     */ 
/* 658 */   private String objectName = "";
/*     */ 
/*     */   final String getServerName()
/*     */   {
/* 647 */     return this.serverName; } 
/* 648 */   final void setServerName(String paramString) { this.serverName = paramString; }
/*     */ 
/*     */   final String getDatabaseName() {
/* 651 */     return this.databaseName; } 
/* 652 */   final void setDatabaseName(String paramString) { this.databaseName = paramString; }
/*     */ 
/*     */   final String getSchemaName() {
/* 655 */     return this.schemaName; } 
/* 656 */   final void setSchemaName(String paramString) { this.schemaName = paramString; }
/*     */ 
/*     */   final String getObjectName() {
/* 659 */     return this.objectName; } 
/* 660 */   final void setObjectName(String paramString) { this.objectName = paramString; }
/*     */ 
/*     */   final String asEscapedString()
/*     */   {
/* 664 */     StringBuilder localStringBuilder = new StringBuilder(256);
/*     */ 
/* 666 */     if (this.serverName.length() > 0) {
/* 667 */       localStringBuilder.append(new StringBuilder().append("[").append(this.serverName).append("].").toString());
/*     */     }
/* 669 */     if (this.databaseName.length() > 0)
/* 670 */       localStringBuilder.append(new StringBuilder().append("[").append(this.databaseName).append("].").toString());
/*     */     else {
/* 672 */       assert (0 == this.serverName.length());
/*     */     }
/* 674 */     if (this.schemaName.length() > 0)
/* 675 */       localStringBuilder.append(new StringBuilder().append("[").append(this.schemaName).append("].").toString());
/* 676 */     else if (this.databaseName.length() > 0) {
/* 677 */       localStringBuilder.append('.');
/*     */     }
/* 679 */     localStringBuilder.append(new StringBuilder().append("[").append(this.objectName).append("]").toString());
/*     */ 
/* 681 */     return localStringBuilder.toString();
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLIdentifier
 * JD-Core Version:    0.6.0
 */