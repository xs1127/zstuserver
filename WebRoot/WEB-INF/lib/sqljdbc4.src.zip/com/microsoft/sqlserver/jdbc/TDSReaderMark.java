/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ final class TDSReaderMark
/*      */ {
/*      */   final TDSPacket packet;
/*      */   final int payloadOffset;
/*      */ 
/*      */   TDSReaderMark(TDSPacket paramTDSPacket, int paramInt)
/*      */   {
/* 4693 */     this.packet = paramTDSPacket;
/* 4694 */     this.payloadOffset = paramInt;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TDSReaderMark
 * JD-Core Version:    0.6.0
 */