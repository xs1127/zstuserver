/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Vector;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.ConnectionEvent;
/*     */ import javax.sql.ConnectionEventListener;
/*     */ import javax.sql.PooledConnection;
/*     */ import javax.sql.StatementEventListener;
/*     */ 
/*     */ public class SQLServerPooledConnection
/*     */   implements PooledConnection
/*     */ {
/*     */   private final Vector<ConnectionEventListener> listeners;
/*     */   private SQLServerDataSource factoryDataSource;
/*     */   private SQLServerConnection physicalConnection;
/*     */   private SQLServerConnectionPoolProxy lastProxyConnection;
/*     */   private String factoryUser;
/*     */   private String factoryPassword;
/*     */   private Logger pcLogger;
/*  24 */   private static int basePooledConnectionID = 0;
/*     */   private final String traceID;
/*     */ 
/*     */   SQLServerPooledConnection(SQLServerDataSource paramSQLServerDataSource, String paramString1, String paramString2)
/*     */     throws SQLException
/*     */   {
/*  30 */     this.listeners = new Vector();
/*     */ 
/*  32 */     this.pcLogger = SQLServerDataSource.dsLogger;
/*     */ 
/*  35 */     this.factoryDataSource = paramSQLServerDataSource;
/*  36 */     this.factoryUser = paramString1;
/*  37 */     this.factoryPassword = paramString2;
/*     */ 
/*  39 */     if (this.pcLogger.isLoggable(Level.FINER)) {
/*  40 */       this.pcLogger.finer(toString() + " Start create new connection for pool.");
/*     */     }
/*  42 */     this.physicalConnection = createNewConnection();
/*  43 */     String str = getClass().getName();
/*  44 */     this.traceID = (str.substring(1 + str.lastIndexOf('.')) + ":" + nextPooledConnectionID());
/*  45 */     if (this.pcLogger.isLoggable(Level.FINE))
/*  46 */       this.pcLogger.fine(toString() + " created by (" + paramSQLServerDataSource.toString() + ")" + " Physical connection " + safeCID() + ", End create new connection for pool");
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  54 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   private SQLServerConnection createNewConnection()
/*     */     throws SQLException
/*     */   {
/*  60 */     return this.factoryDataSource.getConnectionInternal(this.factoryUser, this.factoryPassword, this);
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLServerException
/*     */   {
/*  67 */     if (this.pcLogger.isLoggable(Level.FINER))
/*  68 */       this.pcLogger.finer(toString() + " user:(default).");
/*  69 */     synchronized (this)
/*     */     {
/*  72 */       if (this.physicalConnection == null)
/*     */       {
/*  74 */         SQLServerException.makeFromDriverError(null, this, SQLServerException.getErrString("R_physicalConnectionIsClosed"), "", true);
/*     */       }
/*     */ 
/*  81 */       this.physicalConnection.doSecurityCheck();
/*  82 */       if (this.pcLogger.isLoggable(Level.FINE)) {
/*  83 */         this.pcLogger.fine(toString() + " Physical connection, " + safeCID());
/*     */       }
/*     */ 
/*  86 */       if (null != this.lastProxyConnection)
/*     */       {
/*  89 */         this.physicalConnection.resetPooledConnection();
/*  90 */         if ((this.pcLogger.isLoggable(Level.FINE)) && (!this.lastProxyConnection.isClosed())) {
/*  91 */           this.pcLogger.fine(toString() + "proxy " + this.lastProxyConnection.toString() + " is not closed before getting the connection.");
/*     */         }
/*  93 */         this.lastProxyConnection.internalClose();
/*     */       }
/*  95 */       this.lastProxyConnection = new SQLServerConnectionPoolProxy(this.physicalConnection);
/*  96 */       if ((this.pcLogger.isLoggable(Level.FINE)) && (!this.lastProxyConnection.isClosed())) {
/*  97 */         this.pcLogger.fine(toString() + " proxy " + this.lastProxyConnection.toString() + " is returned.");
/*     */       }
/*  99 */       return this.lastProxyConnection;
/*     */     }
/*     */   }
/*     */ 
/*     */   void notifyEvent(SQLServerException paramSQLServerException)
/*     */   {
/* 110 */     if (this.pcLogger.isLoggable(Level.FINER)) {
/* 111 */       this.pcLogger.finer(toString() + " Exception:" + paramSQLServerException + safeCID());
/*     */     }
/*     */ 
/* 114 */     if (null != paramSQLServerException)
/*     */     {
/* 116 */       synchronized (this)
/*     */       {
/* 118 */         if (null != this.lastProxyConnection)
/*     */         {
/* 120 */           this.lastProxyConnection.internalClose();
/* 121 */           this.lastProxyConnection = null;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 127 */     synchronized (this.listeners)
/*     */     {
/* 129 */       for (int i = 0; i < this.listeners.size(); i++)
/*     */       {
/* 131 */         ConnectionEventListener localConnectionEventListener = (ConnectionEventListener)this.listeners.elementAt(i);
/*     */ 
/* 133 */         if (localConnectionEventListener == null)
/*     */           continue;
/* 135 */         ConnectionEvent localConnectionEvent = new ConnectionEvent(this, paramSQLServerException);
/* 136 */         if (null == paramSQLServerException)
/*     */         {
/* 138 */           if (this.pcLogger.isLoggable(Level.FINER))
/* 139 */             this.pcLogger.finer(toString() + " notifyEvent:connectionClosed " + safeCID());
/* 140 */           localConnectionEventListener.connectionClosed(localConnectionEvent);
/*     */         }
/*     */         else
/*     */         {
/* 144 */           if (this.pcLogger.isLoggable(Level.FINER))
/* 145 */             this.pcLogger.finer(toString() + " notifyEvent:connectionErrorOccurred " + safeCID());
/* 146 */           localConnectionEventListener.connectionErrorOccurred(localConnectionEvent);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addConnectionEventListener(ConnectionEventListener paramConnectionEventListener)
/*     */   {
/* 157 */     if (this.pcLogger.isLoggable(Level.FINER))
/* 158 */       this.pcLogger.finer(toString() + safeCID());
/* 159 */     synchronized (this.listeners)
/*     */     {
/* 161 */       this.listeners.add(paramConnectionEventListener);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 169 */     if (this.pcLogger.isLoggable(Level.FINER))
/* 170 */       this.pcLogger.finer(toString() + " Closing physical connection, " + safeCID());
/* 171 */     synchronized (this)
/*     */     {
/* 174 */       if (null != this.lastProxyConnection)
/*     */       {
/* 176 */         this.lastProxyConnection.internalClose();
/* 177 */       }if (null != this.physicalConnection)
/*     */       {
/* 179 */         this.physicalConnection.DetachFromPool();
/* 180 */         this.physicalConnection.close();
/*     */       }
/* 182 */       this.physicalConnection = null;
/*     */     }
/* 184 */     synchronized (this.listeners)
/*     */     {
/* 186 */       this.listeners.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeConnectionEventListener(ConnectionEventListener paramConnectionEventListener)
/*     */   {
/* 195 */     if (this.pcLogger.isLoggable(Level.FINER))
/* 196 */       this.pcLogger.finer(toString() + safeCID());
/* 197 */     synchronized (this.listeners)
/*     */     {
/* 199 */       this.listeners.remove(paramConnectionEventListener);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addStatementEventListener(StatementEventListener paramStatementEventListener)
/*     */   {
/* 205 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 208 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */   public void removeStatementEventListener(StatementEventListener paramStatementEventListener)
/*     */   {
/* 213 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 216 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */   SQLServerConnection getPhysicalConnection()
/*     */   {
/* 222 */     return this.physicalConnection;
/*     */   }
/*     */ 
/*     */   private static synchronized int nextPooledConnectionID()
/*     */   {
/* 228 */     basePooledConnectionID += 1;
/* 229 */     return basePooledConnectionID;
/*     */   }
/*     */ 
/*     */   private String safeCID()
/*     */   {
/* 236 */     if (null == this.physicalConnection) return " ConnectionID:(null)";
/* 237 */     return this.physicalConnection.toString();
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerPooledConnection
 * JD-Core Version:    0.6.0
 */