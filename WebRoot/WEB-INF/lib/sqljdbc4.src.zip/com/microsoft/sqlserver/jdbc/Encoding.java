/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */  enum Encoding
/*     */ {
/* 531 */   UNICODE("UTF-16LE", true, false), 
/* 532 */   CP437("Cp437", false, false), 
/* 533 */   CP850("Cp850", false, false), 
/* 534 */   CP874("MS874", true, true), 
/* 535 */   CP932("MS932", true, false), 
/* 536 */   CP936("MS936", true, false), 
/* 537 */   CP949("MS949", true, false), 
/* 538 */   CP950("MS950", true, false), 
/* 539 */   CP1250("Cp1250", true, true), 
/* 540 */   CP1251("Cp1251", true, true), 
/* 541 */   CP1252("Cp1252", true, true), 
/* 542 */   CP1253("Cp1253", true, true), 
/* 543 */   CP1254("Cp1254", true, true), 
/* 544 */   CP1255("Cp1255", true, true), 
/* 545 */   CP1256("Cp1256", true, true), 
/* 546 */   CP1257("Cp1257", true, true), 
/* 547 */   CP1258("Cp1258", true, true);
/*     */ 
/*     */   private final String charsetName;
/*     */   private final boolean supportsAsciiConversion;
/*     */   private final boolean hasAsciiCompatibleSBCS;
/* 552 */   private boolean jvmSupportConfirmed = false;
/*     */ 
/*     */   private Encoding(String paramString, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 559 */     this.charsetName = paramString;
/* 560 */     this.supportsAsciiConversion = paramBoolean1;
/* 561 */     this.hasAsciiCompatibleSBCS = paramBoolean2;
/*     */   }
/*     */ 
/*     */   final Encoding checkSupported() throws UnsupportedEncodingException
/*     */   {
/* 566 */     if (!this.jvmSupportConfirmed)
/*     */     {
/*     */       try
/*     */       {
/* 572 */         " ".getBytes(this.charsetName);
/*     */       }
/*     */       catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */       {
/* 576 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_codePageNotSupported"));
/* 577 */         Object[] arrayOfObject = { this.charsetName };
/* 578 */         throw new UnsupportedEncodingException(localMessageFormat.format(arrayOfObject));
/*     */       }
/*     */ 
/* 581 */       this.jvmSupportConfirmed = true;
/*     */     }
/*     */ 
/* 584 */     return this;
/*     */   }
/*     */   final String charsetName() {
/* 587 */     return this.charsetName;
/*     */   }
/*     */ 
/*     */   boolean supportsAsciiConversion()
/*     */   {
/* 597 */     return this.supportsAsciiConversion;
/*     */   }
/*     */ 
/*     */   boolean hasAsciiCompatibleSBCS()
/*     */   {
/* 607 */     return this.hasAsciiCompatibleSBCS;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.Encoding
 * JD-Core Version:    0.6.0
 */