/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */  enum SQLServerDriverStringProperty
/*     */ {
/* 736 */   APPLICATION_INTENT("applicationIntent", ApplicationIntent.READ_WRITE.toString()), 
/* 737 */   APPLICATION_NAME("applicationName", "Microsoft JDBC Driver for SQL Server"), 
/* 738 */   DATABASE_NAME("databaseName", ""), 
/* 739 */   FAILOVER_PARTNER("failoverPartner", ""), 
/* 740 */   HOSTNAME_IN_CERTIFICATE("hostNameInCertificate", ""), 
/* 741 */   INSTANCE_NAME("instanceName", ""), 
/* 742 */   PASSWORD("password", ""), 
/* 743 */   RESPONSE_BUFFERING("responseBuffering", "adaptive"), 
/* 744 */   SELECT_METHOD("selectMethod", "direct"), 
/* 745 */   SERVER_NAME("serverName", ""), 
/* 746 */   TRUST_STORE("trustStore", ""), 
/* 747 */   TRUST_STORE_PASSWORD("trustStorePassword", ""), 
/* 748 */   USER("user", ""), 
/* 749 */   WORKSTATION_ID("workstationID", ""), 
/* 750 */   AUTHENTICATION_SCHEME("authenticationScheme", AuthenticationScheme.nativeAuthentication.toString());
/*     */ 
/*     */   private String name;
/*     */   private String defaultValue;
/*     */ 
/* 757 */   private SQLServerDriverStringProperty(String paramString1, String paramString2) { this.name = paramString1;
/* 758 */     this.defaultValue = paramString2;
/*     */   }
/*     */ 
/*     */   String getDefaultValue()
/*     */   {
/* 763 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 768 */     return this.name;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerDriverStringProperty
 * JD-Core Version:    0.6.0
 */