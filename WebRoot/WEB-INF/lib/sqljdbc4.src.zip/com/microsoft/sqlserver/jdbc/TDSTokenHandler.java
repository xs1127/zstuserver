/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ class TDSTokenHandler
/*     */ {
/*     */   final String logContext;
/*     */   private StreamError databaseError;
/*     */ 
/*     */   final StreamError getDatabaseError()
/*     */   {
/* 149 */     return this.databaseError;
/*     */   }
/*     */ 
/*     */   TDSTokenHandler(String paramString) {
/* 153 */     this.logContext = paramString;
/*     */   }
/*     */ 
/*     */   boolean onSSPI(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 158 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 159 */     return false;
/*     */   }
/*     */ 
/*     */   boolean onLoginAck(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 164 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 165 */     return false;
/*     */   }
/*     */ 
/*     */   boolean onEnvChange(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 170 */     paramTDSReader.getConnection().processEnvChange(paramTDSReader);
/* 171 */     return true;
/*     */   }
/*     */ 
/*     */   boolean onRetStatus(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 176 */     new StreamRetStatus().setFromTDS(paramTDSReader);
/* 177 */     return true;
/*     */   }
/*     */ 
/*     */   boolean onRetValue(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 182 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 183 */     return false;
/*     */   }
/*     */ 
/*     */   boolean onDone(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 188 */     StreamDone localStreamDone = new StreamDone();
/* 189 */     localStreamDone.setFromTDS(paramTDSReader);
/* 190 */     return true;
/*     */   }
/*     */ 
/*     */   boolean onError(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 195 */     if (null == this.databaseError)
/*     */     {
/* 197 */       this.databaseError = new StreamError();
/* 198 */       this.databaseError.setFromTDS(paramTDSReader);
/*     */     }
/*     */     else
/*     */     {
/* 202 */       new StreamError().setFromTDS(paramTDSReader);
/*     */     }
/*     */ 
/* 205 */     return true;
/*     */   }
/*     */ 
/*     */   boolean onInfo(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 210 */     TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
/* 211 */     return true;
/*     */   }
/*     */ 
/*     */   boolean onOrder(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 216 */     TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
/* 217 */     return true;
/*     */   }
/*     */ 
/*     */   boolean onColMetaData(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 222 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 223 */     return false;
/*     */   }
/*     */ 
/*     */   boolean onRow(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 228 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 229 */     return false;
/*     */   }
/*     */ 
/*     */   boolean onNBCRow(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 234 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 235 */     return false;
/*     */   }
/*     */ 
/*     */   boolean onColInfo(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 240 */     TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
/* 241 */     return true;
/*     */   }
/*     */ 
/*     */   boolean onTabName(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 246 */     TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
/* 247 */     return true;
/*     */   }
/*     */ 
/*     */   void onEOF(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 252 */     if (null != getDatabaseError())
/*     */     {
/* 254 */       SQLServerException.makeFromDatabaseError(paramTDSReader.getConnection(), null, getDatabaseError().getMessage(), getDatabaseError(), false);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TDSTokenHandler
 * JD-Core Version:    0.6.0
 */