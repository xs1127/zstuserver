package com.microsoft.sqlserver.jdbc;

final class DriverJDBCVersion
{
  static final int value = 4;

  static final void checkSupportsJDBC4()
  {
  }
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.DriverJDBCVersion
 * JD-Core Version:    0.6.0
 */