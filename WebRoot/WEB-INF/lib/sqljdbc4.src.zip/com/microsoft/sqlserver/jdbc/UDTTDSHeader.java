/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class UDTTDSHeader
/*    */ {
/*    */   private final int maxLen;
/*    */   private final String databaseName;
/*    */   private final String schemaName;
/*    */   private final String typeName;
/*    */   private final String assemblyQualifiedName;
/*    */ 
/*    */   UDTTDSHeader(TDSReader paramTDSReader)
/*    */     throws SQLServerException
/*    */   {
/* 34 */     this.maxLen = paramTDSReader.readUnsignedShort();
/* 35 */     this.databaseName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 36 */     this.schemaName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 37 */     this.typeName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 38 */     this.assemblyQualifiedName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
/*    */   }
/*    */   int getMaxLen() {
/* 41 */     return this.maxLen;
/*    */   }
/*    */   String getTypeName() {
/* 44 */     return this.typeName;
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.UDTTDSHeader
 * JD-Core Version:    0.6.0
 */