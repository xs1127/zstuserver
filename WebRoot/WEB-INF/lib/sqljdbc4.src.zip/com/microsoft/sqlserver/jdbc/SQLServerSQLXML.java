/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.sax.SAXTransformerFactory;
/*     */ import javax.xml.transform.sax.TransformerHandler;
/*     */ import javax.xml.transform.stax.StAXResult;
/*     */ import javax.xml.transform.stax.StAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ final class SQLServerSQLXML
/*     */   implements SQLXML
/*     */ {
/*     */   private final SQLServerConnection con;
/*     */   private final PLPXMLInputStream contents;
/*     */   private final InputStreamGetterArgs getterArgs;
/*     */   private final TypeInfo typeInfo;
/*  37 */   private boolean isUsed = false;
/*  38 */   private boolean isFreed = false;
/*     */   private static final Logger logger;
/*     */   private ByteArrayOutputStreamToInputStream outputStreamValue;
/*     */   private Document docValue;
/*     */   private String strValue;
/*     */   private static int baseID;
/*     */   private final String traceID;
/*     */ 
/*     */   public final String toString()
/*     */   {
/*  54 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   private static synchronized int nextInstanceID()
/*     */   {
/*  59 */     baseID += 1;
/*  60 */     return baseID;
/*     */   }
/*     */ 
/*     */   InputStream getValue()
/*     */     throws SQLServerException
/*     */   {
/*  68 */     checkClosed();
/*     */ 
/*  71 */     if (!this.isUsed)
/*  72 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_noDataXML"), null, true);
/*  73 */     assert (null == this.contents);
/*  74 */     ByteArrayInputStream localByteArrayInputStream = null;
/*  75 */     if (null != this.outputStreamValue)
/*     */     {
/*  77 */       localByteArrayInputStream = this.outputStreamValue.getInputStream();
/*  78 */       assert (null == this.docValue);
/*  79 */       if ((!$assertionsDisabled) && (null != this.strValue)) throw new AssertionError();
/*     */ 
/*     */     }
/*  82 */     else if (null != this.docValue)
/*     */     {
/*  84 */       assert (null == this.outputStreamValue);
/*  85 */       assert (null == this.strValue);
/*  86 */       ByteArrayOutputStreamToInputStream localByteArrayOutputStreamToInputStream = new ByteArrayOutputStreamToInputStream();
/*     */ 
/*  89 */       Object localObject = null;
/*     */       try
/*     */       {
/*  92 */         TransformerFactory localTransformerFactory = TransformerFactory.newInstance();
/*  93 */         localTransformerFactory.newTransformer().transform(new DOMSource(this.docValue), new StreamResult(localByteArrayOutputStreamToInputStream));
/*     */       }
/*     */       catch (TransformerException localTransformerException)
/*     */       {
/*  97 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/*  98 */         Object[] arrayOfObject = { localTransformerException.toString() };
/*  99 */         SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */       }
/* 101 */       localByteArrayInputStream = localByteArrayOutputStreamToInputStream.getInputStream();
/*     */     }
/*     */     else
/*     */     {
/* 105 */       assert (null == this.outputStreamValue);
/* 106 */       assert (null == this.docValue);
/* 107 */       assert (null != this.strValue);
/*     */       try
/*     */       {
/* 110 */         localByteArrayInputStream = new ByteArrayInputStream(this.strValue.getBytes(Encoding.UNICODE.charsetName()));
/*     */       }
/*     */       catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */       {
/* 114 */         throw new SQLServerException(null, localUnsupportedEncodingException.getMessage(), null, 0, true);
/*     */       }
/*     */     }
/* 117 */     assert (null != localByteArrayInputStream);
/* 118 */     this.isFreed = true;
/* 119 */     return localByteArrayInputStream;
/*     */   }
/*     */ 
/*     */   SQLServerSQLXML(SQLServerConnection paramSQLServerConnection)
/*     */   {
/* 125 */     this.contents = null;
/* 126 */     this.traceID = (" SQLServerSQLXML:" + nextInstanceID());
/* 127 */     this.con = paramSQLServerConnection;
/*     */ 
/* 129 */     if (logger.isLoggable(Level.FINE))
/* 130 */       logger.fine(toString() + " created by (" + paramSQLServerConnection.toString() + ")");
/* 131 */     this.getterArgs = null;
/* 132 */     this.typeInfo = null;
/*     */   }
/*     */ 
/*     */   SQLServerSQLXML(InputStream paramInputStream, InputStreamGetterArgs paramInputStreamGetterArgs, TypeInfo paramTypeInfo) throws SQLServerException
/*     */   {
/* 137 */     this.traceID = (" SQLServerSQLXML:" + nextInstanceID());
/* 138 */     this.contents = ((PLPXMLInputStream)paramInputStream);
/* 139 */     this.con = null;
/* 140 */     this.getterArgs = paramInputStreamGetterArgs;
/* 141 */     this.typeInfo = paramTypeInfo;
/* 142 */     if (logger.isLoggable(Level.FINE))
/* 143 */       logger.fine(toString() + " created by (null connection)");
/*     */   }
/*     */ 
/*     */   InputStream getStream() {
/* 147 */     return this.contents;
/*     */   }
/*     */ 
/*     */   public void free() throws SQLException {
/* 151 */     if (!this.isFreed)
/*     */     {
/* 153 */       this.isFreed = true;
/* 154 */       if (null != this.contents)
/*     */       {
/*     */         try
/*     */         {
/* 158 */           this.contents.close();
/*     */         }
/*     */         catch (IOException localIOException)
/*     */         {
/* 162 */           SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkClosed() throws SQLServerException {
/* 169 */     if ((this.isFreed) || ((null != this.con) && (this.con.isClosed())))
/*     */     {
/* 171 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 172 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(new Object[] { "SQLXML" }), null, true);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkReadXML() throws SQLException {
/* 177 */     if (null == this.contents)
/* 178 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_writeOnlyXML"), null, true);
/* 179 */     if (this.isUsed)
/* 180 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenReadXML"), null, true);
/*     */     try
/*     */     {
/* 183 */       this.contents.checkClosed();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 187 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 188 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(new Object[] { "SQLXML" }), null, true);
/*     */     }
/*     */   }
/*     */ 
/*     */   void checkWriteXML() throws SQLException {
/* 193 */     if (null != this.contents)
/* 194 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_readOnlyXML"), null, true);
/* 195 */     if (this.isUsed)
/* 196 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenSetXML"), null, true);
/*     */   }
/*     */ 
/*     */   public InputStream getBinaryStream()
/*     */     throws SQLException
/*     */   {
/* 207 */     checkClosed();
/* 208 */     checkReadXML();
/* 209 */     this.isUsed = true;
/* 210 */     return this.contents;
/*     */   }
/*     */ 
/*     */   public OutputStream setBinaryStream()
/*     */     throws SQLException
/*     */   {
/* 222 */     checkClosed();
/* 223 */     checkWriteXML();
/* 224 */     this.isUsed = true;
/* 225 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 226 */     return this.outputStreamValue;
/*     */   }
/*     */ 
/*     */   public Writer setCharacterStream() throws SQLException {
/* 230 */     checkClosed();
/* 231 */     checkWriteXML();
/* 232 */     this.isUsed = true;
/* 233 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 234 */     OutputStreamWriter localOutputStreamWriter = null;
/*     */     try
/*     */     {
/* 237 */       localOutputStreamWriter = new OutputStreamWriter(this.outputStreamValue, Encoding.UNICODE.charsetName());
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */     {
/* 241 */       throw new SQLServerException(null, localUnsupportedEncodingException.getMessage(), null, 0, true);
/*     */     }
/* 243 */     return localOutputStreamWriter;
/*     */   }
/*     */ 
/*     */   public Reader getCharacterStream() throws SQLException {
/* 247 */     checkClosed();
/* 248 */     checkReadXML();
/* 249 */     this.isUsed = true;
/* 250 */     StreamType localStreamType = StreamType.CHARACTER;
/* 251 */     InputStreamGetterArgs localInputStreamGetterArgs = new InputStreamGetterArgs(localStreamType, this.getterArgs.isAdaptive, this.getterArgs.isStreaming, this.getterArgs.logContext);
/*     */ 
/* 257 */     assert (null != this.contents);
/*     */     try
/*     */     {
/* 261 */       this.contents.read();
/* 262 */       this.contents.read();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 266 */       SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*     */     }
/*     */ 
/* 269 */     Reader localReader = (Reader)DDC.convertStreamToObject(this.contents, this.typeInfo, localStreamType.getJDBCType(), localInputStreamGetterArgs);
/* 270 */     return localReader;
/*     */   }
/*     */ 
/*     */   public String getString() throws SQLException
/*     */   {
/* 275 */     checkClosed();
/* 276 */     checkReadXML();
/* 277 */     this.isUsed = true;
/* 278 */     assert (null != this.contents);
/*     */     try
/*     */     {
/* 282 */       this.contents.read();
/* 283 */       this.contents.read();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 287 */       SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*     */     }
/*     */ 
/* 290 */     byte[] arrayOfByte = this.contents.getBytes();
/* 291 */     String str = null;
/*     */     try
/*     */     {
/* 294 */       str = new String(arrayOfByte, 0, arrayOfByte.length, Encoding.UNICODE.charsetName());
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */     {
/* 298 */       throw new SQLServerException(null, localUnsupportedEncodingException.getMessage(), null, 0, true);
/*     */     }
/* 300 */     return str;
/*     */   }
/*     */ 
/*     */   public void setString(String paramString) throws SQLException {
/* 304 */     checkClosed();
/* 305 */     checkWriteXML();
/* 306 */     this.isUsed = true;
/* 307 */     if (null == paramString)
/* 308 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/* 309 */     this.strValue = paramString;
/*     */   }
/*     */ 
/*     */   public <T extends Source> T getSource(Class<T> paramClass)
/*     */     throws SQLException
/*     */   {
/* 316 */     checkClosed();
/* 317 */     checkReadXML();
/* 318 */     if (null == paramClass)
/*     */     {
/* 322 */       Source localSource = getSourceInternal(StreamSource.class);
/* 323 */       return localSource;
/*     */     }
/*     */ 
/* 326 */     return getSourceInternal(paramClass);
/*     */   }
/*     */ 
/*     */   <T extends Source> T getSourceInternal(Class<T> paramClass) throws SQLException {
/* 330 */     this.isUsed = true;
/* 331 */     Source localSource = null;
/* 332 */     if (DOMSource.class == paramClass)
/*     */     {
/* 334 */       localSource = (Source)paramClass.cast(getDOMSource());
/*     */     }
/* 336 */     else if (SAXSource.class == paramClass)
/*     */     {
/* 338 */       localSource = (Source)paramClass.cast(getSAXSource());
/*     */     }
/* 341 */     else if (StAXSource.class == paramClass)
/*     */     {
/* 343 */       localSource = (Source)paramClass.cast(getStAXSource());
/*     */     }
/* 346 */     else if (StreamSource.class == paramClass)
/*     */     {
/* 348 */       localSource = (Source)paramClass.cast(new StreamSource(this.contents));
/*     */     }
/*     */     else
/*     */     {
/* 352 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true);
/* 353 */     }return localSource;
/*     */   }
/*     */ 
/*     */   public <T extends Result> T setResult(Class<T> paramClass) throws SQLException {
/* 357 */     checkClosed();
/* 358 */     checkWriteXML();
/* 359 */     if (null == paramClass)
/*     */     {
/* 363 */       Result localResult = setResultInternal(StreamResult.class);
/* 364 */       return localResult;
/*     */     }
/*     */ 
/* 367 */     return setResultInternal(paramClass);
/*     */   }
/*     */ 
/*     */   <T extends Result> T setResultInternal(Class<T> paramClass)
/*     */     throws SQLException
/*     */   {
/* 373 */     this.isUsed = true;
/* 374 */     Result localResult = null;
/* 375 */     if (DOMResult.class == paramClass)
/*     */     {
/* 377 */       localResult = (Result)paramClass.cast(getDOMResult());
/*     */     }
/* 380 */     else if (SAXResult.class == paramClass)
/*     */     {
/* 382 */       localResult = (Result)paramClass.cast(getSAXResult());
/*     */     }
/* 385 */     else if (StAXResult.class == paramClass)
/*     */     {
/* 387 */       localResult = (Result)paramClass.cast(getStAXResult());
/*     */     }
/* 389 */     else if (StreamResult.class == paramClass)
/*     */     {
/* 391 */       this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 392 */       localResult = (Result)paramClass.cast(new StreamResult(this.outputStreamValue));
/*     */     }
/*     */     else {
/* 395 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true);
/* 396 */     }return localResult;
/*     */   }
/*     */ 
/*     */   private final DOMSource getDOMSource() throws SQLException
/*     */   {
/* 401 */     Document localDocument = null;
/* 402 */     DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
/*     */     try
/*     */     {
/* 412 */       localDocumentBuilderFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 413 */       DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
/*     */ 
/* 416 */       localDocumentBuilder.setEntityResolver(new SQLServerEntityResolver());
/*     */       try
/*     */       {
/* 419 */         localDocument = localDocumentBuilder.parse(this.contents);
/*     */       }
/*     */       catch (IOException localIOException)
/*     */       {
/* 423 */         localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 424 */         arrayOfObject = new Object[] { localIOException.toString() };
/* 425 */         SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject), "", true);
/*     */       }
/* 427 */       DOMSource localDOMSource = new DOMSource(localDocument);
/* 428 */       return localDOMSource;
/*     */     }
/*     */     catch (ParserConfigurationException localParserConfigurationException)
/*     */     {
/* 432 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 433 */       arrayOfObject = new Object[] { localParserConfigurationException.toString() };
/* 434 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     catch (SAXException localSAXException)
/*     */     {
/* 438 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
/* 439 */       Object[] arrayOfObject = { localSAXException.toString() };
/* 440 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/* 442 */     return null;
/*     */   }
/*     */ 
/*     */   private final SAXSource getSAXSource() throws SQLException
/*     */   {
/*     */     try {
/* 448 */       InputSource localInputSource = new InputSource(this.contents);
/* 449 */       localObject1 = XMLReaderFactory.createXMLReader();
/* 450 */       localObject2 = new SAXSource((XMLReader)localObject1, localInputSource);
/* 451 */       return localObject2;
/*     */     }
/*     */     catch (SAXException localSAXException)
/*     */     {
/* 456 */       Object localObject1 = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
/* 457 */       Object localObject2 = { localSAXException.toString() };
/* 458 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject1).format(localObject2), null, true);
/*     */     }
/* 460 */     return (SAXSource)(SAXSource)null;
/*     */   }
/*     */ 
/*     */   private final StAXSource getStAXSource() throws SQLException {
/* 464 */     XMLInputFactory localXMLInputFactory = XMLInputFactory.newInstance();
/*     */     try
/*     */     {
/* 467 */       XMLStreamReader localXMLStreamReader = localXMLInputFactory.createXMLStreamReader(this.contents);
/* 468 */       localObject = new StAXSource(localXMLStreamReader);
/* 469 */       return localObject;
/*     */     }
/*     */     catch (XMLStreamException localXMLStreamException)
/*     */     {
/* 473 */       Object localObject = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 474 */       Object[] arrayOfObject = { localXMLStreamException.toString() };
/* 475 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/* 477 */     return (StAXSource)null;
/*     */   }
/*     */ 
/*     */   private final StAXResult getStAXResult() throws SQLException
/*     */   {
/* 482 */     XMLOutputFactory localXMLOutputFactory = XMLOutputFactory.newInstance();
/* 483 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/*     */     try
/*     */     {
/* 486 */       XMLStreamWriter localXMLStreamWriter = localXMLOutputFactory.createXMLStreamWriter(this.outputStreamValue);
/* 487 */       localObject = new StAXResult(localXMLStreamWriter);
/* 488 */       return localObject;
/*     */     }
/*     */     catch (XMLStreamException localXMLStreamException)
/*     */     {
/* 492 */       Object localObject = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 493 */       Object[] arrayOfObject = { localXMLStreamException.toString() };
/* 494 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/* 496 */     return (StAXResult)null;
/*     */   }
/*     */ 
/*     */   private final SAXResult getSAXResult() throws SQLException {
/* 500 */     TransformerHandler localTransformerHandler = null;
/*     */     try
/*     */     {
/* 503 */       SAXTransformerFactory localSAXTransformerFactory = (SAXTransformerFactory)TransformerFactory.newInstance();
/*     */ 
/* 505 */       localTransformerHandler = localSAXTransformerFactory.newTransformerHandler();
/*     */     }
/*     */     catch (TransformerConfigurationException localTransformerConfigurationException)
/*     */     {
/* 509 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 510 */       arrayOfObject = new Object[] { localTransformerConfigurationException.toString() };
/* 511 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     catch (ClassCastException localClassCastException)
/*     */     {
/* 515 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 516 */       Object[] arrayOfObject = { localClassCastException.toString() };
/* 517 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/* 519 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 520 */     localTransformerHandler.setResult(new StreamResult(this.outputStreamValue));
/* 521 */     SAXResult localSAXResult = new SAXResult(localTransformerHandler);
/* 522 */     return localSAXResult;
/*     */   }
/*     */ 
/*     */   private final DOMResult getDOMResult() throws SQLException {
/* 526 */     DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
/*     */ 
/* 528 */     assert (null == this.outputStreamValue);
/*     */     try
/*     */     {
/* 531 */       DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
/* 532 */       this.docValue = localDocumentBuilder.newDocument();
/* 533 */       DOMResult localDOMResult = new DOMResult(this.docValue);
/* 534 */       return localDOMResult;
/*     */     }
/*     */     catch (ParserConfigurationException localParserConfigurationException)
/*     */     {
/* 538 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 539 */       Object[] arrayOfObject = { localParserConfigurationException.toString() };
/* 540 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/* 542 */     return null;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  40 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerSQLXML");
/*     */ 
/*  50 */     baseID = 0;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerSQLXML
 * JD-Core Version:    0.6.0
 */