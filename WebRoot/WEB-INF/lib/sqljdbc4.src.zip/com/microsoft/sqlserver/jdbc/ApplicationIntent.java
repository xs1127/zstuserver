/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ 
/*     */  enum ApplicationIntent
/*     */ {
/*     */   private String value;
/*     */ 
/*     */   private ApplicationIntent(String paramString)
/*     */   {
/* 700 */     this.value = paramString;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 706 */     return this.value;
/*     */   }
/*     */ 
/*     */   static ApplicationIntent valueOfString(String paramString) throws SQLServerException
/*     */   {
/* 711 */     ApplicationIntent localApplicationIntent = READ_WRITE;
/* 712 */     assert (paramString != null);
/*     */ 
/* 714 */     paramString = paramString.toUpperCase(Locale.US).toLowerCase(Locale.US);
/* 715 */     if (paramString.equalsIgnoreCase(READ_ONLY.toString()))
/*     */     {
/* 717 */       localApplicationIntent = READ_ONLY;
/*     */     }
/* 719 */     else if (paramString.equalsIgnoreCase(READ_WRITE.toString()))
/*     */     {
/* 721 */       localApplicationIntent = READ_WRITE;
/*     */     }
/*     */     else
/*     */     {
/* 725 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidapplicationIntent"));
/* 726 */       Object[] arrayOfObject = { new String(paramString) };
/* 727 */       throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */     }
/*     */ 
/* 730 */     return localApplicationIntent;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 691 */     READ_WRITE = new ApplicationIntent("READ_WRITE", 0, "readwrite");
/* 692 */     READ_ONLY = new ApplicationIntent("READ_ONLY", 1, "readonly");
/*     */ 
/* 689 */     $VALUES = new ApplicationIntent[] { READ_WRITE, READ_ONLY };
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ApplicationIntent
 * JD-Core Version:    0.6.0
 */