/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.Referenceable;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.sql.DataSource;
/*     */ 
/*     */ public class SQLServerDataSource
/*     */   implements ISQLServerDataSource, DataSource, Serializable, Referenceable
/*     */ {
/*     */   static final Logger dsLogger;
/*     */   static final Logger loggerExternal;
/*     */   private final String loggingClassName;
/*  25 */   private boolean trustStorePasswordStripped = false;
/*     */   private static final long serialVersionUID = 654861379544314296L;
/*     */   private Properties connectionProps;
/*     */   private String dataSourceURL;
/*     */   private String dataSourceDescription;
/*     */   private static int baseDataSourceID;
/*     */   private final String traceID;
/*     */   private transient PrintWriter logWriter;
/*     */ 
/*     */   public SQLServerDataSource()
/*     */   {
/*  36 */     this.connectionProps = new Properties();
/*  37 */     int i = nextDataSourceID();
/*  38 */     String str = getClass().getName();
/*  39 */     this.traceID = (str.substring(1 + str.lastIndexOf(46)) + ":" + i);
/*  40 */     this.loggingClassName = ("com.microsoft.sqlserver.jdbc." + str.substring(1 + str.lastIndexOf(46)) + ":" + i);
/*     */   }
/*     */ 
/*     */   String getClassNameLogging()
/*     */   {
/*  45 */     return this.loggingClassName;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  49 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLServerException
/*     */   {
/*  56 */     loggerExternal.entering(getClassNameLogging(), "getConnection");
/*  57 */     SQLServerConnection localSQLServerConnection = getConnectionInternal(null, null, null);
/*  58 */     loggerExternal.exiting(getClassNameLogging(), "getConnection", localSQLServerConnection);
/*  59 */     return localSQLServerConnection;
/*     */   }
/*     */ 
/*     */   public Connection getConnection(String paramString1, String paramString2) throws SQLServerException {
/*  63 */     if (loggerExternal.isLoggable(Level.FINER))
/*  64 */       loggerExternal.entering(getClassNameLogging(), "getConnection", new Object[] { paramString1, "Password not traced" });
/*  65 */     SQLServerConnection localSQLServerConnection = getConnectionInternal(paramString1, paramString2, null);
/*  66 */     loggerExternal.exiting(getClassNameLogging(), "getConnection", localSQLServerConnection);
/*  67 */     return localSQLServerConnection;
/*     */   }
/*     */ 
/*     */   public void setLoginTimeout(int paramInt)
/*     */   {
/*  74 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), paramInt);
/*     */   }
/*     */ 
/*     */   public int getLoginTimeout() {
/*  78 */     int i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*  79 */     int j = getIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), i);
/*     */ 
/*  81 */     return j == 0 ? i : j;
/*     */   }
/*     */ 
/*     */   public void setLogWriter(PrintWriter paramPrintWriter)
/*     */   {
/*  89 */     loggerExternal.entering(getClassNameLogging(), "setLogWriter", paramPrintWriter);
/*  90 */     this.logWriter = paramPrintWriter;
/*  91 */     loggerExternal.exiting(getClassNameLogging(), "setLogWriter");
/*     */   }
/*     */ 
/*     */   public PrintWriter getLogWriter()
/*     */   {
/*  97 */     loggerExternal.entering(getClassNameLogging(), "getLogWriter");
/*  98 */     loggerExternal.exiting(getClassNameLogging(), "getLogWriter", this.logWriter);
/*  99 */     return this.logWriter;
/*     */   }
/*     */ 
/*     */   public void setApplicationName(String paramString)
/*     */   {
/* 108 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_NAME.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getApplicationName() {
/* 112 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_NAME.toString(), SQLServerDriverStringProperty.APPLICATION_NAME.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setDatabaseName(String paramString)
/*     */   {
/* 119 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.DATABASE_NAME.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getDatabaseName() {
/* 123 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.DATABASE_NAME.toString(), null);
/*     */   }
/*     */ 
/*     */   public void setInstanceName(String paramString)
/*     */   {
/* 130 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.INSTANCE_NAME.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getInstanceName() {
/* 134 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.INSTANCE_NAME.toString(), null);
/*     */   }
/*     */ 
/*     */   public void setIntegratedSecurity(boolean paramBoolean)
/*     */   {
/* 139 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   public void setAuthenticationScheme(String paramString) {
/* 143 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public void setLastUpdateCount(boolean paramBoolean)
/*     */   {
/* 152 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   public boolean getLastUpdateCount() {
/* 156 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setEncrypt(boolean paramBoolean)
/*     */   {
/* 162 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENCRYPT.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   public boolean getEncrypt() {
/* 166 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENCRYPT.toString(), SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setTrustServerCertificate(boolean paramBoolean)
/*     */   {
/* 171 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   public boolean getTrustServerCertificate() {
/* 175 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setTrustStore(String paramString) {
/* 179 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getTrustStore() {
/* 183 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE.toString(), null);
/*     */   }
/*     */ 
/*     */   public void setTrustStorePassword(String paramString)
/*     */   {
/* 189 */     if (paramString != null)
/* 190 */       this.trustStorePasswordStripped = false;
/* 191 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public void setHostNameInCertificate(String paramString) {
/* 195 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getHostNameInCertificate() {
/* 199 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), null);
/*     */   }
/*     */ 
/*     */   public void setLockTimeout(int paramInt)
/*     */   {
/* 209 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), paramInt);
/*     */   }
/*     */ 
/*     */   public int getLockTimeout() {
/* 213 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setPassword(String paramString)
/*     */   {
/* 221 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.PASSWORD.toString(), paramString);
/*     */   }
/*     */ 
/*     */   String getPassword() {
/* 225 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.PASSWORD.toString(), null);
/*     */   }
/*     */ 
/*     */   public void setPortNumber(int paramInt)
/*     */   {
/* 235 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.PORT_NUMBER.toString(), paramInt);
/*     */   }
/*     */ 
/*     */   public int getPortNumber() {
/* 239 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.PORT_NUMBER.toString(), SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setSelectMethod(String paramString)
/*     */   {
/* 250 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SELECT_METHOD.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getSelectMethod() {
/* 254 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SELECT_METHOD.toString(), SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setResponseBuffering(String paramString)
/*     */   {
/* 259 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getResponseBuffering() {
/* 263 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setApplicationIntent(String paramString)
/*     */   {
/* 268 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getApplicationIntent() {
/* 272 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setSendTimeAsDatetime(boolean paramBoolean)
/*     */   {
/* 277 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   public boolean getSendTimeAsDatetime()
/*     */   {
/* 282 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setSendStringParametersAsUnicode(boolean paramBoolean)
/*     */   {
/* 292 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   public boolean getSendStringParametersAsUnicode() {
/* 296 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setServerName(String paramString)
/*     */   {
/* 303 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_NAME.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getServerName() {
/* 307 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_NAME.toString(), null);
/*     */   }
/*     */ 
/*     */   public void setFailoverPartner(String paramString)
/*     */   {
/* 313 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getFailoverPartner()
/*     */   {
/* 319 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), null);
/*     */   }
/*     */ 
/*     */   public void setMultiSubnetFailover(boolean paramBoolean)
/*     */   {
/* 324 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   public boolean getMultiSubnetFailover()
/*     */   {
/* 329 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setUser(String paramString)
/*     */   {
/* 336 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.USER.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getUser() {
/* 340 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.USER.toString(), null);
/*     */   }
/*     */ 
/*     */   public void setWorkstationID(String paramString)
/*     */   {
/* 349 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.WORKSTATION_ID.toString(), paramString);
/*     */   }
/*     */ 
/*     */   public String getWorkstationID() {
/* 353 */     if (loggerExternal.isLoggable(Level.FINER))
/* 354 */       loggerExternal.entering(getClassNameLogging(), "getWorkstationID");
/* 355 */     String str = this.connectionProps.getProperty(SQLServerDriverStringProperty.WORKSTATION_ID.toString());
/*     */ 
/* 357 */     if (null == str)
/*     */     {
/* 359 */       str = Util.lookupHostName();
/*     */     }
/* 361 */     loggerExternal.exiting(getClassNameLogging(), "getWorkstationID", str);
/* 362 */     return str;
/*     */   }
/*     */ 
/*     */   public void setXopenStates(boolean paramBoolean)
/*     */   {
/* 371 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   public boolean getXopenStates() {
/* 375 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), SQLServerDriverBooleanProperty.XOPEN_STATES.getDefaultValue());
/*     */   }
/*     */ 
/*     */   public void setURL(String paramString)
/*     */   {
/* 393 */     loggerExternal.entering(getClassNameLogging(), "setURL", paramString);
/*     */ 
/* 395 */     this.dataSourceURL = paramString;
/* 396 */     loggerExternal.exiting(getClassNameLogging(), "setURL");
/*     */   }
/*     */ 
/*     */   public String getURL() {
/* 400 */     String str = this.dataSourceURL;
/* 401 */     loggerExternal.entering(getClassNameLogging(), "getURL");
/*     */ 
/* 403 */     if (null == this.dataSourceURL)
/* 404 */       str = "jdbc:sqlserver://";
/* 405 */     loggerExternal.exiting(getClassNameLogging(), "getURL", str);
/* 406 */     return str;
/*     */   }
/*     */ 
/*     */   public void setDescription(String paramString)
/*     */   {
/* 415 */     loggerExternal.entering(getClassNameLogging(), "setDescription", paramString);
/* 416 */     this.dataSourceDescription = paramString;
/* 417 */     loggerExternal.exiting(getClassNameLogging(), "setDescription");
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 421 */     loggerExternal.entering(getClassNameLogging(), "getDescription");
/* 422 */     loggerExternal.exiting(getClassNameLogging(), "getDescription", this.dataSourceDescription);
/* 423 */     return this.dataSourceDescription;
/*     */   }
/*     */ 
/*     */   public void setPacketSize(int paramInt)
/*     */   {
/* 432 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.PACKET_SIZE.toString(), paramInt);
/*     */   }
/*     */ 
/*     */   public int getPacketSize() {
/* 436 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.PACKET_SIZE.toString(), SQLServerDriverIntProperty.PACKET_SIZE.getDefaultValue());
/*     */   }
/*     */ 
/*     */   private void setStringProperty(Properties paramProperties, String paramString1, String paramString2)
/*     */   {
/* 464 */     if ((loggerExternal.isLoggable(Level.FINER)) && (!paramString1.contains("password")) && (!paramString1.contains("Password")))
/*     */     {
/* 466 */       loggerExternal.entering(getClassNameLogging(), "set" + paramString1, paramString2);
/*     */     }
/*     */     else
/* 469 */       loggerExternal.entering(getClassNameLogging(), "set" + paramString1);
/* 470 */     if (null != paramString2)
/* 471 */       paramProperties.setProperty(paramString1, paramString2);
/* 472 */     loggerExternal.exiting(getClassNameLogging(), "set" + paramString1);
/*     */   }
/*     */ 
/*     */   private String getStringProperty(Properties paramProperties, String paramString1, String paramString2)
/*     */   {
/* 480 */     if (loggerExternal.isLoggable(Level.FINER))
/* 481 */       loggerExternal.entering(getClassNameLogging(), "get" + paramString1);
/* 482 */     String str = paramProperties.getProperty(paramString1);
/* 483 */     if (null == str)
/* 484 */       str = paramString2;
/* 485 */     if ((loggerExternal.isLoggable(Level.FINER)) && (!paramString1.contains("password")) && (!paramString1.contains("Password")))
/* 486 */       loggerExternal.exiting(getClassNameLogging(), "get" + paramString1, str);
/* 487 */     return str;
/*     */   }
/*     */ 
/*     */   private void setIntProperty(Properties paramProperties, String paramString, int paramInt)
/*     */   {
/* 494 */     if (loggerExternal.isLoggable(Level.FINER))
/* 495 */       loggerExternal.entering(getClassNameLogging(), "set" + paramString, new Integer(paramInt));
/* 496 */     paramProperties.setProperty(paramString, new Integer(paramInt).toString());
/* 497 */     loggerExternal.exiting(getClassNameLogging(), "set" + paramString);
/*     */   }
/*     */ 
/*     */   private int getIntProperty(Properties paramProperties, String paramString, int paramInt)
/*     */   {
/* 505 */     if (loggerExternal.isLoggable(Level.FINER))
/* 506 */       loggerExternal.entering(getClassNameLogging(), "get" + paramString);
/* 507 */     String str = paramProperties.getProperty(paramString);
/* 508 */     int i = paramInt;
/* 509 */     if (null != str)
/*     */     {
/*     */       try
/*     */       {
/* 513 */         i = Integer.parseInt(str);
/*     */       }
/*     */       catch (NumberFormatException localNumberFormatException)
/*     */       {
/* 519 */         if (!$assertionsDisabled) throw new AssertionError("Bad portNumber:-" + str);
/*     */       }
/*     */     }
/* 522 */     if (loggerExternal.isLoggable(Level.FINER))
/* 523 */       loggerExternal.exiting(getClassNameLogging(), "get" + paramString, new Integer(i));
/* 524 */     return i;
/*     */   }
/*     */ 
/*     */   private void setBooleanProperty(Properties paramProperties, String paramString, boolean paramBoolean)
/*     */   {
/* 531 */     if (loggerExternal.isLoggable(Level.FINER))
/* 532 */       loggerExternal.entering(getClassNameLogging(), "set" + paramString, Boolean.valueOf(paramBoolean));
/* 533 */     paramProperties.setProperty(paramString, paramBoolean ? "true" : "false");
/* 534 */     loggerExternal.exiting(getClassNameLogging(), "set" + paramString);
/*     */   }
/*     */ 
/*     */   private boolean getBooleanProperty(Properties paramProperties, String paramString, boolean paramBoolean)
/*     */   {
/* 542 */     if (loggerExternal.isLoggable(Level.FINER))
/* 543 */       loggerExternal.entering(getClassNameLogging(), "get" + paramString);
/* 544 */     String str = paramProperties.getProperty(paramString);
/*     */     Boolean localBoolean;
/* 546 */     if (null == str)
/*     */     {
/* 548 */       localBoolean = Boolean.valueOf(paramBoolean);
/*     */     }
/*     */     else
/*     */     {
/* 554 */       localBoolean = Boolean.valueOf(str);
/*     */     }
/* 556 */     loggerExternal.exiting(getClassNameLogging(), "get" + paramString, localBoolean);
/* 557 */     return localBoolean.booleanValue();
/*     */   }
/*     */ 
/*     */   SQLServerConnection getConnectionInternal(String paramString1, String paramString2, SQLServerPooledConnection paramSQLServerPooledConnection)
/*     */     throws SQLServerException
/*     */   {
/* 572 */     Properties localProperties1 = null;
/* 573 */     Properties localProperties2 = null;
/*     */ 
/* 575 */     if (this.trustStorePasswordStripped) {
/* 576 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_referencingFailedTSP"), null, true);
/*     */     }
/*     */ 
/* 581 */     if ((null != paramString1) || (null != paramString2))
/*     */     {
/* 583 */       localProperties1 = (Properties)this.connectionProps.clone();
/*     */ 
/* 588 */       localProperties1.remove(SQLServerDriverStringProperty.USER.toString());
/* 589 */       localProperties1.remove(SQLServerDriverStringProperty.PASSWORD.toString());
/*     */ 
/* 591 */       if (null != paramString1)
/* 592 */         localProperties1.put(SQLServerDriverStringProperty.USER.toString(), paramString1);
/* 593 */       if (null != paramString2)
/* 594 */         localProperties1.put(SQLServerDriverStringProperty.PASSWORD.toString(), paramString2);
/*     */     }
/*     */     else
/*     */     {
/* 598 */       localProperties1 = this.connectionProps;
/*     */     }
/*     */ 
/* 602 */     if (null != this.dataSourceURL)
/*     */     {
/* 604 */       localObject = Util.parseUrl(this.dataSourceURL, dsLogger);
/*     */ 
/* 606 */       if (null == localObject) {
/* 607 */         SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */       }
/*     */ 
/* 610 */       localProperties2 = SQLServerDriver.mergeURLAndSuppliedProperties((Properties)localObject, localProperties1);
/*     */     }
/*     */     else
/*     */     {
/* 614 */       localProperties2 = localProperties1;
/*     */     }
/*     */ 
/* 618 */     if (dsLogger.isLoggable(Level.FINER))
/* 619 */       dsLogger.finer(toString() + " Begin create new connection.");
/* 620 */     Object localObject = new SQLServerConnection(toString());
/* 621 */     ((SQLServerConnection)localObject).connect(localProperties2, paramSQLServerPooledConnection);
/* 622 */     if (dsLogger.isLoggable(Level.FINER))
/* 623 */       dsLogger.finer(toString() + " End create new connection " + ((SQLServerConnection)localObject).toString());
/* 624 */     return (SQLServerConnection)localObject;
/*     */   }
/*     */ 
/*     */   public Reference getReference()
/*     */   {
/* 631 */     loggerExternal.entering(getClassNameLogging(), "getReference");
/* 632 */     Reference localReference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerDataSource");
/* 633 */     loggerExternal.exiting(getClassNameLogging(), "getReference", localReference);
/* 634 */     return localReference;
/*     */   }
/*     */ 
/*     */   Reference getReferenceInternal(String paramString)
/*     */   {
/* 639 */     if (dsLogger.isLoggable(Level.FINER)) {
/* 640 */       dsLogger.finer(toString() + " creating reference for " + paramString + ".");
/*     */     }
/* 642 */     Reference localReference = new Reference(getClass().getName(), "com.microsoft.sqlserver.jdbc.SQLServerDataSourceObjectFactory", null);
/*     */ 
/* 644 */     if (null != paramString) {
/* 645 */       localReference.add(new StringRefAddr("class", paramString));
/*     */     }
/* 647 */     if (this.trustStorePasswordStripped) {
/* 648 */       localReference.add(new StringRefAddr("trustStorePasswordStripped", "true"));
/*     */     }
/*     */ 
/* 651 */     Enumeration localEnumeration = this.connectionProps.keys();
/* 652 */     while (localEnumeration.hasMoreElements())
/*     */     {
/* 654 */       String str = (String)localEnumeration.nextElement();
/*     */ 
/* 656 */       if (str.equals(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString()))
/*     */       {
/* 659 */         assert (!this.trustStorePasswordStripped);
/* 660 */         localReference.add(new StringRefAddr("trustStorePasswordStripped", "true"));
/*     */       }
/* 665 */       else if (!str.contains(SQLServerDriverStringProperty.PASSWORD.toString())) {
/* 666 */         localReference.add(new StringRefAddr(str, this.connectionProps.getProperty(str)));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 671 */     if (null != this.dataSourceURL) {
/* 672 */       localReference.add(new StringRefAddr("dataSourceURL", this.dataSourceURL));
/*     */     }
/* 674 */     if (null != this.dataSourceDescription) {
/* 675 */       localReference.add(new StringRefAddr("dataSourceDescription", this.dataSourceDescription));
/*     */     }
/* 677 */     return localReference;
/*     */   }
/*     */ 
/*     */   void initializeFromReference(Reference paramReference)
/*     */   {
/* 685 */     Enumeration localEnumeration = paramReference.getAll();
/* 686 */     while (localEnumeration.hasMoreElements())
/*     */     {
/* 688 */       StringRefAddr localStringRefAddr = (StringRefAddr)localEnumeration.nextElement();
/* 689 */       String str1 = localStringRefAddr.getType();
/* 690 */       String str2 = (String)localStringRefAddr.getContent();
/*     */ 
/* 693 */       if (str1.equals("dataSourceURL"))
/*     */       {
/* 695 */         this.dataSourceURL = str2;
/*     */       }
/* 697 */       else if (str1.equals("dataSourceDescription"))
/*     */       {
/* 699 */         this.dataSourceDescription = str2;
/*     */       }
/* 701 */       else if (str1.equals("trustStorePasswordStripped"))
/*     */       {
/* 703 */         this.trustStorePasswordStripped = true;
/*     */       }
/* 706 */       else if (false == str1.equals("class"))
/*     */       {
/* 709 */         this.connectionProps.setProperty(str1, str2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isWrapperFor(Class paramClass) throws SQLException
/*     */   {
/* 716 */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor", paramClass);
/* 717 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 718 */     boolean bool = paramClass.isInstance(this);
/* 719 */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
/* 720 */     return bool;
/*     */   }
/*     */ 
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/* 725 */     loggerExternal.entering(getClassNameLogging(), "unwrap", paramClass);
/* 726 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     Object localObject;
/*     */     try {
/* 731 */       localObject = paramClass.cast(this);
/*     */     }
/*     */     catch (ClassCastException localClassCastException)
/*     */     {
/* 735 */       throw new SQLServerException(localClassCastException.getMessage(), localClassCastException);
/*     */     }
/* 737 */     loggerExternal.exiting(getClassNameLogging(), "unwrap", localObject);
/* 738 */     return localObject;
/*     */   }
/*     */ 
/*     */   private static synchronized int nextDataSourceID()
/*     */   {
/* 744 */     baseDataSourceID += 1;
/* 745 */     return baseDataSourceID;
/*     */   }
/*     */ 
/*     */   private Object writeReplace() throws ObjectStreamException {
/* 749 */     return new SerializationProxy(this);
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream paramObjectInputStream)
/*     */     throws InvalidObjectException
/*     */   {
/* 759 */     throw new InvalidObjectException("");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  21 */     dsLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDataSource");
/*  22 */     loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.DataSource");
/*     */ 
/*  31 */     baseDataSourceID = 0;
/*     */   }
/*     */ 
/*     */   private static class SerializationProxy
/*     */     implements Serializable
/*     */   {
/*     */     private final Reference ref;
/*     */     private static final long serialVersionUID = 654661379542314226L;
/*     */ 
/*     */     SerializationProxy(SQLServerDataSource paramSQLServerDataSource)
/*     */     {
/* 773 */       this.ref = paramSQLServerDataSource.getReferenceInternal(null);
/*     */     }
/*     */ 
/*     */     private Object readResolve() {
/* 777 */       SQLServerDataSource localSQLServerDataSource = new SQLServerDataSource();
/* 778 */       localSQLServerDataSource.initializeFromReference(this.ref);
/* 779 */       return localSQLServerDataSource;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerDataSource
 * JD-Core Version:    0.6.0
 */