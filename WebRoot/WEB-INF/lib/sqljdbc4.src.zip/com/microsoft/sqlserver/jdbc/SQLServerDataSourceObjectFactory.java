/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.Name;
/*    */ import javax.naming.RefAddr;
/*    */ import javax.naming.Reference;
/*    */ import javax.naming.spi.ObjectFactory;
/*    */ 
/*    */ public final class SQLServerDataSourceObjectFactory
/*    */   implements ObjectFactory
/*    */ {
/*    */   public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable paramHashtable)
/*    */     throws SQLServerException
/*    */   {
/*    */     try
/*    */     {
/* 30 */       Reference localReference = (Reference)paramObject;
/*    */ 
/* 32 */       RefAddr localRefAddr = localReference.get("class");
/*    */ 
/* 35 */       if (null == localRefAddr)
/*    */       {
/* 37 */         SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */       }
/*    */ 
/* 41 */       String str = (String)localRefAddr.getContent();
/*    */ 
/* 43 */       if (null == str) {
/* 44 */         SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */       }
/*    */ 
/* 48 */       if ((str.equals("com.microsoft.sqlserver.jdbc.SQLServerDataSource")) || (str.equals("com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource")) || (str.equals("com.microsoft.sqlserver.jdbc.SQLServerXADataSource")))
/*    */       {
/* 54 */         Class localClass = Class.forName(str);
/* 55 */         Object localObject = localClass.newInstance();
/*    */ 
/* 59 */         SQLServerDataSource localSQLServerDataSource = (SQLServerDataSource)localObject;
/* 60 */         localSQLServerDataSource.initializeFromReference(localReference);
/* 61 */         return localObject;
/*    */       }
/*    */ 
/* 64 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */     }
/*    */     catch (ClassNotFoundException localClassNotFoundException)
/*    */     {
/* 69 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */     }
/*    */     catch (InstantiationException localInstantiationException)
/*    */     {
/* 74 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */     }
/*    */     catch (IllegalAccessException localIllegalAccessException)
/*    */     {
/* 79 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */     }
/*    */ 
/* 83 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerDataSourceObjectFactory
 * JD-Core Version:    0.6.0
 */