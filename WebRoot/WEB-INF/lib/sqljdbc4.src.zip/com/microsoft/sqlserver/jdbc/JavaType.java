/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.NClob;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import microsoft.sql.DateTimeOffset;
/*     */ 
/*     */  enum JavaType
/*     */ {
/* 465 */   INTEGER(Integer.class, JDBCType.INTEGER), 
/* 466 */   STRING(String.class, JDBCType.CHAR), 
/* 467 */   DATE(Date.class, JDBCType.DATE), 
/* 468 */   TIME(Time.class, JDBCType.TIME), 
/* 469 */   TIMESTAMP(Timestamp.class, JDBCType.TIMESTAMP), 
/* 470 */   DATETIMEOFFSET(DateTimeOffset.class, JDBCType.DATETIMEOFFSET), 
/* 471 */   BOOLEAN(Boolean.class, JDBCType.BIT), 
/* 472 */   BIGDECIMAL(BigDecimal.class, JDBCType.DECIMAL), 
/* 473 */   DOUBLE(Double.class, JDBCType.DOUBLE), 
/* 474 */   FLOAT(Float.class, JDBCType.REAL), 
/* 475 */   SHORT(Short.class, JDBCType.SMALLINT), 
/* 476 */   LONG(Long.class, JDBCType.BIGINT), 
/* 477 */   BYTE(Byte.class, JDBCType.TINYINT), 
/* 478 */   BYTEARRAY([B.class, JDBCType.BINARY), 
/*     */ 
/* 480 */   NCLOB(NClob.class, JDBCType.NCLOB), 
/* 481 */   CLOB(Clob.class, JDBCType.CLOB), 
/* 482 */   BLOB(Blob.class, JDBCType.BLOB), 
/*     */ 
/* 484 */   INPUTSTREAM(InputStream.class, JDBCType.UNKNOWN), 
/*     */ 
/* 537 */   READER(Reader.class, JDBCType.LONGVARCHAR), 
/*     */ 
/* 539 */   SQLXML(SQLServerSQLXML.class, JDBCType.SQLXML), 
/* 540 */   OBJECT(Object.class, JDBCType.UNKNOWN);
/*     */ 
/*     */   private final Class javaClass;
/*     */   private final JDBCType jdbcTypeFromJavaType;
/*     */ 
/* 547 */   private JavaType(Class paramClass, JDBCType paramJDBCType) { this.javaClass = paramClass;
/* 548 */     this.jdbcTypeFromJavaType = paramJDBCType;
/*     */   }
/*     */ 
/*     */   static JavaType of(Object paramObject)
/*     */   {
/* 553 */     if (null != paramObject)
/*     */     {
/* 555 */       for (JavaType localJavaType : values()) {
/* 556 */         if (localJavaType.javaClass.isInstance(paramObject))
/* 557 */           return localJavaType;
/*     */       }
/*     */     }
/* 560 */     return OBJECT;
/*     */   }
/*     */ 
/*     */   JDBCType getJDBCType(SSType paramSSType, JDBCType paramJDBCType)
/*     */   {
/* 570 */     return this.jdbcTypeFromJavaType;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.JavaType
 * JD-Core Version:    0.6.0
 */