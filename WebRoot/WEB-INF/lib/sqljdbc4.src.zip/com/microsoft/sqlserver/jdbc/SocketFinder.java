/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.Inet4Address;
/*      */ import java.net.Inet6Address;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.channels.SelectionKey;
/*      */ import java.nio.channels.Selector;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.SynchronousQueue;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ final class SocketFinder
/*      */ {
/*      */   private static final ThreadPoolExecutor threadPoolExecutor;
/*      */   private static final int minTimeoutForParallelConnections = 1500;
/* 2031 */   private final Object socketFinderlock = new Object();
/*      */ 
/* 2035 */   private final Object parentThreadLock = new Object();
/*      */ 
/* 2039 */   private volatile Result result = Result.UNKNOWN;
/*      */ 
/* 2043 */   private int noOfSpawnedThreads = 0;
/*      */ 
/* 2047 */   private volatile int noOfThreadsThatNotified = 0;
/*      */ 
/* 2051 */   private volatile Socket selectedSocket = null;
/*      */ 
/* 2055 */   private volatile IOException selectedException = null;
/*      */   private static final Logger logger;
/*      */   private final String traceID;
/*      */   private static final int ipAddressLimit = 64;
/*      */   private final SQLServerConnection conn;
/*      */ 
/*      */   SocketFinder(String paramString, SQLServerConnection paramSQLServerConnection)
/*      */   {
/* 2073 */     this.traceID = ("SocketFinder(" + paramString + ")");
/* 2074 */     this.conn = paramSQLServerConnection;
/*      */   }
/*      */ 
/*      */   Socket findSocket(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 2088 */     assert (paramInt2 != 0) : "The driver does not allow a time out of 0";
/*      */     try
/*      */     {
/* 2092 */       if (!paramBoolean)
/*      */       {
/* 2094 */         return getDefaultSocket(paramString, paramInt1, paramInt2);
/*      */       }
/*      */ 
/* 2097 */       InetAddress[] arrayOfInetAddress = InetAddress.getAllByName(paramString);
/*      */       Object localObject1;
/* 2099 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2101 */         localObject1 = toString() + " Total no of InetAddresses: " + arrayOfInetAddress.length + ". They are: ";
/* 2102 */         for (Object localObject4 : arrayOfInetAddress)
/*      */         {
/* 2104 */           localObject1 = (String)localObject1 + localObject4.toString() + ";";
/*      */         }
/*      */ 
/* 2107 */         logger.finer((String)localObject1);
/*      */       }
/*      */       Object localObject3;
/* 2110 */       if (arrayOfInetAddress.length > 64)
/*      */       {
/* 2112 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_ipAddressLimitWithMultiSubnetFailover"));
/* 2113 */         ??? = new Object[] { Integer.toString(64) };
/* 2114 */         localObject3 = ((MessageFormat)localObject1).format(???);
/*      */ 
/* 2117 */         this.conn.terminate(6, (String)localObject3);
/*      */       }
/*      */ 
/* 2120 */       if (Util.isIBM())
/*      */       {
/* 2122 */         paramInt2 = Math.max(paramInt2, 1500);
/* 2123 */         if (logger.isLoggable(Level.FINER))
/*      */         {
/* 2125 */           logger.finer(toString() + "Using Java NIO with timeout:" + paramInt2);
/*      */         }
/* 2127 */         findSocketUsingJavaNIO(arrayOfInetAddress, paramInt1, paramInt2);
/*      */       }
/*      */       else
/*      */       {
/* 2131 */         localObject1 = new LinkedList();
/* 2132 */         ??? = new LinkedList();
/*      */ 
/* 2134 */         for (Object localObject5 : arrayOfInetAddress)
/*      */         {
/* 2136 */           if ((localObject5 instanceof Inet4Address))
/*      */           {
/* 2138 */             ((LinkedList)localObject1).add((Inet4Address)localObject5);
/*      */           }
/*      */           else
/*      */           {
/* 2142 */             assert ((localObject5 instanceof Inet6Address)) : ("Unexpected IP address " + localObject5.toString());
/* 2143 */             ((LinkedList)???).add((Inet6Address)localObject5);
/*      */           }
/*      */         }
/*      */         int j;
/* 2149 */         if ((!((LinkedList)localObject1).isEmpty()) && (!((LinkedList)???).isEmpty()))
/*      */         {
/* 2151 */           j = Math.max(paramInt2 / 2, 1500);
/*      */         }
/*      */         else {
/* 2154 */           j = Math.max(paramInt2, 1500);
/*      */         }
/* 2156 */         if (!((LinkedList)localObject1).isEmpty())
/*      */         {
/* 2158 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2160 */             logger.finer(toString() + "Using Java NIO with timeout:" + j);
/*      */           }
/*      */ 
/* 2164 */           findSocketUsingJavaNIO((InetAddress[])((LinkedList)localObject1).toArray(new InetAddress[0]), paramInt1, j);
/*      */         }
/*      */ 
/* 2167 */         if (!this.result.equals(Result.SUCCESS))
/*      */         {
/* 2170 */           if (!((LinkedList)???).isEmpty())
/*      */           {
/* 2173 */             if (((LinkedList)???).size() == 1)
/*      */             {
/* 2175 */               return getConnectedSocket((InetAddress)((LinkedList)???).get(0), paramInt1, j);
/*      */             }
/*      */ 
/* 2178 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2180 */               logger.finer(toString() + "Using Threading with timeout:" + j);
/*      */             }
/*      */ 
/* 2183 */             findSocketUsingThreading((LinkedList)???, paramInt1, j);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2192 */       if (this.result.equals(Result.UNKNOWN))
/*      */       {
/* 2194 */         synchronized (this.socketFinderlock)
/*      */         {
/* 2196 */           if (this.result.equals(Result.UNKNOWN))
/*      */           {
/* 2198 */             this.result = Result.FAILURE;
/* 2199 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2201 */               logger.finer(toString() + " The parent thread updated the result to failure");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2211 */       if (this.result.equals(Result.FAILURE))
/*      */       {
/* 2213 */         if (this.selectedException == null)
/*      */         {
/* 2215 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2217 */             logger.finer(toString() + " There is no selectedException. The wait calls timed out before any connect call returned or timed out.");
/*      */           }
/* 2219 */           ??? = SQLServerException.getErrString("R_connectionTimedOut");
/* 2220 */           this.selectedException = new IOException((String)???);
/*      */         }
/* 2222 */         throw this.selectedException;
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (InterruptedException localInterruptedException)
/*      */     {
/* 2228 */       close(this.selectedSocket);
/* 2229 */       SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.conn, localInterruptedException);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2233 */       close(this.selectedSocket);
/*      */ 
/* 2243 */       SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.conn, localIOException);
/*      */     }
/*      */ 
/* 2247 */     assert (this.result.equals(Result.SUCCESS) == true);
/* 2248 */     assert (this.selectedSocket != null) : "Bug in code. Selected Socket cannot be null here.";
/*      */ 
/* 2250 */     return (Socket)(Socket)(Socket)(Socket)this.selectedSocket;
/*      */   }
/*      */ 
/*      */   private void findSocketUsingJavaNIO(InetAddress[] paramArrayOfInetAddress, int paramInt1, int paramInt2)
/*      */     throws IOException
/*      */   {
/* 2268 */     assert (paramInt2 != 0) : "The timeout cannot be zero";
/* 2269 */     assert (paramArrayOfInetAddress.length != 0) : "Number of inetAddresses should not be zero in this function";
/*      */ 
/* 2271 */     Selector localSelector = null;
/* 2272 */     LinkedList localLinkedList = new LinkedList();
/* 2273 */     Object localObject1 = null;
/*      */     try
/*      */     {
/* 2277 */       localSelector = Selector.open();
/*      */ 
/* 2279 */       for (int i = 0; i < paramArrayOfInetAddress.length; i++)
/*      */       {
/* 2281 */         localSocketChannel1 = SocketChannel.open();
/* 2282 */         localLinkedList.add(localSocketChannel1);
/*      */ 
/* 2285 */         localSocketChannel1.configureBlocking(false);
/*      */ 
/* 2288 */         int j = 8;
/* 2289 */         SelectionKey localSelectionKey1 = localSocketChannel1.register(localSelector, j);
/*      */ 
/* 2291 */         localSocketChannel1.connect(new InetSocketAddress(paramArrayOfInetAddress[i], paramInt1));
/*      */ 
/* 2293 */         if (logger.isLoggable(Level.FINER)) {
/* 2294 */           logger.finer(toString() + " initiated connection to address: " + paramArrayOfInetAddress[i] + ", portNumber: " + paramInt1);
/*      */         }
/*      */       }
/* 2297 */       long l1 = System.currentTimeMillis();
/* 2298 */       long l2 = l1 + paramInt2;
/*      */ 
/* 2301 */       int k = paramArrayOfInetAddress.length;
/*      */       while (true)
/*      */       {
/* 2305 */         long l3 = l2 - l1;
/*      */ 
/* 2307 */         if ((l3 <= 0L) || (localObject1 != null) || (k <= 0))
/*      */         {
/*      */           break;
/*      */         }
/*      */ 
/* 2312 */         int m = localSelector.select(l3);
/*      */ 
/* 2314 */         if (logger.isLoggable(Level.FINER)) {
/* 2315 */           logger.finer(toString() + " no of channels ready: " + m);
/*      */         }
/*      */ 
/* 2321 */         if (m != 0)
/*      */         {
/* 2323 */           Set localSet = localSelector.selectedKeys();
/* 2324 */           Iterator localIterator2 = localSet.iterator();
/*      */ 
/* 2326 */           while (localIterator2.hasNext())
/*      */           {
/* 2329 */             SelectionKey localSelectionKey2 = (SelectionKey)localIterator2.next();
/* 2330 */             SocketChannel localSocketChannel2 = (SocketChannel)localSelectionKey2.channel();
/*      */ 
/* 2332 */             if (logger.isLoggable(Level.FINER)) {
/* 2333 */               logger.finer(toString() + " processing the channel :" + localSocketChannel2);
/*      */             }
/* 2335 */             boolean bool = false;
/*      */             try
/*      */             {
/* 2338 */               bool = localSocketChannel2.finishConnect();
/*      */ 
/* 2342 */               assert (bool == true) : ("finishConnect on channel:" + localSocketChannel2 + " cannot be false");
/*      */ 
/* 2344 */               localObject1 = localSocketChannel2;
/*      */ 
/* 2346 */               if (logger.isLoggable(Level.FINER)) {
/* 2347 */                 logger.finer(toString() + " selected the channel :" + localObject1);
/*      */               }
/*      */ 
/*      */             }
/*      */             catch (IOException localIOException2)
/*      */             {
/* 2353 */               if (logger.isLoggable(Level.FINER)) {
/* 2354 */                 logger.finer(toString() + " the exception: " + localIOException2.getClass() + " with message: " + localIOException2.getMessage() + " occured while processing the channel: " + localSocketChannel2);
/*      */               }
/*      */ 
/* 2357 */               updateSelectedException(localIOException2, toString());
/*      */ 
/* 2360 */               localSocketChannel2.close();
/*      */ 
/* 2364 */               localSelectionKey2.cancel();
/* 2365 */               localIterator2.remove();
/* 2366 */               k--;
/*      */             }
/*      */           }
/*      */         }
/* 2370 */         l1 = System.currentTimeMillis();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException1)
/*      */     {
/*      */       SocketChannel localSocketChannel1;
/*      */       Iterator localIterator1;
/* 2378 */       close(localObject1);
/* 2379 */       throw localIOException1;
/*      */     }
/*      */     finally
/*      */     {
/* 2389 */       close(localSelector);
/*      */ 
/* 2397 */       for (SocketChannel localSocketChannel3 : localLinkedList)
/*      */       {
/* 2399 */         if (localSocketChannel3 != localObject1)
/*      */         {
/* 2401 */           close(localSocketChannel3);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2407 */     if (localObject1 != null)
/*      */     {
/* 2411 */       localObject1.configureBlocking(true);
/* 2412 */       this.selectedSocket = localObject1.socket();
/* 2413 */       this.result = Result.SUCCESS;
/*      */     }
/*      */   }
/*      */ 
/*      */   private Socket getDefaultSocket(String paramString, int paramInt1, int paramInt2)
/*      */     throws IOException
/*      */   {
/* 2430 */     InetSocketAddress localInetSocketAddress = new InetSocketAddress(paramString, paramInt1);
/* 2431 */     return getConnectedSocket(localInetSocketAddress, paramInt2);
/*      */   }
/*      */ 
/*      */   private Socket getConnectedSocket(InetAddress paramInetAddress, int paramInt1, int paramInt2) throws IOException
/*      */   {
/* 2436 */     InetSocketAddress localInetSocketAddress = new InetSocketAddress(paramInetAddress, paramInt1);
/* 2437 */     return getConnectedSocket(localInetSocketAddress, paramInt2);
/*      */   }
/*      */ 
/*      */   private Socket getConnectedSocket(InetSocketAddress paramInetSocketAddress, int paramInt) throws IOException
/*      */   {
/* 2442 */     assert (paramInt != 0) : "timeout cannot be zero";
/* 2443 */     if (paramInetSocketAddress.isUnresolved())
/* 2444 */       throw new UnknownHostException();
/* 2445 */     this.selectedSocket = new Socket();
/* 2446 */     this.selectedSocket.connect(paramInetSocketAddress, paramInt);
/* 2447 */     return this.selectedSocket;
/*      */   }
/*      */ 
/*      */   private void findSocketUsingThreading(LinkedList<Inet6Address> paramLinkedList, int paramInt1, int paramInt2) throws IOException, InterruptedException
/*      */   {
/* 2452 */     assert (paramInt2 != 0) : "The timeout cannot be zero";
/* 2453 */     assert (!paramLinkedList.isEmpty()) : "Number of inetAddresses should not be zero in this function";
/*      */ 
/* 2455 */     LinkedList localLinkedList1 = new LinkedList();
/* 2456 */     LinkedList localLinkedList2 = new LinkedList();
/*      */     try
/*      */     {
/* 2462 */       this.noOfSpawnedThreads = paramLinkedList.size();
/* 2463 */       for (Iterator localIterator1 = paramLinkedList.iterator(); localIterator1.hasNext(); ) { localObject1 = (Inet6Address)localIterator1.next();
/*      */ 
/* 2465 */         localObject2 = new Socket();
/* 2466 */         localLinkedList1.add(localObject2);
/*      */ 
/* 2468 */         InetSocketAddress localInetSocketAddress = new InetSocketAddress((InetAddress)localObject1, paramInt1);
/*      */ 
/* 2470 */         SocketConnector localSocketConnector = new SocketConnector((Socket)localObject2, localInetSocketAddress, paramInt2, this);
/* 2471 */         localLinkedList2.add(localSocketConnector);
/*      */       }
/*      */ 
/* 2475 */       synchronized (this.parentThreadLock)
/*      */       {
/* 2477 */         Object localObject2;
/* 2477 */         for (Object localObject1 = localLinkedList2.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (SocketConnector)((Iterator)localObject1).next();
/*      */ 
/* 2479 */           threadPoolExecutor.execute((Runnable)localObject2);
/*      */         }
/*      */ 
/* 2482 */         long l1 = System.currentTimeMillis();
/* 2483 */         long l2 = l1 + paramInt2;
/*      */         while (true)
/*      */         {
/* 2488 */           long l3 = l2 - l1;
/*      */ 
/* 2490 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2492 */             logger.finer(toString() + " TimeRemaining:" + l3 + "; Result:" + this.result + "; Max. open thread count: " + threadPoolExecutor.getLargestPoolSize() + "; Current open thread count:" + threadPoolExecutor.getActiveCount());
/*      */           }
/*      */ 
/* 2506 */           if ((l3 <= 0L) || (!this.result.equals(Result.UNKNOWN))) {
/*      */             break;
/*      */           }
/* 2509 */           this.parentThreadLock.wait(l3);
/*      */ 
/* 2511 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2513 */             logger.finer(toString() + " The parent thread wokeup.");
/*      */           }
/*      */ 
/* 2517 */           l1 = System.currentTimeMillis();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2534 */       for (??? = localLinkedList1.iterator(); ((Iterator)???).hasNext(); ) { Socket localSocket1 = (Socket)((Iterator)???).next();
/*      */ 
/* 2536 */         if (localSocket1 != this.selectedSocket)
/*      */         {
/* 2538 */           close(localSocket1);
/*      */         }
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 2534 */       for (Socket localSocket2 : localLinkedList1)
/*      */       {
/* 2536 */         if (localSocket2 != this.selectedSocket)
/*      */         {
/* 2538 */           close(localSocket2);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   Result getResult()
/*      */   {
/* 2551 */     return this.result;
/*      */   }
/*      */ 
/*      */   void close(Selector paramSelector)
/*      */   {
/* 2556 */     if (null != paramSelector)
/*      */     {
/* 2558 */       if (logger.isLoggable(Level.FINER)) {
/* 2559 */         logger.finer(toString() + ": Closing Selector");
/*      */       }
/*      */       try
/*      */       {
/* 2563 */         paramSelector.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 2567 */         if (logger.isLoggable(Level.FINE))
/* 2568 */           logger.log(Level.FINE, toString() + ": Ignored the following error while closing Selector", localIOException);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void close(Socket paramSocket)
/*      */   {
/* 2575 */     if (null != paramSocket)
/*      */     {
/* 2577 */       if (logger.isLoggable(Level.FINER)) {
/* 2578 */         logger.finer(toString() + ": Closing TCP socket:" + paramSocket);
/*      */       }
/*      */       try
/*      */       {
/* 2582 */         paramSocket.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 2586 */         if (logger.isLoggable(Level.FINE))
/* 2587 */           logger.log(Level.FINE, toString() + ": Ignored the following error while closing socket", localIOException);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void close(SocketChannel paramSocketChannel)
/*      */   {
/* 2594 */     if (null != paramSocketChannel)
/*      */     {
/* 2596 */       if (logger.isLoggable(Level.FINER)) {
/* 2597 */         logger.finer(toString() + ": Closing TCP socket channel:" + paramSocketChannel);
/*      */       }
/*      */       try
/*      */       {
/* 2601 */         paramSocketChannel.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 2605 */         if (logger.isLoggable(Level.FINE))
/* 2606 */           logger.log(Level.FINE, toString() + "Ignored the following error while closing socketChannel", localIOException);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void updateResult(Socket paramSocket, IOException paramIOException, String paramString)
/*      */   {
/* 2627 */     if (this.result.equals(Result.UNKNOWN))
/*      */     {
/* 2629 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2631 */         logger.finer("The following child thread is waiting for socketFinderLock:" + paramString);
/*      */       }
/*      */ 
/* 2634 */       synchronized (this.socketFinderlock)
/*      */       {
/* 2636 */         if (logger.isLoggable(Level.FINER))
/*      */         {
/* 2638 */           logger.finer("The following child thread acquired socketFinderLock:" + paramString);
/*      */         }
/*      */ 
/* 2641 */         if (this.result.equals(Result.UNKNOWN))
/*      */         {
/* 2645 */           if ((paramIOException == null) && (this.selectedSocket == null))
/*      */           {
/* 2647 */             this.selectedSocket = paramSocket;
/* 2648 */             this.result = Result.SUCCESS;
/* 2649 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2651 */               logger.finer("The socket of the following thread has been chosen:" + paramString);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 2656 */           if (paramIOException != null)
/*      */           {
/* 2658 */             updateSelectedException(paramIOException, paramString);
/*      */           }
/*      */         }
/*      */ 
/* 2662 */         this.noOfThreadsThatNotified += 1;
/*      */ 
/* 2666 */         if ((this.noOfThreadsThatNotified >= this.noOfSpawnedThreads) && (this.result.equals(Result.UNKNOWN)))
/*      */         {
/* 2669 */           this.result = Result.FAILURE;
/*      */         }
/*      */ 
/* 2672 */         if (!this.result.equals(Result.UNKNOWN))
/*      */         {
/* 2696 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2698 */             logger.finer("The following child thread is waiting for parentThreadLock:" + paramString);
/*      */           }
/*      */ 
/* 2701 */           synchronized (this.parentThreadLock)
/*      */           {
/* 2703 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2705 */               logger.finer("The following child thread acquired parentThreadLock:" + paramString);
/*      */             }
/*      */ 
/* 2708 */             this.parentThreadLock.notify();
/*      */           }
/*      */ 
/* 2711 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2713 */             logger.finer("The following child thread released parentThreadLock and notified the parent thread:" + paramString);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 2718 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2720 */         logger.finer("The following child thread released socketFinderLock:" + paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateSelectedException(IOException paramIOException, String paramString)
/*      */   {
/* 2735 */     int i = 0;
/* 2736 */     if (this.selectedException == null)
/*      */     {
/* 2738 */       this.selectedException = paramIOException;
/* 2739 */       i = 1;
/*      */     }
/* 2741 */     else if ((!(paramIOException instanceof SocketTimeoutException)) && ((this.selectedException instanceof SocketTimeoutException)))
/*      */     {
/* 2743 */       this.selectedException = paramIOException;
/* 2744 */       i = 1;
/*      */     }
/*      */ 
/* 2747 */     if (i != 0)
/*      */     {
/* 2749 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2751 */         logger.finer("The selected exception is updated to the following: ExceptionType:" + paramIOException.getClass() + "; ExceptionMessage:" + paramIOException.getMessage() + "; by the following thread:" + paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2763 */     return this.traceID;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 2024 */     threadPoolExecutor = new ThreadPoolExecutor(0, 2147483647, 5L, TimeUnit.SECONDS, new SynchronousQueue());
/*      */ 
/* 2058 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SocketFinder");
/*      */   }
/*      */ 
/*      */   static enum Result
/*      */   {
/* 2017 */     UNKNOWN, 
/* 2018 */     SUCCESS, 
/* 2019 */     FAILURE;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SocketFinder
 * JD-Core Version:    0.6.0
 */