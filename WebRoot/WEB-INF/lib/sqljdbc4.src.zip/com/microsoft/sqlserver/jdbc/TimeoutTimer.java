/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.util.logging.Level;
/*      */ 
/*      */ final class TimeoutTimer
/*      */   implements Runnable
/*      */ {
/*      */   private final int timeoutSeconds;
/*      */   private final TDSCommand command;
/*      */   private Thread timerThread;
/* 5524 */   private volatile boolean canceled = false;
/*      */ 
/*      */   TimeoutTimer(int paramInt, TDSCommand paramTDSCommand)
/*      */   {
/* 5528 */     assert (paramInt > 0);
/* 5529 */     assert (null != paramTDSCommand);
/*      */ 
/* 5531 */     this.timeoutSeconds = paramInt;
/* 5532 */     this.command = paramTDSCommand;
/*      */   }
/*      */ 
/*      */   final void start()
/*      */   {
/* 5537 */     this.timerThread = new Thread(this);
/* 5538 */     this.timerThread.setDaemon(true);
/* 5539 */     this.timerThread.start();
/*      */   }
/*      */ 
/*      */   final void stop()
/*      */   {
/* 5544 */     this.canceled = true;
/* 5545 */     this.timerThread.interrupt();
/*      */   }
/*      */ 
/*      */   public void run()
/*      */   {
/* 5550 */     int i = this.timeoutSeconds;
/*      */     try
/*      */     {
/*      */       do
/*      */       {
/* 5557 */         if (this.canceled) {
/* 5558 */           return;
/*      */         }
/* 5560 */         Thread.currentThread(); Thread.sleep(1000L);
/*      */ 
/* 5562 */         i--; } while (i > 0);
/*      */     }
/*      */     catch (InterruptedException localInterruptedException)
/*      */     {
/* 5566 */       return;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 5573 */       this.command.interrupt(SQLServerException.getErrString("R_queryTimedOut"));
/*      */     }
/*      */     catch (SQLServerException localSQLServerException)
/*      */     {
/* 5580 */       this.command.log(Level.FINE, "Command could not be timed out. Reason: " + localSQLServerException.getMessage());
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TimeoutTimer
 * JD-Core Version:    0.6.0
 */