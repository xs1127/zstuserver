/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class StreamInfo extends StreamPacket
/*    */ {
/*  8 */   final StreamError msg = new StreamError();
/*    */ 
/*    */   StreamInfo()
/*    */   {
/* 12 */     super(171);
/*    */   }
/*    */ 
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 17 */     if ((171 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/* 18 */     this.msg.setContentsFromTDS(paramTDSReader);
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamInfo
 * JD-Core Version:    0.6.0
 */