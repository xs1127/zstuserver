/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class StreamRetValue extends StreamPacket
/*    */ {
/*    */   private String paramName;
/*    */   private int ordinalOrLength;
/*    */   private int status;
/*    */ 
/*    */   final int getOrdinalOrLength()
/*    */   {
/* 19 */     return this.ordinalOrLength;
/*    */   }
/*    */ 
/*    */   StreamRetValue()
/*    */   {
/* 30 */     super(172);
/*    */   }
/*    */ 
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 35 */     if ((172 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/* 36 */     this.ordinalOrLength = paramTDSReader.readUnsignedShort();
/* 37 */     this.paramName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 38 */     this.status = paramTDSReader.readUnsignedByte();
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamRetValue
 * JD-Core Version:    0.6.0
 */