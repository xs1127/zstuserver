/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ 
/*    */ final class XidImpl
/*    */   implements Xid
/*    */ {
/*    */   private final int formatId;
/*    */   private final byte[] gtrid;
/*    */   private final byte[] bqual;
/*    */   private final String traceID;
/*    */ 
/*    */   public XidImpl(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
/*    */   {
/* 43 */     this.formatId = paramInt;
/* 44 */     this.gtrid = paramArrayOfByte1;
/* 45 */     this.bqual = paramArrayOfByte2;
/* 46 */     this.traceID = (" XID:" + xidDisplay(this));
/*    */   }
/*    */ 
/*    */   public byte[] getGlobalTransactionId() {
/* 50 */     return this.gtrid;
/*    */   }
/*    */ 
/*    */   public byte[] getBranchQualifier() {
/* 54 */     return this.bqual;
/*    */   }
/*    */ 
/*    */   public int getFormatId() {
/* 58 */     return this.formatId;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 62 */     return this.traceID;
/*    */   }
/*    */ 
/*    */   static String xidDisplay(Xid paramXid)
/*    */   {
/* 68 */     if (null == paramXid) return "(null)";
/* 69 */     StringBuilder localStringBuilder = new StringBuilder(300);
/* 70 */     localStringBuilder.append("formatId=");
/* 71 */     localStringBuilder.append(paramXid.getFormatId());
/* 72 */     localStringBuilder.append(" gtrid=");
/* 73 */     localStringBuilder.append(Util.byteToHexDisplayString(paramXid.getGlobalTransactionId()));
/* 74 */     localStringBuilder.append(" bqual=");
/* 75 */     localStringBuilder.append(Util.byteToHexDisplayString(paramXid.getBranchQualifier()));
/* 76 */     return localStringBuilder.toString();
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.XidImpl
 * JD-Core Version:    0.6.0
 */