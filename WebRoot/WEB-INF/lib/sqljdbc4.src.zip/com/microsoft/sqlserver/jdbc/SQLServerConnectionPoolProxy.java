/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Clob;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.NClob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Struct;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ class SQLServerConnectionPoolProxy
/*     */   implements ISQLServerConnection, Serializable
/*     */ {
/*     */   private SQLServerConnection wrappedConnection;
/*     */   private boolean bIsOpen;
/*  24 */   private static int baseConnectionID = 0;
/*     */   private final String traceID;
/*     */ 
/*     */   private static synchronized int nextConnectionID()
/*     */   {
/*  32 */     baseConnectionID += 1;
/*  33 */     return baseConnectionID;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  38 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   SQLServerConnectionPoolProxy(SQLServerConnection paramSQLServerConnection)
/*     */   {
/*  43 */     this.traceID = (" ProxyConnectionID:" + nextConnectionID());
/*  44 */     this.wrappedConnection = paramSQLServerConnection;
/*     */ 
/*  47 */     paramSQLServerConnection.setAssociatedProxy(this);
/*  48 */     this.bIsOpen = true;
/*     */   }
/*     */ 
/*     */   void checkClosed() throws SQLServerException
/*     */   {
/*  53 */     if (!this.bIsOpen)
/*     */     {
/*  55 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), null, false);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Statement createStatement() throws SQLServerException {
/*  60 */     checkClosed();
/*  61 */     return this.wrappedConnection.createStatement();
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String paramString) throws SQLServerException
/*     */   {
/*  66 */     checkClosed();
/*  67 */     return this.wrappedConnection.prepareStatement(paramString);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String paramString) throws SQLServerException
/*     */   {
/*  72 */     checkClosed();
/*  73 */     return this.wrappedConnection.prepareCall(paramString);
/*     */   }
/*     */ 
/*     */   public String nativeSQL(String paramString) throws SQLServerException
/*     */   {
/*  78 */     checkClosed();
/*  79 */     return this.wrappedConnection.nativeSQL(paramString);
/*     */   }
/*     */ 
/*     */   public void setAutoCommit(boolean paramBoolean) throws SQLServerException
/*     */   {
/*  84 */     checkClosed();
/*  85 */     this.wrappedConnection.setAutoCommit(paramBoolean);
/*     */   }
/*     */ 
/*     */   public boolean getAutoCommit() throws SQLServerException
/*     */   {
/*  90 */     checkClosed();
/*  91 */     return this.wrappedConnection.getAutoCommit();
/*     */   }
/*     */ 
/*     */   public void commit()
/*     */     throws SQLServerException
/*     */   {
/*  99 */     checkClosed();
/* 100 */     this.wrappedConnection.commit();
/*     */   }
/*     */ 
/*     */   public void rollback()
/*     */     throws SQLServerException
/*     */   {
/* 110 */     checkClosed();
/* 111 */     this.wrappedConnection.rollback();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLServerException
/*     */   {
/* 117 */     if ((this.bIsOpen) && (null != this.wrappedConnection))
/*     */     {
/* 119 */       if (this.wrappedConnection.getConnectionLogger().isLoggable(Level.FINER))
/* 120 */         this.wrappedConnection.getConnectionLogger().finer(toString() + " Connection proxy closed ");
/* 121 */       this.wrappedConnection.poolCloseEventNotify();
/* 122 */       this.wrappedConnection = null;
/*     */     }
/* 124 */     this.bIsOpen = false;
/*     */   }
/*     */ 
/*     */   void internalClose() {
/* 128 */     this.bIsOpen = false;
/* 129 */     this.wrappedConnection = null;
/*     */   }
/*     */ 
/*     */   public boolean isClosed()
/*     */     throws SQLServerException
/*     */   {
/* 135 */     return !this.bIsOpen;
/*     */   }
/*     */ 
/*     */   public DatabaseMetaData getMetaData() throws SQLServerException
/*     */   {
/* 140 */     checkClosed();
/* 141 */     return this.wrappedConnection.getMetaData();
/*     */   }
/*     */ 
/*     */   public void setReadOnly(boolean paramBoolean) throws SQLServerException
/*     */   {
/* 146 */     checkClosed();
/* 147 */     this.wrappedConnection.setReadOnly(paramBoolean);
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly() throws SQLServerException
/*     */   {
/* 152 */     checkClosed();
/* 153 */     return this.wrappedConnection.isReadOnly();
/*     */   }
/*     */ 
/*     */   public void setCatalog(String paramString) throws SQLServerException
/*     */   {
/* 158 */     checkClosed();
/* 159 */     this.wrappedConnection.setCatalog(paramString);
/*     */   }
/*     */ 
/*     */   public String getCatalog() throws SQLServerException
/*     */   {
/* 164 */     checkClosed();
/* 165 */     return this.wrappedConnection.getCatalog();
/*     */   }
/*     */ 
/*     */   public void setTransactionIsolation(int paramInt) throws SQLServerException
/*     */   {
/* 170 */     checkClosed();
/* 171 */     this.wrappedConnection.setTransactionIsolation(paramInt);
/*     */   }
/*     */ 
/*     */   public int getTransactionIsolation() throws SQLServerException
/*     */   {
/* 176 */     checkClosed();
/* 177 */     return this.wrappedConnection.getTransactionIsolation();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings() throws SQLServerException
/*     */   {
/* 182 */     checkClosed();
/* 183 */     return this.wrappedConnection.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings() throws SQLServerException
/*     */   {
/* 188 */     checkClosed();
/* 189 */     this.wrappedConnection.clearWarnings();
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 198 */     checkClosed();
/* 199 */     return this.wrappedConnection.createStatement(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 207 */     checkClosed();
/* 208 */     return this.wrappedConnection.prepareStatement(paramString, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 214 */     checkClosed();
/* 215 */     return this.wrappedConnection.prepareCall(paramString, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   public void setTypeMap(Map paramMap) throws SQLServerException
/*     */   {
/* 220 */     checkClosed();
/* 221 */     this.wrappedConnection.setTypeMap(paramMap);
/*     */   }
/*     */ 
/*     */   public Map<String, Class<?>> getTypeMap() throws SQLServerException
/*     */   {
/* 226 */     checkClosed();
/* 227 */     return this.wrappedConnection.getTypeMap();
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*     */   {
/* 232 */     checkClosed();
/* 233 */     return this.wrappedConnection.createStatement(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*     */   {
/* 238 */     checkClosed();
/* 239 */     return this.wrappedConnection.prepareStatement(paramString, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*     */   {
/* 244 */     checkClosed();
/* 245 */     return this.wrappedConnection.prepareCall(paramString, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 252 */     checkClosed();
/* 253 */     return this.wrappedConnection.prepareStatement(paramString, paramInt);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfInt) throws SQLServerException
/*     */   {
/* 258 */     checkClosed();
/* 259 */     return this.wrappedConnection.prepareStatement(paramString, paramArrayOfInt);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLServerException
/*     */   {
/* 264 */     checkClosed();
/* 265 */     return this.wrappedConnection.prepareStatement(paramString, paramArrayOfString);
/*     */   }
/*     */ 
/*     */   public void releaseSavepoint(Savepoint paramSavepoint)
/*     */     throws SQLServerException
/*     */   {
/* 272 */     checkClosed();
/* 273 */     this.wrappedConnection.releaseSavepoint(paramSavepoint);
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint(String paramString) throws SQLServerException
/*     */   {
/* 278 */     checkClosed();
/* 279 */     return this.wrappedConnection.setSavepoint(paramString);
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint() throws SQLServerException
/*     */   {
/* 284 */     checkClosed();
/* 285 */     return this.wrappedConnection.setSavepoint();
/*     */   }
/*     */ 
/*     */   public void rollback(Savepoint paramSavepoint) throws SQLServerException
/*     */   {
/* 290 */     checkClosed();
/* 291 */     this.wrappedConnection.rollback(paramSavepoint);
/*     */   }
/*     */ 
/*     */   public int getHoldability() throws SQLServerException
/*     */   {
/* 296 */     checkClosed();
/* 297 */     return this.wrappedConnection.getHoldability();
/*     */   }
/*     */ 
/*     */   public void setHoldability(int paramInt) throws SQLServerException
/*     */   {
/* 302 */     checkClosed();
/* 303 */     this.wrappedConnection.setHoldability(paramInt);
/*     */   }
/*     */ 
/*     */   public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException
/*     */   {
/* 308 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 310 */     checkClosed();
/* 311 */     return this.wrappedConnection.createArrayOf(paramString, paramArrayOfObject);
/*     */   }
/*     */ 
/*     */   public Blob createBlob() throws SQLException
/*     */   {
/* 316 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 318 */     checkClosed();
/* 319 */     return this.wrappedConnection.createBlob();
/*     */   }
/*     */ 
/*     */   public Clob createClob() throws SQLException
/*     */   {
/* 324 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 326 */     checkClosed();
/* 327 */     return this.wrappedConnection.createClob();
/*     */   }
/*     */ 
/*     */   public NClob createNClob() throws SQLException
/*     */   {
/* 332 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 334 */     checkClosed();
/* 335 */     return this.wrappedConnection.createNClob();
/*     */   }
/*     */ 
/*     */   public SQLXML createSQLXML() throws SQLException
/*     */   {
/* 340 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 342 */     checkClosed();
/* 343 */     return this.wrappedConnection.createSQLXML();
/*     */   }
/*     */ 
/*     */   public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException
/*     */   {
/* 348 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 350 */     checkClosed();
/* 351 */     return this.wrappedConnection.createStruct(paramString, paramArrayOfObject);
/*     */   }
/*     */ 
/*     */   public Properties getClientInfo() throws SQLException
/*     */   {
/* 356 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 358 */     checkClosed();
/* 359 */     return this.wrappedConnection.getClientInfo();
/*     */   }
/*     */ 
/*     */   public String getClientInfo(String paramString) throws SQLException
/*     */   {
/* 364 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 366 */     checkClosed();
/* 367 */     return this.wrappedConnection.getClientInfo(paramString);
/*     */   }
/*     */ 
/*     */   public void setClientInfo(Properties paramProperties) throws SQLClientInfoException
/*     */   {
/* 372 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 375 */     this.wrappedConnection.setClientInfo(paramProperties);
/*     */   }
/*     */ 
/*     */   public void setClientInfo(String paramString1, String paramString2) throws SQLClientInfoException
/*     */   {
/* 380 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 383 */     this.wrappedConnection.setClientInfo(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   public boolean isValid(int paramInt) throws SQLException
/*     */   {
/* 388 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 390 */     checkClosed();
/* 391 */     return this.wrappedConnection.isValid(paramInt);
/*     */   }
/*     */ 
/*     */   public boolean isWrapperFor(Class paramClass) throws SQLException
/*     */   {
/* 396 */     this.wrappedConnection.getConnectionLogger().entering(toString(), "isWrapperFor", paramClass);
/* 397 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 398 */     boolean bool = paramClass.isInstance(this);
/* 399 */     this.wrappedConnection.getConnectionLogger().exiting(toString(), "isWrapperFor", Boolean.valueOf(bool));
/* 400 */     return bool;
/*     */   }
/*     */ 
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/* 405 */     this.wrappedConnection.getConnectionLogger().entering(toString(), "unwrap", paramClass);
/* 406 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     Object localObject;
/*     */     try {
/* 411 */       localObject = paramClass.cast(this);
/*     */     }
/*     */     catch (ClassCastException localClassCastException)
/*     */     {
/* 415 */       SQLServerException localSQLServerException = new SQLServerException(localClassCastException.getMessage(), localClassCastException);
/* 416 */       throw localSQLServerException;
/*     */     }
/* 418 */     this.wrappedConnection.getConnectionLogger().exiting(toString(), "unwrap", localObject);
/* 419 */     return localObject;
/*     */   }
/*     */ 
/*     */   public UUID getClientConnectionId() throws SQLServerException
/*     */   {
/* 424 */     checkClosed();
/* 425 */     return this.wrappedConnection.getClientConnectionId();
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolProxy
 * JD-Core Version:    0.6.0
 */