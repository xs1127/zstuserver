package com.microsoft.sqlserver.jdbc;

import javax.sql.CommonDataSource;

public abstract interface ISQLServerDataSource extends CommonDataSource
{
  public abstract void setApplicationIntent(String paramString);

  public abstract String getApplicationIntent();

  public abstract void setApplicationName(String paramString);

  public abstract String getApplicationName();

  public abstract void setDatabaseName(String paramString);

  public abstract String getDatabaseName();

  public abstract void setInstanceName(String paramString);

  public abstract String getInstanceName();

  public abstract void setIntegratedSecurity(boolean paramBoolean);

  public abstract void setLastUpdateCount(boolean paramBoolean);

  public abstract boolean getLastUpdateCount();

  public abstract void setEncrypt(boolean paramBoolean);

  public abstract boolean getEncrypt();

  public abstract void setTrustServerCertificate(boolean paramBoolean);

  public abstract boolean getTrustServerCertificate();

  public abstract void setTrustStore(String paramString);

  public abstract String getTrustStore();

  public abstract void setTrustStorePassword(String paramString);

  public abstract void setHostNameInCertificate(String paramString);

  public abstract String getHostNameInCertificate();

  public abstract void setLockTimeout(int paramInt);

  public abstract int getLockTimeout();

  public abstract void setPassword(String paramString);

  public abstract void setPortNumber(int paramInt);

  public abstract int getPortNumber();

  public abstract void setSelectMethod(String paramString);

  public abstract String getSelectMethod();

  public abstract void setResponseBuffering(String paramString);

  public abstract String getResponseBuffering();

  public abstract void setSendTimeAsDatetime(boolean paramBoolean);

  public abstract boolean getSendTimeAsDatetime();

  public abstract void setSendStringParametersAsUnicode(boolean paramBoolean);

  public abstract boolean getSendStringParametersAsUnicode();

  public abstract void setServerName(String paramString);

  public abstract String getServerName();

  public abstract void setFailoverPartner(String paramString);

  public abstract String getFailoverPartner();

  public abstract void setMultiSubnetFailover(boolean paramBoolean);

  public abstract boolean getMultiSubnetFailover();

  public abstract void setUser(String paramString);

  public abstract String getUser();

  public abstract void setWorkstationID(String paramString);

  public abstract String getWorkstationID();

  public abstract void setXopenStates(boolean paramBoolean);

  public abstract boolean getXopenStates();

  public abstract void setURL(String paramString);

  public abstract String getURL();

  public abstract void setDescription(String paramString);

  public abstract String getDescription();

  public abstract void setPacketSize(int paramInt);

  public abstract int getPacketSize();

  public abstract void setAuthenticationScheme(String paramString);
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ISQLServerDataSource
 * JD-Core Version:    0.6.0
 */