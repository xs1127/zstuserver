/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ final class AppDTVImpl extends DTVImpl
/*      */ {
/*      */   private JDBCType jdbcType;
/*      */   private Object value;
/*      */   private JavaType javaType;
/*      */   private StreamSetterArgs streamSetterArgs;
/*      */   private Calendar cal;
/*      */   private Integer scale;
/*      */ 
/*      */   AppDTVImpl()
/*      */   {
/* 1174 */     this.jdbcType = JDBCType.UNKNOWN;
/*      */   }
/*      */ 
/*      */   final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 1182 */     if (!$assertionsDisabled) throw new AssertionError(); 
/*      */   }
/*      */ 
/*      */   final void initFromCompressedNull()
/*      */   {
/* 1186 */     if (!$assertionsDisabled) throw new AssertionError();
/*      */   }
/*      */ 
/*      */   void setValue(DTV paramDTV, SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection)
/*      */     throws SQLServerException
/*      */   {
/* 1500 */     paramDTV.setValue(paramObject, paramJavaType);
/* 1501 */     paramDTV.setJdbcType(paramJDBCType);
/* 1502 */     paramDTV.setStreamSetterArgs(paramStreamSetterArgs);
/* 1503 */     paramDTV.setCalendar(paramCalendar);
/* 1504 */     paramDTV.setScale(paramInteger);
/* 1505 */     paramDTV.executeOp(new SetValueOp(paramSQLCollation, paramSQLServerConnection));
/*      */   }
/*      */ 
/*      */   void setValue(Object paramObject, JavaType paramJavaType)
/*      */   {
/* 1510 */     this.value = paramObject;
/* 1511 */     this.javaType = paramJavaType;
/*      */   }
/*      */ 
/*      */   void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs)
/*      */   {
/* 1516 */     this.streamSetterArgs = paramStreamSetterArgs;
/*      */   }
/*      */ 
/*      */   void setCalendar(Calendar paramCalendar)
/*      */   {
/* 1521 */     this.cal = paramCalendar;
/*      */   }
/*      */ 
/*      */   void setScale(Integer paramInteger)
/*      */   {
/* 1526 */     this.scale = paramInteger;
/*      */   }
/*      */   StreamSetterArgs getStreamSetterArgs() {
/* 1529 */     return this.streamSetterArgs; } 
/* 1530 */   Calendar getCalendar() { return this.cal; } 
/* 1531 */   Integer getScale() { return this.scale; }
/*      */ 
/*      */   boolean isNull()
/*      */   {
/* 1535 */     return null == this.value;
/*      */   }
/*      */ 
/*      */   void setJdbcType(JDBCType paramJDBCType)
/*      */   {
/* 1540 */     this.jdbcType = paramJDBCType;
/*      */   }
/*      */ 
/*      */   JDBCType getJdbcType()
/*      */   {
/* 1545 */     return this.jdbcType;
/*      */   }
/*      */ 
/*      */   JavaType getJavaType()
/*      */   {
/* 1550 */     return this.javaType;
/*      */   }
/*      */ 
/*      */   Object getValue(DTV paramDTV, JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 1563 */     if (this.jdbcType != paramJDBCType) {
/* 1564 */       DataTypes.throwConversionError(this.jdbcType.toString(), paramJDBCType.toString());
/*      */     }
/* 1566 */     return this.value;
/*      */   }
/*      */ 
/*      */   Object getSetterValue()
/*      */   {
/* 1571 */     return this.value;
/*      */   }
/*      */ 
/*      */   final class SetValueOp extends DTVExecuteOp
/*      */   {
/*      */     private final SQLCollation collation;
/*      */     private final SQLServerConnection con;
/*      */ 
/*      */     SetValueOp(SQLCollation paramSQLServerConnection, SQLServerConnection arg3)
/*      */     {
/* 1197 */       this.collation = paramSQLServerConnection;
/*      */       Object localObject;
/* 1198 */       this.con = localObject;
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, String paramString) throws SQLServerException
/*      */     {
/* 1203 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*      */ 
/* 1210 */       if ((JDBCType.DECIMAL == localJDBCType) || (JDBCType.NUMERIC == localJDBCType))
/*      */       {
/* 1213 */         assert (null != paramString);
/*      */         try
/*      */         {
/* 1217 */           paramDTV.setValue(new BigDecimal(paramString), JavaType.BIGDECIMAL);
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException)
/*      */         {
/* 1221 */           DataTypes.throwConversionError("String", localJDBCType.toString());
/*      */         }
/*      */ 
/*      */       }
/* 1229 */       else if (localJDBCType.isBinary())
/*      */       {
/* 1231 */         assert (null != paramString);
/* 1232 */         paramDTV.setValue(ParameterUtils.HexToBin(paramString), JavaType.BYTEARRAY);
/*      */       }
/* 1239 */       else if ((null != this.collation) && ((JDBCType.CHAR == localJDBCType) || (JDBCType.VARCHAR == localJDBCType) || (JDBCType.LONGVARCHAR == localJDBCType) || (JDBCType.CLOB == localJDBCType)))
/*      */       {
/* 1245 */         byte[] arrayOfByte = null;
/*      */ 
/* 1247 */         if (null != paramString)
/*      */         {
/*      */           try
/*      */           {
/* 1251 */             arrayOfByte = paramString.getBytes(this.collation.getCharset());
/*      */           }
/*      */           catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */           {
/* 1255 */             MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
/* 1256 */             Object[] arrayOfObject = { new String(localUnsupportedEncodingException.getMessage()) };
/* 1257 */             SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1266 */         paramDTV.setValue(arrayOfByte, JavaType.BYTEARRAY);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Clob paramClob)
/*      */       throws SQLServerException
/*      */     {
/* 1273 */       assert (null != paramClob);
/*      */       try
/*      */       {
/* 1282 */         DataTypes.getCheckedLength(this.con, paramDTV.getJdbcType(), paramClob.length(), false);
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/* 1286 */         SQLServerException.makeFromDriverError(this.con, null, localSQLException.getMessage(), null, false);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, SQLServerSQLXML paramSQLServerSQLXML)
/*      */       throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Byte paramByte) throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Integer paramInteger) throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Time paramTime) throws SQLServerException
/*      */     {
/* 1305 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 1307 */         assert (paramTime != null) : "value is null";
/* 1308 */         paramDTV.setValue(paramTime.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Date paramDate) throws SQLServerException
/*      */     {
/* 1314 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 1316 */         assert (paramDate != null) : "value is null";
/* 1317 */         paramDTV.setValue(paramDate.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Timestamp paramTimestamp) throws SQLServerException
/*      */     {
/* 1323 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 1325 */         assert (paramTimestamp != null) : "value is null";
/* 1326 */         paramDTV.setValue(paramTimestamp.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, DateTimeOffset paramDateTimeOffset)
/*      */       throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Float paramFloat) throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Double paramDouble) throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, BigDecimal paramBigDecimal) throws SQLServerException
/*      */     {
/* 1345 */       if (null != paramBigDecimal)
/*      */       {
/* 1347 */         Integer localInteger = paramDTV.getScale();
/* 1348 */         if ((null != localInteger) && (localInteger.intValue() != paramBigDecimal.scale())) {
/* 1349 */           paramBigDecimal = paramBigDecimal.setScale(localInteger.intValue(), 1);
/*      */         }
/*      */       }
/* 1352 */       paramDTV.setValue(paramBigDecimal, JavaType.BIGDECIMAL);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Long paramLong) throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Short paramShort) throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Boolean paramBoolean) throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, byte[] paramArrayOfByte) throws SQLServerException
/*      */     {
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Blob paramBlob) throws SQLServerException
/*      */     {
/* 1373 */       assert (null != paramBlob);
/*      */       try
/*      */       {
/* 1382 */         DataTypes.getCheckedLength(this.con, paramDTV.getJdbcType(), paramBlob.length(), false);
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/* 1386 */         SQLServerException.makeFromDriverError(this.con, null, localSQLException.getMessage(), null, false);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, InputStream paramInputStream) throws SQLServerException
/*      */     {
/* 1392 */       DataTypes.getCheckedLength(this.con, paramDTV.getJdbcType(), paramDTV.getStreamSetterArgs().getLength(), true);
/*      */ 
/* 1395 */       if ((JDBCType.NCHAR == AppDTVImpl.this.jdbcType) || (JDBCType.NVARCHAR == AppDTVImpl.this.jdbcType) || (JDBCType.LONGNVARCHAR == AppDTVImpl.this.jdbcType))
/*      */       {
/* 1399 */         InputStreamReader localInputStreamReader = null;
/*      */         try
/*      */         {
/* 1402 */           localInputStreamReader = new InputStreamReader(paramInputStream, "US-ASCII");
/*      */         }
/*      */         catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */         {
/* 1406 */           throw new SQLServerException(null, localUnsupportedEncodingException.getMessage(), null, 0, true);
/*      */         }
/*      */ 
/* 1409 */         paramDTV.setValue(localInputStreamReader, JavaType.READER);
/*      */ 
/* 1416 */         execute(paramDTV, localInputStreamReader);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Reader paramReader)
/*      */       throws SQLServerException
/*      */     {
/* 1423 */       assert (null != paramReader);
/*      */ 
/* 1425 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/* 1426 */       long l = DataTypes.getCheckedLength(this.con, paramDTV.getJdbcType(), paramDTV.getStreamSetterArgs().getLength(), true);
/*      */       Object localObject1;
/*      */       Object localObject2;
/* 1428 */       if (localJDBCType.isBinary())
/*      */       {
/* 1435 */         localObject1 = DDC.convertReaderToString(paramReader, (int)l);
/*      */ 
/* 1439 */         if ((-1L != l) && (((String)localObject1).length() != l))
/*      */         {
/* 1441 */           MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 1442 */           localObject2 = new Object[] { Long.valueOf(l), Integer.valueOf(((String)localObject1).length()) };
/* 1443 */           SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(localObject2), "", true);
/*      */         }
/*      */ 
/* 1446 */         paramDTV.setValue(localObject1, JavaType.STRING);
/* 1447 */         execute(paramDTV, (String)localObject1);
/*      */       }
/* 1451 */       else if ((null != this.collation) && ((JDBCType.CHAR == localJDBCType) || (JDBCType.VARCHAR == localJDBCType) || (JDBCType.LONGVARCHAR == localJDBCType) || (JDBCType.CLOB == localJDBCType)))
/*      */       {
/* 1457 */         localObject1 = null;
/*      */         try
/*      */         {
/* 1461 */           localObject1 = new ReaderInputStream(paramReader, this.collation.getCharset(), l);
/*      */         }
/*      */         catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */         {
/* 1468 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
/* 1469 */           Object[] arrayOfObject = { new String(localUnsupportedEncodingException.getMessage()) };
/* 1470 */           SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject2).format(arrayOfObject), null, true);
/*      */         }
/*      */ 
/* 1478 */         paramDTV.setValue(localObject1, JavaType.INPUTSTREAM);
/*      */ 
/* 1481 */         paramDTV.setStreamSetterArgs(new StreamSetterArgs(StreamType.CHARACTER, -1L));
/* 1482 */         execute(paramDTV, (InputStream)localObject1);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.AppDTVImpl
 * JD-Core Version:    0.6.0
 */