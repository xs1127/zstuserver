/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ final class SQLCollation
/*     */   implements Serializable
/*     */ {
/*     */   private final int info;
/*     */   private final int sortId;
/*     */   private final Encoding encoding;
/* 512 */   private static final Map<Integer, WindowsLocale> localeIndex = new HashMap();
/*     */   private static final HashMap<Integer, SortOrder> sortOrderIndex;
/*     */ 
/*     */   private final int langID()
/*     */   {
/*  32 */     return this.info & 0xFFFF;
/*     */   }
/*     */ 
/*     */   final String getCharset()
/*     */   {
/*  37 */     return this.encoding.charsetName(); } 
/*  38 */   final boolean supportsAsciiConversion() { return this.encoding.supportsAsciiConversion(); } 
/*  39 */   final boolean hasAsciiCompatibleSBCS() { return this.encoding.hasAsciiCompatibleSBCS(); } 
/*     */   static final int tdsLength() {
/*  41 */     return 5;
/*     */   }
/*     */ 
/*     */   SQLCollation(TDSReader paramTDSReader)
/*     */     throws UnsupportedEncodingException, SQLServerException
/*     */   {
/*  51 */     this.info = paramTDSReader.readInt();
/*  52 */     this.sortId = paramTDSReader.readUnsignedByte();
/*  53 */     this.encoding = (0 == this.sortId ? encodingFromLCID() : encodingFromSortId());
/*     */   }
/*     */ 
/*     */   void writeCollation(TDSWriter paramTDSWriter)
/*     */     throws SQLServerException
/*     */   {
/*  62 */     paramTDSWriter.writeInt(this.info);
/*  63 */     paramTDSWriter.writeByte((byte)(this.sortId & 0xFF));
/*     */   }
/*     */ 
/*     */   private Encoding encodingFromLCID()
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 312 */     WindowsLocale localWindowsLocale = (WindowsLocale)localeIndex.get(Integer.valueOf(langID()));
/*     */     Object localObject;
/* 314 */     if (null == localWindowsLocale)
/*     */     {
/* 316 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownLCID"));
/* 317 */       localObject = new Object[] { Integer.toHexString(langID()).toUpperCase() };
/* 318 */       throw new UnsupportedEncodingException(localMessageFormat.format(localObject));
/*     */     }
/*     */     UnsupportedEncodingException localUnsupportedEncodingException2;
/*     */     try {
/* 323 */       return localWindowsLocale.getEncoding();
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException1)
/*     */     {
/* 327 */       localObject = new MessageFormat(SQLServerException.getErrString("R_unknownLCID"));
/* 328 */       Object[] arrayOfObject = { localWindowsLocale };
/* 329 */       localUnsupportedEncodingException2 = new UnsupportedEncodingException(((MessageFormat)localObject).format(arrayOfObject));
/* 330 */       localUnsupportedEncodingException2.initCause(localUnsupportedEncodingException1);
/* 331 */     }throw localUnsupportedEncodingException2;
/*     */   }
/*     */ 
/*     */   private Encoding encodingFromSortId()
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 485 */     SortOrder localSortOrder = (SortOrder)sortOrderIndex.get(Integer.valueOf(this.sortId));
/*     */     Object localObject;
/* 487 */     if (null == localSortOrder)
/*     */     {
/* 489 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownSortId"));
/* 490 */       localObject = new Object[] { Integer.valueOf(this.sortId) };
/* 491 */       throw new UnsupportedEncodingException(localMessageFormat.format(localObject));
/*     */     }
/*     */     UnsupportedEncodingException localUnsupportedEncodingException2;
/*     */     try {
/* 496 */       return localSortOrder.getEncoding();
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException1)
/*     */     {
/* 500 */       localObject = new MessageFormat(SQLServerException.getErrString("R_unknownSortId"));
/* 501 */       Object[] arrayOfObject = { localSortOrder };
/* 502 */       localUnsupportedEncodingException2 = new UnsupportedEncodingException(((MessageFormat)localObject).format(arrayOfObject));
/* 503 */       localUnsupportedEncodingException2.initCause(localUnsupportedEncodingException1);
/* 504 */     }throw localUnsupportedEncodingException2;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 513 */     for (Iterator localIterator = EnumSet.allOf(WindowsLocale.class).iterator(); localIterator.hasNext(); ) { localObject = (WindowsLocale)localIterator.next();
/* 514 */       localeIndex.put(Integer.valueOf(((WindowsLocale)localObject).langID), localObject);
/*     */     }
/* 517 */     Object localObject;
/* 516 */     sortOrderIndex = new HashMap();
/* 517 */     for (localIterator = EnumSet.allOf(SortOrder.class).iterator(); localIterator.hasNext(); ) { localObject = (SortOrder)localIterator.next();
/* 518 */       sortOrderIndex.put(Integer.valueOf(((SortOrder)localObject).sortId), localObject);
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum SortOrder
/*     */   {
/* 343 */     BIN_CP437(30, "SQL_Latin1_General_CP437_BIN", Encoding.CP437), 
/* 344 */     DICTIONARY_437(31, "SQL_Latin1_General_CP437_CS_AS", Encoding.CP437), 
/* 345 */     NOCASE_437(32, "SQL_Latin1_General_CP437_CI_AS", Encoding.CP437), 
/* 346 */     NOCASEPREF_437(33, "SQL_Latin1_General_Pref_CP437_CI_AS", Encoding.CP437), 
/* 347 */     NOACCENTS_437(34, "SQL_Latin1_General_CP437_CI_AI", Encoding.CP437), 
/* 348 */     BIN2_CP437(35, "SQL_Latin1_General_CP437_BIN2", Encoding.CP437), 
/*     */ 
/* 350 */     BIN_CP850(40, "SQL_Latin1_General_CP850_BIN", Encoding.CP850), 
/* 351 */     DICTIONARY_850(41, "SQL_Latin1_General_CP850_CS_AS", Encoding.CP850), 
/* 352 */     NOCASE_850(42, "SQL_Latin1_General_CP850_CI_AS", Encoding.CP850), 
/* 353 */     NOCASEPREF_850(43, "SQL_Latin1_General_Pref_CP850_CI_AS", Encoding.CP850), 
/* 354 */     NOACCENTS_850(44, "SQL_Latin1_General_CP850_CI_AI", Encoding.CP850), 
/* 355 */     BIN2_CP850(45, "SQL_Latin1_General_CP850_BIN2", Encoding.CP850), 
/*     */ 
/* 357 */     CASELESS_34(49, "SQL_1xCompat_CP850_CI_AS", Encoding.CP850), 
/* 358 */     BIN_ISO_1(50, "bin_iso_1", Encoding.CP1252), 
/* 359 */     DICTIONARY_ISO(51, "SQL_Latin1_General_CP1_CS_AS", Encoding.CP1252), 
/* 360 */     NOCASE_ISO(52, "SQL_Latin1_General_CP1_CI_AS", Encoding.CP1252), 
/* 361 */     NOCASEPREF_ISO(53, "SQL_Latin1_General_Pref_CP1_CI_AS", Encoding.CP1252), 
/* 362 */     NOACCENTS_ISO(54, "SQL_Latin1_General_CP1_CI_AI", Encoding.CP1252), 
/* 363 */     ALT_DICTIONARY(55, "SQL_AltDiction_CP850_CS_AS", Encoding.CP850), 
/* 364 */     ALT_NOCASEPREF(56, "SQL_AltDiction_Pref_CP850_CI_AS", Encoding.CP850), 
/* 365 */     ALT_NOACCENTS(57, "SQL_AltDiction_CP850_CI_AI", Encoding.CP850), 
/* 366 */     SCAND_NOCASEPREF(58, "SQL_Scandinavian_Pref_CP850_CI_AS", Encoding.CP850), 
/* 367 */     SCAND_DICTIONARY(59, "SQL_Scandinavian_CP850_CS_AS", Encoding.CP850), 
/* 368 */     SCAND_NOCASE(60, "SQL_Scandinavian_CP850_CI_AS", Encoding.CP850), 
/* 369 */     ALT_NOCASE(61, "SQL_AltDiction_CP850_CI_AS", Encoding.CP850), 
/*     */ 
/* 371 */     DICTIONARY_1252(71, "dictionary_1252", Encoding.CP1252), 
/* 372 */     NOCASE_1252(72, "nocase_1252", Encoding.CP1252), 
/* 373 */     DNK_NOR_DICTIONARY(73, "dnk_nor_dictionary", Encoding.CP1252), 
/* 374 */     FIN_SWE_DICTIONARY(74, "fin_swe_dictionary", Encoding.CP1252), 
/* 375 */     ISL_DICTIONARY(75, "isl_dictionary", Encoding.CP1252), 
/*     */ 
/* 377 */     BIN_CP1250(80, "bin_cp1250", Encoding.CP1250), 
/* 378 */     DICTIONARY_1250(81, "SQL_Latin1_General_CP1250_CS_AS", Encoding.CP1250), 
/* 379 */     NOCASE_1250(82, "SQL_Latin1_General_CP1250_CI_AS", Encoding.CP1250), 
/* 380 */     CSYDIC(83, "SQL_Czech_CP1250_CS_AS", Encoding.CP1250), 
/* 381 */     CSYNC(84, "SQL_Czech_CP1250_CI_AS", Encoding.CP1250), 
/* 382 */     HUNDIC(85, "SQL_Hungarian_CP1250_CS_AS", Encoding.CP1250), 
/* 383 */     HUNNC(86, "SQL_Hungarian_CP1250_CI_AS", Encoding.CP1250), 
/* 384 */     PLKDIC(87, "SQL_Polish_CP1250_CS_AS", Encoding.CP1250), 
/* 385 */     PLKNC(88, "SQL_Polish_CP1250_CI_AS", Encoding.CP1250), 
/* 386 */     ROMDIC(89, "SQL_Romanian_CP1250_CS_AS", Encoding.CP1250), 
/* 387 */     ROMNC(90, "SQL_Romanian_CP1250_CI_AS", Encoding.CP1250), 
/* 388 */     SHLDIC(91, "SQL_Croatian_CP1250_CS_AS", Encoding.CP1250), 
/* 389 */     SHLNC(92, "SQL_Croatian_CP1250_CI_AS", Encoding.CP1250), 
/* 390 */     SKYDIC(93, "SQL_Slovak_CP1250_CS_AS", Encoding.CP1250), 
/* 391 */     SKYNC(94, "SQL_Slovak_CP1250_CI_AS", Encoding.CP1250), 
/* 392 */     SLVDIC(95, "SQL_Slovenian_CP1250_CS_AS", Encoding.CP1250), 
/* 393 */     SLVNC(96, "SQL_Slovenian_CP1250_CI_AS", Encoding.CP1250), 
/* 394 */     POLISH_CS(97, "polish_cs", Encoding.CP1250), 
/* 395 */     POLISH_CI(98, "polish_ci", Encoding.CP1250), 
/*     */ 
/* 397 */     BIN_CP1251(104, "bin_cp1251", Encoding.CP1251), 
/* 398 */     DICTIONARY_1251(105, "SQL_Latin1_General_CP1251_CS_AS", Encoding.CP1251), 
/* 399 */     NOCASE_1251(106, "SQL_Latin1_General_CP1251_CI_AS", Encoding.CP1251), 
/* 400 */     UKRDIC(107, "SQL_Ukrainian_CP1251_CS_AS", Encoding.CP1251), 
/* 401 */     UKRNC(108, "SQL_Ukrainian_CP1251_CI_AS", Encoding.CP1251), 
/*     */ 
/* 403 */     BIN_CP1253(112, "bin_cp1253", Encoding.CP1253), 
/* 404 */     DICTIONARY_1253(113, "SQL_Latin1_General_CP1253_CS_AS", Encoding.CP1253), 
/* 405 */     NOCASE_1253(114, "SQL_Latin1_General_CP1253_CI_AS", Encoding.CP1253), 
/*     */ 
/* 407 */     GREEK_MIXEDDICTIONARY(120, "SQL_MixDiction_CP1253_CS_AS", Encoding.CP1253), 
/* 408 */     GREEK_ALTDICTIONARY(121, "SQL_AltDiction_CP1253_CS_AS", Encoding.CP1253), 
/* 409 */     GREEK_ALTDICTIONARY2(122, "SQL_AltDiction2_CP1253_CS_AS", Encoding.CP1253), 
/* 410 */     GREEK_NOCASEDICT(124, "SQL_Latin1_General_CP1253_CI_AI", Encoding.CP1253), 
/* 411 */     BIN_CP1254(128, "bin_cp1254", Encoding.CP1254), 
/* 412 */     DICTIONARY_1254(129, "SQL_Latin1_General_CP1254_CS_AS", Encoding.CP1254), 
/* 413 */     NOCASE_1254(130, "SQL_Latin1_General_CP1254_CI_AS", Encoding.CP1254), 
/*     */ 
/* 415 */     BIN_CP1255(136, "bin_cp1255", Encoding.CP1255), 
/* 416 */     DICTIONARY_1255(137, "SQL_Latin1_General_CP1255_CS_AS", Encoding.CP1255), 
/* 417 */     NOCASE_1255(138, "SQL_Latin1_General_CP1255_CI_AS", Encoding.CP1255), 
/*     */ 
/* 419 */     BIN_CP1256(144, "bin_cp1256", Encoding.CP1256), 
/* 420 */     DICTIONARY_1256(145, "SQL_Latin1_General_CP1256_CS_AS", Encoding.CP1256), 
/* 421 */     NOCASE_1256(146, "SQL_Latin1_General_CP1256_CI_AS", Encoding.CP1256), 
/*     */ 
/* 423 */     BIN_CP1257(152, "bin_cp1257", Encoding.CP1257), 
/* 424 */     DICTIONARY_1257(153, "SQL_Latin1_General_CP1257_CS_AS", Encoding.CP1257), 
/* 425 */     NOCASE_1257(154, "SQL_Latin1_General_CP1257_CI_AS", Encoding.CP1257), 
/* 426 */     ETIDIC(155, "SQL_Estonian_CP1257_CS_AS", Encoding.CP1257), 
/* 427 */     ETINC(156, "SQL_Estonian_CP1257_CI_AS", Encoding.CP1257), 
/* 428 */     LVIDIC(157, "SQL_Latvian_CP1257_CS_AS", Encoding.CP1257), 
/* 429 */     LVINC(158, "SQL_Latvian_CP1257_CI_AS", Encoding.CP1257), 
/* 430 */     LTHDIC(159, "SQL_Lithuanian_CP1257_CS_AS", Encoding.CP1257), 
/* 431 */     LTHNC(160, "SQL_Lithuanian_CP1257_CI_AS", Encoding.CP1257), 
/*     */ 
/* 433 */     DANNO_NOCASEPREF(183, "SQL_Danish_Pref_CP1_CI_AS", Encoding.CP1252), 
/* 434 */     SVFI1_NOCASEPREF(184, "SQL_SwedishPhone_Pref_CP1_CI_AS", Encoding.CP1252), 
/* 435 */     SVFI2_NOCASEPREF(185, "SQL_SwedishStd_Pref_CP1_CI_AS", Encoding.CP1252), 
/* 436 */     ISLAN_NOCASEPREF(186, "SQL_Icelandic_Pref_CP1_CI_AS", Encoding.CP1252), 
/*     */ 
/* 438 */     BIN_CP932(192, "bin_cp932", Encoding.CP932), 
/* 439 */     NLS_CP932(193, "nls_cp932", Encoding.CP932), 
/* 440 */     BIN_CP949(194, "bin_cp949", Encoding.CP949), 
/* 441 */     NLS_CP949(195, "nls_cp949", Encoding.CP949), 
/* 442 */     BIN_CP950(196, "bin_cp950", Encoding.CP950), 
/* 443 */     NLS_CP950(197, "nls_cp950", Encoding.CP950), 
/* 444 */     BIN_CP936(198, "bin_cp936", Encoding.CP936), 
/* 445 */     NLS_CP936(199, "nls_cp936", Encoding.CP936), 
/* 446 */     NLS_CP932_CS(200, "nls_cp932_cs", Encoding.CP932), 
/* 447 */     NLS_CP949_CS(201, "nls_cp949_cs", Encoding.CP949), 
/* 448 */     NLS_CP950_CS(202, "nls_cp950_cs", Encoding.CP950), 
/* 449 */     NLS_CP936_CS(203, "nls_cp936_cs", Encoding.CP936), 
/* 450 */     BIN_CP874(204, "bin_cp874", Encoding.CP874), 
/* 451 */     NLS_CP874(205, "nls_cp874", Encoding.CP874), 
/* 452 */     NLS_CP874_CS(206, "nls_cp874_cs", Encoding.CP874), 
/*     */ 
/* 454 */     EBCDIC_037(210, "SQL_EBCDIC037_CP1_CS_AS", Encoding.CP1252), 
/* 455 */     EBCDIC_273(211, "SQL_EBCDIC273_CP1_CS_AS", Encoding.CP1252), 
/* 456 */     EBCDIC_277(212, "SQL_EBCDIC277_CP1_CS_AS", Encoding.CP1252), 
/* 457 */     EBCDIC_278(213, "SQL_EBCDIC278_CP1_CS_AS", Encoding.CP1252), 
/* 458 */     EBCDIC_280(214, "SQL_EBCDIC280_CP1_CS_AS", Encoding.CP1252), 
/* 459 */     EBCDIC_284(215, "SQL_EBCDIC284_CP1_CS_AS", Encoding.CP1252), 
/* 460 */     EBCDIC_285(216, "SQL_EBCDIC285_CP1_CS_AS", Encoding.CP1252), 
/* 461 */     EBCDIC_297(217, "SQL_EBCDIC297_CP1_CS_AS", Encoding.CP1252);
/*     */ 
/*     */     private final int sortId;
/*     */     private final String name;
/*     */     private final Encoding encoding;
/*     */ 
/* 468 */     final Encoding getEncoding() throws UnsupportedEncodingException { return this.encoding.checkSupported();
/*     */     }
/*     */ 
/*     */     private SortOrder(int paramInt, String paramString, Encoding paramEncoding)
/*     */     {
/* 473 */       this.sortId = paramInt;
/* 474 */       this.name = paramString;
/* 475 */       this.encoding = paramEncoding;
/*     */     }
/*     */     public final String toString() {
/* 478 */       return this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum WindowsLocale
/*     */   {
/*  83 */     ar_SA(1025, Encoding.CP1256), 
/*  84 */     bg_BG(1026, Encoding.CP1251), 
/*  85 */     ca_ES(1027, Encoding.CP1252), 
/*  86 */     zh_TW(1028, Encoding.CP950), 
/*  87 */     cs_CZ(1029, Encoding.CP1250), 
/*  88 */     da_DK(1030, Encoding.CP1252), 
/*  89 */     de_DE(1031, Encoding.CP1252), 
/*  90 */     el_GR(1032, Encoding.CP1253), 
/*  91 */     en_US(1033, Encoding.CP1252), 
/*  92 */     es_ES_tradnl(1034, Encoding.CP1252), 
/*  93 */     fi_FI(1035, Encoding.CP1252), 
/*  94 */     fr_FR(1036, Encoding.CP1252), 
/*  95 */     he_IL(1037, Encoding.CP1255), 
/*  96 */     hu_HU(1038, Encoding.CP1250), 
/*  97 */     is_IS(1039, Encoding.CP1252), 
/*  98 */     it_IT(1040, Encoding.CP1252), 
/*  99 */     ja_JP(1041, Encoding.CP932), 
/* 100 */     ko_KR(1042, Encoding.CP949), 
/* 101 */     nl_NL(1043, Encoding.CP1252), 
/* 102 */     nb_NO(1044, Encoding.CP1252), 
/* 103 */     pl_PL(1045, Encoding.CP1250), 
/* 104 */     pt_BR(1046, Encoding.CP1252), 
/* 105 */     rm_CH(1047, Encoding.CP1252), 
/* 106 */     ro_RO(1048, Encoding.CP1250), 
/* 107 */     ru_RU(1049, Encoding.CP1251), 
/* 108 */     hr_HR(1050, Encoding.CP1250), 
/* 109 */     sk_SK(1051, Encoding.CP1250), 
/* 110 */     sq_AL(1052, Encoding.CP1250), 
/* 111 */     sv_SE(1053, Encoding.CP1252), 
/* 112 */     th_TH(1054, Encoding.CP874), 
/* 113 */     tr_TR(1055, Encoding.CP1254), 
/* 114 */     ur_PK(1056, Encoding.CP1256), 
/* 115 */     id_ID(1057, Encoding.CP1252), 
/* 116 */     uk_UA(1058, Encoding.CP1251), 
/* 117 */     be_BY(1059, Encoding.CP1251), 
/* 118 */     sl_SI(1060, Encoding.CP1250), 
/* 119 */     et_EE(1061, Encoding.CP1257), 
/* 120 */     lv_LV(1062, Encoding.CP1257), 
/* 121 */     lt_LT(1063, Encoding.CP1257), 
/* 122 */     tg_Cyrl_TJ(1064, Encoding.CP1251), 
/* 123 */     fa_IR(1065, Encoding.CP1256), 
/* 124 */     vi_VN(1066, Encoding.CP1258), 
/* 125 */     hy_AM(1067, Encoding.CP1252), 
/* 126 */     az_Latn_AZ(1068, Encoding.CP1254), 
/* 127 */     eu_ES(1069, Encoding.CP1252), 
/* 128 */     wen_DE(1070, Encoding.CP1252), 
/* 129 */     mk_MK(1071, Encoding.CP1251), 
/* 130 */     tn_ZA(1074, Encoding.CP1252), 
/* 131 */     xh_ZA(1076, Encoding.CP1252), 
/* 132 */     zu_ZA(1077, Encoding.CP1252), 
/* 133 */     Af_ZA(1078, Encoding.CP1252), 
/* 134 */     ka_GE(1079, Encoding.CP1252), 
/* 135 */     fo_FO(1080, Encoding.CP1252), 
/* 136 */     hi_IN(1081, Encoding.UNICODE), 
/* 137 */     mt_MT(1082, Encoding.UNICODE), 
/* 138 */     se_NO(1083, Encoding.CP1252), 
/* 139 */     ms_MY(1086, Encoding.CP1252), 
/* 140 */     kk_KZ(1087, Encoding.CP1251), 
/* 141 */     ky_KG(1088, Encoding.CP1251), 
/* 142 */     sw_KE(1089, Encoding.CP1252), 
/* 143 */     tk_TM(1090, Encoding.CP1250), 
/* 144 */     uz_Latn_UZ(1091, Encoding.CP1254), 
/* 145 */     tt_RU(1092, Encoding.CP1251), 
/* 146 */     bn_IN(1093, Encoding.UNICODE), 
/* 147 */     pa_IN(1094, Encoding.UNICODE), 
/* 148 */     gu_IN(1095, Encoding.UNICODE), 
/* 149 */     or_IN(1096, Encoding.UNICODE), 
/* 150 */     ta_IN(1097, Encoding.UNICODE), 
/* 151 */     te_IN(1098, Encoding.UNICODE), 
/* 152 */     kn_IN(1099, Encoding.UNICODE), 
/* 153 */     ml_IN(1100, Encoding.UNICODE), 
/* 154 */     as_IN(1101, Encoding.UNICODE), 
/* 155 */     mr_IN(1102, Encoding.UNICODE), 
/* 156 */     sa_IN(1103, Encoding.UNICODE), 
/* 157 */     mn_MN(1104, Encoding.CP1251), 
/* 158 */     bo_CN(1105, Encoding.UNICODE), 
/* 159 */     cy_GB(1106, Encoding.CP1252), 
/* 160 */     km_KH(1107, Encoding.UNICODE), 
/* 161 */     lo_LA(1108, Encoding.UNICODE), 
/* 162 */     gl_ES(1110, Encoding.CP1252), 
/* 163 */     kok_IN(1111, Encoding.UNICODE), 
/* 164 */     syr_SY(1114, Encoding.UNICODE), 
/* 165 */     si_LK(1115, Encoding.UNICODE), 
/* 166 */     iu_Cans_CA(1117, Encoding.CP1252), 
/* 167 */     am_ET(1118, Encoding.CP1252), 
/* 168 */     ne_NP(1121, Encoding.UNICODE), 
/* 169 */     fy_NL(1122, Encoding.CP1252), 
/* 170 */     ps_AF(1123, Encoding.UNICODE), 
/* 171 */     fil_PH(1124, Encoding.CP1252), 
/* 172 */     dv_MV(1125, Encoding.UNICODE), 
/* 173 */     ha_Latn_NG(1128, Encoding.CP1252), 
/* 174 */     yo_NG(1130, Encoding.CP1252), 
/* 175 */     quz_BO(1131, Encoding.CP1252), 
/* 176 */     nso_ZA(1132, Encoding.CP1252), 
/* 177 */     ba_RU(1133, Encoding.CP1251), 
/* 178 */     lb_LU(1134, Encoding.CP1252), 
/* 179 */     kl_GL(1135, Encoding.CP1252), 
/* 180 */     ig_NG(1136, Encoding.CP1252), 
/* 181 */     ii_CN(1144, Encoding.CP1252), 
/* 182 */     arn_CL(1146, Encoding.CP1252), 
/* 183 */     moh_CA(1148, Encoding.CP1252), 
/* 184 */     br_FR(1150, Encoding.CP1252), 
/* 185 */     ug_CN(1152, Encoding.CP1256), 
/* 186 */     mi_NZ(1153, Encoding.UNICODE), 
/* 187 */     oc_FR(1154, Encoding.CP1252), 
/* 188 */     co_FR(1155, Encoding.CP1252), 
/* 189 */     gsw_FR(1156, Encoding.CP1252), 
/* 190 */     sah_RU(1157, Encoding.CP1251), 
/* 191 */     qut_GT(1158, Encoding.CP1252), 
/* 192 */     rw_RW(1159, Encoding.CP1252), 
/* 193 */     wo_SN(1160, Encoding.CP1252), 
/* 194 */     prs_AF(1164, Encoding.CP1256), 
/* 195 */     ar_IQ(2049, Encoding.CP1256), 
/* 196 */     zh_CN(2052, Encoding.CP936), 
/* 197 */     de_CH(2055, Encoding.CP1252), 
/* 198 */     en_GB(2057, Encoding.CP1252), 
/* 199 */     es_MX(2058, Encoding.CP1252), 
/* 200 */     fr_BE(2060, Encoding.CP1252), 
/* 201 */     it_CH(2064, Encoding.CP1252), 
/* 202 */     nl_BE(2067, Encoding.CP1252), 
/* 203 */     nn_NO(2068, Encoding.CP1252), 
/* 204 */     pt_PT(2070, Encoding.CP1252), 
/* 205 */     sr_Latn_CS(2074, Encoding.CP1250), 
/* 206 */     sv_FI(2077, Encoding.CP1252), 
/* 207 */     Lithuanian_Classic(2087, Encoding.CP1257), 
/* 208 */     az_Cyrl_AZ(2092, Encoding.CP1251), 
/* 209 */     dsb_DE(2094, Encoding.CP1252), 
/* 210 */     se_SE(2107, Encoding.CP1252), 
/* 211 */     ga_IE(2108, Encoding.CP1252), 
/* 212 */     ms_BN(2110, Encoding.CP1252), 
/* 213 */     uz_Cyrl_UZ(2115, Encoding.CP1251), 
/* 214 */     bn_BD(2117, Encoding.UNICODE), 
/* 215 */     mn_Mong_CN(2128, Encoding.CP1251), 
/* 216 */     iu_Latn_CA(2141, Encoding.CP1252), 
/* 217 */     tzm_Latn_DZ(2143, Encoding.CP1252), 
/* 218 */     quz_EC(2155, Encoding.CP1252), 
/* 219 */     ar_EG(3073, Encoding.CP1256), 
/* 220 */     zh_HK(3076, Encoding.CP950), 
/* 221 */     de_AT(3079, Encoding.CP1252), 
/* 222 */     en_AU(3081, Encoding.CP1252), 
/* 223 */     es_ES(3082, Encoding.CP1252), 
/* 224 */     fr_CA(3084, Encoding.CP1252), 
/* 225 */     sr_Cyrl_CS(3098, Encoding.CP1251), 
/* 226 */     se_FI(3131, Encoding.CP1252), 
/* 227 */     quz_PE(3179, Encoding.CP1252), 
/* 228 */     ar_LY(4097, Encoding.CP1256), 
/* 229 */     zh_SG(4100, Encoding.CP936), 
/* 230 */     de_LU(4103, Encoding.CP1252), 
/* 231 */     en_CA(4105, Encoding.CP1252), 
/* 232 */     es_GT(4106, Encoding.CP1252), 
/* 233 */     fr_CH(4108, Encoding.CP1252), 
/* 234 */     hr_BA(4122, Encoding.CP1250), 
/* 235 */     smj_NO(4155, Encoding.CP1252), 
/* 236 */     ar_DZ(5121, Encoding.CP1256), 
/* 237 */     zh_MO(5124, Encoding.CP950), 
/* 238 */     de_LI(5127, Encoding.CP1252), 
/* 239 */     en_NZ(5129, Encoding.CP1252), 
/* 240 */     es_CR(5130, Encoding.CP1252), 
/* 241 */     fr_LU(5132, Encoding.CP1252), 
/* 242 */     bs_Latn_BA(5146, Encoding.CP1250), 
/* 243 */     smj_SE(5179, Encoding.CP1252), 
/* 244 */     ar_MA(6145, Encoding.CP1256), 
/* 245 */     en_IE(6153, Encoding.CP1252), 
/* 246 */     es_PA(6154, Encoding.CP1252), 
/* 247 */     fr_MC(6156, Encoding.CP1252), 
/* 248 */     sr_Latn_BA(6170, Encoding.CP1250), 
/* 249 */     sma_NO(6203, Encoding.CP1252), 
/* 250 */     ar_TN(7169, Encoding.CP1256), 
/* 251 */     en_ZA(7177, Encoding.CP1252), 
/* 252 */     es_DO(7178, Encoding.CP1252), 
/* 253 */     sr_Cyrl_BA(7194, Encoding.CP1251), 
/* 254 */     sma_SB(7227, Encoding.CP1252), 
/* 255 */     ar_OM(8193, Encoding.CP1256), 
/* 256 */     en_JM(8201, Encoding.CP1252), 
/* 257 */     es_VE(8202, Encoding.CP1252), 
/* 258 */     bs_Cyrl_BA(8218, Encoding.CP1251), 
/* 259 */     sms_FI(8251, Encoding.CP1252), 
/* 260 */     ar_YE(9217, Encoding.CP1256), 
/* 261 */     en_CB(9225, Encoding.CP1252), 
/* 262 */     es_CO(9226, Encoding.CP1252), 
/* 263 */     smn_FI(9275, Encoding.CP1252), 
/* 264 */     ar_SY(10241, Encoding.CP1256), 
/* 265 */     en_BZ(10249, Encoding.CP1252), 
/* 266 */     es_PE(10250, Encoding.CP1252), 
/* 267 */     ar_JO(11265, Encoding.CP1256), 
/* 268 */     en_TT(11273, Encoding.CP1252), 
/* 269 */     es_AR(11274, Encoding.CP1252), 
/* 270 */     ar_LB(12289, Encoding.CP1256), 
/* 271 */     en_ZW(12297, Encoding.CP1252), 
/* 272 */     es_EC(12298, Encoding.CP1252), 
/* 273 */     ar_KW(13313, Encoding.CP1256), 
/* 274 */     en_PH(13321, Encoding.CP1252), 
/* 275 */     es_CL(13322, Encoding.CP1252), 
/* 276 */     ar_AE(14337, Encoding.CP1256), 
/* 277 */     es_UY(14346, Encoding.CP1252), 
/* 278 */     ar_BH(15361, Encoding.CP1256), 
/* 279 */     es_PY(15370, Encoding.CP1252), 
/* 280 */     ar_QA(16385, Encoding.CP1256), 
/* 281 */     en_IN(16393, Encoding.CP1252), 
/* 282 */     es_BO(16394, Encoding.CP1252), 
/* 283 */     en_MY(17417, Encoding.CP1252), 
/* 284 */     es_SV(17418, Encoding.CP1252), 
/* 285 */     en_SG(18441, Encoding.CP1252), 
/* 286 */     es_HN(18442, Encoding.CP1252), 
/* 287 */     es_NI(19466, Encoding.CP1252), 
/* 288 */     es_PR(20490, Encoding.CP1252), 
/* 289 */     es_US(21514, Encoding.CP1252);
/*     */ 
/*     */     private final int langID;
/*     */     private final Encoding encoding;
/*     */ 
/* 296 */     private WindowsLocale(int paramInt, Encoding paramEncoding) { this.langID = paramInt;
/* 297 */       this.encoding = paramEncoding; }
/*     */ 
/*     */     final Encoding getEncoding()
/*     */       throws UnsupportedEncodingException
/*     */     {
/* 302 */       return this.encoding.checkSupported();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLCollation
 * JD-Core Version:    0.6.0
 */