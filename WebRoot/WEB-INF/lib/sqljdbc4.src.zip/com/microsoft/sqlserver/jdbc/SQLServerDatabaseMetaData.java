/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowIdLifetime;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.EnumMap;
/*      */ import java.util.Properties;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ public final class SQLServerDatabaseMetaData
/*      */   implements DatabaseMetaData, Serializable
/*      */ {
/*      */   private SQLServerConnection connection;
/*      */   static final String urlprefix = "jdbc:sqlserver://";
/*      */   private static final Logger logger;
/*      */   private static final Logger loggerExternal;
/*      */   private static int baseID;
/*      */   private final String traceID;
/*   72 */   EnumMap<CallableHandles, HandleAssociation> handleMap = new EnumMap(CallableHandles.class);
/*      */   private static final String ASC_OR_DESC = "ASC_OR_DESC";
/*      */   private static final String ATTR_NAME = "ATTR_NAME";
/*      */   private static final String ATTR_TYPE_NAME = "ATTR_TYPE_NAME";
/*      */   private static final String ATTR_SIZE = "ATTR_SIZE";
/*      */   private static final String ATTR_DEF = "ATTR_DEF";
/*      */   private static final String BASE_TYPE = "BASE_TYPE";
/*      */   private static final String BUFFER_LENGTH = "BUFFER_LENGTH";
/*      */   private static final String CARDINALITY = "CARDINALITY";
/*      */   private static final String CHAR_OCTET_LENGTH = "CHAR_OCTET_LENGTH";
/*      */   private static final String CLASS_NAME = "CLASS_NAME";
/*      */   private static final String COLUMN_DEF = "COLUMN_DEF";
/*      */   private static final String COLUMN_NAME = "COLUMN_NAME";
/*      */   private static final String COLUMN_SIZE = "COLUMN_SIZE";
/*      */   private static final String COLUMN_TYPE = "COLUMN_TYPE";
/*      */   private static final String DATA_TYPE = "DATA_TYPE";
/*      */   private static final String DECIMAL_DIGITS = "DECIMAL_DIGITS";
/*      */   private static final String DEFERRABILITY = "DEFERRABILITY";
/*      */   private static final String DELETE_RULE = "DELETE_RULE";
/*      */   private static final String FILTER_CONDITION = "FILTER_CONDITION";
/*      */   private static final String FK_NAME = "FK_NAME";
/*      */   private static final String FKCOLUMN_NAME = "FKCOLUMN_NAME";
/*      */   private static final String FKTABLE_CAT = "FKTABLE_CAT";
/*      */   private static final String FKTABLE_NAME = "FKTABLE_NAME";
/*      */   private static final String FKTABLE_SCHEM = "FKTABLE_SCHEM";
/*      */   private static final String GRANTEE = "GRANTEE";
/*      */   private static final String GRANTOR = "GRANTOR";
/*      */   private static final String INDEX_NAME = "INDEX_NAME";
/*      */   private static final String INDEX_QUALIFIER = "INDEX_QUALIFIER";
/*      */   private static final String IS_GRANTABLE = "IS_GRANTABLE";
/*      */   private static final String IS_NULLABLE = "IS_NULLABLE";
/*      */   private static final String KEY_SEQ = "KEY_SEQ";
/*      */   private static final String LENGTH = "LENGTH";
/*      */   private static final String NON_UNIQUE = "NON_UNIQUE";
/*      */   private static final String NULLABLE = "NULLABLE";
/*      */   private static final String NUM_INPUT_PARAMS = "NUM_INPUT_PARAMS";
/*      */   private static final String NUM_OUTPUT_PARAMS = "NUM_OUTPUT_PARAMS";
/*      */   private static final String NUM_PREC_RADIX = "NUM_PREC_RADIX";
/*      */   private static final String NUM_RESULT_SETS = "NUM_RESULT_SETS";
/*      */   private static final String ORDINAL_POSITION = "ORDINAL_POSITION";
/*      */   private static final String PAGES = "PAGES";
/*      */   private static final String PK_NAME = "PK_NAME";
/*      */   private static final String PKCOLUMN_NAME = "PKCOLUMN_NAME";
/*      */   private static final String PKTABLE_CAT = "PKTABLE_CAT";
/*      */   private static final String PKTABLE_NAME = "PKTABLE_NAME";
/*      */   private static final String PKTABLE_SCHEM = "PKTABLE_SCHEM";
/*      */   private static final String PRECISION = "PRECISION";
/*      */   private static final String PRIVILEGE = "PRIVILEGE";
/*      */   private static final String PROCEDURE_CAT = "PROCEDURE_CAT";
/*      */   private static final String PROCEDURE_NAME = "PROCEDURE_NAME";
/*      */   private static final String PROCEDURE_SCHEM = "PROCEDURE_SCHEM";
/*      */   private static final String PROCEDURE_TYPE = "PROCEDURE_TYPE";
/*      */   private static final String PSEUDO_COLUMN = "PSEUDO_COLUMN";
/*      */   private static final String RADIX = "RADIX";
/*      */   private static final String REMARKS = "REMARKS";
/*      */   private static final String SCALE = "SCALE";
/*      */   private static final String SCOPE = "SCOPE";
/*      */   private static final String SCOPE_CATALOG = "SCOPE_CATALOG";
/*      */   private static final String SCOPE_SCHEMA = "SCOPE_SCHEMA";
/*      */   private static final String SCOPE_TABLE = "SCOPE_TABLE";
/*      */   private static final String SOURCE_DATA_TYPE = "SOURCE_DATA_TYPE";
/*      */   private static final String SQL_DATA_TYPE = "SQL_DATA_TYPE";
/*      */   private static final String SQL_DATETIME_SUB = "SQL_DATETIME_SUB";
/*      */   private static final String SS_DATA_TYPE = "SS_DATA_TYPE";
/*      */   private static final String SUPERTABLE_NAME = "SUPERTABLE_NAME";
/*      */   private static final String SUPERTYPE_CAT = "SUPERTYPE_CAT";
/*      */   private static final String SUPERTYPE_NAME = "SUPERTYPE_NAME";
/*      */   private static final String SUPERTYPE_SCHEM = "SUPERTYPE_SCHEM";
/*      */   private static final String TABLE_CAT = "TABLE_CAT";
/*      */   private static final String TABLE_NAME = "TABLE_NAME";
/*      */   private static final String TABLE_SCHEM = "TABLE_SCHEM";
/*      */   private static final String TABLE_TYPE = "TABLE_TYPE";
/*      */   private static final String TYPE = "TYPE";
/*      */   private static final String TYPE_CAT = "TYPE_CAT";
/*      */   private static final String TYPE_NAME = "TYPE_NAME";
/*      */   private static final String TYPE_SCHEM = "TYPE_SCHEM";
/*      */   private static final String UPDATE_RULE = "UPDATE_RULE";
/*      */   private static final String FUNCTION_CAT = "FUNCTION_CAT";
/*      */   private static final String FUNCTION_NAME = "FUNCTION_NAME";
/*      */   private static final String FUNCTION_SCHEM = "FUNCTION_SCHEM";
/*      */   private static final String FUNCTION_TYPE = "FUNCTION_TYPE";
/*      */   private static final String SS_IS_SPARSE = "SS_IS_SPARSE";
/*      */   private static final String SS_IS_COLUMN_SET = "SS_IS_COLUMN_SET";
/*      */   private static final String SS_IS_COMPUTED = "SS_IS_COMPUTED";
/*      */   private static final String IS_AUTOINCREMENT = "IS_AUTOINCREMENT";
/*      */   private static final String[] getColumnPrivilegesColumnNames;
/*      */   private static final String[] getTablesColumnNames;
/*      */   static final char LEFT_BRACKET = '[';
/*      */   static final char RIGHT_BRACKET = ']';
/*      */   static final char ESCAPE = '\\';
/*      */   static final char PERCENT = '%';
/*      */   static final char UNDERSCORE = '_';
/*      */   static final char[] DOUBLE_RIGHT_BRACKET;
/*      */   private static final String[] getColumnsColumnNames;
/*      */   private static final String[] getColumnsColumnNamesKatmai;
/*      */   private static final String[] getFunctionsColumnNames;
/*      */   private static final String[] getFunctionsColumnsColumnNames;
/*      */   private static final String[] getBestRowIdentifierColumnNames;
/*      */   private static final String[] pkfkColumnNames;
/*      */   private static final String[] getIndexInfoColumnNames;
/*      */   private static final String[] getPrimaryKeysColumnNames;
/*      */   private static final String[] getProcedureColumnsColumnNames;
/*      */   private static final String[] getProceduresColumnNames;
/*      */   private static final String[] getTablePrivilegesColumnNames;
/*      */   private static final String[] getVersionColumnsColumnNames;
/*      */ 
/*      */   private static synchronized int nextInstanceID()
/*      */   {
/*   80 */     baseID += 1;
/*   81 */     return baseID;
/*      */   }
/*      */ 
/*      */   public final String toString() {
/*   85 */     return this.traceID;
/*      */   }
/*      */ 
/*      */   public SQLServerDatabaseMetaData(SQLServerConnection paramSQLServerConnection)
/*      */   {
/*   94 */     this.traceID = new StringBuilder().append(" SQLServerDatabaseMetaData:").append(nextInstanceID()).toString();
/*   95 */     this.connection = paramSQLServerConnection;
/*   96 */     if (logger.isLoggable(Level.FINE))
/*      */     {
/*   98 */       logger.fine(new StringBuilder().append(toString()).append(" created by (").append(this.connection.toString()).append(")").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isWrapperFor(Class paramClass) throws SQLException
/*      */   {
/*  104 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*  106 */     return false;
/*      */   }
/*      */ 
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException
/*      */   {
/*  111 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  112 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   private void checkClosed() throws SQLServerException
/*      */   {
/*  117 */     if (this.connection.isClosed())
/*      */     {
/*  119 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), "08003", false);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final SQLServerResultSet getResultSetFromInternalQueries(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/*  222 */     checkClosed();
/*  223 */     String str = null;
/*  224 */     str = switchCatalogs(paramString1);
/*  225 */     SQLServerResultSet localSQLServerResultSet = null;
/*      */     try
/*      */     {
/*  228 */       localSQLServerResultSet = ((SQLServerStatement)this.connection.createStatement()).executeQueryInternal(paramString2);
/*      */ 
/*  233 */       if (null != str)
/*      */       {
/*  235 */         this.connection.setCatalog(str);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  233 */       if (null != str)
/*      */       {
/*  235 */         this.connection.setCatalog(str);
/*      */       }
/*      */     }
/*  238 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   private CallableStatement getCallableStatementHandle(CallableHandles paramCallableHandles, String paramString)
/*      */     throws SQLServerException
/*      */   {
/*  247 */     CallableStatement localCallableStatement = null;
/*  248 */     HandleAssociation localHandleAssociation1 = (HandleAssociation)this.handleMap.get(paramCallableHandles);
/*  249 */     if ((null == localHandleAssociation1) || (null == localHandleAssociation1.databaseName) || (!localHandleAssociation1.databaseName.equals(paramString)))
/*      */     {
/*  253 */       localCallableStatement = paramCallableHandles.prepare(this.connection);
/*  254 */       localHandleAssociation1 = new HandleAssociation(paramString, localCallableStatement);
/*  255 */       HandleAssociation localHandleAssociation2 = (HandleAssociation)this.handleMap.put(paramCallableHandles, localHandleAssociation1);
/*  256 */       if (null != localHandleAssociation2)
/*      */       {
/*  258 */         localHandleAssociation2.close();
/*      */       }
/*      */     }
/*  261 */     return localHandleAssociation1.stmt;
/*      */   }
/*      */ 
/*      */   private final SQLServerResultSet getResultSetFromStoredProc(String paramString, CallableHandles paramCallableHandles, String[] paramArrayOfString)
/*      */     throws SQLServerException
/*      */   {
/*  274 */     checkClosed();
/*  275 */     assert (null != paramArrayOfString);
/*  276 */     String str = null;
/*  277 */     str = switchCatalogs(paramString);
/*  278 */     SQLServerResultSet localSQLServerResultSet = null;
/*      */     try
/*      */     {
/*  281 */       SQLServerCallableStatement localSQLServerCallableStatement = (SQLServerCallableStatement)getCallableStatementHandle(paramCallableHandles, paramString);
/*      */ 
/*  283 */       for (int i = 1; i <= paramArrayOfString.length; i++)
/*      */       {
/*  286 */         localSQLServerCallableStatement.setString(i, paramArrayOfString[(i - 1)]);
/*      */       }
/*  288 */       localSQLServerResultSet = (SQLServerResultSet)localSQLServerCallableStatement.executeQueryInternal();
/*      */ 
/*  292 */       if (null != str)
/*      */       {
/*  294 */         this.connection.setCatalog(str);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  292 */       if (null != str)
/*      */       {
/*  294 */         this.connection.setCatalog(str);
/*      */       }
/*      */     }
/*  297 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   private final SQLServerResultSet getResultSetWithProvidedColumnNames(String paramString, CallableHandles paramCallableHandles, String[] paramArrayOfString1, String[] paramArrayOfString2)
/*      */     throws SQLServerException
/*      */   {
/*  304 */     SQLServerResultSet localSQLServerResultSet = getResultSetFromStoredProc(paramString, paramCallableHandles, paramArrayOfString1);
/*      */ 
/*  307 */     for (int i = 0; i < paramArrayOfString2.length; i++)
/*  308 */       localSQLServerResultSet.setColumnName(1 + i, paramArrayOfString2[i]);
/*  309 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   private String switchCatalogs(String paramString)
/*      */     throws SQLServerException
/*      */   {
/*  319 */     if (paramString == null)
/*  320 */       return null;
/*  321 */     String str1 = null;
/*  322 */     str1 = this.connection.getCatalog().trim();
/*  323 */     String str2 = paramString.trim();
/*  324 */     if (str1.equals(str2))
/*  325 */       return null;
/*  326 */     this.connection.setCatalog(str2);
/*  327 */     if ((str1 == null) || (str1.length() == 0))
/*  328 */       return null;
/*  329 */     return str1;
/*      */   }
/*      */ 
/*      */   public boolean allProceduresAreCallable()
/*      */     throws SQLServerException
/*      */   {
/*  335 */     checkClosed();
/*  336 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean allTablesAreSelectable() throws SQLServerException {
/*  340 */     checkClosed();
/*  341 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean autoCommitFailureClosesAllResultSets() throws SQLException
/*      */   {
/*  346 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  347 */     checkClosed();
/*  348 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean dataDefinitionCausesTransactionCommit() throws SQLServerException {
/*  352 */     checkClosed();
/*  353 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean dataDefinitionIgnoredInTransactions() throws SQLServerException {
/*  357 */     checkClosed();
/*  358 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean doesMaxRowSizeIncludeBlobs() throws SQLServerException {
/*  362 */     checkClosed();
/*  363 */     return false;
/*      */   }
/*      */ 
/*      */   public ResultSet getCatalogs() throws SQLServerException {
/*  367 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  369 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  371 */     checkClosed();
/*      */ 
/*  373 */     String str = "SELECT name AS TABLE_CAT FROM sys.databases order by name";
/*  374 */     return getResultSetFromInternalQueries(null, str);
/*      */   }
/*      */ 
/*      */   public String getCatalogSeparator() throws SQLServerException {
/*  378 */     checkClosed();
/*  379 */     return ".";
/*      */   }
/*      */ 
/*      */   public String getCatalogTerm() throws SQLServerException {
/*  383 */     checkClosed();
/*  384 */     return "database";
/*      */   }
/*      */ 
/*      */   public ResultSet getColumnPrivileges(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws SQLServerException
/*      */   {
/*  402 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  404 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  406 */     checkClosed();
/*      */ 
/*  408 */     paramString4 = EscapeIDName(paramString4);
/*      */ 
/*  415 */     String[] arrayOfString = new String[4];
/*  416 */     arrayOfString[0] = paramString3;
/*  417 */     arrayOfString[1] = paramString2;
/*  418 */     arrayOfString[2] = paramString1;
/*  419 */     arrayOfString[3] = paramString4;
/*  420 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_COLUMN_PRIVILEGES, arrayOfString, getColumnPrivilegesColumnNames);
/*      */   }
/*      */ 
/*      */   public ResultSet getTables(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString)
/*      */     throws SQLServerException
/*      */   {
/*  434 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  436 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  438 */     checkClosed();
/*      */ 
/*  441 */     paramString3 = EscapeIDName(paramString3);
/*  442 */     paramString2 = EscapeIDName(paramString2);
/*      */ 
/*  448 */     String[] arrayOfString = new String[4];
/*  449 */     arrayOfString[0] = paramString3;
/*  450 */     arrayOfString[1] = paramString2;
/*  451 */     arrayOfString[2] = paramString1;
/*      */ 
/*  453 */     String str = null;
/*  454 */     if (paramArrayOfString != null)
/*      */     {
/*  456 */       str = "'";
/*  457 */       for (int i = 0; i < paramArrayOfString.length; i++)
/*      */       {
/*  459 */         if (i > 0)
/*  460 */           str = new StringBuilder().append(str).append(",").toString();
/*  461 */         str = new StringBuilder().append(str).append("''").append(paramArrayOfString[i]).append("''").toString();
/*      */       }
/*  463 */       str = new StringBuilder().append(str).append("'").toString();
/*      */     }
/*  465 */     arrayOfString[3] = str;
/*  466 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_TABLES, arrayOfString, getTablesColumnNames);
/*      */   }
/*      */ 
/*      */   private static String EscapeIDName(String paramString)
/*      */     throws SQLServerException
/*      */   {
/*  485 */     if (null == paramString) {
/*  486 */       return paramString;
/*      */     }
/*      */ 
/*  499 */     StringBuilder localStringBuilder = new StringBuilder(paramString.length() + 2);
/*      */ 
/*  501 */     for (int i = 0; i < paramString.length(); i++)
/*      */     {
/*  503 */       char c = paramString.charAt(i);
/*  504 */       if ('\\' == c) { i++; if (i < paramString.length())
/*      */         {
/*  506 */           c = paramString.charAt(i);
/*  507 */           switch (c)
/*      */           {
/*      */           case '%':
/*      */           case '[':
/*      */           case '_':
/*  512 */             localStringBuilder.append('[');
/*  513 */             localStringBuilder.append(c);
/*  514 */             localStringBuilder.append(']');
/*  515 */             break;
/*      */           case '\\':
/*      */           case ']':
/*  518 */             localStringBuilder.append(c);
/*  519 */             break;
/*      */           default:
/*  521 */             localStringBuilder.append('\\');
/*  522 */             localStringBuilder.append(c); break;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  529 */       localStringBuilder.append(c);
/*      */     }
/*      */ 
/*  532 */     return localStringBuilder.toString();
/*      */   }
/*      */ 
/*      */   public ResultSet getColumns(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws SQLServerException
/*      */   {
/*  588 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  590 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  592 */     checkClosed();
/*      */ 
/*  595 */     String str = EscapeIDName(paramString4);
/*  596 */     paramString3 = EscapeIDName(paramString3);
/*  597 */     paramString2 = EscapeIDName(paramString2);
/*      */     String[] arrayOfString;
/*  606 */     if (this.connection.isKatmaiOrLater())
/*  607 */       arrayOfString = new String[6];
/*      */     else
/*  609 */       arrayOfString = new String[5];
/*  610 */     arrayOfString[0] = paramString3;
/*  611 */     arrayOfString[1] = paramString2;
/*  612 */     arrayOfString[2] = paramString1;
/*  613 */     arrayOfString[3] = str;
/*  614 */     if (this.connection.isKatmaiOrLater())
/*      */     {
/*  616 */       arrayOfString[4] = "2";
/*  617 */       arrayOfString[5] = "3";
/*      */     }
/*      */     else {
/*  620 */       arrayOfString[4] = "3";
/*      */     }
/*      */     SQLServerResultSet localSQLServerResultSet;
/*  622 */     if (this.connection.isKatmaiOrLater())
/*  623 */       localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_COLUMNS, arrayOfString, getColumnsColumnNamesKatmai);
/*      */     else {
/*  625 */       localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_COLUMNS, arrayOfString, getColumnsColumnNames);
/*      */     }
/*      */ 
/*  629 */     localSQLServerResultSet.getColumn(5).setFilter(new DataTypeFilter());
/*      */ 
/*  631 */     if (this.connection.isKatmaiOrLater())
/*      */     {
/*  633 */       localSQLServerResultSet.getColumn(22).setFilter(new IntColumnIdentityFilter());
/*  634 */       localSQLServerResultSet.getColumn(7).setFilter(new ZeroFixupFilter());
/*  635 */       localSQLServerResultSet.getColumn(8).setFilter(new ZeroFixupFilter());
/*  636 */       localSQLServerResultSet.getColumn(16).setFilter(new ZeroFixupFilter());
/*      */     }
/*  638 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   public ResultSet getFunctions(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLException
/*      */   {
/*  656 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  657 */     checkClosed();
/*      */ 
/*  665 */     if ((paramString1 != null) && (paramString1.length() == 0))
/*      */     {
/*  667 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/*  668 */       Object[] arrayOfObject = { "catalog" };
/*  669 */       SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject).format(arrayOfObject), null, false);
/*      */     }
/*      */ 
/*  672 */     Object localObject = new String[3];
/*  673 */     localObject[0] = EscapeIDName(paramString3);
/*  674 */     localObject[1] = EscapeIDName(paramString2);
/*  675 */     localObject[2] = paramString1;
/*  676 */     return (ResultSet)getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_STORED_PROCEDURES, localObject, getFunctionsColumnNames);
/*      */   }
/*      */ 
/*      */   public ResultSet getFunctionColumns(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws SQLException
/*      */   {
/*  705 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  706 */     checkClosed();
/*      */ 
/*  715 */     if ((paramString1 != null) && (paramString1.length() == 0))
/*      */     {
/*  717 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/*  718 */       localObject2 = new Object[] { "catalog" };
/*  719 */       SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject1).format(localObject2), null, false);
/*      */     }
/*      */ 
/*  722 */     Object localObject1 = new String[5];
/*      */ 
/*  725 */     localObject1[0] = EscapeIDName(paramString3);
/*      */ 
/*  727 */     localObject1[1] = EscapeIDName(paramString2);
/*  728 */     localObject1[2] = paramString1;
/*      */ 
/*  730 */     localObject1[3] = EscapeIDName(paramString4);
/*  731 */     localObject1[4] = "3";
/*  732 */     Object localObject2 = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPROC_COLUMNS, localObject1, getFunctionsColumnsColumnNames);
/*      */ 
/*  737 */     ((SQLServerResultSet)localObject2).getColumn(6).setFilter(new DataTypeFilter());
/*      */ 
/*  739 */     if (this.connection.isKatmaiOrLater())
/*      */     {
/*  741 */       ((SQLServerResultSet)localObject2).getColumn(8).setFilter(new ZeroFixupFilter());
/*  742 */       ((SQLServerResultSet)localObject2).getColumn(9).setFilter(new ZeroFixupFilter());
/*  743 */       ((SQLServerResultSet)localObject2).getColumn(17).setFilter(new ZeroFixupFilter());
/*      */     }
/*  745 */     return (ResultSet)(ResultSet)localObject2;
/*      */   }
/*      */ 
/*      */   public ResultSet getClientInfoProperties()
/*      */     throws SQLException
/*      */   {
/*  751 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  752 */     checkClosed();
/*  753 */     return getResultSetFromInternalQueries(null, "SELECT cast(NULL as char(1)) as NAME, cast(0 as int) as MAX_LEN, cast(NULL as char(1)) as DEFAULT_VALUE, cast(NULL as char(1)) as DESCRIPTION  where 0 = 1");
/*      */   }
/*      */ 
/*      */   public ResultSet getBestRowIdentifier(String paramString1, String paramString2, String paramString3, int paramInt, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/*  777 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  779 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  781 */     checkClosed();
/*      */ 
/*  791 */     String[] arrayOfString = new String[7];
/*  792 */     arrayOfString[0] = paramString3;
/*  793 */     arrayOfString[1] = paramString2;
/*  794 */     arrayOfString[2] = paramString1;
/*  795 */     arrayOfString[3] = "R";
/*  796 */     if (0 == paramInt)
/*  797 */       arrayOfString[4] = "C";
/*      */     else
/*  799 */       arrayOfString[4] = "T";
/*  800 */     if (paramBoolean)
/*  801 */       arrayOfString[5] = "U";
/*      */     else
/*  803 */       arrayOfString[5] = "O";
/*  804 */     arrayOfString[6] = "3";
/*  805 */     SQLServerResultSet localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPECIAL_COLUMNS, arrayOfString, getBestRowIdentifierColumnNames);
/*      */ 
/*  810 */     localSQLServerResultSet.getColumn(3).setFilter(new DataTypeFilter());
/*  811 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   public ResultSet getCrossReference(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
/*      */     throws SQLServerException
/*      */   {
/*  836 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  838 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  840 */     checkClosed();
/*      */ 
/*  848 */     String[] arrayOfString = new String[6];
/*  849 */     arrayOfString[0] = paramString3;
/*  850 */     arrayOfString[1] = paramString2;
/*  851 */     arrayOfString[2] = paramString1;
/*  852 */     arrayOfString[3] = paramString6;
/*  853 */     arrayOfString[4] = paramString5;
/*  854 */     arrayOfString[5] = paramString4;
/*      */ 
/*  856 */     return getResultSetWithProvidedColumnNames(null, CallableHandles.SP_FKEYS, arrayOfString, pkfkColumnNames);
/*      */   }
/*      */ 
/*      */   public String getDatabaseProductName() throws SQLServerException {
/*  860 */     checkClosed();
/*  861 */     return "Microsoft SQL Server";
/*      */   }
/*      */ 
/*      */   public String getDatabaseProductVersion() throws SQLServerException {
/*  865 */     checkClosed();
/*  866 */     return this.connection.sqlServerVersion;
/*      */   }
/*      */ 
/*      */   public int getDefaultTransactionIsolation() throws SQLServerException
/*      */   {
/*  871 */     checkClosed();
/*  872 */     return 2;
/*      */   }
/*      */ 
/*      */   public int getDriverMajorVersion()
/*      */   {
/*  877 */     return 4;
/*      */   }
/*      */ 
/*      */   public int getDriverMinorVersion()
/*      */   {
/*  882 */     return 0;
/*      */   }
/*      */ 
/*      */   public String getDriverName() throws SQLServerException {
/*  886 */     checkClosed();
/*  887 */     return "Microsoft JDBC Driver 4.0 for SQL Server";
/*      */   }
/*      */ 
/*      */   public String getDriverVersion()
/*      */     throws SQLServerException
/*      */   {
/*  895 */     int i = getDriverMinorVersion();
/*  896 */     String str = new StringBuilder().append(getDriverMajorVersion()).append(".").toString();
/*  897 */     str = new StringBuilder().append(str).append("").append(i).toString();
/*  898 */     str = new StringBuilder().append(str).append(".").toString();
/*  899 */     str = new StringBuilder().append(str).append(4621).toString();
/*  900 */     str = new StringBuilder().append(str).append(".").toString();
/*  901 */     str = new StringBuilder().append(str).append(201).toString();
/*  902 */     return str;
/*      */   }
/*      */ 
/*      */   public ResultSet getExportedKeys(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/*  908 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  910 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  912 */     checkClosed();
/*      */ 
/*  920 */     String[] arrayOfString = new String[6];
/*  921 */     arrayOfString[0] = paramString3;
/*  922 */     arrayOfString[1] = paramString2;
/*  923 */     arrayOfString[2] = paramString1;
/*  924 */     arrayOfString[3] = null;
/*  925 */     arrayOfString[4] = null;
/*  926 */     arrayOfString[5] = null;
/*  927 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_FKEYS, arrayOfString, pkfkColumnNames);
/*      */   }
/*      */ 
/*      */   public String getExtraNameCharacters() throws SQLServerException {
/*  931 */     checkClosed();
/*  932 */     return "$#@";
/*      */   }
/*      */ 
/*      */   public String getIdentifierQuoteString() throws SQLServerException
/*      */   {
/*  937 */     checkClosed();
/*  938 */     return "\"";
/*      */   }
/*      */ 
/*      */   public ResultSet getImportedKeys(String paramString1, String paramString2, String paramString3) throws SQLServerException
/*      */   {
/*  943 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  945 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  947 */     checkClosed();
/*      */ 
/*  955 */     String[] arrayOfString = new String[6];
/*  956 */     arrayOfString[0] = null;
/*  957 */     arrayOfString[1] = null;
/*  958 */     arrayOfString[2] = null;
/*  959 */     arrayOfString[3] = paramString3;
/*  960 */     arrayOfString[4] = paramString2;
/*  961 */     arrayOfString[5] = paramString1;
/*  962 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_FKEYS, arrayOfString, pkfkColumnNames);
/*      */   }
/*      */ 
/*      */   public ResultSet getIndexInfo(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2)
/*      */     throws SQLServerException
/*      */   {
/*  985 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  987 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  989 */     checkClosed();
/*      */ 
/*  996 */     String[] arrayOfString = new String[6];
/*  997 */     arrayOfString[0] = paramString3;
/*  998 */     arrayOfString[1] = paramString2;
/*  999 */     arrayOfString[2] = paramString1;
/*      */ 
/* 1001 */     arrayOfString[3] = "%";
/* 1002 */     if (paramBoolean1)
/* 1003 */       arrayOfString[4] = "Y";
/*      */     else
/* 1005 */       arrayOfString[4] = "N";
/* 1006 */     if (paramBoolean2)
/* 1007 */       arrayOfString[5] = "Q";
/*      */     else
/* 1009 */       arrayOfString[5] = "E";
/* 1010 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_STATISTICS, arrayOfString, getIndexInfoColumnNames);
/*      */   }
/*      */ 
/*      */   public int getMaxBinaryLiteralLength() throws SQLServerException {
/* 1014 */     checkClosed();
/* 1015 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxCatalogNameLength() throws SQLServerException {
/* 1019 */     checkClosed();
/* 1020 */     return 128;
/*      */   }
/*      */ 
/*      */   public int getMaxCharLiteralLength() throws SQLServerException {
/* 1024 */     checkClosed();
/* 1025 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnNameLength() throws SQLServerException {
/* 1029 */     checkClosed();
/* 1030 */     return 128;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInGroupBy() throws SQLServerException {
/* 1034 */     checkClosed();
/* 1035 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInIndex() throws SQLServerException {
/* 1039 */     checkClosed();
/* 1040 */     return 16;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInOrderBy() throws SQLServerException {
/* 1044 */     checkClosed();
/* 1045 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInSelect() throws SQLServerException {
/* 1049 */     checkClosed();
/* 1050 */     return 4096;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInTable() throws SQLServerException {
/* 1054 */     checkClosed();
/* 1055 */     return 1024;
/*      */   }
/*      */ 
/*      */   public int getMaxConnections() throws SQLServerException
/*      */   {
/* 1060 */     checkClosed();
/*      */     try
/*      */     {
/* 1063 */       String str = "sp_configure 'user connections'";
/* 1064 */       SQLServerResultSet localSQLServerResultSet = getResultSetFromInternalQueries(null, str);
/* 1065 */       if (!localSQLServerResultSet.next())
/* 1066 */         return 0;
/* 1067 */       return localSQLServerResultSet.getInt("maximum");
/*      */     }
/*      */     catch (SQLServerException localSQLServerException) {
/*      */     }
/* 1071 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxCursorNameLength()
/*      */     throws SQLServerException
/*      */   {
/* 1078 */     checkClosed();
/* 1079 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxIndexLength() throws SQLServerException {
/* 1083 */     checkClosed();
/* 1084 */     return 900;
/*      */   }
/*      */ 
/*      */   public int getMaxProcedureNameLength() throws SQLServerException {
/* 1088 */     checkClosed();
/* 1089 */     return 128;
/*      */   }
/*      */ 
/*      */   public int getMaxRowSize() throws SQLServerException {
/* 1093 */     checkClosed();
/* 1094 */     return 8060;
/*      */   }
/*      */ 
/*      */   public int getMaxSchemaNameLength() throws SQLServerException {
/* 1098 */     checkClosed();
/* 1099 */     return 128;
/*      */   }
/*      */ 
/*      */   public int getMaxStatementLength() throws SQLServerException {
/* 1103 */     checkClosed();
/*      */ 
/* 1109 */     return 65536 * this.connection.getTDSPacketSize();
/*      */   }
/*      */ 
/*      */   public int getMaxStatements() throws SQLServerException {
/* 1113 */     checkClosed();
/* 1114 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxTableNameLength() throws SQLServerException {
/* 1118 */     checkClosed();
/* 1119 */     return 128;
/*      */   }
/*      */ 
/*      */   public int getMaxTablesInSelect() throws SQLServerException {
/* 1123 */     checkClosed();
/* 1124 */     return 256;
/*      */   }
/*      */ 
/*      */   public int getMaxUserNameLength() throws SQLServerException {
/* 1128 */     checkClosed();
/* 1129 */     return 128;
/*      */   }
/*      */ 
/*      */   public String getNumericFunctions() throws SQLServerException {
/* 1133 */     checkClosed();
/* 1134 */     return "ABS,ACOS,ASIN,ATAN,ATAN2,CEILING,COS,COT,DEGREES,EXP, FLOOR,LOG,LOG10,MOD,PI,POWER,RADIANS,RAND,ROUND,SIGN,SIN,SQRT,TAN,TRUNCATE";
/*      */   }
/*      */ 
/*      */   public ResultSet getPrimaryKeys(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 1150 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1152 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1154 */     checkClosed();
/*      */ 
/* 1160 */     String[] arrayOfString = new String[3];
/* 1161 */     arrayOfString[0] = paramString3;
/* 1162 */     arrayOfString[1] = paramString2;
/* 1163 */     arrayOfString[2] = paramString1;
/* 1164 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_PKEYS, arrayOfString, getPrimaryKeysColumnNames);
/*      */   }
/*      */ 
/*      */   public ResultSet getProcedureColumns(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws SQLServerException
/*      */   {
/* 1193 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1195 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1197 */     checkClosed();
/*      */ 
/* 1205 */     String[] arrayOfString = new String[5];
/*      */ 
/* 1208 */     paramString3 = EscapeIDName(paramString3);
/* 1209 */     arrayOfString[0] = paramString3;
/* 1210 */     arrayOfString[1] = paramString2;
/* 1211 */     arrayOfString[2] = paramString1;
/*      */ 
/* 1213 */     paramString4 = EscapeIDName(paramString4);
/* 1214 */     arrayOfString[3] = paramString4;
/* 1215 */     arrayOfString[4] = "3";
/* 1216 */     SQLServerResultSet localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPROC_COLUMNS, arrayOfString, getProcedureColumnsColumnNames);
/*      */ 
/* 1221 */     localSQLServerResultSet.getColumn(6).setFilter(new DataTypeFilter());
/* 1222 */     if (this.connection.isKatmaiOrLater())
/*      */     {
/* 1224 */       localSQLServerResultSet.getColumn(8).setFilter(new ZeroFixupFilter());
/* 1225 */       localSQLServerResultSet.getColumn(9).setFilter(new ZeroFixupFilter());
/* 1226 */       localSQLServerResultSet.getColumn(17).setFilter(new ZeroFixupFilter());
/*      */     }
/*      */ 
/* 1229 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   public ResultSet getProcedures(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 1247 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1249 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*      */ 
/* 1252 */     checkClosed();
/*      */ 
/* 1258 */     String[] arrayOfString = new String[3];
/* 1259 */     arrayOfString[0] = EscapeIDName(paramString3);
/* 1260 */     arrayOfString[1] = paramString2;
/* 1261 */     arrayOfString[2] = paramString1;
/* 1262 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_STORED_PROCEDURES, arrayOfString, getProceduresColumnNames);
/*      */   }
/*      */ 
/*      */   public String getProcedureTerm() throws SQLServerException {
/* 1266 */     checkClosed();
/* 1267 */     return "stored procedure";
/*      */   }
/*      */ 
/*      */   public ResultSet getSchemas() throws SQLServerException
/*      */   {
/* 1272 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1274 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1276 */     checkClosed();
/* 1277 */     return getSchemasInternal(null, null);
/*      */   }
/*      */ 
/*      */   private ResultSet getSchemasInternal(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/* 1286 */     String str2 = " ('dbo', 'guest','INFORMATION_SCHEMA','sys','db_owner', 'db_accessadmin', 'db_securityadmin', 'db_ddladmin'  ,'db_backupoperator','db_datareader','db_datawriter','db_denydatareader','db_denydatawriter') ";
/*      */ 
/* 1289 */     String str3 = "sys.schemas";
/* 1290 */     String str4 = "sys.schemas.name";
/* 1291 */     if ((null != paramString1) && (paramString1.length() != 0))
/*      */     {
/* 1293 */       str3 = new StringBuilder().append(paramString1).append(".").append(str3).toString();
/* 1294 */       str4 = new StringBuilder().append(paramString1).append(".").append(str4).toString();
/*      */     }
/*      */ 
/* 1299 */     String str1 = new StringBuilder().append("select ").append(str4).append(" 'TABLE_SCHEM',").toString();
/* 1300 */     if ((null != paramString1) && (paramString1.length() == 0))
/*      */     {
/* 1302 */       str1 = new StringBuilder().append(str1).append("null 'TABLE_CATALOG' ").toString();
/*      */     }
/*      */     else
/*      */     {
/* 1306 */       str1 = new StringBuilder().append(str1).append(" CASE WHEN ").append(str4).append("  IN ").append(str2).append(" THEN null ELSE ").toString();
/*      */ 
/* 1308 */       if ((null != paramString1) && (paramString1.length() != 0))
/*      */       {
/* 1310 */         str1 = new StringBuilder().append(str1).append("'").append(paramString1).append("' ").toString();
/*      */       }
/*      */       else {
/* 1313 */         str1 = new StringBuilder().append(str1).append(" DB_NAME() ").toString();
/*      */       }
/* 1315 */       str1 = new StringBuilder().append(str1).append(" END 'TABLE_CATALOG' ").toString();
/*      */     }
/* 1317 */     str1 = new StringBuilder().append(str1).append("   from ").append(str3).toString();
/*      */ 
/* 1321 */     if ((null != paramString1) && (paramString1.length() == 0))
/*      */     {
/* 1323 */       if (null != paramString2)
/* 1324 */         str1 = new StringBuilder().append(str1).append(" where ").append(str4).append(" like ?  and ").toString();
/*      */       else
/* 1326 */         str1 = new StringBuilder().append(str1).append(" where ").toString();
/* 1327 */       str1 = new StringBuilder().append(str1).append(str4).append(" in ").append(str2).toString();
/*      */     }
/* 1330 */     else if (null != paramString2) {
/* 1331 */       str1 = new StringBuilder().append(str1).append(" where ").append(str4).append(" like ?  ").toString();
/*      */     }
/* 1333 */     str1 = new StringBuilder().append(str1).append(" order by 2, 1").toString();
/* 1334 */     if (logger.isLoggable(Level.FINE))
/*      */     {
/* 1336 */       logger.fine(new StringBuilder().append(toString()).append(" schema query (").append(str1).append(")").toString());
/*      */     }
/*      */     SQLServerResultSet localSQLServerResultSet;
/* 1339 */     if (null == paramString2)
/*      */     {
/* 1341 */       paramString1 = null;
/* 1342 */       localSQLServerResultSet = getResultSetFromInternalQueries(paramString1, str1);
/*      */     }
/*      */     else
/*      */     {
/* 1350 */       SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)this.connection.prepareStatement(str1);
/* 1351 */       localSQLServerPreparedStatement.setString(1, paramString2);
/* 1352 */       localSQLServerResultSet = (SQLServerResultSet)localSQLServerPreparedStatement.executeQueryInternal();
/*      */     }
/* 1354 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   public ResultSet getSchemas(String paramString1, String paramString2) throws SQLException
/*      */   {
/* 1359 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1361 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1363 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1364 */     return getSchemasInternal(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */   public String getSchemaTerm() throws SQLServerException {
/* 1368 */     checkClosed();
/* 1369 */     return "schema";
/*      */   }
/*      */ 
/*      */   public String getSearchStringEscape() throws SQLServerException {
/* 1373 */     checkClosed();
/* 1374 */     return "\\";
/*      */   }
/*      */ 
/*      */   public String getSQLKeywords() throws SQLServerException {
/* 1378 */     checkClosed();
/* 1379 */     return "BACKUP,BREAK,BROWSE,BULK,CHECKPOINT,CLUSTERED,COMPUTE,CONTAINS,CONTAINSTABLE,DATABASE,DBCC,DENY,DISK,DISTRIBUTED,DUMMY,DUMP,ERRLVL,EXIT,FILE,FILLFACTOR,FREETEXT,FREETEXTTABLE,FUNCTION,HOLDLOCK,IDENTITY_INSERT,IDENTITYCOL,IF,KILL,LINENO,LOAD,NOCHECK,NONCLUSTERED,OFF,OFFSETS,OPENDATASOURCE,OPENQUERY,OPENROWSET,OPENXML,OVER,PERCENT,PLAN,PRINT,PROC,RAISERROR,READTEXT,RECONFIGURE,REPLICATION,RESTORE,RETURN,ROWCOUNT,ROWGUIDCOL,RULE,SAVE,SETUSER,SHUTDOWN,STATISTICS,TEXTSIZE,TOP,TRAN,TRIGGER,TRUNCATE,TSEQUAL,UPDATETEXT,USE,WAITFOR,WHILE,WRITETEXT";
/*      */   }
/*      */ 
/*      */   public String getStringFunctions() throws SQLServerException {
/* 1383 */     checkClosed();
/* 1384 */     return "ASCII,CHAR,CONCAT, DIFFERENCE,INSERT,LCASE,LEFT,LENGTH,LOCATE,LTRIM,REPEAT,REPLACE,RIGHT,RTRIM,SOUNDEX,SPACE,SUBSTRING,UCASE";
/*      */   }
/*      */ 
/*      */   public String getSystemFunctions() throws SQLServerException {
/* 1388 */     checkClosed();
/* 1389 */     return "DATABASE,IFNULL,USER";
/*      */   }
/*      */ 
/*      */   public ResultSet getTablePrivileges(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 1405 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1407 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1409 */     checkClosed();
/* 1410 */     paramString3 = EscapeIDName(paramString3);
/* 1411 */     paramString2 = EscapeIDName(paramString2);
/*      */ 
/* 1417 */     String[] arrayOfString = new String[3];
/* 1418 */     arrayOfString[0] = paramString3;
/* 1419 */     arrayOfString[1] = paramString2;
/* 1420 */     arrayOfString[2] = paramString1;
/*      */ 
/* 1422 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_TABLE_PRIVILEGES, arrayOfString, getTablePrivilegesColumnNames);
/*      */   }
/*      */ 
/*      */   public ResultSet getTableTypes() throws SQLServerException
/*      */   {
/* 1427 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1429 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1431 */     checkClosed();
/* 1432 */     String str = "SELECT 'VIEW' 'TABLE_TYPE' UNION SELECT 'TABLE' UNION SELECT 'SYSTEM TABLE'";
/* 1433 */     SQLServerResultSet localSQLServerResultSet = getResultSetFromInternalQueries(null, str);
/* 1434 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   public String getTimeDateFunctions() throws SQLServerException {
/* 1438 */     checkClosed();
/* 1439 */     return "CURDATE,CURTIME,DAYNAME,DAYOFMONTH,DAYOFWEEK,DAYOFYEAR,HOUR,MINUTE,MONTH,MONTHNAME,NOW,QUARTER,SECOND,TIMESTAMPADD,TIMESTAMPDIFF,WEEK,YEAR";
/*      */   }
/*      */ 
/*      */   public ResultSet getTypeInfo() throws SQLServerException
/*      */   {
/* 1444 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1446 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1448 */     checkClosed();
/*      */     SQLServerResultSet localSQLServerResultSet;
/* 1452 */     if (this.connection.isKatmaiOrLater())
/* 1453 */       localSQLServerResultSet = getResultSetFromInternalQueries(null, "sp_datatype_info_100 @ODBCVer=3");
/*      */     else {
/* 1455 */       localSQLServerResultSet = getResultSetFromInternalQueries(null, "sp_datatype_info @ODBCVer=3");
/*      */     }
/* 1457 */     localSQLServerResultSet.setColumnName(11, "FIXED_PREC_SCALE");
/*      */ 
/* 1461 */     localSQLServerResultSet.getColumn(2).setFilter(new DataTypeFilter());
/* 1462 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   public String getURL() throws SQLServerException
/*      */   {
/* 1467 */     checkClosed();
/*      */ 
/* 1469 */     StringBuilder localStringBuilder = new StringBuilder();
/*      */ 
/* 1471 */     Properties localProperties = this.connection.activeConnectionProperties;
/* 1472 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = SQLServerDriver.getPropertyInfoFromProperties(localProperties);
/* 1473 */     Object localObject1 = null;
/* 1474 */     Object localObject2 = null;
/* 1475 */     Object localObject3 = null;
/*      */ 
/* 1479 */     int i = arrayOfDriverPropertyInfo.length;
/*      */     while (true) { i--; if (i < 0)
/*      */         break;
/* 1482 */       String str1 = arrayOfDriverPropertyInfo[i].name;
/*      */ 
/* 1485 */       if ((!str1.equals(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString())) && (!str1.equals(SQLServerDriverStringProperty.USER.toString())) && (!str1.equals(SQLServerDriverStringProperty.PASSWORD.toString())))
/*      */       {
/* 1487 */         String str2 = arrayOfDriverPropertyInfo[i].value;
/*      */ 
/* 1489 */         if (0 != str2.length())
/*      */         {
/* 1492 */           if (str1.equals(SQLServerDriverStringProperty.SERVER_NAME.toString()))
/*      */           {
/* 1494 */             localObject1 = str2;
/*      */           }
/* 1496 */           else if (str1.equals(SQLServerDriverStringProperty.INSTANCE_NAME.toString()))
/*      */           {
/* 1498 */             localObject3 = str2;
/*      */           }
/* 1500 */           else if (str1.equals(SQLServerDriverIntProperty.PORT_NUMBER.toString()))
/*      */           {
/* 1502 */             localObject2 = str2;
/*      */           }
/*      */           else
/*      */           {
/* 1507 */             localStringBuilder.append(str1);
/* 1508 */             localStringBuilder.append("=");
/* 1509 */             localStringBuilder.append(str2);
/* 1510 */             localStringBuilder.append(";");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1520 */     localStringBuilder.insert(0, ";");
/* 1521 */     localStringBuilder.insert(0, localObject2);
/* 1522 */     localStringBuilder.insert(0, ":");
/* 1523 */     if (null != localObject3)
/*      */     {
/* 1525 */       localStringBuilder.insert(0, localObject3);
/* 1526 */       localStringBuilder.insert(0, "\\");
/*      */     }
/* 1528 */     localStringBuilder.insert(0, localObject1);
/*      */ 
/* 1530 */     localStringBuilder.insert(0, "jdbc:sqlserver://");
/* 1531 */     return localStringBuilder.toString();
/*      */   }
/*      */ 
/*      */   public String getUserName() throws SQLServerException {
/* 1535 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1537 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1539 */     checkClosed();
/* 1540 */     SQLServerStatement localSQLServerStatement = null;
/* 1541 */     SQLServerResultSet localSQLServerResultSet = null;
/* 1542 */     String str = "";
/*      */     try
/*      */     {
/* 1545 */       localSQLServerStatement = (SQLServerStatement)this.connection.createStatement();
/* 1546 */       localSQLServerResultSet = localSQLServerStatement.executeQueryInternal("select system_user");
/*      */ 
/* 1548 */       boolean bool = localSQLServerResultSet.next();
/* 1549 */       assert (bool);
/*      */ 
/* 1551 */       str = localSQLServerResultSet.getString(1);
/*      */     }
/*      */     finally {
/* 1554 */       if (localSQLServerResultSet != null) {
/* 1555 */         localSQLServerResultSet.close();
/*      */       }
/* 1557 */       if (localSQLServerStatement != null) {
/* 1558 */         localSQLServerStatement.close();
/*      */       }
/*      */     }
/* 1561 */     return str;
/*      */   }
/*      */ 
/*      */   public ResultSet getVersionColumns(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 1579 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1581 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1583 */     checkClosed();
/*      */ 
/* 1591 */     String[] arrayOfString = new String[7];
/* 1592 */     arrayOfString[0] = paramString3;
/* 1593 */     arrayOfString[1] = paramString2;
/* 1594 */     arrayOfString[2] = paramString1;
/* 1595 */     arrayOfString[3] = "V";
/* 1596 */     arrayOfString[4] = "T";
/* 1597 */     arrayOfString[5] = "U";
/* 1598 */     arrayOfString[6] = "3";
/* 1599 */     SQLServerResultSet localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPECIAL_COLUMNS, arrayOfString, getVersionColumnsColumnNames);
/*      */ 
/* 1604 */     localSQLServerResultSet.getColumn(3).setFilter(new DataTypeFilter());
/* 1605 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   public boolean isCatalogAtStart() throws SQLServerException {
/* 1609 */     checkClosed();
/* 1610 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean isReadOnly() throws SQLServerException {
/* 1614 */     checkClosed();
/* 1615 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean nullPlusNonNullIsNull() throws SQLServerException {
/* 1619 */     checkClosed();
/* 1620 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean nullsAreSortedAtEnd() throws SQLServerException {
/* 1624 */     checkClosed();
/* 1625 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean nullsAreSortedAtStart() throws SQLServerException {
/* 1629 */     checkClosed();
/* 1630 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean nullsAreSortedHigh() throws SQLServerException {
/* 1634 */     checkClosed();
/* 1635 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean nullsAreSortedLow() throws SQLServerException {
/* 1639 */     checkClosed();
/* 1640 */     return true;
/*      */   }
/*      */   public boolean storesLowerCaseIdentifiers() throws SQLServerException {
/* 1643 */     checkClosed();
/* 1644 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean storesLowerCaseQuotedIdentifiers() throws SQLServerException {
/* 1648 */     checkClosed();
/* 1649 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean storesMixedCaseIdentifiers() throws SQLServerException {
/* 1653 */     checkClosed();
/* 1654 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean storesMixedCaseQuotedIdentifiers() throws SQLServerException {
/* 1658 */     checkClosed();
/* 1659 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean storesUpperCaseIdentifiers() throws SQLServerException {
/* 1663 */     checkClosed();
/* 1664 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean storesUpperCaseQuotedIdentifiers() throws SQLServerException {
/* 1668 */     checkClosed();
/* 1669 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsAlterTableWithAddColumn() throws SQLServerException {
/* 1673 */     checkClosed();
/* 1674 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsAlterTableWithDropColumn() throws SQLServerException {
/* 1678 */     checkClosed();
/* 1679 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsANSI92EntryLevelSQL() throws SQLServerException {
/* 1683 */     checkClosed();
/* 1684 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsANSI92FullSQL() throws SQLServerException {
/* 1688 */     checkClosed(); return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsANSI92IntermediateSQL() throws SQLServerException {
/* 1692 */     checkClosed(); return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInDataManipulation() throws SQLServerException {
/* 1696 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInIndexDefinitions() throws SQLServerException {
/* 1700 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLServerException {
/* 1704 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInProcedureCalls() throws SQLServerException {
/* 1708 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInTableDefinitions() throws SQLServerException {
/* 1712 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsColumnAliasing() throws SQLServerException {
/* 1716 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsConvert() throws SQLServerException {
/* 1720 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsConvert(int paramInt1, int paramInt2) throws SQLServerException {
/* 1724 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsCoreSQLGrammar() throws SQLServerException {
/* 1728 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsCorrelatedSubqueries() throws SQLServerException {
/* 1732 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLServerException {
/* 1736 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsDataManipulationTransactionsOnly() throws SQLServerException {
/* 1740 */     checkClosed(); return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsDifferentTableCorrelationNames() throws SQLServerException {
/* 1744 */     checkClosed(); return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsExpressionsInOrderBy() throws SQLServerException {
/* 1748 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsExtendedSQLGrammar() throws SQLServerException {
/* 1752 */     checkClosed(); return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsFullOuterJoins() throws SQLServerException {
/* 1756 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsGroupBy() throws SQLServerException {
/* 1760 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsGroupByBeyondSelect() throws SQLServerException {
/* 1764 */     checkClosed();
/* 1765 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsGroupByUnrelated() throws SQLServerException {
/* 1769 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsIntegrityEnhancementFacility() throws SQLServerException {
/* 1773 */     checkClosed();
/* 1774 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsLikeEscapeClause() throws SQLServerException
/*      */   {
/* 1779 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsLimitedOuterJoins() throws SQLServerException {
/* 1783 */     checkClosed();
/* 1784 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsMinimumSQLGrammar() throws SQLServerException {
/* 1788 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsMixedCaseIdentifiers() throws SQLServerException {
/* 1792 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsMixedCaseQuotedIdentifiers() throws SQLServerException {
/* 1796 */     checkClosed();
/* 1797 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsMultipleResultSets() throws SQLServerException {
/* 1801 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsMultipleTransactions() throws SQLServerException {
/* 1805 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsNonNullableColumns() throws SQLServerException {
/* 1809 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsOpenCursorsAcrossCommit() throws SQLServerException {
/* 1813 */     checkClosed();
/* 1814 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsOpenCursorsAcrossRollback() throws SQLServerException {
/* 1818 */     checkClosed();
/* 1819 */     return false;
/*      */   }
/*      */   public boolean supportsOpenStatementsAcrossCommit() throws SQLServerException {
/* 1822 */     checkClosed();
/* 1823 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsOpenStatementsAcrossRollback() throws SQLServerException {
/* 1827 */     checkClosed();
/* 1828 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsOrderByUnrelated() throws SQLServerException {
/* 1832 */     checkClosed();
/* 1833 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsOuterJoins() throws SQLServerException {
/* 1837 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsPositionedDelete() throws SQLServerException {
/* 1841 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsPositionedUpdate() throws SQLServerException {
/* 1845 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInDataManipulation() throws SQLServerException {
/* 1849 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInIndexDefinitions() throws SQLServerException {
/* 1853 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInPrivilegeDefinitions() throws SQLServerException {
/* 1857 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInProcedureCalls() throws SQLServerException {
/* 1861 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInTableDefinitions() throws SQLServerException {
/* 1865 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSelectForUpdate() throws SQLServerException {
/* 1869 */     checkClosed();
/* 1870 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsStoredProcedures() throws SQLServerException {
/* 1874 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSubqueriesInComparisons() throws SQLServerException {
/* 1878 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSubqueriesInExists() throws SQLServerException {
/* 1882 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSubqueriesInIns() throws SQLServerException {
/* 1886 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSubqueriesInQuantifieds() throws SQLServerException {
/* 1890 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsTableCorrelationNames() throws SQLServerException {
/* 1894 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsTransactionIsolationLevel(int paramInt) throws SQLServerException {
/* 1898 */     checkClosed();
/* 1899 */     switch (paramInt)
/*      */     {
/*      */     case 1:
/*      */     case 2:
/*      */     case 4:
/*      */     case 8:
/*      */     case 4096:
/* 1906 */       return true;
/*      */     }
/* 1908 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsTransactions() throws SQLServerException {
/* 1912 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsUnion() throws SQLServerException {
/* 1916 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsUnionAll() throws SQLServerException {
/* 1920 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean usesLocalFilePerTable() throws SQLServerException {
/* 1924 */     checkClosed(); return false;
/*      */   }
/*      */ 
/*      */   public boolean usesLocalFiles() throws SQLServerException {
/* 1928 */     checkClosed(); return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsResultSetType(int paramInt) throws SQLServerException {
/* 1932 */     checkClosed();
/* 1933 */     checkResultType(paramInt);
/* 1934 */     switch (paramInt)
/*      */     {
/*      */     case 1003:
/*      */     case 1004:
/*      */     case 1005:
/*      */     case 1006:
/*      */     case 2003:
/*      */     case 2004:
/* 1944 */       return true;
/*      */     }
/* 1946 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsResultSetConcurrency(int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 1951 */     checkClosed();
/* 1952 */     checkResultType(paramInt1);
/* 1953 */     checkConcurrencyType(paramInt2);
/* 1954 */     switch (paramInt1)
/*      */     {
/*      */     case 1003:
/*      */     case 1005:
/*      */     case 1006:
/*      */     case 2004:
/* 1961 */       return true;
/*      */     case 1004:
/*      */     case 2003:
/* 1966 */       return 1007 == paramInt2;
/*      */     }
/*      */ 
/* 1971 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean ownUpdatesAreVisible(int paramInt) throws SQLServerException {
/* 1975 */     checkClosed();
/* 1976 */     checkResultType(paramInt);
/*      */ 
/* 1980 */     return (paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt);
/*      */   }
/*      */ 
/*      */   public boolean ownDeletesAreVisible(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1985 */     checkClosed();
/* 1986 */     checkResultType(paramInt);
/*      */ 
/* 1990 */     return (paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt);
/*      */   }
/*      */ 
/*      */   public boolean ownInsertsAreVisible(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1995 */     checkClosed();
/* 1996 */     checkResultType(paramInt);
/*      */ 
/* 2000 */     return (paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt);
/*      */   }
/*      */ 
/*      */   public boolean othersUpdatesAreVisible(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2005 */     checkClosed();
/* 2006 */     checkResultType(paramInt);
/*      */ 
/* 2010 */     return (paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt);
/*      */   }
/*      */ 
/*      */   public boolean othersDeletesAreVisible(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2015 */     checkClosed();
/* 2016 */     checkResultType(paramInt);
/*      */ 
/* 2020 */     return (paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt);
/*      */   }
/*      */ 
/*      */   public boolean othersInsertsAreVisible(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2025 */     checkClosed();
/* 2026 */     checkResultType(paramInt);
/*      */ 
/* 2029 */     return (paramInt == 1006) || (1003 == paramInt) || (2004 == paramInt);
/*      */   }
/*      */ 
/*      */   public boolean updatesAreDetected(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2034 */     checkClosed();
/* 2035 */     checkResultType(paramInt);
/* 2036 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean deletesAreDetected(int paramInt) throws SQLServerException
/*      */   {
/* 2041 */     checkClosed();
/* 2042 */     checkResultType(paramInt);
/*      */ 
/* 2044 */     return 1005 == paramInt;
/*      */   }
/*      */ 
/*      */   private void checkResultType(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2052 */     switch (paramInt)
/*      */     {
/*      */     case 1003:
/*      */     case 1004:
/*      */     case 1005:
/*      */     case 1006:
/*      */     case 2003:
/*      */     case 2004:
/* 2062 */       return;
/*      */     }
/*      */ 
/* 2065 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2066 */     Object[] arrayOfObject = { new Integer(paramInt) };
/* 2067 */     throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*      */   }
/*      */ 
/*      */   private void checkConcurrencyType(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2073 */     switch (paramInt)
/*      */     {
/*      */     case 1007:
/*      */     case 1008:
/*      */     case 1009:
/*      */     case 1010:
/* 2080 */       return;
/*      */     }
/*      */ 
/* 2083 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2084 */     Object[] arrayOfObject = { new Integer(paramInt) };
/* 2085 */     throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*      */   }
/*      */ 
/*      */   public boolean insertsAreDetected(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2091 */     checkClosed();
/* 2092 */     checkResultType(paramInt);
/* 2093 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsBatchUpdates() throws SQLServerException {
/* 2097 */     checkClosed();
/* 2098 */     return true;
/*      */   }
/*      */ 
/*      */   public ResultSet getUDTs(String paramString1, String paramString2, String paramString3, int[] paramArrayOfInt) throws SQLServerException
/*      */   {
/* 2103 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2105 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 2107 */     checkClosed();
/* 2108 */     return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as CLASS_NAME, cast(0 as int) as DATA_TYPE, cast(NULL as char(1)) as REMARKS, cast(0 as smallint) as BASE_TYPE where 0 = 1");
/*      */   }
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLServerException
/*      */   {
/* 2121 */     checkClosed();
/* 2122 */     return this.connection.getConnection();
/*      */   }
/*      */ 
/*      */   public int getSQLStateType()
/*      */     throws SQLServerException
/*      */   {
/* 2129 */     checkClosed();
/* 2130 */     if ((this.connection != null) && (this.connection.xopenStates)) {
/* 2131 */       return 1;
/*      */     }
/* 2133 */     return 2;
/*      */   }
/*      */ 
/*      */   public int getDatabaseMajorVersion() throws SQLServerException {
/* 2137 */     checkClosed();
/* 2138 */     String str = this.connection.sqlServerVersion;
/* 2139 */     int i = str.indexOf(46);
/* 2140 */     if (i > 0)
/* 2141 */       str = str.substring(0, i);
/*      */     try {
/* 2143 */       return new Integer(str).intValue();
/*      */     } catch (NumberFormatException localNumberFormatException) {
/*      */     }
/* 2146 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getDatabaseMinorVersion() throws SQLServerException
/*      */   {
/* 2151 */     checkClosed();
/* 2152 */     String str = this.connection.sqlServerVersion;
/* 2153 */     int i = str.indexOf(46);
/* 2154 */     int j = str.indexOf(46, i + 1);
/* 2155 */     if ((i > 0) && (j > 0))
/* 2156 */       str = str.substring(i + 1, j);
/*      */     try {
/* 2158 */       return new Integer(str).intValue();
/*      */     } catch (NumberFormatException localNumberFormatException) {
/*      */     }
/* 2161 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getJDBCMajorVersion() throws SQLServerException
/*      */   {
/* 2166 */     checkClosed();
/* 2167 */     return 4;
/*      */   }
/*      */   public int getJDBCMinorVersion() throws SQLServerException {
/* 2170 */     checkClosed(); return 0;
/*      */   }
/*      */ 
/*      */   public int getResultSetHoldability() throws SQLServerException {
/* 2174 */     checkClosed(); return 1;
/*      */   }
/*      */ 
/*      */   public RowIdLifetime getRowIdLifetime() throws SQLException
/*      */   {
/* 2179 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2180 */     checkClosed();
/* 2181 */     return RowIdLifetime.ROWID_UNSUPPORTED;
/*      */   }
/*      */ 
/*      */   public boolean supportsResultSetHoldability(int paramInt) throws SQLServerException
/*      */   {
/* 2186 */     checkClosed();
/* 2187 */     if ((1 == paramInt) || (2 == paramInt))
/*      */     {
/* 2189 */       return true;
/*      */     }
/*      */ 
/* 2193 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2194 */     Object[] arrayOfObject = { new Integer(paramInt) };
/* 2195 */     throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*      */   }
/*      */ 
/*      */   public ResultSet getAttributes(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLServerException
/*      */   {
/* 2200 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2202 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 2204 */     checkClosed();
/* 2205 */     return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as ATTR_NAME, cast(0 as int) as DATA_TYPE, cast(NULL as char(1)) as ATTR_TYPE_NAME, cast(0 as int) as ATTR_SIZE, cast(0 as int) as DECIMAL_DIGITS, cast(0 as int) as NUM_PREC_RADIX, cast(0 as int) as NULLABLE, cast(NULL as char(1)) as REMARKS, cast(NULL as char(1)) as ATTR_DEF, cast(0 as int) as SQL_DATA_TYPE, cast(0 as int) as SQL_DATETIME_SUB, cast(0 as int) as CHAR_OCTET_LENGTH, cast(0 as int) as ORDINAL_POSITION, cast(NULL as char(1)) as IS_NULLABLE, cast(NULL as char(1)) as SCOPE_CATALOG, cast(NULL as char(1)) as SCOPE_SCHEMA, cast(NULL as char(1)) as SCOPE_TABLE, cast(0 as smallint) as SOURCE_DATA_TYPE where 0 = 1");
/*      */   }
/*      */ 
/*      */   public ResultSet getSuperTables(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 2232 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2234 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 2236 */     checkClosed();
/* 2237 */     return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as SUPERTABLE_NAME where 0 = 1");
/*      */   }
/*      */ 
/*      */   public ResultSet getSuperTypes(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 2247 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2249 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 2251 */     checkClosed();
/* 2252 */     return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as SUPERTYPE_CAT, cast(NULL as char(1)) as SUPERTYPE_SCHEM, cast(NULL as char(1)) as SUPERTYPE_NAME where 0 = 1");
/*      */   }
/*      */ 
/*      */   public boolean supportsGetGeneratedKeys()
/*      */     throws SQLServerException
/*      */   {
/* 2264 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsMultipleOpenResults() throws SQLServerException {
/* 2268 */     checkClosed(); return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsNamedParameters() throws SQLServerException {
/* 2272 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsSavepoints() throws SQLServerException {
/* 2276 */     checkClosed(); return true;
/*      */   }
/*      */   public boolean supportsStatementPooling() throws SQLException {
/* 2279 */     checkClosed();
/* 2280 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException
/*      */   {
/* 2285 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2286 */     checkClosed();
/* 2287 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean locatorsUpdateCopy() throws SQLException {
/* 2291 */     checkClosed(); return true;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   22 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDatabaseMetaData");
/*      */ 
/*   25 */     loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.DatabaseMetaData");
/*      */ 
/*   28 */     baseID = 0;
/*      */ 
/*  387 */     getColumnPrivilegesColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE" };
/*      */ 
/*  423 */     getTablesColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "TABLE_TYPE", "REMARKS" };
/*      */ 
/*  482 */     DOUBLE_RIGHT_BRACKET = new char[] { ']', ']' };
/*      */ 
/*  535 */     getColumnsColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "NUM_PREC_RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };
/*      */ 
/*  559 */     getColumnsColumnNamesKatmai = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "NUM_PREC_RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE", "SS_IS_SPARSE", "SS_IS_COLUMN_SET", "SS_IS_COMPUTED", "IS_AUTOINCREMENT" };
/*      */ 
/*  641 */     getFunctionsColumnNames = new String[] { "FUNCTION_CAT", "FUNCTION_SCHEM", "FUNCTION_NAME", "NUM_INPUT_PARAMS", "NUM_OUTPUT_PARAMS", "NUM_RESULT_SETS", "REMARKS", "FUNCTION_TYPE" };
/*      */ 
/*  679 */     getFunctionsColumnsColumnNames = new String[] { "FUNCTION_CAT", "FUNCTION_SCHEM", "FUNCTION_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };
/*      */ 
/*  762 */     getBestRowIdentifierColumnNames = new String[] { "SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN" };
/*      */ 
/*  814 */     pkfkColumnNames = new String[] { "PKTABLE_CAT", "PKTABLE_SCHEM", "PKTABLE_NAME", "PKCOLUMN_NAME", "FKTABLE_CAT", "FKTABLE_SCHEM", "FKTABLE_NAME", "FKCOLUMN_NAME", "KEY_SEQ", "UPDATE_RULE", "DELETE_RULE", "FK_NAME", "PK_NAME", "DEFERRABILITY" };
/*      */ 
/*  965 */     getIndexInfoColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "NON_UNIQUE", "INDEX_QUALIFIER", "INDEX_NAME", "TYPE", "ORDINAL_POSITION", "COLUMN_NAME", "ASC_OR_DESC", "CARDINALITY", "PAGES", "FILTER_CONDITION" };
/*      */ 
/* 1137 */     getPrimaryKeysColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "KEY_SEQ", "PK_NAME" };
/*      */ 
/* 1167 */     getProcedureColumnsColumnNames = new String[] { "PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };
/*      */ 
/* 1232 */     getProceduresColumnNames = new String[] { "PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "NUM_INPUT_PARAMS", "NUM_OUTPUT_PARAMS", "NUM_RESULT_SETS", "REMARKS", "PROCEDURE_TYPE" };
/*      */ 
/* 1392 */     getTablePrivilegesColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE" };
/*      */ 
/* 1564 */     getVersionColumnsColumnNames = new String[] { "SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN" };
/*      */   }
/*      */ 
/*      */   final class HandleAssociation
/*      */   {
/*      */     final String databaseName;
/*      */     final CallableStatement stmt;
/*      */ 
/*      */     HandleAssociation(String paramCallableStatement, CallableStatement arg3)
/*      */     {
/*   64 */       this.databaseName = paramCallableStatement;
/*      */       Object localObject;
/*   65 */       this.stmt = localObject;
/*      */     }
/*      */ 
/*      */     final void close() throws SQLServerException {
/*   69 */       ((SQLServerCallableStatement)this.stmt).close();
/*      */     }
/*      */   }
/*      */ 
/*      */   static enum CallableHandles
/*      */   {
/*   32 */     SP_COLUMNS("{ call sp_columns(?, ?, ?, ?, ?) }", "{ call sp_columns_100(?, ?, ?, ?, ?, ?) }"), 
/*   33 */     SP_COLUMN_PRIVILEGES("{ call sp_column_privileges(?, ?, ?, ?)}", "{ call sp_column_privileges(?, ?, ?, ?)}"), 
/*   34 */     SP_TABLES("{ call sp_tables(?, ?, ?, ?) }", "{ call sp_tables(?, ?, ?, ?) }"), 
/*   35 */     SP_SPECIAL_COLUMNS("{ call sp_special_columns (?, ?, ?, ?, ?, ?, ?)}", "{ call sp_special_columns_100 (?, ?, ?, ?, ?, ?, ?)}"), 
/*   36 */     SP_FKEYS("{ call sp_fkeys (?, ?, ?, ? , ? ,?)}", "{ call sp_fkeys (?, ?, ?, ? , ? ,?)}"), 
/*   37 */     SP_STATISTICS("{ call sp_statistics(?,?,?,?,?, ?) }", "{ call sp_statistics_100(?,?,?,?,?, ?) }"), 
/*   38 */     SP_SPROC_COLUMNS("{ call sp_sproc_columns(?, ?, ?,?,?) }", "{ call sp_sproc_columns_100(?, ?, ?,?,?) }"), 
/*   39 */     SP_STORED_PROCEDURES("{call sp_stored_procedures(?, ?, ?) }", "{call sp_stored_procedures(?, ?, ?) }"), 
/*   40 */     SP_TABLE_PRIVILEGES("{call sp_table_privileges(?,?,?) }", "{call sp_table_privileges(?,?,?) }"), 
/*   41 */     SP_PKEYS("{ call sp_pkeys (?, ?, ?)}", "{ call sp_pkeys (?, ?, ?)}");
/*      */ 
/*      */     private final String preKatProc;
/*      */     private final String katProc;
/*      */ 
/*      */     private CallableHandles(String paramString1, String paramString2) {
/*   49 */       this.preKatProc = paramString1;
/*   50 */       this.katProc = paramString2;
/*      */     }
/*      */ 
/*      */     CallableStatement prepare(SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/*   54 */       return paramSQLServerConnection.prepareCall(paramSQLServerConnection.isKatmaiOrLater() ? this.katProc : this.preKatProc);
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerDatabaseMetaData
 * JD-Core Version:    0.6.0
 */