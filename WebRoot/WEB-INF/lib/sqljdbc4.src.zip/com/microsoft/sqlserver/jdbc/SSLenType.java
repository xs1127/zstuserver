/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */  enum SSLenType
/*     */ {
/*  98 */   FIXEDLENTYPE, 
/*  99 */   BYTELENTYPE, 
/* 100 */   USHORTLENTYPE, 
/* 101 */   LONGLENTYPE, 
/* 102 */   PARTLENTYPE;
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SSLenType
 * JD-Core Version:    0.6.0
 */