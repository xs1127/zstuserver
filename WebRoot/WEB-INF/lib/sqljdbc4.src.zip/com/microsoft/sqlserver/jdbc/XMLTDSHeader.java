/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class XMLTDSHeader
/*    */ {
/*    */   private final String databaseName;
/*    */   private final String owningSchema;
/*    */   private final String xmlSchemaCollection;
/*    */ 
/*    */   XMLTDSHeader(TDSReader paramTDSReader)
/*    */     throws SQLServerException
/*    */   {
/* 34 */     if (0 != paramTDSReader.readUnsignedByte())
/*    */     {
/* 37 */       this.databaseName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 38 */       this.owningSchema = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 39 */       this.xmlSchemaCollection = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
/*    */     }
/*    */     else
/*    */     {
/* 43 */       this.xmlSchemaCollection = null;
/* 44 */       this.owningSchema = null;
/* 45 */       this.databaseName = null;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.XMLTDSHeader
 * JD-Core Version:    0.6.0
 */