/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */  enum SQLServerDriverIntProperty
/*     */ {
/* 774 */   PACKET_SIZE("packetSize", 8000), 
/* 775 */   LOCK_TIMEOUT("lockTimeout", -1), 
/* 776 */   LOGIN_TIMEOUT("loginTimeout", 15), 
/* 777 */   PORT_NUMBER("portNumber", 1433);
/*     */ 
/*     */   private String name;
/*     */   private int defaultValue;
/*     */ 
/* 784 */   private SQLServerDriverIntProperty(String paramString, int paramInt) { this.name = paramString;
/* 785 */     this.defaultValue = paramInt;
/*     */   }
/*     */ 
/*     */   int getDefaultValue()
/*     */   {
/* 790 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 795 */     return this.name;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerDriverIntProperty
 * JD-Core Version:    0.6.0
 */