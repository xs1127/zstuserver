/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Locale;
/*      */ import java.util.SimpleTimeZone;
/*      */ import java.util.TimeZone;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ final class DTV
/*      */ {
/*      */   private DTVImpl impl;
/*      */ 
/*      */   void setValue(SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection)
/*      */     throws SQLServerException
/*      */   {
/*   86 */     if (null == this.impl) {
/*   87 */       this.impl = new AppDTVImpl();
/*      */     }
/*   89 */     this.impl.setValue(this, paramSQLCollation, paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger, paramSQLServerConnection);
/*      */   }
/*      */ 
/*      */   final void setValue(Object paramObject, JavaType paramJavaType)
/*      */   {
/*   94 */     this.impl.setValue(paramObject, paramJavaType);
/*      */   }
/*      */   final void clear() {
/*   97 */     this.impl = null;
/*      */   }
/*      */ 
/*      */   final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
/*  101 */     if (null == this.impl) {
/*  102 */       this.impl = new ServerDTVImpl();
/*      */     }
/*  104 */     this.impl.skipValue(paramTypeInfo, paramTDSReader, paramBoolean);
/*      */   }
/*      */ 
/*      */   final void initFromCompressedNull()
/*      */   {
/*  109 */     if (null == this.impl) {
/*  110 */       this.impl = new ServerDTVImpl();
/*      */     }
/*  112 */     this.impl.initFromCompressedNull();
/*      */   }
/*      */ 
/*      */   final void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs)
/*      */   {
/*  117 */     this.impl.setStreamSetterArgs(paramStreamSetterArgs);
/*      */   }
/*      */ 
/*      */   final void setCalendar(Calendar paramCalendar)
/*      */   {
/*  122 */     this.impl.setCalendar(paramCalendar);
/*      */   }
/*      */ 
/*      */   final void setScale(Integer paramInteger)
/*      */   {
/*  127 */     this.impl.setScale(paramInteger);
/*      */   }
/*      */   StreamSetterArgs getStreamSetterArgs() {
/*  130 */     return this.impl.getStreamSetterArgs(); } 
/*  131 */   Calendar getCalendar() { return this.impl.getCalendar(); } 
/*  132 */   Integer getScale() { return this.impl.getScale();
/*      */   }
/*      */ 
/*      */   boolean isNull()
/*      */   {
/*  139 */     return (null == this.impl) || (this.impl.isNull());
/*      */   }
/*      */ 
/*      */   final boolean isInitialized()
/*      */   {
/*  148 */     return null != this.impl;
/*      */   }
/*      */ 
/*      */   final void setJdbcType(JDBCType paramJDBCType)
/*      */   {
/*  153 */     if (null == this.impl) {
/*  154 */       this.impl = new AppDTVImpl();
/*      */     }
/*  156 */     this.impl.setJdbcType(paramJDBCType);
/*      */   }
/*      */ 
/*      */   final JDBCType getJdbcType()
/*      */   {
/*  164 */     assert (null != this.impl);
/*  165 */     return this.impl.getJdbcType();
/*      */   }
/*      */ 
/*      */   final JavaType getJavaType()
/*      */   {
/*  173 */     assert (null != this.impl);
/*  174 */     return this.impl.getJavaType();
/*      */   }
/*      */ 
/*      */   Object getValue(JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/*  191 */     if (null == this.impl)
/*  192 */       this.impl = new ServerDTVImpl();
/*  193 */     return this.impl.getValue(this, paramJDBCType, paramInt, paramInputStreamGetterArgs, paramCalendar, paramTypeInfo, paramTDSReader);
/*      */   }
/*      */ 
/*      */   Object getSetterValue()
/*      */   {
/*  198 */     return this.impl.getSetterValue();
/*      */   }
/*      */ 
/*      */   void setImpl(DTVImpl paramDTVImpl)
/*      */   {
/*  207 */     this.impl = paramDTVImpl;
/*      */   }
/*      */ 
/*      */   final void executeOp(DTVExecuteOp paramDTVExecuteOp)
/*      */     throws SQLServerException
/*      */   {
/*  903 */     JDBCType localJDBCType = getJdbcType();
/*  904 */     Object localObject = getSetterValue();
/*  905 */     JavaType localJavaType = getJavaType();
/*  906 */     int i = 0;
/*      */ 
/*  908 */     if (null == localObject)
/*      */     {
/*  910 */       switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[localJDBCType.ordinal()])
/*      */       {
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  916 */         paramDTVExecuteOp.execute(this, (String)null);
/*  917 */         break;
/*      */       case 9:
/*  920 */         paramDTVExecuteOp.execute(this, (Integer)null);
/*  921 */         break;
/*      */       case 3:
/*  924 */         paramDTVExecuteOp.execute(this, (Date)null);
/*  925 */         break;
/*      */       case 2:
/*  928 */         paramDTVExecuteOp.execute(this, (Time)null);
/*  929 */         break;
/*      */       case 1:
/*  932 */         paramDTVExecuteOp.execute(this, (Timestamp)null);
/*  933 */         break;
/*      */       case 4:
/*  936 */         paramDTVExecuteOp.execute(this, (DateTimeOffset)null);
/*  937 */         break;
/*      */       case 10:
/*      */       case 11:
/*  941 */         paramDTVExecuteOp.execute(this, (Float)null);
/*  942 */         break;
/*      */       case 12:
/*      */       case 13:
/*  946 */         paramDTVExecuteOp.execute(this, (BigDecimal)null);
/*  947 */         break;
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*  957 */         paramDTVExecuteOp.execute(this, (byte[])null);
/*  958 */         break;
/*      */       case 22:
/*  961 */         paramDTVExecuteOp.execute(this, (Byte)null);
/*  962 */         break;
/*      */       case 23:
/*  965 */         paramDTVExecuteOp.execute(this, (Long)null);
/*  966 */         break;
/*      */       case 24:
/*  969 */         paramDTVExecuteOp.execute(this, (Double)null);
/*  970 */         break;
/*      */       case 25:
/*  973 */         paramDTVExecuteOp.execute(this, (Short)null);
/*  974 */         break;
/*      */       case 26:
/*      */       case 27:
/*  978 */         paramDTVExecuteOp.execute(this, (Boolean)null);
/*  979 */         break;
/*      */       case 28:
/*  982 */         paramDTVExecuteOp.execute(this, (SQLServerSQLXML)null);
/*  983 */         break;
/*      */       case 29:
/*      */       case 30:
/*      */       case 31:
/*      */       case 32:
/*      */       case 33:
/*      */       case 34:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*  994 */         i = 1;
/*  995 */         break;
/*      */       case 38:
/*      */       default:
/*  999 */         if (!$assertionsDisabled) throw new AssertionError("Unexpected JDBCType: " + localJDBCType);
/* 1000 */         i = 1;
/* 1001 */         break;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1006 */       switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JavaType[localJavaType.ordinal()])
/*      */       {
/*      */       case 5:
/* 1009 */         paramDTVExecuteOp.execute(this, (String)localObject);
/* 1010 */         break;
/*      */       case 6:
/* 1013 */         paramDTVExecuteOp.execute(this, (Integer)localObject);
/* 1014 */         break;
/*      */       case 2:
/* 1017 */         paramDTVExecuteOp.execute(this, (Date)localObject);
/* 1018 */         break;
/*      */       case 1:
/* 1021 */         paramDTVExecuteOp.execute(this, (Time)localObject);
/* 1022 */         break;
/*      */       case 3:
/* 1025 */         paramDTVExecuteOp.execute(this, (Timestamp)localObject);
/* 1026 */         break;
/*      */       case 4:
/* 1029 */         paramDTVExecuteOp.execute(this, (DateTimeOffset)localObject);
/* 1030 */         break;
/*      */       case 7:
/* 1033 */         paramDTVExecuteOp.execute(this, (Float)localObject);
/* 1034 */         break;
/*      */       case 8:
/* 1037 */         paramDTVExecuteOp.execute(this, (BigDecimal)localObject);
/* 1038 */         break;
/*      */       case 9:
/* 1041 */         paramDTVExecuteOp.execute(this, (byte[])(byte[])localObject);
/* 1042 */         break;
/*      */       case 10:
/* 1045 */         paramDTVExecuteOp.execute(this, (Byte)localObject);
/* 1046 */         break;
/*      */       case 11:
/* 1049 */         paramDTVExecuteOp.execute(this, (Long)localObject);
/* 1050 */         break;
/*      */       case 12:
/* 1053 */         paramDTVExecuteOp.execute(this, (Double)localObject);
/* 1054 */         break;
/*      */       case 13:
/* 1057 */         paramDTVExecuteOp.execute(this, (Short)localObject);
/* 1058 */         break;
/*      */       case 14:
/* 1061 */         paramDTVExecuteOp.execute(this, (Boolean)localObject);
/* 1062 */         break;
/*      */       case 15:
/* 1065 */         paramDTVExecuteOp.execute(this, (Blob)localObject);
/* 1066 */         break;
/*      */       case 16:
/*      */       case 17:
/* 1070 */         paramDTVExecuteOp.execute(this, (Clob)localObject);
/* 1071 */         break;
/*      */       case 18:
/* 1074 */         paramDTVExecuteOp.execute(this, (InputStream)localObject);
/* 1075 */         break;
/*      */       case 19:
/* 1078 */         paramDTVExecuteOp.execute(this, (Reader)localObject);
/* 1079 */         break;
/*      */       case 20:
/* 1082 */         paramDTVExecuteOp.execute(this, (SQLServerSQLXML)localObject);
/* 1083 */         break;
/*      */       default:
/* 1086 */         if (!$assertionsDisabled) throw new AssertionError("Unexpected JavaType: " + localJavaType);
/* 1087 */         i = 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1092 */     if (i != 0)
/*      */     {
/* 1094 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
/* 1095 */       Object[] arrayOfObject = { localJavaType, localJDBCType };
/* 1096 */       throw new SQLServerException(localMessageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   void sendByRPC(String paramString, TypeInfo paramTypeInfo, SQLCollation paramSQLCollation, int paramInt, boolean paramBoolean, TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection)
/*      */     throws SQLServerException
/*      */   {
/* 1116 */     executeOp(new SendByRPCOp(paramString, paramTypeInfo, paramSQLCollation, paramInt, paramBoolean, paramTDSWriter, paramSQLServerConnection));
/*      */   }
/*      */ 
/*      */   final class SendByRPCOp extends DTVExecuteOp
/*      */   {
/*      */     private final String name;
/*      */     private final TypeInfo typeInfo;
/*      */     private final SQLCollation collation;
/*      */     private final int outScale;
/*      */     private final boolean isOutParam;
/*      */     private final TDSWriter tdsWriter;
/*      */     private final SQLServerConnection conn;
/*      */ 
/*      */     SendByRPCOp(String paramTypeInfo, TypeInfo paramSQLCollation, SQLCollation paramInt, int paramBoolean, boolean paramTDSWriter, TDSWriter paramSQLServerConnection, SQLServerConnection arg8)
/*      */     {
/*  229 */       this.name = paramTypeInfo;
/*  230 */       this.typeInfo = paramSQLCollation;
/*  231 */       this.collation = paramInt;
/*  232 */       this.outScale = paramBoolean;
/*  233 */       this.isOutParam = paramTDSWriter;
/*  234 */       this.tdsWriter = paramSQLServerConnection;
/*      */       Object localObject;
/*  235 */       this.conn = localObject;
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, String paramString) throws SQLServerException
/*      */     {
/*  240 */       this.tdsWriter.writeRPCStringUnicode(this.name, paramString, this.isOutParam, this.collation);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Clob paramClob)
/*      */       throws SQLServerException
/*      */     {
/*  246 */       assert (null != paramClob);
/*      */ 
/*  248 */       long l = 0L;
/*  249 */       Reader localReader = null;
/*      */       try
/*      */       {
/*  253 */         l = DataTypes.getCheckedLength(this.conn, paramDTV.getJdbcType(), paramClob.length(), false);
/*  254 */         localReader = paramClob.getCharacterStream();
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/*  258 */         SQLServerException.makeFromDriverError(this.conn, null, localSQLException.getMessage(), null, false);
/*      */       }
/*      */ 
/*  262 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*  263 */       if ((null != this.collation) && ((JDBCType.CHAR == localJDBCType) || (JDBCType.VARCHAR == localJDBCType) || (JDBCType.LONGVARCHAR == localJDBCType) || (JDBCType.CLOB == localJDBCType)))
/*      */       {
/*  269 */         if (null == localReader)
/*      */         {
/*  271 */           this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, localJDBCType, this.collation);
/*      */         }
/*      */         else
/*      */         {
/*  280 */           ReaderInputStream localReaderInputStream = null;
/*      */           try
/*      */           {
/*  284 */             localReaderInputStream = new ReaderInputStream(localReader, this.collation.getCharset(), l);
/*      */           }
/*      */           catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */           {
/*  291 */             MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
/*  292 */             Object[] arrayOfObject = { new String(localUnsupportedEncodingException.getMessage()) };
/*  293 */             SQLServerException.makeFromDriverError(this.conn, null, localMessageFormat.format(arrayOfObject), null, true);
/*      */           }
/*      */ 
/*  301 */           this.tdsWriter.writeRPCInputStream(this.name, localReaderInputStream, -1L, this.isOutParam, localJDBCType, this.collation);
/*      */         }
/*      */ 
/*      */       }
/*  312 */       else if (null == localReader)
/*      */       {
/*  314 */         this.tdsWriter.writeRPCStringUnicode(this.name, null, this.isOutParam, this.collation);
/*      */       }
/*      */       else
/*      */       {
/*  318 */         this.tdsWriter.writeRPCReaderUnicode(this.name, localReader, l, this.isOutParam, this.collation);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Byte paramByte)
/*      */       throws SQLServerException
/*      */     {
/*  330 */       this.tdsWriter.writeRPCByte(this.name, paramByte, this.isOutParam);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Integer paramInteger) throws SQLServerException
/*      */     {
/*  335 */       this.tdsWriter.writeRPCInt(this.name, paramInteger, this.isOutParam);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Time paramTime) throws SQLServerException
/*      */     {
/*  340 */       sendTemporal(paramDTV, JavaType.TIME, paramTime);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Date paramDate)
/*      */       throws SQLServerException
/*      */     {
/*  348 */       sendTemporal(paramDTV, JavaType.DATE, paramDate);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Timestamp paramTimestamp)
/*      */       throws SQLServerException
/*      */     {
/*  356 */       sendTemporal(paramDTV, JavaType.TIMESTAMP, paramTimestamp);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, DateTimeOffset paramDateTimeOffset)
/*      */       throws SQLServerException
/*      */     {
/*  364 */       sendTemporal(paramDTV, JavaType.DATETIMEOFFSET, paramDateTimeOffset);
/*      */     }
/*      */ 
/*      */     private void sendTemporal(DTV paramDTV, JavaType paramJavaType, Object paramObject)
/*      */       throws SQLServerException
/*      */     {
/*  388 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*  389 */       GregorianCalendar localGregorianCalendar = null;
/*  390 */       int i = 0;
/*  391 */       int j = 0;
/*      */ 
/*  398 */       if (null != paramObject)
/*      */       {
/*      */         Object localObject1;
/*      */         long l;
/*      */         Object localObject2;
/*  404 */         switch (DTV.1.$SwitchMap$com$microsoft$sqlserver$jdbc$JavaType[paramJavaType.ordinal()])
/*      */         {
/*      */         case 1:
/*  409 */           localObject1 = null != paramDTV.getCalendar() ? paramDTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */ 
/*  412 */           l = ((Time)paramObject).getTime();
/*  413 */           i = 1000000 * (int)(l % 1000L);
/*      */ 
/*  422 */           if (i >= 0) break;
/*  423 */           i += 1000000000; break;
/*      */         case 2:
/*  431 */           localObject1 = null != paramDTV.getCalendar() ? paramDTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */ 
/*  434 */           l = ((Date)paramObject).getTime();
/*  435 */           break;
/*      */         case 3:
/*  441 */           localObject1 = null != paramDTV.getCalendar() ? paramDTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */ 
/*  444 */           localObject2 = (Timestamp)paramObject;
/*  445 */           l = ((Timestamp)localObject2).getTime();
/*  446 */           i = ((Timestamp)localObject2).getNanos();
/*  447 */           break;
/*      */         case 4:
/*  452 */           localObject2 = (DateTimeOffset)paramObject;
/*      */ 
/*  454 */           l = ((DateTimeOffset)localObject2).getTimestamp().getTime();
/*  455 */           i = ((DateTimeOffset)localObject2).getTimestamp().getNanos();
/*  456 */           j = ((DateTimeOffset)localObject2).getMinutesOffset();
/*      */ 
/*  460 */           assert (null == paramDTV.getCalendar());
/*      */ 
/*  467 */           localObject1 = (JDBCType.DATETIMEOFFSET == localJDBCType) && ((null == this.typeInfo) || (SSType.DATETIMEOFFSET == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");
/*      */ 
/*  473 */           break;
/*      */         default:
/*  477 */           throw new AssertionError("Unexpected JavaType: " + paramJavaType);
/*      */         }
/*      */ 
/*  482 */         localGregorianCalendar = new GregorianCalendar((TimeZone)localObject1, Locale.US);
/*      */ 
/*  486 */         localGregorianCalendar.setLenient(true);
/*      */ 
/*  490 */         localGregorianCalendar.clear();
/*      */ 
/*  493 */         localGregorianCalendar.setTimeInMillis(l);
/*      */       }
/*      */ 
/*  498 */       if (null != this.typeInfo)
/*      */       {
/*  500 */         switch (DTV.1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSType[this.typeInfo.getSSType().ordinal()])
/*      */         {
/*      */         case 1:
/*  503 */           this.tdsWriter.writeRPCDateTime2(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, this.typeInfo.getScale(), this.isOutParam);
/*      */ 
/*  510 */           break;
/*      */         case 2:
/*  513 */           this.tdsWriter.writeRPCDate(this.name, localGregorianCalendar, this.isOutParam);
/*      */ 
/*  518 */           break;
/*      */         case 3:
/*  521 */           this.tdsWriter.writeRPCTime(this.name, localGregorianCalendar, i, this.typeInfo.getScale(), this.isOutParam);
/*      */ 
/*  528 */           break;
/*      */         case 4:
/*  534 */           if (JavaType.DATETIMEOFFSET != paramJavaType)
/*      */           {
/*  536 */             localGregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(localGregorianCalendar), paramJavaType, this.conn.baseYear());
/*      */ 
/*  542 */             j = 0;
/*      */           }
/*      */ 
/*  545 */           this.tdsWriter.writeRPCDateTimeOffset(this.name, localGregorianCalendar, j, i, this.typeInfo.getScale(), this.isOutParam);
/*      */ 
/*  553 */           break;
/*      */         case 5:
/*      */         case 6:
/*  557 */           this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, this.isOutParam);
/*      */ 
/*  562 */           break;
/*      */         default:
/*  565 */           if ($assertionsDisabled) break; throw new AssertionError("Unexpected SSType: " + this.typeInfo.getSSType());
/*      */         }
/*      */ 
/*      */       }
/*  579 */       else if (this.conn.isKatmaiOrLater())
/*      */       {
/*  581 */         switch (DTV.1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[localJDBCType.ordinal()])
/*      */         {
/*      */         case 1:
/*  584 */           this.tdsWriter.writeRPCDateTime2(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, 7, this.isOutParam);
/*      */ 
/*  591 */           break;
/*      */         case 2:
/*  596 */           if (this.conn.sendTimeAsDatetime())
/*      */           {
/*  598 */             this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(localGregorianCalendar, JavaType.TIME, 1970), i, this.isOutParam); break;
/*      */           }
/*      */ 
/*  606 */           this.tdsWriter.writeRPCTime(this.name, localGregorianCalendar, i, 7, this.isOutParam);
/*      */ 
/*  614 */           break;
/*      */         case 3:
/*  617 */           this.tdsWriter.writeRPCDate(this.name, localGregorianCalendar, this.isOutParam);
/*      */ 
/*  622 */           break;
/*      */         case 4:
/*  628 */           if (JavaType.DATETIMEOFFSET != paramJavaType)
/*      */           {
/*  630 */             localGregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(localGregorianCalendar), paramJavaType, this.conn.baseYear());
/*      */ 
/*  636 */             j = 0;
/*      */           }
/*      */ 
/*  639 */           this.tdsWriter.writeRPCDateTimeOffset(this.name, localGregorianCalendar, j, i, 7, this.isOutParam);
/*      */ 
/*  647 */           break;
/*      */         default:
/*  650 */           if ($assertionsDisabled) break; throw new AssertionError("Unexpected JDBCType: " + localJDBCType);
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  669 */         assert ((JDBCType.TIME == localJDBCType) || (JDBCType.DATE == localJDBCType) || (JDBCType.TIMESTAMP == localJDBCType)) : ("Unexpected JDBCType: " + localJDBCType);
/*      */ 
/*  671 */         this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, 1970), i, this.isOutParam);
/*      */       }
/*      */     }
/*      */ 
/*      */     private GregorianCalendar timestampNormalizedCalendar(GregorianCalendar paramGregorianCalendar, JavaType paramJavaType, int paramInt)
/*      */     {
/*  698 */       if (null != paramGregorianCalendar)
/*      */       {
/*  700 */         switch (DTV.1.$SwitchMap$com$microsoft$sqlserver$jdbc$JavaType[paramJavaType.ordinal()])
/*      */         {
/*      */         case 2:
/*  703 */           paramGregorianCalendar.set(11, 0);
/*  704 */           paramGregorianCalendar.set(12, 0);
/*  705 */           paramGregorianCalendar.set(13, 0);
/*  706 */           paramGregorianCalendar.set(14, 0);
/*  707 */           break;
/*      */         case 1:
/*  710 */           assert ((1970 == paramInt) || (1900 == paramInt));
/*  711 */           paramGregorianCalendar.set(paramInt, 0, 1);
/*  712 */           break;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  719 */       return paramGregorianCalendar;
/*      */     }
/*      */ 
/*      */     private GregorianCalendar localCalendarAsUTC(GregorianCalendar paramGregorianCalendar)
/*      */     {
/*  730 */       if (null == paramGregorianCalendar) {
/*  731 */         return null;
/*      */       }
/*      */ 
/*  734 */       int i = paramGregorianCalendar.get(1);
/*  735 */       int j = paramGregorianCalendar.get(2);
/*  736 */       int k = paramGregorianCalendar.get(5);
/*  737 */       int m = paramGregorianCalendar.get(11);
/*  738 */       int n = paramGregorianCalendar.get(12);
/*  739 */       int i1 = paramGregorianCalendar.get(13);
/*  740 */       int i2 = paramGregorianCalendar.get(14);
/*      */ 
/*  742 */       paramGregorianCalendar.setTimeZone(UTC.timeZone);
/*  743 */       paramGregorianCalendar.set(i, j, k, m, n, i1);
/*  744 */       paramGregorianCalendar.set(14, i2);
/*  745 */       return paramGregorianCalendar;
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Float paramFloat) throws SQLServerException
/*      */     {
/*  750 */       if (JDBCType.REAL == paramDTV.getJdbcType())
/*      */       {
/*  752 */         this.tdsWriter.writeRPCReal(this.name, paramFloat, this.isOutParam);
/*      */       }
/*      */       else
/*      */       {
/*  762 */         Double localDouble = null == paramFloat ? null : new Double(paramFloat.floatValue());
/*  763 */         this.tdsWriter.writeRPCDouble(this.name, localDouble, this.isOutParam);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Double paramDouble) throws SQLServerException
/*      */     {
/*  769 */       this.tdsWriter.writeRPCDouble(this.name, paramDouble, this.isOutParam);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, BigDecimal paramBigDecimal) throws SQLServerException
/*      */     {
/*  774 */       if (DDC.exceedsMaxRPCDecimalPrecisionOrScale(paramBigDecimal))
/*      */       {
/*  776 */         String str = paramBigDecimal.toString();
/*  777 */         this.tdsWriter.writeRPCStringUnicode(this.name, str, this.isOutParam, this.collation);
/*      */       }
/*      */       else
/*      */       {
/*  781 */         this.tdsWriter.writeRPCBigDecimal(this.name, paramBigDecimal, this.outScale, this.isOutParam);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Long paramLong)
/*      */       throws SQLServerException
/*      */     {
/*  791 */       this.tdsWriter.writeRPCLong(this.name, paramLong, this.isOutParam);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Short paramShort) throws SQLServerException
/*      */     {
/*  796 */       this.tdsWriter.writeRPCShort(this.name, paramShort, this.isOutParam);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Boolean paramBoolean) throws SQLServerException
/*      */     {
/*  801 */       this.tdsWriter.writeRPCBit(this.name, paramBoolean, this.isOutParam);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, byte[] paramArrayOfByte) throws SQLServerException
/*      */     {
/*  806 */       this.tdsWriter.writeRPCByteArray(this.name, paramArrayOfByte, this.isOutParam, paramDTV.getJdbcType(), this.collation);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Blob paramBlob)
/*      */       throws SQLServerException
/*      */     {
/*  816 */       assert (null != paramBlob);
/*      */ 
/*  818 */       long l = 0L;
/*  819 */       InputStream localInputStream = null;
/*      */       try
/*      */       {
/*  823 */         l = DataTypes.getCheckedLength(this.conn, paramDTV.getJdbcType(), paramBlob.length(), false);
/*  824 */         localInputStream = paramBlob.getBinaryStream();
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/*  828 */         SQLServerException.makeFromDriverError(this.conn, null, localSQLException.getMessage(), null, false);
/*      */       }
/*      */ 
/*  831 */       if (null == localInputStream)
/*      */       {
/*  833 */         this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, paramDTV.getJdbcType(), this.collation);
/*      */       }
/*      */       else
/*      */       {
/*  842 */         this.tdsWriter.writeRPCInputStream(this.name, localInputStream, l, this.isOutParam, paramDTV.getJdbcType(), this.collation);
/*      */       }
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, SQLServerSQLXML paramSQLServerSQLXML)
/*      */       throws SQLServerException
/*      */     {
/*  854 */       InputStream localInputStream = null == paramSQLServerSQLXML ? null : paramSQLServerSQLXML.getValue();
/*  855 */       this.tdsWriter.writeRPCXML(this.name, localInputStream, null == localInputStream ? 0L : paramDTV.getStreamSetterArgs().getLength(), this.isOutParam);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, InputStream paramInputStream)
/*      */       throws SQLServerException
/*      */     {
/*  863 */       this.tdsWriter.writeRPCInputStream(this.name, paramInputStream, null == paramInputStream ? 0L : paramDTV.getStreamSetterArgs().getLength(), this.isOutParam, paramDTV.getJdbcType(), this.collation);
/*      */     }
/*      */ 
/*      */     void execute(DTV paramDTV, Reader paramReader)
/*      */       throws SQLServerException
/*      */     {
/*  874 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*      */ 
/*  877 */       assert (null != paramReader);
/*      */ 
/*  884 */       assert ((JDBCType.NCHAR == localJDBCType) || (JDBCType.NVARCHAR == localJDBCType) || (JDBCType.LONGNVARCHAR == localJDBCType) || (JDBCType.NCLOB == localJDBCType)) : ("SendByRPCOp(Reader): Unexpected JDBC type " + localJDBCType);
/*      */ 
/*  887 */       this.tdsWriter.writeRPCReaderUnicode(this.name, paramReader, paramDTV.getStreamSetterArgs().getLength(), this.isOutParam, this.collation);
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.DTV
 * JD-Core Version:    0.6.0
 */