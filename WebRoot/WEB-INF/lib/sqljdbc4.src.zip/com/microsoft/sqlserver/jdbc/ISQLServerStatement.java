package com.microsoft.sqlserver.jdbc;

import java.sql.Statement;

public abstract interface ISQLServerStatement extends Statement
{
  public abstract void setResponseBuffering(String paramString)
    throws SQLServerException;

  public abstract String getResponseBuffering()
    throws SQLServerException;
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ISQLServerStatement
 * JD-Core Version:    0.6.0
 */