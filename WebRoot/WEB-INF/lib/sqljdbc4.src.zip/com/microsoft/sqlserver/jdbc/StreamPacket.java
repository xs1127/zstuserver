/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ abstract class StreamPacket
/*    */ {
/*    */   int packetType;
/*    */ 
/*    */   final int getTokenType()
/*    */   {
/* 13 */     return this.packetType;
/*    */   }
/*    */ 
/*    */   StreamPacket() {
/* 17 */     this.packetType = 0;
/*    */   }
/*    */ 
/*    */   StreamPacket(int paramInt)
/*    */   {
/* 22 */     this.packetType = paramInt;
/*    */   }
/*    */ 
/*    */   abstract void setFromTDS(TDSReader paramTDSReader)
/*    */     throws SQLServerException;
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamPacket
 * JD-Core Version:    0.6.0
 */