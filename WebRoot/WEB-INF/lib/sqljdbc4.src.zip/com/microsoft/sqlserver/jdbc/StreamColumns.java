/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class StreamColumns extends StreamPacket
/*    */ {
/*    */   private Column[] columns;
/*    */ 
/*    */   StreamColumns()
/*    */   {
/* 23 */     super(129);
/*    */   }
/*    */ 
/*    */   void setFromTDS(TDSReader paramTDSReader)
/*    */     throws SQLServerException
/*    */   {
/* 33 */     if ((129 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/*    */ 
/* 35 */     int i = paramTDSReader.readUnsignedShort();
/*    */ 
/* 38 */     if (65535 == i) {
/* 39 */       return;
/*    */     }
/* 41 */     this.columns = new Column[i];
/*    */ 
/* 43 */     for (int j = 0; j < i; j++)
/*    */     {
/* 46 */       TypeInfo localTypeInfo = TypeInfo.getInstance(paramTDSReader);
/*    */ 
/* 52 */       SQLIdentifier localSQLIdentifier = new SQLIdentifier();
/* 53 */       if ((SSType.TEXT == localTypeInfo.getSSType()) || (SSType.NTEXT == localTypeInfo.getSSType()) || (SSType.IMAGE == localTypeInfo.getSSType()))
/*    */       {
/* 58 */         localSQLIdentifier = paramTDSReader.readSQLIdentifier();
/*    */       }
/*    */ 
/* 62 */       String str = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/*    */ 
/* 64 */       this.columns[j] = new Column(localTypeInfo, str, localSQLIdentifier);
/*    */     }
/*    */   }
/*    */ 
/*    */   Column[] buildColumns(StreamColInfo paramStreamColInfo, StreamTabName paramStreamTabName)
/*    */     throws SQLServerException
/*    */   {
/* 75 */     if ((null != paramStreamColInfo) && (null != paramStreamTabName)) {
/* 76 */       paramStreamTabName.applyTo(this.columns, paramStreamColInfo.applyTo(this.columns));
/*    */     }
/* 78 */     return this.columns;
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamColumns
 * JD-Core Version:    0.6.0
 */