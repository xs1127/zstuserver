/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ final class SQLServerClobAsciiOutputStream extends OutputStream
/*     */ {
/* 571 */   private SQLServerClobBase parentClob = null;
/*     */   private long streamPos;
/* 602 */   private byte[] bSingleByte = new byte[1];
/*     */ 
/*     */   SQLServerClobAsciiOutputStream(SQLServerClobBase paramSQLServerClobBase, long paramLong)
/*     */   {
/* 575 */     this.parentClob = paramSQLServerClobBase;
/* 576 */     this.streamPos = paramLong;
/*     */   }
/*     */ 
/*     */   public void write(byte[] paramArrayOfByte) throws IOException {
/* 580 */     if (null == paramArrayOfByte) return;
/* 581 */     write(paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */   }
/*     */ 
/*     */   public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/* 585 */     if (null == paramArrayOfByte) return;
/*     */ 
/*     */     try
/*     */     {
/* 589 */       String str = new String(paramArrayOfByte, paramInt1, paramInt2, "US-ASCII");
/*     */ 
/* 594 */       int i = this.parentClob.setString(this.streamPos, str);
/* 595 */       this.streamPos += i;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 599 */       throw new IOException(localSQLException.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void write(int paramInt) throws IOException
/*     */   {
/* 605 */     this.bSingleByte[0] = (byte)(paramInt & 0xFF);
/* 606 */     write(this.bSingleByte, 0, this.bSingleByte.length);
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerClobAsciiOutputStream
 * JD-Core Version:    0.6.0
 */