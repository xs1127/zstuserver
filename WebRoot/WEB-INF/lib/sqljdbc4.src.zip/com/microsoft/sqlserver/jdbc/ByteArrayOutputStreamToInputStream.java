/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ 
/*     */ final class ByteArrayOutputStreamToInputStream extends ByteArrayOutputStream
/*     */ {
/*     */   ByteArrayInputStream getInputStream()
/*     */     throws SQLServerException
/*     */   {
/* 553 */     ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(this.buf, 0, this.count);
/* 554 */     return localByteArrayInputStream;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ByteArrayOutputStreamToInputStream
 * JD-Core Version:    0.6.0
 */