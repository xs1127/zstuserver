package com.microsoft.sqlserver.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.UUID;

public abstract interface ISQLServerConnection extends Connection
{
  public static final int TRANSACTION_SNAPSHOT = 4096;

  public abstract UUID getClientConnectionId()
    throws SQLException;
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ISQLServerConnection
 * JD-Core Version:    0.6.0
 */