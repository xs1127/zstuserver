/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */  enum SQLServerDriverBooleanProperty
/*     */ {
/* 801 */   DISABLE_STATEMENT_POOLING("disableStatementPooling", true), 
/* 802 */   ENCRYPT("encrypt", false), 
/* 803 */   INTEGRATED_SECURITY("integratedSecurity", false), 
/* 804 */   LAST_UPDATE_COUNT("lastUpdateCount", true), 
/* 805 */   MULTI_SUBNET_FAILOVER("multiSubnetFailover", false), 
/* 806 */   SEND_STRING_PARAMETERS_AS_UNICODE("sendStringParametersAsUnicode", true), 
/* 807 */   SEND_TIME_AS_DATETIME("sendTimeAsDatetime", true), 
/* 808 */   TRUST_SERVER_CERTIFICATE("trustServerCertificate", false), 
/* 809 */   XOPEN_STATES("xopenStates", false);
/*     */ 
/*     */   private String name;
/*     */   private boolean defaultValue;
/*     */ 
/* 816 */   private SQLServerDriverBooleanProperty(String paramString, boolean paramBoolean) { this.name = paramString;
/* 817 */     this.defaultValue = paramBoolean;
/*     */   }
/*     */ 
/*     */   boolean getDefaultValue()
/*     */   {
/* 822 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 827 */     return this.name;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerDriverBooleanProperty
 * JD-Core Version:    0.6.0
 */