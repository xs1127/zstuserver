/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ final class SQLServerConnectionSecurityManager
/*      */ {
/*      */   static final String dllName = "sqljdbc_auth.dll";
/*      */   String serverName;
/*      */   int portNumber;
/*      */ 
/*      */   SQLServerConnectionSecurityManager(String paramString, int paramInt)
/*      */   {
/* 3634 */     this.serverName = paramString;
/* 3635 */     this.portNumber = paramInt;
/*      */   }
/*      */ 
/*      */   public void checkConnect()
/*      */     throws SecurityException
/*      */   {
/* 3641 */     SecurityManager localSecurityManager = System.getSecurityManager();
/* 3642 */     if (null != localSecurityManager)
/*      */     {
/* 3644 */       localSecurityManager.checkConnect(this.serverName, this.portNumber);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void checkLink() throws SecurityException {
/* 3649 */     SecurityManager localSecurityManager = System.getSecurityManager();
/* 3650 */     if (null != localSecurityManager)
/*      */     {
/* 3652 */       localSecurityManager.checkLink("sqljdbc_auth.dll");
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerConnectionSecurityManager
 * JD-Core Version:    0.6.0
 */