/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ class IntColumnIdentityFilter extends ColumnFilter
/*      */ {
/*      */   private static final String zeroOneToYesNo(int paramInt)
/*      */   {
/* 2380 */     return 0 == paramInt ? "NO" : "YES";
/*      */   }
/*      */ 
/*      */   final Object apply(Object paramObject, JDBCType paramJDBCType) throws SQLServerException {
/* 2384 */     if (paramObject == null) {
/* 2385 */       return paramObject;
/*      */     }
/*      */ 
/* 2390 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*      */     {
/*      */     case 1:
/*      */     case 2:
/* 2400 */       assert ((paramObject instanceof Number));
/* 2401 */       return zeroOneToYesNo(((Number)paramObject).intValue());
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/* 2405 */       assert ((paramObject instanceof String));
/* 2406 */       return zeroOneToYesNo(Integer.parseInt((String)paramObject));
/*      */     }
/* 2408 */     DataTypes.throwConversionError("char", paramJDBCType.toString());
/* 2409 */     return paramObject;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.IntColumnIdentityFilter
 * JD-Core Version:    0.6.0
 */