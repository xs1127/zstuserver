/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.UUID;
/*     */ 
/*     */ class ActivityId
/*     */ {
/*     */   private final UUID Id;
/*     */   private long Sequence;
/*     */   private boolean isSentToServer;
/*     */ 
/*     */   ActivityId()
/*     */   {
/*  60 */     this.Id = UUID.randomUUID();
/*  61 */     this.Sequence = 0L;
/*  62 */     this.isSentToServer = false;
/*     */   }
/*     */ 
/*     */   UUID getId()
/*     */   {
/*  67 */     return this.Id;
/*     */   }
/*     */ 
/*     */   long getSequence()
/*     */   {
/*  72 */     return this.Sequence;
/*     */   }
/*     */ 
/*     */   void Increment()
/*     */   {
/*  77 */     if (this.Sequence < 4294967295L)
/*     */     {
/*  79 */       this.Sequence += 1L;
/*     */     }
/*     */     else
/*     */     {
/*  83 */       this.Sequence = 0L;
/*     */     }
/*     */ 
/*  86 */     this.isSentToServer = false;
/*     */   }
/*     */ 
/*     */   void setSentFlag()
/*     */   {
/*  91 */     this.isSentToServer = true;
/*     */   }
/*     */ 
/*     */   boolean IsSentToServer()
/*     */   {
/*  96 */     return this.isSentToServer;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 101 */     StringBuilder localStringBuilder = new StringBuilder();
/* 102 */     localStringBuilder.append(this.Id.toString());
/* 103 */     localStringBuilder.append("-");
/* 104 */     localStringBuilder.append(this.Sequence);
/* 105 */     return localStringBuilder.toString();
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ActivityId
 * JD-Core Version:    0.6.0
 */