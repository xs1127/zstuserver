/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class StreamRetStatus extends StreamPacket
/*    */ {
/*    */   private int status;
/*    */ 
/*    */   final int getStatus()
/*    */   {
/* 13 */     return this.status;
/*    */   }
/*    */ 
/*    */   StreamRetStatus() {
/* 17 */     super(121);
/*    */   }
/*    */ 
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 22 */     if ((121 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/* 23 */     this.status = paramTDSReader.readInt();
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamRetStatus
 * JD-Core Version:    0.6.0
 */