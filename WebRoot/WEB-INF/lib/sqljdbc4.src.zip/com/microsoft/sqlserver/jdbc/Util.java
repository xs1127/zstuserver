/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ final class Util
/*     */ {
/*     */   static final String SYSTEM_SPEC_VERSION;
/*     */   static final char[] hexChars;
/*     */   static final String WSIDNotAvailable = "";
/*     */   static final String ActivityIdTraceProperty = "com.microsoft.sqlserver.jdbc.traceactivity";
/*     */   static final String SYSTEM_JRE;
/*     */ 
/*     */   static boolean isIBM()
/*     */   {
/*  33 */     return SYSTEM_JRE.startsWith("IBM");
/*     */   }
/*     */ 
/*     */   static short readShort(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/*  43 */     return (short)(paramArrayOfByte[paramInt] & 0xFF | (paramArrayOfByte[(paramInt + 1)] & 0xFF) << 8);
/*     */   }
/*     */ 
/*     */   static int readUnsignedShort(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/*  53 */     return paramArrayOfByte[paramInt] & 0xFF | (paramArrayOfByte[(paramInt + 1)] & 0xFF) << 8;
/*     */   }
/*     */ 
/*     */   static int readUnsignedShortBigEndian(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/*  58 */     return (paramArrayOfByte[paramInt] & 0xFF) << 8 | paramArrayOfByte[(paramInt + 1)] & 0xFF;
/*     */   }
/*     */ 
/*     */   static void writeShort(short paramShort, byte[] paramArrayOfByte, int paramInt)
/*     */   {
/*  63 */     paramArrayOfByte[(paramInt + 0)] = (byte)(paramShort >> 0 & 0xFF);
/*  64 */     paramArrayOfByte[(paramInt + 1)] = (byte)(paramShort >> 8 & 0xFF);
/*     */   }
/*     */ 
/*     */   static void writeShortBigEndian(short paramShort, byte[] paramArrayOfByte, int paramInt)
/*     */   {
/*  69 */     paramArrayOfByte[(paramInt + 0)] = (byte)(paramShort >> 8 & 0xFF);
/*  70 */     paramArrayOfByte[(paramInt + 1)] = (byte)(paramShort >> 0 & 0xFF);
/*     */   }
/*     */ 
/*     */   static int readInt(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/*  79 */     int i = paramArrayOfByte[(paramInt + 0)] & 0xFF;
/*  80 */     int j = (paramArrayOfByte[(paramInt + 1)] & 0xFF) << 8;
/*  81 */     int k = (paramArrayOfByte[(paramInt + 2)] & 0xFF) << 16;
/*  82 */     int m = (paramArrayOfByte[(paramInt + 3)] & 0xFF) << 24;
/*  83 */     return m | k | j | i;
/*     */   }
/*     */ 
/*     */   static int readIntBigEndian(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/*  88 */     return (paramArrayOfByte[(paramInt + 3)] & 0xFF) << 0 | (paramArrayOfByte[(paramInt + 2)] & 0xFF) << 8 | (paramArrayOfByte[(paramInt + 1)] & 0xFF) << 16 | (paramArrayOfByte[(paramInt + 0)] & 0xFF) << 24;
/*     */   }
/*     */ 
/*     */   static void writeInt(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*     */   {
/*  97 */     paramArrayOfByte[(paramInt2 + 0)] = (byte)(paramInt1 >> 0 & 0xFF);
/*  98 */     paramArrayOfByte[(paramInt2 + 1)] = (byte)(paramInt1 >> 8 & 0xFF);
/*  99 */     paramArrayOfByte[(paramInt2 + 2)] = (byte)(paramInt1 >> 16 & 0xFF);
/* 100 */     paramArrayOfByte[(paramInt2 + 3)] = (byte)(paramInt1 >> 24 & 0xFF);
/*     */   }
/*     */ 
/*     */   static void writeIntBigEndian(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*     */   {
/* 105 */     paramArrayOfByte[(paramInt2 + 0)] = (byte)(paramInt1 >> 24 & 0xFF);
/* 106 */     paramArrayOfByte[(paramInt2 + 1)] = (byte)(paramInt1 >> 16 & 0xFF);
/* 107 */     paramArrayOfByte[(paramInt2 + 2)] = (byte)(paramInt1 >> 8 & 0xFF);
/* 108 */     paramArrayOfByte[(paramInt2 + 3)] = (byte)(paramInt1 >> 0 & 0xFF);
/*     */   }
/*     */ 
/*     */   static void writeLongBigEndian(long paramLong, byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 113 */     paramArrayOfByte[(paramInt + 0)] = (byte)(int)(paramLong >> 56 & 0xFF);
/* 114 */     paramArrayOfByte[(paramInt + 1)] = (byte)(int)(paramLong >> 48 & 0xFF);
/* 115 */     paramArrayOfByte[(paramInt + 2)] = (byte)(int)(paramLong >> 40 & 0xFF);
/* 116 */     paramArrayOfByte[(paramInt + 3)] = (byte)(int)(paramLong >> 32 & 0xFF);
/* 117 */     paramArrayOfByte[(paramInt + 4)] = (byte)(int)(paramLong >> 24 & 0xFF);
/* 118 */     paramArrayOfByte[(paramInt + 5)] = (byte)(int)(paramLong >> 16 & 0xFF);
/* 119 */     paramArrayOfByte[(paramInt + 6)] = (byte)(int)(paramLong >> 8 & 0xFF);
/* 120 */     paramArrayOfByte[(paramInt + 7)] = (byte)(int)(paramLong >> 0 & 0xFF);
/*     */   }
/*     */ 
/*     */   static long readLong(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 132 */     long l = 0L;
/* 133 */     for (int i = 7; i > 0; i--)
/*     */     {
/* 135 */       l += (paramArrayOfByte[(paramInt + i)] & 0xFF);
/* 136 */       l <<= 8;
/*     */     }
/* 138 */     return l + (paramArrayOfByte[paramInt] & 0xFF);
/*     */   }
/*     */ 
/*     */   static Properties parseUrl(String paramString, Logger paramLogger)
/*     */     throws SQLServerException
/*     */   {
/* 148 */     Properties localProperties = new Properties();
/* 149 */     String str1 = paramString;
/* 150 */     String str2 = "jdbc:sqlserver://";
/* 151 */     String str3 = "";
/* 152 */     String str4 = "";
/* 153 */     String str5 = "";
/*     */ 
/* 155 */     if (!str1.startsWith(str2)) {
/* 156 */       return null;
/*     */     }
/* 158 */     str1 = str1.substring(str2.length());
/* 159 */     int i = 0;
/*     */ 
/* 172 */     int j = 0;
/*     */ 
/* 174 */     i = 0;
/* 175 */     while (i < str1.length())
/*     */     {
/* 177 */       char c = str1.charAt(i);
/* 178 */       switch (j)
/*     */       {
/*     */       case 0:
/* 182 */         if (c == ';')
/*     */         {
/* 185 */           j = 7;
/*     */         }
/*     */         else
/*     */         {
/* 189 */           str3 = new StringBuilder().append(str3).append(c).toString();
/* 190 */           j = 1;
/*     */         }
/* 192 */         break;
/*     */       case 1:
/* 197 */         if ((c == ';') || (c == ':') || (c == '\\'))
/*     */         {
/* 200 */           str3 = str3.trim();
/* 201 */           if (str3.length() > 0)
/*     */           {
/* 203 */             localProperties.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), str3);
/* 204 */             if (paramLogger.isLoggable(Level.FINE))
/*     */             {
/* 206 */               paramLogger.fine(new StringBuilder().append("Property:serverName Value:").append(str3).toString());
/*     */             }
/*     */           }
/* 209 */           str3 = "";
/*     */ 
/* 211 */           if (c == ';') {
/* 212 */             j = 7;
/*     */           }
/* 214 */           else if (c == ':')
/* 215 */             j = 2;
/*     */           else
/* 217 */             j = 3;
/*     */         }
/*     */         else
/*     */         {
/* 221 */           str3 = new StringBuilder().append(str3).append(c).toString();
/*     */         }
/*     */ 
/* 224 */         break;
/*     */       case 2:
/* 229 */         if (c == ';')
/*     */         {
/* 231 */           str3 = str3.trim();
/* 232 */           if (paramLogger.isLoggable(Level.FINE))
/*     */           {
/* 234 */             paramLogger.fine(new StringBuilder().append("Property:portNumber Value:").append(str3).toString());
/*     */           }
/* 236 */           localProperties.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), str3);
/* 237 */           str3 = "";
/* 238 */           j = 7;
/*     */         }
/*     */         else
/*     */         {
/* 242 */           str3 = new StringBuilder().append(str3).append(c).toString();
/*     */         }
/*     */ 
/* 245 */         break;
/*     */       case 3:
/* 249 */         if ((c == ';') || (c == ':'))
/*     */         {
/* 252 */           str3 = str3.trim();
/* 253 */           if (paramLogger.isLoggable(Level.FINE))
/*     */           {
/* 255 */             paramLogger.fine(new StringBuilder().append("Property:instanceName Value:").append(str3).toString());
/*     */           }
/* 257 */           localProperties.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str3.toLowerCase(Locale.US));
/* 258 */           str3 = "";
/*     */ 
/* 260 */           if (c == ';')
/* 261 */             j = 7;
/*     */           else
/* 263 */             j = 2;
/*     */         }
/*     */         else
/*     */         {
/* 267 */           str3 = new StringBuilder().append(str3).append(c).toString();
/*     */         }
/*     */ 
/* 270 */         break;
/*     */       case 7:
/* 274 */         if (c == '=')
/*     */         {
/* 277 */           str4 = str4.trim();
/* 278 */           if (str4.length() <= 0)
/*     */           {
/* 280 */             SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */           }
/*     */ 
/* 283 */           j = 6;
/*     */         }
/* 286 */         else if (c == ';')
/*     */         {
/* 288 */           str4 = str4.trim();
/* 289 */           if (str4.length() <= 0)
/*     */             break;
/* 291 */           SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */         }
/*     */         else
/*     */         {
/* 298 */           str4 = new StringBuilder().append(str4).append(c).toString();
/*     */         }
/*     */ 
/* 301 */         break;
/*     */       case 6:
/* 305 */         if (c == ';')
/*     */         {
/* 308 */           str5 = str5.trim();
/* 309 */           str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
/* 310 */           if (null != str4)
/*     */           {
/* 312 */             if (paramLogger.isLoggable(Level.FINE))
/*     */             {
/* 314 */               if ((false == str4.equals(SQLServerDriverStringProperty.USER.toString())) && (false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString())))
/* 315 */                 paramLogger.fine(new StringBuilder().append("Property:").append(str4).append(" Value:").append(str5).toString());
/*     */             }
/* 317 */             localProperties.put(str4, str5);
/*     */           }
/* 319 */           str4 = "";
/* 320 */           str5 = "";
/* 321 */           j = 7;
/*     */         }
/* 325 */         else if (c == '{')
/*     */         {
/* 327 */           j = 4;
/* 328 */           str5 = str5.trim();
/* 329 */           if (str5.length() <= 0)
/*     */             break;
/* 331 */           SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */         }
/*     */         else
/*     */         {
/* 336 */           str5 = new StringBuilder().append(str5).append(c).toString();
/*     */         }
/*     */ 
/* 339 */         break;
/*     */       case 4:
/* 343 */         if (c == '}')
/*     */         {
/* 346 */           str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
/* 347 */           if (null != str4)
/*     */           {
/* 349 */             if (paramLogger.isLoggable(Level.FINE))
/*     */             {
/* 351 */               if ((false == str4.equals(SQLServerDriverStringProperty.USER.toString())) && (false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString())))
/* 352 */                 paramLogger.fine(new StringBuilder().append("Property:").append(str4).append(" Value:").append(str5).toString());
/*     */             }
/* 354 */             localProperties.put(str4, str5);
/*     */           }
/*     */ 
/* 357 */           str4 = "";
/* 358 */           str5 = "";
/*     */ 
/* 361 */           j = 5;
/*     */         }
/*     */         else
/*     */         {
/* 365 */           str5 = new StringBuilder().append(str5).append(c).toString();
/*     */         }
/*     */ 
/* 368 */         break;
/*     */       case 5:
/* 372 */         if (c == ';')
/*     */         {
/* 374 */           j = 7;
/*     */         } else {
/* 376 */           if (c == ' ') {
/*     */             break;
/*     */           }
/* 379 */           SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true); } break;
/*     */       default:
/* 386 */         if ($assertionsDisabled) break; throw new AssertionError(new StringBuilder().append("parseURL: Invalid state ").append(j).toString());
/*     */       }
/* 388 */       i++;
/*     */     }
/*     */ 
/* 392 */     switch (j)
/*     */     {
/*     */     case 1:
/* 395 */       str3 = str3.trim();
/* 396 */       if (str3.length() <= 0)
/*     */         break;
/* 398 */       if (paramLogger.isLoggable(Level.FINE))
/*     */       {
/* 400 */         paramLogger.fine(new StringBuilder().append("Property:serverName Value:").append(str3).toString());
/*     */       }
/* 402 */       localProperties.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), str3); break;
/*     */     case 2:
/* 406 */       str3 = str3.trim();
/* 407 */       if (paramLogger.isLoggable(Level.FINE))
/*     */       {
/* 409 */         paramLogger.fine(new StringBuilder().append("Property:portNumber Value:").append(str3).toString());
/*     */       }
/* 411 */       localProperties.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), str3);
/* 412 */       break;
/*     */     case 3:
/* 414 */       str3 = str3.trim();
/* 415 */       if (paramLogger.isLoggable(Level.FINE))
/*     */       {
/* 417 */         paramLogger.fine(new StringBuilder().append("Property:instanceName Value:").append(str3).toString());
/*     */       }
/* 419 */       localProperties.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str3);
/* 420 */       break;
/*     */     case 6:
/* 423 */       str5 = str5.trim();
/* 424 */       str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
/* 425 */       if (null == str4)
/*     */         break;
/* 427 */       if (paramLogger.isLoggable(Level.FINE))
/*     */       {
/* 429 */         if ((false == str4.equals(SQLServerDriverStringProperty.USER.toString())) && (false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString())))
/* 430 */           paramLogger.fine(new StringBuilder().append("Property:").append(str4).append(" Value:").append(str5).toString());
/*     */       }
/* 432 */       localProperties.put(str4, str5); break;
/*     */     case 0:
/*     */     case 5:
/* 439 */       break;
/*     */     case 7:
/* 442 */       str4 = str4.trim();
/* 443 */       if (str4.length() <= 0)
/*     */         break;
/* 445 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true); break;
/*     */     case 4:
/*     */     default:
/* 452 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */     }
/*     */ 
/* 455 */     return localProperties;
/*     */   }
/*     */ 
/*     */   static String escapeSQLId(String paramString)
/*     */   {
/* 477 */     StringBuilder localStringBuilder = new StringBuilder(paramString.length() + 2);
/*     */ 
/* 479 */     localStringBuilder.append('[');
/* 480 */     for (int i = 0; i < paramString.length(); i++)
/*     */     {
/* 482 */       char c = paramString.charAt(i);
/* 483 */       if (']' == c)
/* 484 */         localStringBuilder.append("]]");
/*     */       else
/* 486 */         localStringBuilder.append(c);
/*     */     }
/* 488 */     localStringBuilder.append(']');
/* 489 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   static String readUnicodeString(byte[] paramArrayOfByte, int paramInt1, int paramInt2, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/*     */     MessageFormat localMessageFormat;
/*     */     Object[] arrayOfObject;
/*     */     try
/*     */     {
/* 504 */       return new String(paramArrayOfByte, paramInt1, paramInt2, Encoding.UNICODE.charsetName());
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */     {
/* 508 */       str = SQLServerException.checkAndAppendClientConnId(SQLServerException.getErrString("R_stringReadError"), paramSQLServerConnection);
/* 509 */       localMessageFormat = new MessageFormat(str);
/* 510 */       arrayOfObject = new Object[] { new Integer(paramInt1) };
/*     */ 
/* 512 */       throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*     */     }
/*     */     catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
/*     */     {
/* 516 */       String str = SQLServerException.checkAndAppendClientConnId(SQLServerException.getErrString("R_stringReadError"), paramSQLServerConnection);
/* 517 */       localMessageFormat = new MessageFormat(str);
/* 518 */       arrayOfObject = new Object[] { new Integer(paramInt1) };
/*     */     }
/* 520 */     throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*     */   }
/*     */ 
/*     */   static String byteToHexDisplayString(byte[] paramArrayOfByte)
/*     */   {
/* 533 */     if (null == paramArrayOfByte) return "(null)";
/*     */ 
/* 535 */     StringBuilder localStringBuilder = new StringBuilder(paramArrayOfByte.length * 2 + 2);
/* 536 */     localStringBuilder.append("0x");
/* 537 */     for (int j = 0; j < paramArrayOfByte.length; j++)
/*     */     {
/* 539 */       int i = paramArrayOfByte[j] & 0xFF;
/* 540 */       localStringBuilder.append(hexChars[((i & 0xF0) >> 4)]);
/* 541 */       localStringBuilder.append(hexChars[(i & 0xF)]);
/*     */     }
/* 543 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   static String bytesToHexString(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 554 */     StringBuilder localStringBuilder = new StringBuilder(paramInt * 2);
/* 555 */     for (int i = 0; i < paramInt; i++)
/*     */     {
/* 557 */       int j = paramArrayOfByte[i] & 0xFF;
/* 558 */       localStringBuilder.append(hexChars[((j & 0xF0) >> 4)]);
/* 559 */       localStringBuilder.append(hexChars[(j & 0xF)]);
/*     */     }
/* 561 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   static String lookupHostName()
/*     */   {
/*     */     try
/*     */     {
/* 575 */       InetAddress localInetAddress = InetAddress.getLocalHost();
/* 576 */       if (null != localInetAddress)
/*     */       {
/* 578 */         String str = localInetAddress.getHostName();
/* 579 */         if ((null != str) && (str.length() > 0)) return str;
/*     */ 
/* 581 */         str = localInetAddress.getHostAddress();
/* 582 */         if ((null != str) && (str.length() > 0)) return str;
/*     */       }
/*     */     }
/*     */     catch (UnknownHostException localUnknownHostException)
/*     */     {
/* 587 */       return "";
/*     */     }
/*     */ 
/* 590 */     return "";
/*     */   }
/*     */ 
/*     */   static final byte[] asGuidByteArray(UUID paramUUID)
/*     */   {
/* 595 */     long l1 = paramUUID.getMostSignificantBits();
/* 596 */     long l2 = paramUUID.getLeastSignificantBits();
/* 597 */     byte[] arrayOfByte = new byte[16];
/* 598 */     writeLongBigEndian(l1, arrayOfByte, 0);
/* 599 */     writeLongBigEndian(l2, arrayOfByte, 8);
/*     */ 
/* 608 */     int i = arrayOfByte[0];
/* 609 */     arrayOfByte[0] = arrayOfByte[3];
/* 610 */     arrayOfByte[3] = i;
/* 611 */     i = arrayOfByte[1];
/* 612 */     arrayOfByte[1] = arrayOfByte[2];
/* 613 */     arrayOfByte[2] = i;
/*     */ 
/* 616 */     i = arrayOfByte[4];
/* 617 */     arrayOfByte[4] = arrayOfByte[5];
/* 618 */     arrayOfByte[5] = i;
/*     */ 
/* 621 */     i = arrayOfByte[6];
/* 622 */     arrayOfByte[6] = arrayOfByte[7];
/* 623 */     arrayOfByte[7] = i;
/*     */ 
/* 625 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   static boolean IsActivityTraceOn()
/*     */   {
/* 630 */     LogManager localLogManager = LogManager.getLogManager();
/* 631 */     String str = localLogManager.getProperty("com.microsoft.sqlserver.jdbc.traceactivity");
/*     */ 
/* 633 */     return (null != str) && (str.equalsIgnoreCase("on"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  21 */     SYSTEM_SPEC_VERSION = System.getProperty("java.specification.version");
/*  22 */     hexChars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/*  29 */     SYSTEM_JRE = new StringBuilder().append(System.getProperty("java.vendor")).append(" ").append(System.getProperty("java.version")).toString();
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.Util
 * JD-Core Version:    0.6.0
 */