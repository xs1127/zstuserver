package com.microsoft.sqlserver.jdbc;

final class SQLJdbcVersion
{
  static final int major = 4;
  static final int minor = 0;
  static final int MMDD = 4621;
  static final int revision = 201;
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLJdbcVersion
 * JD-Core Version:    0.6.0
 */