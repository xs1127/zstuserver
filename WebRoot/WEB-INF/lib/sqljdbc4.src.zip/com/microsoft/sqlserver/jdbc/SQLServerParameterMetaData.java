/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.Statement;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public final class SQLServerParameterMetaData
/*     */   implements ParameterMetaData
/*     */ {
/*     */   private final SQLServerStatement stmtParent;
/*     */   private SQLServerConnection con;
/*     */   private Statement stmtRegular;
/*     */   private ResultSetMetaData md;
/*     */   private Statement stmtCall;
/*     */   private SQLServerResultSet rsProcedureMeta;
/*     */   private static final Logger logger;
/*     */   private static int baseID;
/*  38 */   private final String traceID = new StringBuilder().append(" SQLServerParameterMetaData:").append(nextInstanceID()).toString();
/*     */ 
/*     */   private static synchronized int nextInstanceID()
/*     */   {
/*  42 */     baseID += 1;
/*  43 */     return baseID;
/*     */   }
/*     */ 
/*     */   public final String toString() {
/*  47 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   private String parseColumns(String paramString1, String paramString2)
/*     */   {
/*  58 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, " =?<>!", true);
/*     */ 
/*  64 */     int i = 0;
/*  65 */     Object localObject = null;
/*  66 */     StringBuilder localStringBuilder = new StringBuilder();
/*     */ 
/*  68 */     while (localStringTokenizer.hasMoreTokens())
/*     */     {
/*  71 */       String str1 = localStringTokenizer.nextToken();
/*  72 */       if (str1.equalsIgnoreCase(paramString2))
/*     */       {
/*  74 */         i = 1;
/*  75 */         continue;
/*     */       }
/*  77 */       if (i == 0)
/*     */         continue;
/*  79 */       if ((str1.charAt(0) == '=') || (str1.equalsIgnoreCase("is")) || (str1.charAt(0) == '<') || (str1.charAt(0) == '>') || (str1.equalsIgnoreCase("like")) || (str1.equalsIgnoreCase("not")) || (str1.equalsIgnoreCase("in")) || (str1.charAt(0) == '!'))
/*     */       {
/*  83 */         i = 2;
/*  84 */         continue;
/*     */       }
/*  86 */       if ((str1.charAt(0) == '?') && (localObject != null))
/*     */       {
/*  88 */         if (localStringBuilder.length() != 0)
/*     */         {
/*  90 */           localStringBuilder.append(", ");
/*     */         }
/*  92 */         localStringBuilder.append((String)localObject);
/*  93 */         i = 1;
/*  94 */         localObject = null;
/*  95 */         continue;
/*     */       }
/*  97 */       if (i == 1)
/*     */       {
/* 100 */         if (str1.equals(" "))
/*     */           continue;
/* 102 */         String str2 = escapeParse(localStringTokenizer, str1);
/* 103 */         if (str2.length() > 0)
/*     */         {
/* 105 */           localObject = str2;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 110 */     return (String)localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   private String parseInsertColumns(String paramString1, String paramString2)
/*     */   {
/* 119 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, " (),", true);
/* 120 */     int i = 0;
/* 121 */     String str1 = null;
/* 122 */     StringBuilder localStringBuilder = new StringBuilder();
/*     */ 
/* 124 */     while (localStringTokenizer.hasMoreTokens()) {
/* 125 */       String str2 = localStringTokenizer.nextToken();
/* 126 */       if (str2.equalsIgnoreCase(paramString2)) {
/* 127 */         i = 1;
/* 128 */         continue;
/*     */       }
/* 130 */       if (i == 0)
/*     */         continue;
/* 132 */       if (str2.charAt(0) == '=') {
/* 133 */         i = 2;
/* 134 */         continue;
/*     */       }
/* 136 */       if (((str2.charAt(0) == ',') || (str2.charAt(0) == ')') || (str2.charAt(0) == ' ')) && (str1 != null))
/*     */       {
/* 139 */         if (localStringBuilder.length() != 0)
/* 140 */           localStringBuilder.append(", ");
/* 141 */         localStringBuilder.append(str1);
/* 142 */         i = 1;
/* 143 */         str1 = null;
/*     */       }
/* 145 */       if (str2.charAt(0) == ')') {
/* 146 */         i = 0;
/* 147 */         break;
/*     */       }
/* 149 */       if ((i == 1) && 
/* 150 */         (str2.trim().length() > 0) && 
/* 151 */         (str2.charAt(0) != ',')) {
/* 152 */         str1 = escapeParse(localStringTokenizer, str2);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 157 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   private String escapeParse(StringTokenizer paramStringTokenizer, String paramString)
/*     */   {
/* 170 */     String str1 = paramString;
/*     */ 
/* 172 */     while ((str1.equals(" ")) && (paramStringTokenizer.hasMoreTokens()))
/*     */     {
/* 174 */       str1 = paramStringTokenizer.nextToken();
/*     */     }
/* 176 */     String str2 = str1;
/* 177 */     if ((str1.charAt(0) == '[') && (str1.charAt(str1.length() - 1) != ']'))
/*     */     {
/* 179 */       while (paramStringTokenizer.hasMoreTokens())
/*     */       {
/* 181 */         str1 = paramStringTokenizer.nextToken();
/* 182 */         str2 = str2.concat(str1);
/* 183 */         if (str1.charAt(str1.length() - 1) != ']')
/*     */         {
/*     */           continue;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 190 */     str2 = str2.trim();
/* 191 */     return str2;
/*     */   }
/*     */ 
/*     */   private MetaInfo parseStatement(String paramString1, String paramString2)
/*     */   {
/* 213 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, " ,", true);
/*     */ 
/* 217 */     String str1 = null;
/* 218 */     String str2 = "";
/* 219 */     while (localStringTokenizer.hasMoreTokens())
/*     */     {
/* 221 */       String str3 = localStringTokenizer.nextToken().trim();
/*     */ 
/* 223 */       if (str3.equalsIgnoreCase(paramString2))
/*     */       {
/* 225 */         if (localStringTokenizer.hasMoreTokens())
/*     */         {
/* 227 */           str1 = escapeParse(localStringTokenizer, localStringTokenizer.nextToken());
/* 228 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 233 */     if (null != str1)
/*     */     {
/* 235 */       if (paramString2.equalsIgnoreCase("UPDATE"))
/* 236 */         str2 = parseColumns(paramString1, "SET");
/* 237 */       else if (paramString2.equalsIgnoreCase("INTO"))
/* 238 */         str2 = parseInsertColumns(paramString1, "(");
/*     */       else {
/* 240 */         str2 = parseColumns(paramString1, "WHERE");
/*     */       }
/* 242 */       return new MetaInfo(str1, str2);
/*     */     }
/*     */ 
/* 245 */     return null;
/*     */   }
/*     */ 
/*     */   private MetaInfo parseStatement(String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 255 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString, " ");
/* 256 */     if (localStringTokenizer.hasMoreTokens())
/*     */     {
/* 258 */       String str = localStringTokenizer.nextToken().trim();
/*     */ 
/* 260 */       if (str.equalsIgnoreCase("INSERT")) {
/* 261 */         return parseStatement(paramString, "INTO");
/*     */       }
/* 263 */       if (str.equalsIgnoreCase("UPDATE")) {
/* 264 */         return parseStatement(paramString, "UPDATE");
/*     */       }
/* 266 */       if (str.equalsIgnoreCase("SELECT")) {
/* 267 */         return parseStatement(paramString, "FROM");
/*     */       }
/* 269 */       if (str.equalsIgnoreCase("DELETE")) {
/* 270 */         return parseStatement(paramString, "FROM");
/*     */       }
/*     */     }
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */   String parseThreePartNames(String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 280 */     int i = 0;
/* 281 */     Object localObject1 = null;
/* 282 */     Object localObject2 = null;
/* 283 */     Object localObject3 = null;
/* 284 */     int j = 0;
/* 285 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ".", true);
/*     */ 
/* 289 */     while (localStringTokenizer.hasMoreTokens())
/*     */     {
/* 291 */       localObject4 = localStringTokenizer.nextToken();
/* 292 */       String str = escapeParse(localStringTokenizer, (String)localObject4);
/* 293 */       if (!str.equals("."))
/*     */       {
/* 295 */         switch (i)
/*     */         {
/*     */         case 2:
/* 298 */           localObject3 = localObject2;
/* 299 */           localObject2 = localObject1;
/* 300 */           localObject1 = str;
/* 301 */           i++;
/* 302 */           break;
/*     */         case 1:
/* 304 */           localObject2 = localObject1;
/* 305 */           localObject1 = str;
/* 306 */           i++;
/* 307 */           break;
/*     */         case 0:
/* 309 */           localObject1 = str;
/* 310 */           i++;
/* 311 */           break;
/*     */         default:
/* 313 */           i++;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 318 */     Object localObject4 = new StringBuilder(100);
/*     */ 
/* 320 */     if ((i > 3) && (1 < i)) {
/* 321 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), null, false);
/*     */     }
/* 323 */     switch (i)
/*     */     {
/*     */     case 3:
/* 326 */       ((StringBuilder)localObject4).append("@procedure_qualifier =");
/* 327 */       ((StringBuilder)localObject4).append(localObject3);
/* 328 */       ((StringBuilder)localObject4).append(", ");
/* 329 */       ((StringBuilder)localObject4).append("@procedure_owner =");
/* 330 */       ((StringBuilder)localObject4).append(localObject2);
/* 331 */       ((StringBuilder)localObject4).append(", ");
/* 332 */       ((StringBuilder)localObject4).append("@procedure_name =");
/* 333 */       ((StringBuilder)localObject4).append(localObject1);
/* 334 */       ((StringBuilder)localObject4).append(", ");
/* 335 */       break;
/*     */     case 2:
/* 338 */       ((StringBuilder)localObject4).append("@procedure_owner =");
/* 339 */       ((StringBuilder)localObject4).append(localObject2);
/* 340 */       ((StringBuilder)localObject4).append(", ");
/* 341 */       ((StringBuilder)localObject4).append("@procedure_name =");
/* 342 */       ((StringBuilder)localObject4).append(localObject1);
/* 343 */       ((StringBuilder)localObject4).append(", ");
/* 344 */       break;
/*     */     case 1:
/* 346 */       ((StringBuilder)localObject4).append("@procedure_name =");
/* 347 */       ((StringBuilder)localObject4).append(localObject1);
/* 348 */       ((StringBuilder)localObject4).append(", ");
/* 349 */       break;
/*     */     }
/*     */ 
/* 353 */     return (String)((StringBuilder)localObject4).toString();
/*     */   }
/*     */ 
/*     */   private void checkClosed()
/*     */     throws SQLServerException
/*     */   {
/* 359 */     this.stmtParent.checkClosed();
/*     */   }
/*     */ 
/*     */   SQLServerParameterMetaData(SQLServerStatement paramSQLServerStatement, String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 371 */     assert (null != paramSQLServerStatement);
/* 372 */     this.stmtParent = paramSQLServerStatement;
/* 373 */     this.con = paramSQLServerStatement.connection;
/* 374 */     if (logger.isLoggable(Level.FINE))
/*     */     {
/* 376 */       logger.fine(new StringBuilder().append(toString()).append(" created by (").append(paramSQLServerStatement.toString()).append(")").toString());
/*     */     }
/*     */     try
/*     */     {
/*     */       Object localObject1;
/*     */       Object localObject2;
/* 383 */       if (null != paramSQLServerStatement.procedureName)
/*     */       {
/* 385 */         localObject1 = (SQLServerStatement)this.con.createStatement(1004, 1007);
/* 386 */         localObject2 = parseThreePartNames(paramSQLServerStatement.procedureName);
/* 387 */         if (this.con.isKatmaiOrLater())
/* 388 */           this.rsProcedureMeta = ((SQLServerStatement)localObject1).executeQueryInternal(new StringBuilder().append("exec sp_sproc_columns_100 ").append((String)localObject2).append(" @ODBCVer=3").toString());
/*     */         else {
/* 390 */           this.rsProcedureMeta = ((SQLServerStatement)localObject1).executeQueryInternal(new StringBuilder().append("exec sp_sproc_columns ").append((String)localObject2).append(" @ODBCVer=3").toString());
/*     */         }
/* 392 */         this.rsProcedureMeta.getColumn(6).setFilter(new DataTypeFilter());
/* 393 */         if (this.con.isKatmaiOrLater())
/*     */         {
/* 395 */           this.rsProcedureMeta.getColumn(8).setFilter(new ZeroFixupFilter());
/* 396 */           this.rsProcedureMeta.getColumn(9).setFilter(new ZeroFixupFilter());
/* 397 */           this.rsProcedureMeta.getColumn(17).setFilter(new ZeroFixupFilter());
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 405 */         localObject1 = parseStatement(paramString);
/* 406 */         if (null == localObject1)
/*     */         {
/* 408 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_cantIdentifyTableMetadata"));
/* 409 */           localObject3 = new Object[] { new String(paramString) };
/* 410 */           SQLServerException.makeFromDriverError(this.con, this.stmtParent, ((MessageFormat)localObject2).format(localObject3), null, false);
/*     */         }
/*     */ 
/* 413 */         if (((MetaInfo)localObject1).fields.length() <= 0) {
/* 414 */           return;
/*     */         }
/* 416 */         this.stmtRegular = this.con.createStatement();
/* 417 */         localObject2 = new StringBuilder().append("sp_executesql N'SET FMTONLY ON SELECT ").append(((MetaInfo)localObject1).fields).append(" FROM ").append(((MetaInfo)localObject1).table).append(" WHERE 1 = 2'").toString();
/* 418 */         Object localObject3 = this.stmtRegular.executeQuery((String)localObject2);
/* 419 */         this.md = ((ResultSet)localObject3).getMetaData();
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 426 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isWrapperFor(Class paramClass) throws SQLException
/*     */   {
/* 432 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 434 */     return false;
/*     */   }
/*     */ 
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException
/*     */   {
/* 439 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 440 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */   private void verifyParameterPosition(int paramInt) throws SQLServerException {
/* 445 */     boolean bool = false;
/*     */     Object localObject;
/*     */     try { bool = this.rsProcedureMeta.absolute(paramInt + 1);
/*     */     } catch (SQLException localSQLException)
/*     */     {
/* 450 */       localObject = new MessageFormat(SQLServerException.getErrString("R_metaDataErrorForParameter"));
/* 451 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 452 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, new StringBuilder().append(((MessageFormat)localObject).format(arrayOfObject)).append(" ").append(localSQLException.toString()).toString(), null, false);
/*     */     }
/*     */ 
/* 455 */     if (!bool) {
/* 456 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidParameterNumber"));
/* 457 */       localObject = new Object[] { new Integer(paramInt) };
/* 458 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localMessageFormat.format(localObject), null, false);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkParam(int paramInt) throws SQLServerException {
/* 463 */     if (this.md == null)
/* 464 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), null, false);
/*     */   }
/*     */ 
/*     */   public String getParameterClassName(int paramInt) throws SQLServerException {
/* 468 */     checkClosed();
/*     */     try {
/* 470 */       if (this.rsProcedureMeta == null) {
/* 471 */         checkParam(paramInt);
/* 472 */         return this.md.getColumnClassName(paramInt);
/*     */       }
/*     */ 
/* 475 */       verifyParameterPosition(paramInt);
/* 476 */       JDBCType localJDBCType = JDBCType.of(this.rsProcedureMeta.getShort("DATA_TYPE"));
/* 477 */       return localJDBCType.className();
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 481 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/* 482 */     }return null;
/*     */   }
/*     */ 
/*     */   public int getParameterCount() throws SQLServerException
/*     */   {
/* 487 */     checkClosed();
/*     */     try {
/* 489 */       if (this.rsProcedureMeta == null) {
/* 490 */         if (this.md == null)
/* 491 */           return 0;
/* 492 */         return this.md.getColumnCount();
/*     */       }
/*     */ 
/* 495 */       this.rsProcedureMeta.last();
/* 496 */       int i = this.rsProcedureMeta.getRow() - 1;
/* 497 */       if (i < 0)
/* 498 */         i = 0;
/* 499 */       return i;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 503 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/* 504 */     }return 0;
/*     */   }
/*     */ 
/*     */   public int getParameterMode(int paramInt) throws SQLServerException
/*     */   {
/* 509 */     checkClosed();
/*     */     try {
/* 511 */       if (this.rsProcedureMeta == null) {
/* 512 */         checkParam(paramInt);
/*     */ 
/* 514 */         return 1;
/*     */       }
/*     */ 
/* 517 */       verifyParameterPosition(paramInt);
/* 518 */       int i = this.rsProcedureMeta.getInt("COLUMN_TYPE");
/* 519 */       switch (i) {
/*     */       case 1:
/* 521 */         return 1;
/*     */       case 2:
/* 523 */         return 4;
/*     */       }
/* 525 */       return 0;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 530 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/* 531 */     }return 0;
/*     */   }
/*     */ 
/*     */   public int getParameterType(int paramInt) throws SQLServerException
/*     */   {
/* 536 */     checkClosed();
/*     */     try {
/* 538 */       if (this.rsProcedureMeta == null) {
/* 539 */         checkParam(paramInt);
/* 540 */         return this.md.getColumnType(paramInt);
/*     */       }
/*     */ 
/* 543 */       verifyParameterPosition(paramInt);
/* 544 */       int i = this.rsProcedureMeta.getShort("DATA_TYPE");
/* 545 */       return i;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 549 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/* 550 */     }return 0;
/*     */   }
/*     */ 
/*     */   public String getParameterTypeName(int paramInt) throws SQLServerException
/*     */   {
/* 555 */     checkClosed();
/*     */     try {
/* 557 */       if (this.rsProcedureMeta == null) {
/* 558 */         checkParam(paramInt);
/* 559 */         return this.md.getColumnTypeName(paramInt);
/*     */       }
/*     */ 
/* 562 */       verifyParameterPosition(paramInt);
/* 563 */       return this.rsProcedureMeta.getString("TYPE_NAME");
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 567 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/* 568 */     }return null;
/*     */   }
/*     */ 
/*     */   public int getPrecision(int paramInt) throws SQLServerException
/*     */   {
/* 573 */     checkClosed();
/*     */     try {
/* 575 */       if (this.rsProcedureMeta == null) {
/* 576 */         checkParam(paramInt);
/* 577 */         return this.md.getPrecision(paramInt);
/*     */       }
/*     */ 
/* 580 */       verifyParameterPosition(paramInt);
/* 581 */       int i = this.rsProcedureMeta.getInt("PRECISION");
/* 582 */       return i;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 586 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/* 587 */     }return 0;
/*     */   }
/*     */ 
/*     */   public int getScale(int paramInt) throws SQLServerException
/*     */   {
/* 592 */     checkClosed();
/*     */     try {
/* 594 */       if (this.rsProcedureMeta == null) {
/* 595 */         checkParam(paramInt);
/* 596 */         return this.md.getScale(paramInt);
/*     */       }
/*     */ 
/* 599 */       verifyParameterPosition(paramInt);
/* 600 */       int i = this.rsProcedureMeta.getInt("SCALE");
/* 601 */       return i;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 605 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/* 606 */     }return 0;
/*     */   }
/*     */ 
/*     */   public int isNullable(int paramInt) throws SQLServerException
/*     */   {
/* 611 */     checkClosed();
/*     */     try {
/* 613 */       if (this.rsProcedureMeta == null) {
/* 614 */         checkParam(paramInt);
/* 615 */         return this.md.isNullable(paramInt);
/*     */       }
/*     */ 
/* 618 */       verifyParameterPosition(paramInt);
/* 619 */       int i = this.rsProcedureMeta.getInt("NULLABLE");
/* 620 */       if (i == 1)
/* 621 */         return 1;
/* 622 */       if (i == 0)
/* 623 */         return 0;
/* 624 */       return 2;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 628 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/* 629 */     }return 0;
/*     */   }
/*     */ 
/*     */   public boolean isSigned(int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 640 */     checkClosed();
/*     */     try {
/* 642 */       if (this.rsProcedureMeta == null) {
/* 643 */         checkParam(paramInt);
/* 644 */         return this.md.isSigned(paramInt);
/*     */       }
/*     */ 
/* 647 */       verifyParameterPosition(paramInt);
/* 648 */       return JDBCType.of(this.rsProcedureMeta.getShort("DATA_TYPE")).isSigned();
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 652 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/* 653 */     }return false;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  34 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerParameterMetaData");
/*     */ 
/*  37 */     baseID = 0;
/*     */   }
/*     */ 
/*     */   private class MetaInfo
/*     */   {
/*     */     String table;
/*     */     String fields;
/*     */ 
/*     */     MetaInfo(String paramString1, String arg3)
/*     */     {
/* 201 */       this.table = paramString1;
/*     */       Object localObject;
/* 202 */       this.fields = localObject;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerParameterMetaData
 * JD-Core Version:    0.6.0
 */