/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import microsoft.sql.DateTimeOffset;
/*     */ 
/*     */ final class DDC
/*     */ {
/*     */   private static final BigInteger maxRPCDecimalValue;
/*     */ 
/*     */   static final Object convertIntegerToObject(int paramInt1, int paramInt2, JDBCType paramJDBCType, StreamType paramStreamType)
/*     */   {
/*  33 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*     */     {
/*     */     case 1:
/*  36 */       return new Integer(paramInt1);
/*     */     case 2:
/*     */     case 3:
/*  39 */       return new Short((short)paramInt1);
/*     */     case 4:
/*     */     case 5:
/*  42 */       return new Boolean(0 != paramInt1);
/*     */     case 6:
/*  44 */       return new Long(paramInt1);
/*     */     case 7:
/*     */     case 8:
/*  47 */       return new BigDecimal(Integer.toString(paramInt1));
/*     */     case 9:
/*     */     case 10:
/*  50 */       return new Double(paramInt1);
/*     */     case 11:
/*  52 */       return new Float(paramInt1);
/*     */     case 12:
/*  54 */       return convertIntToBytes(paramInt1, paramInt2);
/*     */     }
/*  56 */     return Integer.toString(paramInt1);
/*     */   }
/*     */ 
/*     */   static final Object convertLongToObject(long paramLong, JDBCType paramJDBCType, StreamType paramStreamType)
/*     */   {
/*  68 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*     */     {
/*     */     case 6:
/*  71 */       return new Long(paramLong);
/*     */     case 1:
/*  73 */       return new Integer((int)paramLong);
/*     */     case 2:
/*     */     case 3:
/*  76 */       return new Short((short)(int)paramLong);
/*     */     case 4:
/*     */     case 5:
/*  79 */       return new Boolean(0L != paramLong);
/*     */     case 7:
/*     */     case 8:
/*  82 */       return new BigDecimal(Long.toString(paramLong));
/*     */     case 9:
/*     */     case 10:
/*  85 */       return new Double(paramLong);
/*     */     case 11:
/*  87 */       return new Float((float)paramLong);
/*     */     case 12:
/*  89 */       return convertLongToBytes(paramLong);
/*     */     }
/*  91 */     return Long.toString(paramLong);
/*     */   }
/*     */ 
/*     */   static final byte[] convertIntToBytes(int paramInt1, int paramInt2)
/*     */   {
/* 103 */     byte[] arrayOfByte = new byte[paramInt2];
/* 104 */     for (int i = paramInt2; i-- > 0; )
/*     */     {
/* 106 */       arrayOfByte[i] = (byte)(paramInt1 & 0xFF);
/* 107 */       paramInt1 >>= 8;
/*     */     }
/* 109 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   static final Object convertFloatToObject(float paramFloat, JDBCType paramJDBCType, StreamType paramStreamType)
/*     */   {
/* 120 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*     */     {
/*     */     case 11:
/* 123 */       return new Float(paramFloat);
/*     */     case 1:
/* 125 */       return new Integer((int)paramFloat);
/*     */     case 2:
/*     */     case 3:
/* 128 */       return new Short((short)(int)paramFloat);
/*     */     case 4:
/*     */     case 5:
/* 131 */       return new Boolean(0 != Float.compare(0.0F, paramFloat));
/*     */     case 6:
/* 133 */       return new Long(()paramFloat);
/*     */     case 7:
/*     */     case 8:
/* 136 */       return new BigDecimal(Float.toString(paramFloat));
/*     */     case 9:
/*     */     case 10:
/* 139 */       return new Double(new Float(paramFloat).doubleValue());
/*     */     case 12:
/* 141 */       return convertIntToBytes(Float.floatToRawIntBits(paramFloat), 4);
/*     */     }
/* 143 */     return Float.toString(paramFloat);
/*     */   }
/*     */ 
/*     */   static final byte[] convertLongToBytes(long paramLong)
/*     */   {
/* 154 */     byte[] arrayOfByte = new byte[8];
/* 155 */     for (int i = 8; i-- > 0; )
/*     */     {
/* 157 */       arrayOfByte[i] = (byte)(int)(paramLong & 0xFF);
/* 158 */       paramLong >>= 8;
/*     */     }
/* 160 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   static final Object convertDoubleToObject(double paramDouble, JDBCType paramJDBCType, StreamType paramStreamType)
/*     */   {
/* 171 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*     */     {
/*     */     case 9:
/*     */     case 10:
/* 175 */       return new Double(paramDouble);
/*     */     case 11:
/* 177 */       return new Float(new Double(paramDouble).floatValue());
/*     */     case 1:
/* 179 */       return new Integer((int)paramDouble);
/*     */     case 2:
/*     */     case 3:
/* 182 */       return new Short((short)(int)paramDouble);
/*     */     case 4:
/*     */     case 5:
/* 185 */       return new Boolean(0 != Double.compare(0.0D, paramDouble));
/*     */     case 6:
/* 187 */       return new Long(()paramDouble);
/*     */     case 7:
/*     */     case 8:
/* 190 */       return new BigDecimal(Double.toString(paramDouble));
/*     */     case 12:
/* 192 */       return convertLongToBytes(Double.doubleToRawLongBits(paramDouble));
/*     */     }
/* 194 */     return Double.toString(paramDouble);
/*     */   }
/*     */ 
/*     */   static final byte[] convertBigDecimalToBytes(BigDecimal paramBigDecimal, int paramInt)
/*     */   {
/*     */     byte[] arrayOfByte1;
/* 202 */     if (paramBigDecimal == null)
/*     */     {
/* 204 */       arrayOfByte1 = new byte[2];
/* 205 */       arrayOfByte1[0] = (byte)paramInt;
/* 206 */       arrayOfByte1[1] = 0;
/*     */     }
/*     */     else
/*     */     {
/* 210 */       int i = paramBigDecimal.signum() < 0 ? 1 : 0;
/*     */ 
/* 213 */       if (paramBigDecimal.scale() < 0) {
/* 214 */         paramBigDecimal = paramBigDecimal.setScale(0);
/*     */       }
/* 216 */       BigInteger localBigInteger = paramBigDecimal.unscaledValue();
/*     */ 
/* 218 */       if (i != 0) {
/* 219 */         localBigInteger = localBigInteger.negate();
/*     */       }
/* 221 */       byte[] arrayOfByte2 = localBigInteger.toByteArray();
/*     */ 
/* 223 */       arrayOfByte1 = new byte[arrayOfByte2.length + 3];
/* 224 */       int j = 0;
/* 225 */       arrayOfByte1[(j++)] = (byte)paramBigDecimal.scale();
/* 226 */       arrayOfByte1[(j++)] = (byte)(arrayOfByte2.length + 1);
/* 227 */       arrayOfByte1[(j++)] = (byte)(i != 0 ? 0 : 1);
/* 228 */       for (int k = arrayOfByte2.length - 1; k >= 0; k--) {
/* 229 */         arrayOfByte1[(j++)] = arrayOfByte2[k];
/*     */       }
/*     */     }
/* 232 */     return arrayOfByte1;
/*     */   }
/*     */ 
/*     */   static final Object convertBigDecimalToObject(BigDecimal paramBigDecimal, JDBCType paramJDBCType, StreamType paramStreamType)
/*     */   {
/* 243 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*     */     {
/*     */     case 7:
/*     */     case 8:
/* 247 */       return paramBigDecimal;
/*     */     case 9:
/*     */     case 10:
/* 250 */       return new Double(paramBigDecimal.doubleValue());
/*     */     case 11:
/* 252 */       return new Float(paramBigDecimal.floatValue());
/*     */     case 1:
/* 254 */       return new Integer(paramBigDecimal.intValue());
/*     */     case 2:
/*     */     case 3:
/* 257 */       return new Short(paramBigDecimal.shortValue());
/*     */     case 4:
/*     */     case 5:
/* 260 */       return new Boolean(0 != paramBigDecimal.compareTo(BigDecimal.valueOf(0L)));
/*     */     case 6:
/* 262 */       return new Long(paramBigDecimal.longValue());
/*     */     case 12:
/* 264 */       return convertBigDecimalToBytes(paramBigDecimal, paramBigDecimal.scale());
/*     */     }
/* 266 */     return paramBigDecimal.toString();
/*     */   }
/*     */ 
/*     */   static final Object convertStringToObject(String paramString1, String paramString2, JDBCType paramJDBCType, StreamType paramStreamType)
/*     */     throws UnsupportedEncodingException, IllegalArgumentException
/*     */   {
/* 282 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*     */     {
/*     */     case 7:
/*     */     case 8:
/* 287 */       return new BigDecimal(paramString1.trim());
/*     */     case 9:
/*     */     case 10:
/* 290 */       return Double.valueOf(paramString1.trim());
/*     */     case 11:
/* 292 */       return Float.valueOf(paramString1.trim());
/*     */     case 1:
/* 294 */       return Integer.valueOf(paramString1.trim());
/*     */     case 2:
/*     */     case 3:
/* 297 */       return Short.valueOf(paramString1.trim());
/*     */     case 4:
/*     */     case 5:
/* 300 */       String str = paramString1.trim();
/* 301 */       return 1 == str.length() ? Boolean.valueOf('1' == str.charAt(0)) : Boolean.valueOf(str);
/*     */     case 6:
/* 305 */       return Long.valueOf(paramString1.trim());
/*     */     case 13:
/* 309 */       return Timestamp.valueOf(paramString1.trim());
/*     */     case 14:
/* 311 */       return Date.valueOf(getDatePart(paramString1.trim()));
/*     */     case 15:
/* 322 */       Timestamp localTimestamp = Timestamp.valueOf(new StringBuilder().append("1970-01-01 ").append(getTimePart(paramString1.trim())).toString());
/* 323 */       GregorianCalendar localGregorianCalendar = new GregorianCalendar(Locale.US);
/* 324 */       localGregorianCalendar.clear();
/* 325 */       localGregorianCalendar.setTimeInMillis(localTimestamp.getTime());
/* 326 */       if (localTimestamp.getNanos() % 1000000 >= 500000)
/* 327 */         localGregorianCalendar.add(14, 1);
/* 328 */       localGregorianCalendar.set(1970, 0, 1);
/* 329 */       return new Time(localGregorianCalendar.getTimeInMillis());
/*     */     case 12:
/* 333 */       return paramString1.getBytes(paramString2);
/*     */     }
/*     */ 
/* 337 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$StreamType[paramStreamType.ordinal()])
/*     */     {
/*     */     case 1:
/* 340 */       return new StringReader(paramString1);
/*     */     case 2:
/* 342 */       return new ByteArrayInputStream(paramString1.getBytes("US-ASCII"));
/*     */     case 3:
/* 344 */       return new ByteArrayInputStream(paramString1.getBytes());
/*     */     }
/*     */ 
/* 347 */     return paramString1; } 
/*     */   static final Object convertStreamToObject(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs) throws SQLServerException { // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: aload_0
/*     */     //   2: if_acmpne +5 -> 7
/*     */     //   5: aconst_null
/*     */     //   6: areturn
/*     */     //   7: getstatic 89	com/microsoft/sqlserver/jdbc/DDC:$assertionsDisabled	Z
/*     */     //   10: ifne +16 -> 26
/*     */     //   13: aconst_null
/*     */     //   14: aload_1
/*     */     //   15: if_acmpne +11 -> 26
/*     */     //   18: new 90	java/lang/AssertionError
/*     */     //   21: dup
/*     */     //   22: invokespecial 91	java/lang/AssertionError:<init>	()V
/*     */     //   25: athrow
/*     */     //   26: getstatic 89	com/microsoft/sqlserver/jdbc/DDC:$assertionsDisabled	Z
/*     */     //   29: ifne +16 -> 45
/*     */     //   32: aconst_null
/*     */     //   33: aload_3
/*     */     //   34: if_acmpne +11 -> 45
/*     */     //   37: new 90	java/lang/AssertionError
/*     */     //   40: dup
/*     */     //   41: invokespecial 91	java/lang/AssertionError:<init>	()V
/*     */     //   44: athrow
/*     */     //   45: aload_1
/*     */     //   46: invokevirtual 92	com/microsoft/sqlserver/jdbc/TypeInfo:getSSType	()Lcom/microsoft/sqlserver/jdbc/SSType;
/*     */     //   49: astore 4
/*     */     //   51: getstatic 2	com/microsoft/sqlserver/jdbc/DDC$1:$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType	[I
/*     */     //   54: aload_2
/*     */     //   55: invokevirtual 3	com/microsoft/sqlserver/jdbc/JDBCType:ordinal	()I
/*     */     //   58: iaload
/*     */     //   59: tableswitch	default:+77 -> 136, 12:+424->483, 13:+77->136, 14:+77->136, 15:+77->136, 16:+77->136, 17:+77->136, 18:+77->136, 19:+77->136, 20:+77->136, 21:+77->136, 22:+393->452, 23:+403->462, 24:+413->472, 25:+424->483, 26:+424->483, 27:+424->483
/*     */     //   137: nop
/*     */     //   138: dup2_x1
/*     */     //   139: aload 4
/*     */     //   141: if_acmpeq +43 -> 184
/*     */     //   144: getstatic 94	com/microsoft/sqlserver/jdbc/SSType:VARBINARY	Lcom/microsoft/sqlserver/jdbc/SSType;
/*     */     //   147: aload 4
/*     */     //   149: if_acmpeq +35 -> 184
/*     */     //   152: getstatic 95	com/microsoft/sqlserver/jdbc/SSType:VARBINARYMAX	Lcom/microsoft/sqlserver/jdbc/SSType;
/*     */     //   155: aload 4
/*     */     //   157: if_acmpeq +27 -> 184
/*     */     //   160: getstatic 96	com/microsoft/sqlserver/jdbc/SSType:TIMESTAMP	Lcom/microsoft/sqlserver/jdbc/SSType;
/*     */     //   163: aload 4
/*     */     //   165: if_acmpeq +19 -> 184
/*     */     //   168: getstatic 97	com/microsoft/sqlserver/jdbc/SSType:IMAGE	Lcom/microsoft/sqlserver/jdbc/SSType;
/*     */     //   171: aload 4
/*     */     //   173: if_acmpeq +11 -> 184
/*     */     //   176: getstatic 98	com/microsoft/sqlserver/jdbc/SSType:UDT	Lcom/microsoft/sqlserver/jdbc/SSType;
/*     */     //   179: aload 4
/*     */     //   181: if_acmpne +88 -> 269
/*     */     //   184: getstatic 99	com/microsoft/sqlserver/jdbc/StreamType:ASCII	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   187: aload_3
/*     */     //   188: getfield 100	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:streamType	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   191: if_acmpne +5 -> 196
/*     */     //   194: aload_0
/*     */     //   195: areturn
/*     */     //   196: getstatic 89	com/microsoft/sqlserver/jdbc/DDC:$assertionsDisabled	Z
/*     */     //   199: ifne +31 -> 230
/*     */     //   202: getstatic 101	com/microsoft/sqlserver/jdbc/StreamType:CHARACTER	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   205: aload_3
/*     */     //   206: getfield 100	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:streamType	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   209: if_acmpeq +21 -> 230
/*     */     //   212: getstatic 102	com/microsoft/sqlserver/jdbc/StreamType:NONE	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   215: aload_3
/*     */     //   216: getfield 100	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:streamType	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   219: if_acmpeq +11 -> 230
/*     */     //   222: new 90	java/lang/AssertionError
/*     */     //   225: dup
/*     */     //   226: invokespecial 91	java/lang/AssertionError:<init>	()V
/*     */     //   229: athrow
/*     */     //   230: aload_0
/*     */     //   231: invokevirtual 103	com/microsoft/sqlserver/jdbc/BaseInputStream:getBytes	()[B
/*     */     //   234: astore 5
/*     */     //   236: aload 5
/*     */     //   238: aload 5
/*     */     //   240: arraylength
/*     */     //   241: invokestatic 104	com/microsoft/sqlserver/jdbc/Util:bytesToHexString	([BI)Ljava/lang/String;
/*     */     //   244: astore 6
/*     */     //   246: getstatic 102	com/microsoft/sqlserver/jdbc/StreamType:NONE	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   249: aload_3
/*     */     //   250: getfield 100	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:streamType	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   253: if_acmpne +6 -> 259
/*     */     //   256: aload 6
/*     */     //   258: areturn
/*     */     //   259: new 83	java/io/StringReader
/*     */     //   262: dup
/*     */     //   263: aload 6
/*     */     //   265: invokespecial 84	java/io/StringReader:<init>	(Ljava/lang/String;)V
/*     */     //   268: areturn
/*     */     //   269: getstatic 99	com/microsoft/sqlserver/jdbc/StreamType:ASCII	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   272: aload_3
/*     */     //   273: getfield 100	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:streamType	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   276: if_acmpne +78 -> 354
/*     */     //   279: aload_1
/*     */     //   280: invokevirtual 105	com/microsoft/sqlserver/jdbc/TypeInfo:supportsFastAsciiConversion	()Z
/*     */     //   283: ifeq +12 -> 295
/*     */     //   286: new 106	com/microsoft/sqlserver/jdbc/AsciiFilteredInputStream
/*     */     //   289: dup
/*     */     //   290: aload_0
/*     */     //   291: invokespecial 107	com/microsoft/sqlserver/jdbc/AsciiFilteredInputStream:<init>	(Lcom/microsoft/sqlserver/jdbc/BaseInputStream;)V
/*     */     //   294: areturn
/*     */     //   295: aload_3
/*     */     //   296: getfield 108	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:isAdaptive	Z
/*     */     //   299: ifeq +27 -> 326
/*     */     //   302: aload_0
/*     */     //   303: new 109	java/io/BufferedReader
/*     */     //   306: dup
/*     */     //   307: new 110	java/io/InputStreamReader
/*     */     //   310: dup
/*     */     //   311: aload_0
/*     */     //   312: aload_1
/*     */     //   313: invokevirtual 111	com/microsoft/sqlserver/jdbc/TypeInfo:getCharset	()Ljava/lang/String;
/*     */     //   316: invokespecial 112	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
/*     */     //   319: invokespecial 113	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
/*     */     //   322: invokestatic 114	com/microsoft/sqlserver/jdbc/AsciiFilteredUnicodeInputStream:MakeAsciiFilteredUnicodeInputStream	(Lcom/microsoft/sqlserver/jdbc/BaseInputStream;Ljava/io/Reader;)Lcom/microsoft/sqlserver/jdbc/AsciiFilteredUnicodeInputStream;
/*     */     //   325: areturn
/*     */     //   326: new 85	java/io/ByteArrayInputStream
/*     */     //   329: dup
/*     */     //   330: new 115	java/lang/String
/*     */     //   333: dup
/*     */     //   334: aload_0
/*     */     //   335: invokevirtual 103	com/microsoft/sqlserver/jdbc/BaseInputStream:getBytes	()[B
/*     */     //   338: aload_1
/*     */     //   339: invokevirtual 111	com/microsoft/sqlserver/jdbc/TypeInfo:getCharset	()Ljava/lang/String;
/*     */     //   342: invokespecial 116	java/lang/String:<init>	([BLjava/lang/String;)V
/*     */     //   345: ldc 86
/*     */     //   347: invokevirtual 80	java/lang/String:getBytes	(Ljava/lang/String;)[B
/*     */     //   350: invokespecial 87	java/io/ByteArrayInputStream:<init>	([B)V
/*     */     //   353: areturn
/*     */     //   354: getstatic 101	com/microsoft/sqlserver/jdbc/StreamType:CHARACTER	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   357: aload_3
/*     */     //   358: getfield 100	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:streamType	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   361: if_acmpeq +13 -> 374
/*     */     //   364: getstatic 117	com/microsoft/sqlserver/jdbc/StreamType:NCHARACTER	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   367: aload_3
/*     */     //   368: getfield 100	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:streamType	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   371: if_acmpne +53 -> 424
/*     */     //   374: aload_3
/*     */     //   375: getfield 108	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:isAdaptive	Z
/*     */     //   378: ifeq +23 -> 401
/*     */     //   381: new 109	java/io/BufferedReader
/*     */     //   384: dup
/*     */     //   385: new 110	java/io/InputStreamReader
/*     */     //   388: dup
/*     */     //   389: aload_0
/*     */     //   390: aload_1
/*     */     //   391: invokevirtual 111	com/microsoft/sqlserver/jdbc/TypeInfo:getCharset	()Ljava/lang/String;
/*     */     //   394: invokespecial 112	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
/*     */     //   397: invokespecial 113	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
/*     */     //   400: areturn
/*     */     //   401: new 83	java/io/StringReader
/*     */     //   404: dup
/*     */     //   405: new 115	java/lang/String
/*     */     //   408: dup
/*     */     //   409: aload_0
/*     */     //   410: invokevirtual 103	com/microsoft/sqlserver/jdbc/BaseInputStream:getBytes	()[B
/*     */     //   413: aload_1
/*     */     //   414: invokevirtual 111	com/microsoft/sqlserver/jdbc/TypeInfo:getCharset	()Ljava/lang/String;
/*     */     //   417: invokespecial 116	java/lang/String:<init>	([BLjava/lang/String;)V
/*     */     //   420: invokespecial 84	java/io/StringReader:<init>	(Ljava/lang/String;)V
/*     */     //   423: areturn
/*     */     //   424: new 115	java/lang/String
/*     */     //   427: dup
/*     */     //   428: aload_0
/*     */     //   429: invokevirtual 103	com/microsoft/sqlserver/jdbc/BaseInputStream:getBytes	()[B
/*     */     //   432: aload_1
/*     */     //   433: invokevirtual 111	com/microsoft/sqlserver/jdbc/TypeInfo:getCharset	()Ljava/lang/String;
/*     */     //   436: invokespecial 116	java/lang/String:<init>	([BLjava/lang/String;)V
/*     */     //   439: aload_1
/*     */     //   440: invokevirtual 111	com/microsoft/sqlserver/jdbc/TypeInfo:getCharset	()Ljava/lang/String;
/*     */     //   443: aload_2
/*     */     //   444: aload_3
/*     */     //   445: getfield 100	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:streamType	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   448: invokestatic 118	com/microsoft/sqlserver/jdbc/DDC:convertStringToObject	(Ljava/lang/String;Ljava/lang/String;Lcom/microsoft/sqlserver/jdbc/JDBCType;Lcom/microsoft/sqlserver/jdbc/StreamType;)Ljava/lang/Object;
/*     */     //   451: areturn
/*     */     //   452: new 119	com/microsoft/sqlserver/jdbc/SQLServerClob
/*     */     //   455: dup
/*     */     //   456: aload_0
/*     */     //   457: aload_1
/*     */     //   458: invokespecial 120	com/microsoft/sqlserver/jdbc/SQLServerClob:<init>	(Lcom/microsoft/sqlserver/jdbc/BaseInputStream;Lcom/microsoft/sqlserver/jdbc/TypeInfo;)V
/*     */     //   461: areturn
/*     */     //   462: new 121	com/microsoft/sqlserver/jdbc/SQLServerNClob
/*     */     //   465: dup
/*     */     //   466: aload_0
/*     */     //   467: aload_1
/*     */     //   468: invokespecial 122	com/microsoft/sqlserver/jdbc/SQLServerNClob:<init>	(Lcom/microsoft/sqlserver/jdbc/BaseInputStream;Lcom/microsoft/sqlserver/jdbc/TypeInfo;)V
/*     */     //   471: areturn
/*     */     //   472: new 123	com/microsoft/sqlserver/jdbc/SQLServerSQLXML
/*     */     //   475: dup
/*     */     //   476: aload_0
/*     */     //   477: aload_3
/*     */     //   478: aload_1
/*     */     //   479: invokespecial 124	com/microsoft/sqlserver/jdbc/SQLServerSQLXML:<init>	(Ljava/io/InputStream;Lcom/microsoft/sqlserver/jdbc/InputStreamGetterArgs;Lcom/microsoft/sqlserver/jdbc/TypeInfo;)V
/*     */     //   482: areturn
/*     */     //   483: getstatic 125	com/microsoft/sqlserver/jdbc/StreamType:BINARY	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   486: aload_3
/*     */     //   487: getfield 100	com/microsoft/sqlserver/jdbc/InputStreamGetterArgs:streamType	Lcom/microsoft/sqlserver/jdbc/StreamType;
/*     */     //   490: if_acmpne +5 -> 495
/*     */     //   493: aload_0
/*     */     //   494: areturn
/*     */     //   495: getstatic 126	com/microsoft/sqlserver/jdbc/JDBCType:BLOB	Lcom/microsoft/sqlserver/jdbc/JDBCType;
/*     */     //   498: aload_2
/*     */     //   499: if_acmpne +12 -> 511
/*     */     //   502: new 127	com/microsoft/sqlserver/jdbc/SQLServerBlob
/*     */     //   505: dup
/*     */     //   506: aload_0
/*     */     //   507: invokespecial 128	com/microsoft/sqlserver/jdbc/SQLServerBlob:<init>	(Lcom/microsoft/sqlserver/jdbc/BaseInputStream;)V
/*     */     //   510: areturn
/*     */     //   511: aload_0
/*     */     //   512: invokevirtual 103	com/microsoft/sqlserver/jdbc/BaseInputStream:getBytes	()[B
/*     */     //   515: areturn
/*     */     //   516: astore 5
/*     */     //   518: new 130	java/text/MessageFormat
/*     */     //   521: dup
/*     */     //   522: ldc 131
/*     */     //   524: invokestatic 132	com/microsoft/sqlserver/jdbc/SQLServerException:getErrString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   527: invokespecial 133	java/text/MessageFormat:<init>	(Ljava/lang/String;)V
/*     */     //   530: astore 6
/*     */     //   532: new 134	com/microsoft/sqlserver/jdbc/SQLServerException
/*     */     //   535: dup
/*     */     //   536: aload 6
/*     */     //   538: iconst_2
/*     */     //   539: anewarray 135	java/lang/Object
/*     */     //   542: dup
/*     */     //   543: iconst_0
/*     */     //   544: aload_1
/*     */     //   545: invokevirtual 92	com/microsoft/sqlserver/jdbc/TypeInfo:getSSType	()Lcom/microsoft/sqlserver/jdbc/SSType;
/*     */     //   548: aastore
/*     */     //   549: dup
/*     */     //   550: iconst_1
/*     */     //   551: aload_2
/*     */     //   552: aastore
/*     */     //   553: invokevirtual 136	java/text/MessageFormat:format	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   556: aconst_null
/*     */     //   557: iconst_0
/*     */     //   558: aload 5
/*     */     //   560: invokespecial 137	com/microsoft/sqlserver/jdbc/SQLServerException:<init>	(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Throwable;)V
/*     */     //   563: athrow
/*     */     //   564: astore 5
/*     */     //   566: new 130	java/text/MessageFormat
/*     */     //   569: dup
/*     */     //   570: ldc 131
/*     */     //   572: invokestatic 132	com/microsoft/sqlserver/jdbc/SQLServerException:getErrString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   575: invokespecial 133	java/text/MessageFormat:<init>	(Ljava/lang/String;)V
/*     */     //   578: astore 6
/*     */     //   580: new 134	com/microsoft/sqlserver/jdbc/SQLServerException
/*     */     //   583: dup
/*     */     //   584: aload 6
/*     */     //   586: iconst_2
/*     */     //   587: anewarray 135	java/lang/Object
/*     */     //   590: dup
/*     */     //   591: iconst_0
/*     */     //   592: aload_1
/*     */     //   593: invokevirtual 92	com/microsoft/sqlserver/jdbc/TypeInfo:getSSType	()Lcom/microsoft/sqlserver/jdbc/SSType;
/*     */     //   596: aastore
/*     */     //   597: dup
/*     */     //   598: iconst_1
/*     */     //   599: aload_2
/*     */     //   600: aastore
/*     */     //   601: invokevirtual 136	java/text/MessageFormat:format	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   604: aconst_null
/*     */     //   605: iconst_0
/*     */     //   606: aload 5
/*     */     //   608: invokespecial 137	com/microsoft/sqlserver/jdbc/SQLServerException:<init>	(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Throwable;)V
/*     */     //   611: athrow
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   51	195	516	java/lang/IllegalArgumentException
/*     */     //   196	258	516	java/lang/IllegalArgumentException
/*     */     //   259	268	516	java/lang/IllegalArgumentException
/*     */     //   269	294	516	java/lang/IllegalArgumentException
/*     */     //   295	325	516	java/lang/IllegalArgumentException
/*     */     //   326	353	516	java/lang/IllegalArgumentException
/*     */     //   354	400	516	java/lang/IllegalArgumentException
/*     */     //   401	423	516	java/lang/IllegalArgumentException
/*     */     //   424	451	516	java/lang/IllegalArgumentException
/*     */     //   452	461	516	java/lang/IllegalArgumentException
/*     */     //   462	471	516	java/lang/IllegalArgumentException
/*     */     //   472	482	516	java/lang/IllegalArgumentException
/*     */     //   483	494	516	java/lang/IllegalArgumentException
/*     */     //   495	510	516	java/lang/IllegalArgumentException
/*     */     //   511	515	516	java/lang/IllegalArgumentException
/*     */     //   51	195	564	java/io/UnsupportedEncodingException
/*     */     //   196	258	564	java/io/UnsupportedEncodingException
/*     */     //   259	268	564	java/io/UnsupportedEncodingException
/*     */     //   269	294	564	java/io/UnsupportedEncodingException
/*     */     //   295	325	564	java/io/UnsupportedEncodingException
/*     */     //   326	353	564	java/io/UnsupportedEncodingException
/*     */     //   354	400	564	java/io/UnsupportedEncodingException
/*     */     //   401	423	564	java/io/UnsupportedEncodingException
/*     */     //   424	451	564	java/io/UnsupportedEncodingException
/*     */     //   452	461	564	java/io/UnsupportedEncodingException
/*     */     //   462	471	564	java/io/UnsupportedEncodingException
/*     */     //   472	482	564	java/io/UnsupportedEncodingException
/*     */     //   483	494	564	java/io/UnsupportedEncodingException
/*     */     //   495	510	564	java/io/UnsupportedEncodingException
/*     */     //   511	515	564	java/io/UnsupportedEncodingException } 
/* 488 */   private static final String getDatePart(String paramString) { int i = paramString.indexOf(32);
/* 489 */     if (-1 == i) return paramString;
/* 490 */     return paramString.substring(0, i);
/*     */   }
/*     */ 
/*     */   private static final String getTimePart(String paramString)
/*     */   {
/* 496 */     int i = paramString.indexOf(32);
/* 497 */     if (-1 == i) return paramString;
/* 498 */     return paramString.substring(i + 1);
/*     */   }
/*     */ 
/*     */   private static String fractionalSecondsString(long paramLong, int paramInt)
/*     */   {
/* 505 */     assert ((0L <= paramLong) && (paramLong < 1000000000L));
/* 506 */     assert ((0 <= paramInt) && (paramInt <= 7));
/*     */ 
/* 510 */     if (0 == paramInt) {
/* 511 */       return "";
/*     */     }
/* 513 */     return BigDecimal.valueOf(paramLong % 1000000000L, 9).setScale(paramInt).toPlainString().substring(1);
/*     */   }
/*     */ 
/*     */   static final Object convertTemporalToObject(JDBCType paramJDBCType, SSType paramSSType, Calendar paramCalendar, int paramInt1, long paramLong, int paramInt2)
/*     */   {
/* 581 */     TimeZone localTimeZone1 = null != paramCalendar ? paramCalendar.getTimeZone() : TimeZone.getDefault();
/*     */ 
/* 590 */     TimeZone localTimeZone2 = SSType.DATETIMEOFFSET == paramSSType ? UTC.timeZone : localTimeZone1;
/*     */ 
/* 592 */     int i = 0;
/*     */ 
/* 597 */     Object localObject1 = new GregorianCalendar(localTimeZone2, Locale.US);
/*     */ 
/* 601 */     ((GregorianCalendar)localObject1).setLenient(true);
/*     */ 
/* 605 */     ((GregorianCalendar)localObject1).clear();
/*     */     Object localObject2;
/* 609 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSType[paramSSType.ordinal()])
/*     */     {
/*     */     case 1:
/* 623 */       ((GregorianCalendar)localObject1).set(1900, 0, 1, 0, 0, 0);
/* 624 */       ((GregorianCalendar)localObject1).set(14, (int)(paramLong / 1000000L));
/*     */ 
/* 626 */       i = (int)(paramLong % 1000000000L);
/* 627 */       break;
/*     */     case 2:
/*     */     case 3:
/*     */     case 4:
/* 640 */       if (paramInt1 >= GregorianChange.DAYS_SINCE_BASE_DATE_HINT)
/*     */       {
/* 647 */         ((GregorianCalendar)localObject1).set(1, 0, 1 + paramInt1 + GregorianChange.EXTRA_DAYS_TO_BE_ADDED, 0, 0, 0);
/* 648 */         ((GregorianCalendar)localObject1).set(14, (int)(paramLong / 1000000L));
/*     */       }
/*     */       else
/*     */       {
/* 662 */         ((GregorianCalendar)localObject1).setGregorianChange(GregorianChange.PURE_CHANGE_DATE);
/*     */ 
/* 668 */         ((GregorianCalendar)localObject1).set(1, 0, 1 + paramInt1, 0, 0, 0);
/* 669 */         ((GregorianCalendar)localObject1).set(14, (int)(paramLong / 1000000L));
/*     */ 
/* 674 */         int j = ((GregorianCalendar)localObject1).get(1);
/* 675 */         int m = ((GregorianCalendar)localObject1).get(2);
/* 676 */         int i1 = ((GregorianCalendar)localObject1).get(5);
/* 677 */         int i2 = ((GregorianCalendar)localObject1).get(11);
/* 678 */         int i3 = ((GregorianCalendar)localObject1).get(12);
/* 679 */         int i4 = ((GregorianCalendar)localObject1).get(13);
/* 680 */         int i5 = ((GregorianCalendar)localObject1).get(14);
/*     */ 
/* 682 */         ((GregorianCalendar)localObject1).setGregorianChange(GregorianChange.STANDARD_CHANGE_DATE);
/* 683 */         ((GregorianCalendar)localObject1).set(j, m, i1, i2, i3, i4);
/* 684 */         ((GregorianCalendar)localObject1).set(14, i5);
/*     */       }
/*     */ 
/* 693 */       if ((SSType.DATETIMEOFFSET == paramSSType) && (!localTimeZone2.hasSameRules(localTimeZone1)))
/*     */       {
/* 695 */         localObject2 = new GregorianCalendar(localTimeZone1, Locale.US);
/* 696 */         ((GregorianCalendar)localObject2).clear();
/* 697 */         ((GregorianCalendar)localObject2).setTimeInMillis(((GregorianCalendar)localObject1).getTimeInMillis());
/* 698 */         localObject1 = localObject2;
/*     */       }
/*     */ 
/* 701 */       i = (int)(paramLong % 1000000000L);
/* 702 */       break;
/*     */     case 5:
/* 716 */       ((GregorianCalendar)localObject1).set(1900, 0, 1 + paramInt1, 0, 0, 0);
/* 717 */       ((GregorianCalendar)localObject1).set(14, (int)paramLong);
/*     */ 
/* 719 */       i = (int)(paramLong * 1000000L % 1000000000L);
/*     */ 
/* 721 */       break;
/*     */     default:
/* 725 */       throw new AssertionError(new StringBuilder().append("Unexpected SSType: ").append(paramSSType).toString());
/*     */     }
/*     */     int k;
/* 729 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType$Category[paramJDBCType.category.ordinal()])
/*     */     {
/*     */     case 1:
/* 735 */       ((GregorianCalendar)localObject1).set(11, 0);
/* 736 */       ((GregorianCalendar)localObject1).set(12, 0);
/* 737 */       ((GregorianCalendar)localObject1).set(13, 0);
/* 738 */       ((GregorianCalendar)localObject1).set(14, 0);
/* 739 */       return new Date(((GregorianCalendar)localObject1).getTimeInMillis());
/*     */     case 2:
/* 748 */       if (i % 1000000 >= 500000) {
/* 749 */         ((GregorianCalendar)localObject1).add(14, 1);
/*     */       }
/*     */ 
/* 755 */       ((GregorianCalendar)localObject1).set(1970, 0, 1);
/*     */ 
/* 757 */       return new Time(((GregorianCalendar)localObject1).getTimeInMillis());
/*     */     case 3:
/* 762 */       localObject2 = new Timestamp(((GregorianCalendar)localObject1).getTimeInMillis());
/* 763 */       ((Timestamp)localObject2).setNanos(i);
/* 764 */       return localObject2;
/*     */     case 4:
/* 771 */       assert (SSType.DATETIMEOFFSET == paramSSType);
/*     */ 
/* 778 */       k = paramCalendar.get(15);
/* 779 */       assert (0 == k % 60000);
/*     */ 
/* 781 */       Timestamp localTimestamp = new Timestamp(((GregorianCalendar)localObject1).getTimeInMillis());
/* 782 */       localTimestamp.setNanos(i);
/* 783 */       return DateTimeOffset.valueOf(localTimestamp, k / 60000);
/*     */     case 5:
/* 788 */       switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSType[paramSSType.ordinal()])
/*     */       {
/*     */       case 2:
/* 792 */         return String.format(Locale.US, "%1$tF", new Object[] { localObject1 });
/*     */       case 1:
/* 800 */         return String.format(Locale.US, "%1$tT%2$s", new Object[] { localObject1, fractionalSecondsString(i, paramInt2) });
/*     */       case 3:
/* 811 */         return String.format(Locale.US, "%1$tF %1$tT%2$s", new Object[] { localObject1, fractionalSecondsString(i, paramInt2) });
/*     */       case 4:
/* 824 */         k = paramCalendar.get(15);
/* 825 */         assert (0 == k % 60000);
/*     */ 
/* 827 */         int n = Math.abs(k / 60000);
/* 828 */         return String.format(Locale.US, "%1$tF %1$tT%2$s %3$c%4$02d:%5$02d", new Object[] { localObject1, fractionalSecondsString(i, paramInt2), Character.valueOf(k >= 0 ? 43 : '-'), Integer.valueOf(n / 60), Integer.valueOf(n % 60) });
/*     */       case 5:
/* 842 */         return new Timestamp(((GregorianCalendar)localObject1).getTimeInMillis()).toString();
/*     */       }
/*     */ 
/* 846 */       throw new AssertionError(new StringBuilder().append("Unexpected SSType: ").append(paramSSType).toString());
/*     */     }
/*     */ 
/* 851 */     throw new AssertionError(new StringBuilder().append("Unexpected JDBCType: ").append(paramJDBCType).toString());
/*     */   }
/*     */ 
/*     */   static int daysSinceBaseDate(int paramInt1, int paramInt2, int paramInt3)
/*     */   {
/* 865 */     assert (paramInt1 >= 1);
/* 866 */     assert (paramInt3 >= 1);
/* 867 */     assert (paramInt2 >= 1);
/*     */ 
/* 869 */     return paramInt2 - 1 + (paramInt1 - paramInt3) * 365 + leapDaysBeforeYear(paramInt1) - leapDaysBeforeYear(paramInt3);
/*     */   }
/*     */ 
/*     */   private static int leapDaysBeforeYear(int paramInt)
/*     */   {
/* 882 */     assert (paramInt >= 1);
/*     */ 
/* 893 */     return (paramInt - 1) / 4 - (paramInt - 1) / 100 + (paramInt - 1) / 400;
/*     */   }
/*     */ 
/*     */   static final boolean exceedsMaxRPCDecimalPrecisionOrScale(BigDecimal paramBigDecimal)
/*     */   {
/* 904 */     if (null == paramBigDecimal) return false;
/*     */ 
/* 907 */     if (paramBigDecimal.scale() > 38) return true;
/*     */ 
/* 911 */     BigInteger localBigInteger = paramBigDecimal.scale() < 0 ? paramBigDecimal.setScale(0).unscaledValue() : paramBigDecimal.unscaledValue();
/*     */ 
/* 913 */     if (paramBigDecimal.signum() < 0) localBigInteger = localBigInteger.negate();
/* 914 */     return localBigInteger.compareTo(maxRPCDecimalValue) > 0;
/*     */   }
/*     */ 
/*     */   static String convertReaderToString(Reader paramReader, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 920 */     assert ((-1 == paramInt) || (paramInt >= 0));
/*     */ 
/* 923 */     if (null == paramReader) return null;
/* 924 */     if (0 == paramInt) return "";
/*     */ 
/*     */     try
/*     */     {
/* 931 */       StringBuilder localStringBuilder = new StringBuilder(-1 != paramInt ? paramInt : 4000);
/*     */ 
/* 936 */       localObject = new char[(-1 != paramInt) && (paramInt < 4000) ? paramInt : 4000];
/*     */       int i;
/* 941 */       while ((i = paramReader.read(localObject, 0, localObject.length)) > 0)
/*     */       {
/* 944 */         if (i > localObject.length)
/*     */         {
/* 946 */           MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 947 */           Object[] arrayOfObject2 = { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
/* 948 */           SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject2), "", true);
/*     */         }
/*     */ 
/* 951 */         localStringBuilder.append(localObject, 0, i);
/*     */       }
/*     */ 
/* 954 */       return localStringBuilder.toString();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 958 */       Object localObject = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 959 */       Object[] arrayOfObject1 = { localIOException.toString() };
/* 960 */       SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject).format(arrayOfObject1), "", true);
/*     */     }
/*     */ 
/* 964 */     return (String)null;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 898 */     maxRPCDecimalValue = new BigInteger("99999999999999999999999999999999999999");
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.DDC
 * JD-Core Version:    0.6.0
 */