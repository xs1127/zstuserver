/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ final class SQLServerBlobOutputStream extends OutputStream
/*     */ {
/* 452 */   private SQLServerBlob parentBlob = null;
/*     */   private long currentPos;
/*     */ 
/*     */   SQLServerBlobOutputStream(SQLServerBlob paramSQLServerBlob, long paramLong)
/*     */   {
/* 456 */     this.parentBlob = paramSQLServerBlob;
/* 457 */     this.currentPos = paramLong;
/*     */   }
/*     */ 
/*     */   public void write(byte[] paramArrayOfByte)
/*     */     throws IOException
/*     */   {
/* 464 */     if (null == paramArrayOfByte) return;
/* 465 */     write(paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */   }
/*     */ 
/*     */   public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 474 */       int i = this.parentBlob.setBytes(this.currentPos, paramArrayOfByte, paramInt1, paramInt2);
/* 475 */       this.currentPos += i;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 479 */       throw new IOException(localSQLException.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void write(int paramInt) throws IOException {
/* 484 */     byte[] arrayOfByte = new byte[1];
/* 485 */     arrayOfByte[0] = (byte)(paramInt & 0xFF);
/* 486 */     write(arrayOfByte, 0, arrayOfByte.length);
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerBlobOutputStream
 * JD-Core Version:    0.6.0
 */