/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.StringReader;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ final class SQLServerEntityResolver
/*     */   implements EntityResolver
/*     */ {
/*     */   public InputSource resolveEntity(String paramString1, String paramString2)
/*     */   {
/* 563 */     return new InputSource(new StringReader(""));
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerEntityResolver
 * JD-Core Version:    0.6.0
 */