/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ final class SimpleInputStream extends BaseInputStream
/*     */ {
/*     */   private final int payloadLength;
/*     */   private byte[] bSingleByte;
/*     */ 
/*     */   SimpleInputStream(TDSReader paramTDSReader, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, ServerDTVImpl paramServerDTVImpl)
/*     */     throws SQLServerException
/*     */   {
/* 141 */     super(paramTDSReader, paramInputStreamGetterArgs.isAdaptive, paramInputStreamGetterArgs.isStreaming, paramServerDTVImpl);
/* 142 */     setLoggingInfo(paramInputStreamGetterArgs.logContext);
/* 143 */     this.payloadLength = paramInt;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 152 */     if (null == this.tdsReader)
/* 153 */       return;
/* 154 */     if (logger.isLoggable(Level.FINER)) {
/* 155 */       logger.finer(toString() + "Enter Closing SimpleInputStream.");
/*     */     }
/*     */ 
/* 160 */     skip(this.payloadLength - this.streamPos);
/*     */ 
/* 162 */     closeHelper();
/* 163 */     if (logger.isLoggable(Level.FINER))
/* 164 */       logger.finer(toString() + "Exit Closing SimpleInputStream.");
/*     */   }
/*     */ 
/*     */   private final boolean isEOS()
/*     */     throws IOException
/*     */   {
/* 172 */     assert (this.streamPos <= this.payloadLength);
/* 173 */     return this.streamPos == this.payloadLength;
/*     */   }
/*     */ 
/*     */   public long skip(long paramLong)
/*     */     throws IOException
/*     */   {
/* 186 */     checkClosed();
/* 187 */     if (logger.isLoggable(Level.FINER))
/* 188 */       logger.finer(toString() + " Skipping :" + paramLong);
/* 189 */     if (paramLong < 0L) return 0L;
/* 190 */     if (isEOS()) return 0L;
/*     */     int i;
/* 193 */     if (this.streamPos + paramLong > this.payloadLength)
/*     */     {
/* 195 */       i = this.payloadLength - this.streamPos;
/*     */     }
/*     */     else
/*     */     {
/* 199 */       i = (int)paramLong;
/*     */     }
/*     */     try
/*     */     {
/* 203 */       this.tdsReader.skip(i);
/*     */     }
/*     */     catch (SQLServerException localSQLServerException)
/*     */     {
/* 207 */       throw new IOException(localSQLServerException.getMessage());
/*     */     }
/* 209 */     this.streamPos += i;
/* 210 */     if ((this.isReadLimitSet) && (this.streamPos - this.markedStreamPos > this.readLimit)) {
/* 211 */       clearCurrentMark();
/*     */     }
/* 213 */     return i;
/*     */   }
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 225 */     checkClosed();
/* 226 */     assert (this.streamPos <= this.payloadLength);
/*     */ 
/* 228 */     int i = this.payloadLength - this.streamPos;
/* 229 */     if (this.tdsReader.available() < i)
/* 230 */       i = this.tdsReader.available();
/* 231 */     return i;
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 242 */     checkClosed();
/* 243 */     if (null == this.bSingleByte)
/* 244 */       this.bSingleByte = new byte[1];
/* 245 */     if (isEOS()) return -1;
/* 246 */     int i = read(this.bSingleByte, 0, 1);
/* 247 */     return 0 == i ? -1 : this.bSingleByte[0] & 0xFF;
/*     */   }
/*     */ 
/*     */   public int read(byte[] paramArrayOfByte)
/*     */     throws IOException
/*     */   {
/* 258 */     checkClosed();
/* 259 */     return read(paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */   }
/*     */ 
/*     */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException
/*     */   {
/* 272 */     checkClosed();
/* 273 */     if (logger.isLoggable(Level.FINER)) {
/* 274 */       logger.finer(toString() + " Reading " + paramInt2 + " from stream offset " + this.streamPos + " payload length " + this.payloadLength);
/*     */     }
/* 276 */     if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 + paramInt2 > paramArrayOfByte.length)) {
/* 277 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 279 */     if (0 == paramInt2) return 0;
/* 280 */     if (isEOS()) return -1;
/*     */ 
/* 282 */     int i = 0;
/* 283 */     if (this.streamPos + paramInt2 > this.payloadLength)
/*     */     {
/* 285 */       i = this.payloadLength - this.streamPos;
/*     */     }
/*     */     else
/*     */     {
/* 289 */       i = paramInt2;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 294 */       this.tdsReader.readBytes(paramArrayOfByte, paramInt1, i);
/*     */     }
/*     */     catch (SQLServerException localSQLServerException)
/*     */     {
/* 298 */       throw new IOException(localSQLServerException.getMessage());
/*     */     }
/* 300 */     this.streamPos += i;
/*     */ 
/* 302 */     if ((this.isReadLimitSet) && (this.streamPos - this.markedStreamPos > this.readLimit)) {
/* 303 */       clearCurrentMark();
/*     */     }
/* 305 */     return i;
/*     */   }
/*     */ 
/*     */   public void mark(int paramInt)
/*     */   {
/* 314 */     if ((null != this.tdsReader) && (paramInt > 0))
/*     */     {
/* 316 */       this.currentMark = this.tdsReader.mark();
/* 317 */       this.markedStreamPos = this.streamPos;
/* 318 */       setReadLimit(paramInt);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 328 */     resetHelper();
/* 329 */     this.streamPos = this.markedStreamPos;
/*     */   }
/*     */ 
/*     */   final byte[] getBytes()
/*     */     throws SQLServerException
/*     */   {
/* 340 */     assert (0 == this.streamPos);
/*     */ 
/* 342 */     byte[] arrayOfByte = new byte[this.payloadLength];
/*     */     try
/*     */     {
/* 345 */       read(arrayOfByte);
/* 346 */       close();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 350 */       SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*     */     }
/*     */ 
/* 359 */     return arrayOfByte;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SimpleInputStream
 * JD-Core Version:    0.6.0
 */