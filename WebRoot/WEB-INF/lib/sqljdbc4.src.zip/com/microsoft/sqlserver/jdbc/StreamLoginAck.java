/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class StreamLoginAck extends StreamPacket
/*    */ {
/*    */   String sSQLServerVersion;
/*    */   int tdsVersion;
/*    */ 
/*    */   StreamLoginAck()
/*    */   {
/* 18 */     super(173);
/*    */   }
/*    */ 
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 23 */     if ((173 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/* 24 */     int i = paramTDSReader.readUnsignedShort();
/* 25 */     int j = paramTDSReader.readUnsignedByte();
/* 26 */     this.tdsVersion = paramTDSReader.readIntBigEndian();
/* 27 */     String str = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 28 */     int k = paramTDSReader.readUnsignedByte();
/* 29 */     int m = paramTDSReader.readUnsignedByte();
/* 30 */     int n = paramTDSReader.readUnsignedByte() << 8 | paramTDSReader.readUnsignedByte();
/*    */ 
/* 32 */     this.sSQLServerVersion = new StringBuilder().append(k).append(".").append(m <= 9 ? "0" : "").append(m).append(".").append(n).toString();
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamLoginAck
 * JD-Core Version:    0.6.0
 */