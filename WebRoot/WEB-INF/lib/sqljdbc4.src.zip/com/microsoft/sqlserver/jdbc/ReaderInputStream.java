/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.IllegalCharsetNameException;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ class ReaderInputStream extends InputStream
/*     */ {
/*     */   private final Reader reader;
/*     */   private final Charset charset;
/*     */   private final long readerLength;
/*  35 */   private long readerCharsRead = 0L;
/*     */ 
/*  38 */   private boolean atEndOfStream = false;
/*     */ 
/*  42 */   private CharBuffer rawChars = null;
/*     */   private static final int MAX_CHAR_BUFFER_SIZE = 4000;
/*     */   private static final ByteBuffer EMPTY_BUFFER;
/*  48 */   private ByteBuffer encodedChars = EMPTY_BUFFER;
/*     */ 
/* 104 */   private final byte[] oneByte = new byte[1];
/*     */ 
/*     */   ReaderInputStream(Reader paramReader, String paramString, long paramLong)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  52 */     assert (paramReader != null);
/*  53 */     assert (paramString != null);
/*  54 */     assert ((-1L == paramLong) || (paramLong >= 0L));
/*     */ 
/*  56 */     this.reader = paramReader;
/*     */     try
/*     */     {
/*  59 */       this.charset = Charset.forName(paramString);
/*     */     }
/*     */     catch (IllegalCharsetNameException localIllegalCharsetNameException)
/*     */     {
/*  63 */       throw new UnsupportedEncodingException(localIllegalCharsetNameException.getMessage());
/*     */     }
/*     */     catch (UnsupportedCharsetException localUnsupportedCharsetException)
/*     */     {
/*  67 */       throw new UnsupportedEncodingException(localUnsupportedCharsetException.getMessage());
/*     */     }
/*     */ 
/*  70 */     this.readerLength = paramLong;
/*     */   }
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/*  82 */     assert (null != this.reader);
/*  83 */     assert (null != this.encodedChars);
/*     */ 
/*  86 */     if (0L == this.readerLength) {
/*  87 */       return 0;
/*     */     }
/*     */ 
/*  90 */     if (this.encodedChars.remaining() > 0) {
/*  91 */       return this.encodedChars.remaining();
/*     */     }
/*     */ 
/*  96 */     if (this.reader.ready()) {
/*  97 */       return 1;
/*     */     }
/*     */ 
/* 101 */     return 0;
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 107 */     return -1 == readInternal(this.oneByte, 0, this.oneByte.length) ? -1 : this.oneByte[0];
/*     */   }
/*     */ 
/*     */   public int read(byte[] paramArrayOfByte) throws IOException
/*     */   {
/* 112 */     return readInternal(paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */   }
/*     */ 
/*     */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*     */   {
/* 117 */     return readInternal(paramArrayOfByte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   private int readInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*     */   {
/* 122 */     assert (null != paramArrayOfByte);
/* 123 */     assert ((0 <= paramInt1) && (paramInt1 <= paramArrayOfByte.length));
/* 124 */     assert ((0 <= paramInt2) && (paramInt2 <= paramArrayOfByte.length));
/* 125 */     assert (paramInt1 <= paramArrayOfByte.length - paramInt2);
/*     */ 
/* 127 */     if (0 == paramInt2) {
/* 128 */       return 0;
/*     */     }
/* 130 */     int i = 0;
/* 131 */     while ((i < paramInt2) && (encodeChars()))
/*     */     {
/* 136 */       int j = this.encodedChars.remaining();
/* 137 */       if (j > paramInt2 - i) {
/* 138 */         j = paramInt2 - i;
/*     */       }
/*     */ 
/* 142 */       assert (j > 0);
/*     */ 
/* 144 */       this.encodedChars.get(paramArrayOfByte, paramInt1 + i, j);
/* 145 */       i += j;
/*     */     }
/*     */ 
/* 150 */     return (0 == i) && (this.atEndOfStream) ? -1 : i;
/*     */   }
/*     */ 
/*     */   private boolean encodeChars()
/*     */     throws IOException
/*     */   {
/* 164 */     if (this.atEndOfStream) {
/* 165 */       return false;
/*     */     }
/*     */ 
/* 170 */     if (this.encodedChars.hasRemaining()) {
/* 171 */       return true;
/*     */     }
/*     */ 
/* 181 */     if ((null == this.rawChars) || (!this.rawChars.hasRemaining()))
/*     */     {
/* 183 */       if (null == this.rawChars)
/*     */       {
/* 186 */         this.rawChars = CharBuffer.allocate((-1L == this.readerLength) || (this.readerLength > 4000L) ? 4000 : Math.max((int)this.readerLength, 1));
/*     */       }
/*     */       else
/*     */       {
/* 193 */         this.rawChars.clear();
/*     */       }
/*     */ 
/* 204 */       while (this.rawChars.hasRemaining())
/*     */       {
/* 206 */         int i = this.rawChars.position();
/* 207 */         int j = 0;
/*     */         try
/*     */         {
/* 212 */           j = this.reader.read(this.rawChars);
/*     */         }
/*     */         catch (Exception localException)
/*     */         {
/* 219 */           String str = localException.getMessage();
/* 220 */           if (null == str)
/* 221 */             str = SQLServerException.getErrString("R_streamReadReturnedInvalidValue");
/* 222 */           IOException localIOException = new IOException(str);
/* 223 */           localIOException.initCause(localException);
/* 224 */           throw localIOException;
/*     */         }
/*     */ 
/* 227 */         if ((j < -1) || (0 == j))
/* 228 */           throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
/*     */         MessageFormat localMessageFormat;
/* 230 */         if (-1 == j)
/*     */         {
/* 233 */           if (this.rawChars.position() != i) {
/* 234 */             throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
/*     */           }
/*     */ 
/* 237 */           if ((-1L != this.readerLength) && (0L != this.readerLength - this.readerCharsRead))
/*     */           {
/* 239 */             localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 240 */             throw new IOException(localMessageFormat.format(new Object[] { Long.valueOf(this.readerLength), Long.valueOf(this.readerCharsRead) }));
/*     */           }
/*     */ 
/* 244 */           if (0 != this.rawChars.position())
/*     */             break;
/* 246 */           this.rawChars = null;
/* 247 */           this.atEndOfStream = true;
/* 248 */           return false;
/*     */         }
/*     */ 
/* 255 */         assert (j > 0);
/*     */ 
/* 258 */         if (j != this.rawChars.position() - i) {
/* 259 */           throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
/*     */         }
/*     */ 
/* 262 */         if ((-1L != this.readerLength) && (j > this.readerLength - this.readerCharsRead))
/*     */         {
/* 264 */           localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 265 */           throw new IOException(localMessageFormat.format(new Object[] { Long.valueOf(this.readerLength), Long.valueOf(this.readerCharsRead) }));
/*     */         }
/*     */ 
/* 268 */         this.readerCharsRead += j;
/*     */       }
/*     */ 
/* 273 */       this.rawChars.flip();
/*     */     }
/*     */ 
/* 279 */     if (!this.rawChars.hasRemaining()) {
/* 280 */       return false;
/*     */     }
/*     */ 
/* 283 */     this.encodedChars = this.charset.encode(this.rawChars);
/* 284 */     return true;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  47 */     EMPTY_BUFFER = ByteBuffer.allocate(0);
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ReaderInputStream
 * JD-Core Version:    0.6.0
 */