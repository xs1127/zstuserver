/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.sql.NClob;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public final class SQLServerNClob extends SQLServerClobBase
/*    */   implements NClob
/*    */ {
/* 15 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerNClob");
/*    */ 
/*    */   SQLServerNClob(SQLServerConnection paramSQLServerConnection)
/*    */   {
/* 19 */     super(paramSQLServerConnection, "", paramSQLServerConnection.getDatabaseCollation(), logger);
/*    */   }
/*    */ 
/*    */   SQLServerNClob(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo) throws SQLServerException, UnsupportedEncodingException
/*    */   {
/* 24 */     super(null, new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getSQLCollation(), logger);
/*    */   }
/*    */   final JDBCType getJdbcType() {
/* 27 */     return JDBCType.NCLOB;
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerNClob
 * JD-Core Version:    0.6.0
 */