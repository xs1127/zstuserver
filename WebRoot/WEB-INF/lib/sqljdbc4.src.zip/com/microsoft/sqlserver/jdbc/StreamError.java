/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class StreamError extends StreamPacket
/*    */ {
/* 18 */   String errorMessage = "";
/*    */   int errorNumber;
/*    */   int errorState;
/*    */   int errorSeverity;
/*    */   String serverName;
/*    */   String procName;
/*    */   long lineNumber;
/*    */ 
/*    */   final String getMessage()
/*    */   {
/* 31 */     return this.errorMessage;
/*    */   }
/*    */   final int getErrorNumber() {
/* 34 */     return this.errorNumber;
/*    */   }
/*    */   final int getErrorState() {
/* 37 */     return this.errorState;
/*    */   }
/*    */   final int getErrorSeverity() {
/* 40 */     return this.errorSeverity;
/*    */   }
/*    */ 
/*    */   StreamError()
/*    */   {
/* 45 */     super(170);
/*    */   }
/*    */ 
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 50 */     if ((170 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/* 51 */     setContentsFromTDS(paramTDSReader);
/*    */   }
/*    */ 
/*    */   void setContentsFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 56 */     paramTDSReader.readUnsignedShort();
/* 57 */     this.errorNumber = paramTDSReader.readInt();
/* 58 */     this.errorState = paramTDSReader.readUnsignedByte();
/* 59 */     this.errorSeverity = paramTDSReader.readUnsignedByte();
/* 60 */     this.errorMessage = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
/* 61 */     this.serverName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 62 */     this.procName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 63 */     this.lineNumber = paramTDSReader.readUnsignedInt();
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamError
 * JD-Core Version:    0.6.0
 */