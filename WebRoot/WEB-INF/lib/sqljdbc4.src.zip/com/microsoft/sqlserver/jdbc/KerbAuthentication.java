/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.login.AppConfigurationEntry;
/*     */ import javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.ietf.jgss.GSSContext;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSManager;
/*     */ import org.ietf.jgss.GSSName;
/*     */ import org.ietf.jgss.Oid;
/*     */ 
/*     */ final class KerbAuthentication extends SSPIAuthentication
/*     */ {
/*     */   private static final String CONFIGNAME = "SQLJDBCDriver";
/*  19 */   private static final Logger authLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.KerbAuthentication");
/*     */   private final SQLServerConnection con;
/*     */   private final String spn;
/*  25 */   private final GSSManager manager = GSSManager.getInstance();
/*  26 */   private LoginContext lc = null;
/*  27 */   private GSSCredential peerCredentials = null;
/*  28 */   private GSSContext peerContext = null;
/*     */ 
/*     */   private void intAuthInit()
/*     */     throws SQLServerException
/*     */   {
/*     */     try
/*     */     {
/* 124 */       Oid localOid = new Oid("1.2.840.113554.1.2.2");
/* 125 */       Subject localSubject = null;
/*     */       try
/*     */       {
/* 128 */         AccessControlContext localAccessControlContext = AccessController.getContext();
/* 129 */         localSubject = Subject.getSubject(localAccessControlContext);
/* 130 */         if (null == localSubject)
/*     */         {
/* 132 */           this.lc = new LoginContext("SQLJDBCDriver");
/* 133 */           this.lc.login();
/*     */ 
/* 135 */           localSubject = this.lc.getSubject();
/*     */         }
/*     */       }
/*     */       catch (LoginException localLoginException)
/*     */       {
/* 140 */         this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), localLoginException);
/*     */       }
/*     */ 
/* 145 */       GSSName localGSSName = this.manager.createName(this.spn, null);
/* 146 */       if (authLogger.isLoggable(Level.FINER))
/*     */       {
/* 148 */         authLogger.finer(new StringBuilder().append(toString()).append(" Getting client credentials").toString());
/*     */       }
/* 150 */       this.peerCredentials = getClientCredential(localSubject, this.manager, localOid);
/* 151 */       if (authLogger.isLoggable(Level.FINER))
/*     */       {
/* 153 */         authLogger.finer(new StringBuilder().append(toString()).append(" creating security context").toString());
/*     */       }
/*     */ 
/* 156 */       this.peerContext = this.manager.createContext(localGSSName, localOid, this.peerCredentials, 0);
/*     */ 
/* 161 */       this.peerContext.requestCredDeleg(true);
/* 162 */       this.peerContext.requestMutualAuth(true);
/* 163 */       this.peerContext.requestInteg(true);
/*     */     }
/*     */     catch (GSSException localGSSException)
/*     */     {
/* 168 */       authLogger.finer(new StringBuilder().append(toString()).append("initAuthInit failed GSSException:-").append(localGSSException).toString());
/*     */ 
/* 170 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), localGSSException);
/*     */     }
/*     */     catch (PrivilegedActionException localPrivilegedActionException)
/*     */     {
/* 174 */       authLogger.finer(new StringBuilder().append(toString()).append("initAuthInit failed privileged exception:-").append(localPrivilegedActionException).toString());
/*     */ 
/* 176 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), localPrivilegedActionException);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static GSSCredential getClientCredential(Subject paramSubject, GSSManager paramGSSManager, Oid paramOid)
/*     */     throws PrivilegedActionException
/*     */   {
/* 186 */     1 local1 = new PrivilegedExceptionAction(paramGSSManager, paramOid)
/*     */     {
/*     */       public GSSCredential run() throws GSSException {
/* 189 */         return this.val$MANAGER.createCredential(null, 0, this.val$kerboid, 1);
/*     */       }
/*     */     };
/* 199 */     Object localObject = Subject.doAs(paramSubject, local1);
/* 200 */     return (GSSCredential)localObject;
/*     */   }
/*     */ 
/*     */   private byte[] intAuthHandShake(byte[] paramArrayOfByte, boolean[] paramArrayOfBoolean) throws SQLServerException
/*     */   {
/*     */     try {
/* 206 */       if (authLogger.isLoggable(Level.FINER))
/*     */       {
/* 208 */         authLogger.finer(new StringBuilder().append(toString()).append(" Sending token to server over secure context").toString());
/*     */       }
/* 210 */       byte[] arrayOfByte = this.peerContext.initSecContext(paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */ 
/* 212 */       if (this.peerContext.isEstablished())
/*     */       {
/* 214 */         paramArrayOfBoolean[0] = true;
/* 215 */         if (authLogger.isLoggable(Level.FINER)) {
/* 216 */           authLogger.finer(new StringBuilder().append(toString()).append("Authentication done.").toString());
/*     */         }
/*     */       }
/* 219 */       else if (null == arrayOfByte)
/*     */       {
/* 222 */         authLogger.info(new StringBuilder().append(toString()).append("byteToken is null in initSecContext.").toString());
/* 223 */         this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"));
/*     */       }
/* 225 */       return arrayOfByte;
/*     */     }
/*     */     catch (GSSException localGSSException)
/*     */     {
/* 229 */       authLogger.finer(new StringBuilder().append(toString()).append("initSecContext Failed :-").append(localGSSException).toString());
/*     */ 
/* 231 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), localGSSException);
/*     */     }
/*     */ 
/* 234 */     return null;
/*     */   }
/*     */ 
/*     */   private String makeSpn(String paramString, int paramInt) throws SQLServerException
/*     */   {
/* 239 */     if (authLogger.isLoggable(Level.FINER))
/*     */     {
/* 241 */       authLogger.finer(new StringBuilder().append(toString()).append(" Server: ").append(paramString).append(" port: ").append(paramInt).toString());
/*     */     }
/* 243 */     StringBuilder localStringBuilder = new StringBuilder("MSSQLSvc/");
/*     */ 
/* 246 */     localStringBuilder.append(paramString);
/* 247 */     localStringBuilder.append(":");
/* 248 */     localStringBuilder.append(paramInt);
/* 249 */     String str = localStringBuilder.toString();
/* 250 */     if (authLogger.isLoggable(Level.FINER))
/*     */     {
/* 252 */       authLogger.finer(new StringBuilder().append(toString()).append(" SPN: ").append(str).toString());
/*     */     }
/* 254 */     return str;
/*     */   }
/*     */ 
/*     */   KerbAuthentication(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 260 */     this.con = paramSQLServerConnection;
/* 261 */     this.spn = makeSpn(paramString, paramInt);
/*     */   }
/*     */ 
/*     */   byte[] GenerateClientContext(byte[] paramArrayOfByte, boolean[] paramArrayOfBoolean) throws SQLServerException
/*     */   {
/* 266 */     if (null == this.peerContext)
/*     */     {
/* 268 */       intAuthInit();
/*     */     }
/* 270 */     return intAuthHandShake(paramArrayOfByte, paramArrayOfBoolean);
/*     */   }
/*     */ 
/*     */   int ReleaseClientContext() throws SQLServerException
/*     */   {
/*     */     try {
/* 276 */       if (null != this.peerCredentials)
/* 277 */         this.peerCredentials.dispose();
/* 278 */       if (null != this.peerContext)
/* 279 */         this.peerContext.dispose();
/* 280 */       if (null != this.lc) {
/* 281 */         this.lc.logout();
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (LoginException localLoginException)
/*     */     {
/* 287 */       authLogger.fine(new StringBuilder().append(toString()).append(" Release of the credentials failed LoginException: ").append(localLoginException).toString());
/*     */     }
/*     */     catch (GSSException localGSSException)
/*     */     {
/* 293 */       authLogger.fine(new StringBuilder().append(toString()).append(" Release of the credentials failed GSSException: ").append(localGSSException).toString());
/*     */     }
/* 295 */     return 0;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 115 */     1SQLJDBCDriverConfig local1SQLJDBCDriverConfig = new Configuration()
/*     */     {
/*  40 */       Configuration current = null;
/*     */       AppConfigurationEntry[] driverConf;
/*     */ 
/*     */       public AppConfigurationEntry[] getAppConfigurationEntry(String paramString)
/*     */       {
/*  96 */         if (paramString.equals("SQLJDBCDriver"))
/*     */         {
/*  98 */           return this.driverConf;
/*     */         }
/*     */ 
/* 102 */         if (null != this.current) {
/* 103 */           return this.current.getAppConfigurationEntry(paramString);
/*     */         }
/* 105 */         return null;
/*     */       }
/*     */ 
/*     */       public void refresh()
/*     */       {
/* 111 */         if (null != this.current)
/* 112 */           this.current.refresh();
/*     */       }
/*     */     };
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.KerbAuthentication
 * JD-Core Version:    0.6.0
 */