/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ final class FailoverInfo
/*     */ {
/*     */   private String failoverPartner;
/*     */   private int portNumber;
/*     */   private String failoverInstance;
/*     */   private boolean setUpInfocalled;
/*     */   private boolean useFailoverPartner;
/*     */ 
/*     */   boolean getUseFailoverPartner()
/*     */   {
/*  23 */     return this.useFailoverPartner;
/*     */   }
/*     */ 
/*     */   FailoverInfo(String paramString, SQLServerConnection paramSQLServerConnection, boolean paramBoolean)
/*     */   {
/*  28 */     this.failoverPartner = paramString;
/*  29 */     this.useFailoverPartner = paramBoolean;
/*  30 */     this.portNumber = -1;
/*     */   }
/*     */ 
/*     */   void log(SQLServerConnection paramSQLServerConnection)
/*     */   {
/*  36 */     if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE))
/*  37 */       paramSQLServerConnection.getConnectionLogger().fine(paramSQLServerConnection.toString() + " Failover server :" + this.failoverPartner + " Failover partner is primary : " + this.useFailoverPartner);
/*     */   }
/*     */ 
/*     */   private void setupInfo(SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/*  45 */     if (this.setUpInfocalled) {
/*  46 */       return;
/*     */     }
/*  48 */     if (0 == this.failoverPartner.length())
/*     */     {
/*  50 */       this.portNumber = SQLServerConnection.DEFAULTPORT;
/*     */     }
/*     */     else
/*     */     {
/*  55 */       int i = this.failoverPartner.indexOf('\\');
/*  56 */       String str1 = null;
/*  57 */       String str2 = null;
/*     */ 
/*  60 */       if (i >= 0)
/*     */       {
/*  62 */         if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE))
/*  63 */           paramSQLServerConnection.getConnectionLogger().fine(paramSQLServerConnection.toString() + " Failover server :" + this.failoverPartner);
/*  64 */         str2 = this.failoverPartner.substring(i + 1, this.failoverPartner.length());
/*  65 */         this.failoverPartner = this.failoverPartner.substring(0, i);
/*  66 */         paramSQLServerConnection.ValidateMaxSQLLoginName(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str2);
/*  67 */         this.failoverInstance = str2;
/*  68 */         str1 = paramSQLServerConnection.getInstancePort(this.failoverPartner, str2);
/*     */         try
/*     */         {
/*  72 */           this.portNumber = new Integer(str1).intValue();
/*     */         }
/*     */         catch (NumberFormatException localNumberFormatException)
/*     */         {
/*  77 */           MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/*  78 */           Object[] arrayOfObject = { str1 };
/*  79 */           SQLServerException.makeFromDriverError(paramSQLServerConnection, null, localMessageFormat.format(arrayOfObject), null, false);
/*     */         }
/*     */       }
/*     */       else {
/*  83 */         this.portNumber = SQLServerConnection.DEFAULTPORT;
/*     */       }
/*     */     }
/*  85 */     this.setUpInfocalled = true;
/*     */   }
/*     */ 
/*     */   synchronized ServerPortPlaceHolder failoverPermissionCheck(SQLServerConnection paramSQLServerConnection, boolean paramBoolean) throws SQLServerException
/*     */   {
/*  90 */     setupInfo(paramSQLServerConnection);
/*  91 */     return new ServerPortPlaceHolder(this.failoverPartner, this.portNumber, this.failoverInstance, paramBoolean);
/*     */   }
/*     */ 
/*     */   synchronized void failoverAdd(SQLServerConnection paramSQLServerConnection, boolean paramBoolean, String paramString)
/*     */     throws SQLServerException
/*     */   {
/*  97 */     if (this.useFailoverPartner != paramBoolean)
/*     */     {
/*  99 */       if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE))
/* 100 */         paramSQLServerConnection.getConnectionLogger().fine(paramSQLServerConnection.toString() + " Failover detected. failover partner=" + paramString);
/* 101 */       this.useFailoverPartner = paramBoolean;
/*     */     }
/*     */ 
/* 107 */     if ((!paramBoolean) && (!this.failoverPartner.equals(paramString)))
/*     */     {
/* 109 */       this.failoverPartner = paramString;
/*     */ 
/* 111 */       this.setUpInfocalled = false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.FailoverInfo
 * JD-Core Version:    0.6.0
 */