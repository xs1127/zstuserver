/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ class ZeroFixupFilter extends IntColumnFilter
/*      */ {
/*      */   int oneValueToAnother(int paramInt)
/*      */   {
/* 2332 */     if (0 == paramInt) {
/* 2333 */       return 2147483647;
/*      */     }
/* 2335 */     return paramInt;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ZeroFixupFilter
 * JD-Core Version:    0.6.0
 */