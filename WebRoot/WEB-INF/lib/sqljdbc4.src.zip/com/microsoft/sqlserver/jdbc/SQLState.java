/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */  enum SQLState
/*    */ {
/* 19 */   STATEMENT_CANCELED("HY008"), 
/* 20 */   DATA_EXCEPTION_NOT_SPECIFIC("22000"), 
/* 21 */   DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW("22008"), 
/* 22 */   DATA_EXCEPTION_LENGTH_MISMATCH("22026");
/*    */ 
/*    */   private final String sqlStateCode;
/*    */ 
/* 25 */   final String getSQLStateCode() { return this.sqlStateCode; }
/*    */ 
/*    */   private SQLState(String paramString)
/*    */   {
/* 29 */     this.sqlStateCode = paramString;
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLState
 * JD-Core Version:    0.6.0
 */