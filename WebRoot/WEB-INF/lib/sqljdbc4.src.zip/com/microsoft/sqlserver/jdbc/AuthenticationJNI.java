/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ final class AuthenticationJNI extends SSPIAuthentication
/*     */ {
/*     */   private static final int maximumpointersize = 128;
/*     */   private static boolean enabled;
/*     */   private static Logger authLogger;
/*     */   private static int sspiBlobMaxlen;
/*  19 */   private byte[] sniSec = new byte[''];
/*  20 */   private int[] sniSecLen = { 0 };
/*     */   private final String DNSName;
/*     */   private final int port;
/*     */   private SQLServerConnection con;
/*     */   private static final UnsatisfiedLinkError linkError;
/*     */ 
/*     */   static int GetMaxSSPIBlobSize()
/*     */   {
/*  26 */     return sspiBlobMaxlen;
/*     */   }
/*     */ 
/*     */   AuthenticationJNI(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/*  59 */     if (!enabled) {
/*  60 */       paramSQLServerConnection.terminate(0, SQLServerException.getErrString("R_notConfiguredForIntegrated"), linkError);
/*     */     }
/*  62 */     this.con = paramSQLServerConnection;
/*  63 */     this.DNSName = GetDNSName(paramString);
/*  64 */     this.port = paramInt;
/*     */   }
/*     */ 
/*     */   byte[] GenerateClientContext(byte[] paramArrayOfByte, boolean[] paramArrayOfBoolean)
/*     */     throws SQLServerException
/*     */   {
/*  73 */     int[] arrayOfInt = new int[1];
/*  74 */     arrayOfInt[0] = GetMaxSSPIBlobSize();
/*  75 */     byte[] arrayOfByte1 = new byte[arrayOfInt[0]];
/*     */ 
/*  78 */     assert (this.DNSName != null);
/*     */ 
/*  80 */     int i = SNISecGenClientContext(this.sniSec, this.sniSecLen, paramArrayOfByte, paramArrayOfByte.length, arrayOfByte1, arrayOfInt, paramArrayOfBoolean, this.DNSName, this.port, null, null, authLogger);
/*     */ 
/*  82 */     if (i != 0)
/*     */     {
/*  84 */       authLogger.warning(toString() + " Authentication failed code : " + i);
/*  85 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), linkError);
/*     */     }
/*     */ 
/*  88 */     byte[] arrayOfByte2 = new byte[arrayOfInt[0]];
/*  89 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfInt[0]);
/*  90 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */   int ReleaseClientContext()
/*     */   {
/*  96 */     int i = 0;
/*  97 */     if (this.sniSecLen[0] > 0)
/*     */     {
/*  99 */       i = SNISecReleaseClientContext(this.sniSec, this.sniSecLen[0], authLogger);
/* 100 */       this.sniSecLen[0] = 0;
/*     */     }
/* 102 */     return i;
/*     */   }
/*     */ 
/*     */   private static String GetDNSName(String paramString)
/*     */   {
/* 108 */     String[] arrayOfString = new String[1];
/* 109 */     if (GetDNSName(paramString, arrayOfString, authLogger) != 0)
/*     */     {
/* 112 */       arrayOfString[0] = paramString;
/*     */     }
/* 114 */     return arrayOfString[0];
/*     */   }
/*     */ 
/*     */   private static native int SNISecGenClientContext(byte[] paramArrayOfByte1, int[] paramArrayOfInt1, byte[] paramArrayOfByte2, int paramInt1, byte[] paramArrayOfByte3, int[] paramArrayOfInt2, boolean[] paramArrayOfBoolean, String paramString1, int paramInt2, String paramString2, String paramString3, Logger paramLogger);
/*     */ 
/*     */   private static native int SNISecReleaseClientContext(byte[] paramArrayOfByte, int paramInt, Logger paramLogger);
/*     */ 
/*     */   private static native int SNISecInitPackage(int[] paramArrayOfInt, Logger paramLogger);
/*     */ 
/*     */   private static native int SNISecTerminatePackage(Logger paramLogger);
/*     */ 
/*     */   private static native int SNIGetSID(byte[] paramArrayOfByte, Logger paramLogger);
/*     */ 
/*     */   private static native boolean SNIIsEqualToCurrentSID(byte[] paramArrayOfByte, Logger paramLogger);
/*     */ 
/*     */   private static native int GetDNSName(String paramString, String[] paramArrayOfString, Logger paramLogger);
/*     */ 
/*     */   static
/*     */   {
/*  16 */     enabled = false;
/*  17 */     authLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.AuthenticationJNI");
/*  18 */     sspiBlobMaxlen = 0;
/*     */ 
/*  30 */     Object localObject1 = null;
/*     */     try
/*     */     {
/*  34 */       String str = "sqljdbc_auth";
/*  35 */       System.loadLibrary(str);
/*  36 */       int[] arrayOfInt = new int[1];
/*  37 */       arrayOfInt[0] = 0;
/*  38 */       if (0 == SNISecInitPackage(arrayOfInt, authLogger))
/*     */       {
/*  40 */         sspiBlobMaxlen = arrayOfInt[0];
/*     */       }
/*     */       else
/*  43 */         throw new UnsatisfiedLinkError();
/*  44 */       enabled = true;
/*     */     }
/*     */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError)
/*     */     {
/*  48 */       localObject1 = localUnsatisfiedLinkError;
/*  49 */       authLogger.warning("Failed to load the sqljdbc_auth.dll cause : " + localUnsatisfiedLinkError.getMessage());
/*     */     }
/*     */     finally
/*     */     {
/*  53 */       linkError = localObject1;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.AuthenticationJNI
 * JD-Core Version:    0.6.0
 */