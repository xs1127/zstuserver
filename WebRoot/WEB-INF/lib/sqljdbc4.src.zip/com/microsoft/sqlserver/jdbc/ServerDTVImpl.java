/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.Calendar;
/*      */ 
/*      */ final class ServerDTVImpl extends DTVImpl
/*      */ {
/*      */   private int valueLength;
/*      */   private TDSReaderMark valueMark;
/*      */   private boolean isNull;
/*      */   private static final int STREAMCONSUMED = -2;
/*      */ 
/*      */   void setValue(DTV paramDTV, SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection)
/*      */     throws SQLServerException
/*      */   {
/* 2252 */     paramDTV.setImpl(new AppDTVImpl());
/* 2253 */     paramDTV.setValue(paramSQLCollation, paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger, paramSQLServerConnection);
/*      */   }
/*      */ 
/*      */   void setValue(Object paramObject, JavaType paramJavaType)
/*      */   {
/* 2259 */     if (!$assertionsDisabled) throw new AssertionError();
/*      */   }
/*      */ 
/*      */   void setPositionAfterStreamed(TDSReader paramTDSReader)
/*      */   {
/* 2269 */     this.valueMark = paramTDSReader.mark();
/* 2270 */     this.valueLength = -2;
/*      */   }
/*      */ 
/*      */   void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs)
/*      */   {
/* 2276 */     if (!$assertionsDisabled) throw new AssertionError();
/*      */   }
/*      */ 
/*      */   void setCalendar(Calendar paramCalendar)
/*      */   {
/* 2282 */     if (!$assertionsDisabled) throw new AssertionError();
/*      */   }
/*      */ 
/*      */   void setScale(Integer paramInteger)
/*      */   {
/* 2288 */     if (!$assertionsDisabled) throw new AssertionError();
/*      */   }
/*      */ 
/*      */   StreamSetterArgs getStreamSetterArgs()
/*      */   {
/* 2294 */     if (!$assertionsDisabled) throw new AssertionError();
/* 2295 */     return null;
/*      */   }
/*      */ 
/*      */   Calendar getCalendar()
/*      */   {
/* 2301 */     if (!$assertionsDisabled) throw new AssertionError();
/* 2302 */     return null;
/*      */   }
/*      */ 
/*      */   Integer getScale()
/*      */   {
/* 2308 */     if (!$assertionsDisabled) throw new AssertionError();
/* 2309 */     return null;
/*      */   }
/*      */ 
/*      */   boolean isNull()
/*      */   {
/* 2314 */     return this.isNull;
/*      */   }
/*      */ 
/*      */   void setJdbcType(JDBCType paramJDBCType)
/*      */   {
/* 2320 */     if (!$assertionsDisabled) throw new AssertionError();
/*      */   }
/*      */ 
/*      */   JDBCType getJdbcType()
/*      */   {
/* 2326 */     if (!$assertionsDisabled) throw new AssertionError();
/* 2327 */     return JDBCType.UNKNOWN;
/*      */   }
/*      */ 
/*      */   JavaType getJavaType()
/*      */   {
/* 2333 */     if (!$assertionsDisabled) throw new AssertionError();
/* 2334 */     return JavaType.OBJECT;
/*      */   }
/*      */ 
/*      */   final void initFromCompressedNull()
/*      */   {
/* 2342 */     assert (this.valueMark == null);
/* 2343 */     this.isNull = true;
/*      */   }
/*      */ 
/*      */   final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 2350 */     if ((null == this.valueMark) && (this.isNull))
/*      */     {
/* 2352 */       return;
/*      */     }
/*      */ 
/* 2355 */     if (null == this.valueMark)
/* 2356 */       getValuePrep(paramTypeInfo, paramTDSReader);
/* 2357 */     paramTDSReader.reset(this.valueMark);
/*      */ 
/* 2359 */     if (this.valueLength != -2)
/*      */     {
/* 2361 */       if (this.valueLength == -1)
/*      */       {
/* 2363 */         assert (SSLenType.PARTLENTYPE == paramTypeInfo.getSSLenType());
/*      */ 
/* 2366 */         PLPInputStream localPLPInputStream = PLPInputStream.makeTempStream(paramTDSReader, paramBoolean, this);
/*      */         try
/*      */         {
/* 2369 */           if (null != localPLPInputStream)
/* 2370 */             localPLPInputStream.close();
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 2374 */           paramTDSReader.getConnection().terminate(3, localIOException.getMessage());
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 2379 */         assert (this.valueLength >= 0);
/* 2380 */         paramTDSReader.skip(this.valueLength);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void getValuePrep(TypeInfo paramTypeInfo, TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 2389 */     assert (null == this.valueMark);
/*      */ 
/* 2392 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSLenType[paramTypeInfo.getSSLenType().ordinal()])
/*      */     {
/*      */     case 1:
/* 2395 */       this.valueLength = -1;
/* 2396 */       this.isNull = PLPInputStream.isNull(paramTDSReader);
/* 2397 */       break;
/*      */     case 2:
/* 2400 */       this.valueLength = paramTypeInfo.getMaxLength();
/* 2401 */       this.isNull = (0 == this.valueLength);
/* 2402 */       break;
/*      */     case 3:
/* 2405 */       this.valueLength = paramTDSReader.readUnsignedByte();
/* 2406 */       this.isNull = (0 == this.valueLength);
/* 2407 */       break;
/*      */     case 4:
/* 2410 */       this.valueLength = paramTDSReader.readUnsignedShort();
/* 2411 */       this.isNull = (65535 == this.valueLength);
/* 2412 */       if (!this.isNull) break;
/* 2413 */       this.valueLength = 0; break;
/*      */     case 5:
/* 2417 */       if ((SSType.TEXT == paramTypeInfo.getSSType()) || (SSType.IMAGE == paramTypeInfo.getSSType()) || (SSType.NTEXT == paramTypeInfo.getSSType()))
/*      */       {
/* 2421 */         this.isNull = (0 == paramTDSReader.readUnsignedByte());
/* 2422 */         if (this.isNull)
/*      */         {
/* 2424 */           this.valueLength = 0;
/*      */         }
/*      */         else
/*      */         {
/* 2429 */           paramTDSReader.skip(24);
/* 2430 */           this.valueLength = paramTDSReader.readInt();
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 2435 */         this.valueLength = paramTDSReader.readInt();
/* 2436 */         this.isNull = (0 == this.valueLength);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2441 */     if (this.valueLength > paramTypeInfo.getMaxLength()) {
/* 2442 */       paramTDSReader.throwInvalidTDS();
/*      */     }
/* 2444 */     this.valueMark = paramTDSReader.mark();
/*      */   }
/*      */ 
/*      */   Object getValue(DTV paramDTV, JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 2457 */     Object localObject = null;
/*      */ 
/* 2464 */     if ((null == this.valueMark) && (!this.isNull)) {
/* 2465 */       getValuePrep(paramTypeInfo, paramTDSReader);
/*      */     }
/*      */ 
/* 2469 */     assert ((this.valueMark != null) || ((this.valueMark == null) && (this.isNull)));
/*      */ 
/* 2471 */     int i = 0;
/*      */ 
/* 2473 */     if (null != paramInputStreamGetterArgs)
/*      */     {
/* 2475 */       if (!paramInputStreamGetterArgs.streamType.convertsFrom(paramTypeInfo))
/* 2476 */         DataTypes.throwConversionError(paramTypeInfo.getSSType().toString(), paramInputStreamGetterArgs.streamType.toString());
/*      */     }
/*      */     else
/*      */     {
/* 2480 */       if (!paramTypeInfo.getSSType().convertsTo(paramJDBCType)) {
/* 2481 */         DataTypes.throwConversionError(paramTypeInfo.getSSType().toString(), paramJDBCType.toString());
/*      */       }
/* 2483 */       paramInputStreamGetterArgs = InputStreamGetterArgs.getDefaultArgs();
/*      */     }
/*      */ 
/* 2486 */     if (-2 == this.valueLength)
/*      */     {
/* 2488 */       throw new SQLServerException(null, SQLServerException.getErrString("R_dataAlreadyAccessed"), null, 0, false);
/*      */     }
/*      */ 
/* 2491 */     if (!this.isNull)
/*      */     {
/* 2493 */       paramTDSReader.reset(this.valueMark);
/*      */ 
/* 2495 */       switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSType[paramTypeInfo.getSSType().ordinal()])
/*      */       {
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/* 2503 */         localObject = DDC.convertStreamToObject(PLPInputStream.makeStream(paramTDSReader, paramInputStreamGetterArgs, this), paramTypeInfo, paramJDBCType, paramInputStreamGetterArgs);
/*      */ 
/* 2508 */         break;
/*      */       case 5:
/* 2513 */         localObject = DDC.convertStreamToObject((paramJDBCType.isBinary()) || (paramJDBCType == JDBCType.SQLXML) ? PLPXMLInputStream.makeXMLStream(paramTDSReader, paramInputStreamGetterArgs, this) : PLPInputStream.makeStream(paramTDSReader, paramInputStreamGetterArgs, this), paramTypeInfo, paramJDBCType, paramInputStreamGetterArgs);
/*      */ 
/* 2520 */         break;
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/* 2536 */         localObject = DDC.convertStreamToObject(new SimpleInputStream(paramTDSReader, this.valueLength, paramInputStreamGetterArgs, this), paramTypeInfo, paramJDBCType, paramInputStreamGetterArgs);
/*      */ 
/* 2541 */         break;
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/* 2551 */         switch (this.valueLength)
/*      */         {
/*      */         case 8:
/* 2554 */           localObject = DDC.convertLongToObject(paramTDSReader.readLong(), paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2558 */           break;
/*      */         case 4:
/* 2561 */           localObject = DDC.convertIntegerToObject(paramTDSReader.readInt(), this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2566 */           break;
/*      */         case 2:
/* 2569 */           localObject = DDC.convertIntegerToObject(paramTDSReader.readShort(), this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2574 */           break;
/*      */         case 1:
/* 2577 */           localObject = DDC.convertIntegerToObject(paramTDSReader.readUnsignedByte(), this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2582 */           break;
/*      */         case 3:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*      */         default:
/* 2585 */           if ($assertionsDisabled) break; throw new AssertionError("Unexpected valueLength" + this.valueLength);
/*      */         }
/*      */ 
/*      */       case 21:
/*      */       case 22:
/* 2594 */         localObject = paramTDSReader.readDecimal(this.valueLength, paramTypeInfo, paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2599 */         break;
/*      */       case 23:
/*      */       case 24:
/* 2604 */         localObject = paramTDSReader.readMoney(this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2608 */         break;
/*      */       case 25:
/* 2612 */         localObject = paramTDSReader.readFloat(this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2616 */         break;
/*      */       case 26:
/* 2620 */         localObject = paramTDSReader.readReal(this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2624 */         break;
/*      */       case 27:
/*      */       case 28:
/* 2629 */         localObject = paramTDSReader.readDateTime(this.valueLength, paramCalendar, paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2634 */         break;
/*      */       case 29:
/* 2638 */         localObject = paramTDSReader.readDate(this.valueLength, paramCalendar, paramJDBCType);
/*      */ 
/* 2642 */         break;
/*      */       case 30:
/* 2646 */         localObject = paramTDSReader.readTime(this.valueLength, paramTypeInfo, paramCalendar, paramJDBCType);
/*      */ 
/* 2651 */         break;
/*      */       case 31:
/* 2655 */         localObject = paramTDSReader.readDateTime2(this.valueLength, paramTypeInfo, paramCalendar, paramJDBCType);
/*      */ 
/* 2660 */         break;
/*      */       case 32:
/* 2664 */         localObject = paramTDSReader.readDateTimeOffset(this.valueLength, paramTypeInfo, paramJDBCType);
/*      */ 
/* 2668 */         break;
/*      */       case 33:
/* 2672 */         localObject = paramTDSReader.readGUID(this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */ 
/* 2676 */         break;
/*      */       default:
/* 2680 */         if ($assertionsDisabled) break; throw new AssertionError("Unexpected SSType " + paramTypeInfo.getSSType());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2686 */     assert ((this.isNull) || (null != localObject));
/* 2687 */     return localObject;
/*      */   }
/*      */ 
/*      */   Object getSetterValue()
/*      */   {
/* 2693 */     if (!$assertionsDisabled) throw new AssertionError();
/* 2694 */     return null;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ServerDTVImpl
 * JD-Core Version:    0.6.0
 */