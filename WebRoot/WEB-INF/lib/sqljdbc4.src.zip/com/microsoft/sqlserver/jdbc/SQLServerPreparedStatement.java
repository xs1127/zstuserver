/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ public class SQLServerPreparedStatement extends SQLServerStatement
/*      */   implements ISQLServerPreparedStatement
/*      */ {
/*      */   private static final int BATCH_STATEMENT_DELIMITER_TDS_71 = 128;
/*      */   private static final int BATCH_STATEMENT_DELIMITER_TDS_72 = 255;
/*   34 */   final int nBatchStatementDelimiter = 255;
/*      */   private String sqlCommand;
/*      */   private String preparedTypeDefinitions;
/*      */   private final String userSQL;
/*      */   private String preparedSQL;
/*      */   final boolean bReturnValueSyntax;
/*      */   int outParamIndexAdjustment;
/*      */   ArrayList<Parameter[]> batchParamValues;
/*   65 */   private int prepStmtHandle = 0;
/*      */ 
/*   68 */   private boolean expectPrepStmtHandle = false;
/*      */ 
/*      */   String getClassNameInternal()
/*      */   {
/*   73 */     return "SQLServerPreparedStatement";
/*      */   }
/*      */ 
/*      */   SQLServerPreparedStatement(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLServerException
/*      */   {
/*   88 */     super(paramSQLServerConnection, paramInt1, paramInt2);
/*   89 */     this.stmtPoolable = true;
/*   90 */     this.sqlCommand = paramString;
/*      */ 
/*   92 */     JDBCCallSyntaxTranslator localJDBCCallSyntaxTranslator = new JDBCCallSyntaxTranslator();
/*   93 */     paramString = localJDBCCallSyntaxTranslator.translate(paramString);
/*   94 */     this.procedureName = localJDBCCallSyntaxTranslator.getProcedureName();
/*   95 */     this.bReturnValueSyntax = localJDBCCallSyntaxTranslator.hasReturnValueSyntax();
/*      */ 
/*   97 */     this.userSQL = paramString;
/*   98 */     initParams(this.userSQL);
/*      */   }
/*      */ 
/*      */   private void closePreparedHandle()
/*      */   {
/*  106 */     if (0 == this.prepStmtHandle) {
/*  107 */       return;
/*      */     }
/*      */ 
/*  112 */     if (this.connection.isSessionUnAvailable())
/*      */     {
/*  114 */       if (getStatementLogger().isLoggable(Level.FINER))
/*  115 */         getStatementLogger().finer(new StringBuilder().append(this).append(": Not closing PreparedHandle:").append(this.prepStmtHandle).append("; connection is already closed.").toString());
/*      */     }
/*      */     else
/*      */     {
/*  119 */       if (getStatementLogger().isLoggable(Level.FINER)) {
/*  120 */         getStatementLogger().finer(new StringBuilder().append(this).append(": Closing PreparedHandle:").append(this.prepStmtHandle).toString());
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  146 */         executeCommand(new UninterruptableTDSCommand()
/*      */         {
/*      */           final boolean doExecute()
/*      */             throws SQLServerException
/*      */           {
/*  131 */             TDSWriter localTDSWriter = startRequest(3);
/*  132 */             localTDSWriter.writeShort(-1);
/*  133 */             localTDSWriter.writeShort(SQLServerPreparedStatement.this.executedSqlDirectly ? 15 : 6);
/*  134 */             localTDSWriter.writeByte(0);
/*  135 */             localTDSWriter.writeByte(0);
/*  136 */             localTDSWriter.writeRPCInt(null, new Integer(SQLServerPreparedStatement.this.prepStmtHandle), false);
/*  137 */             SQLServerPreparedStatement.access$002(SQLServerPreparedStatement.this, 0);
/*  138 */             TDSParser.parse(startResponse(), getLogContext());
/*  139 */             return true;
/*      */           }
/*      */ 
/*      */         });
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/*  150 */         if (getStatementLogger().isLoggable(Level.FINER)) {
/*  151 */           getStatementLogger().log(Level.FINER, new StringBuilder().append(this).append(": Error (ignored) closing PreparedHandle:").append(this.prepStmtHandle).toString(), localSQLServerException);
/*      */         }
/*      */       }
/*  154 */       if (getStatementLogger().isLoggable(Level.FINER))
/*  155 */         getStatementLogger().finer(new StringBuilder().append(this).append(": Closed PreparedHandle:").append(this.prepStmtHandle).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   final void closeInternal()
/*      */   {
/*  170 */     super.closeInternal();
/*      */ 
/*  173 */     closePreparedHandle();
/*      */ 
/*  176 */     this.batchParamValues = null;
/*      */   }
/*      */ 
/*      */   final void initParams(String paramString)
/*      */   {
/*  185 */     int i = 0;
/*      */ 
/*  189 */     int j = -1;
/*      */     while (true) { j++; if ((j = ParameterUtils.scanSQLForChar('?', paramString, j)) >= paramString.length()) break;
/*  191 */       i++;
/*      */     }
/*  193 */     this.inOutParam = new Parameter[i];
/*  194 */     for (int k = 0; k < i; k++)
/*  195 */       this.inOutParam[k] = new Parameter();
/*      */   }
/*      */ 
/*      */   public final void clearParameters()
/*      */     throws SQLServerException
/*      */   {
/*  201 */     loggerExternal.entering(getClassNameLogging(), "clearParameters");
/*  202 */     checkClosed();
/*      */ 
/*  204 */     if (this.inOutParam == null) return;
/*  205 */     for (int i = 0; i < this.inOutParam.length; i++)
/*      */     {
/*  207 */       this.inOutParam[i].clearInputValue();
/*      */     }
/*  209 */     loggerExternal.exiting(getClassNameLogging(), "clearParameters");
/*      */   }
/*      */ 
/*      */   private final boolean buildPreparedStrings(Parameter[] paramArrayOfParameter)
/*      */     throws SQLServerException
/*      */   {
/*  219 */     String str = buildParamTypeDefinitions(paramArrayOfParameter);
/*  220 */     if ((null != this.preparedTypeDefinitions) && (str.equals(this.preparedTypeDefinitions))) {
/*  221 */       return false;
/*      */     }
/*  223 */     this.preparedTypeDefinitions = str;
/*      */ 
/*  226 */     this.preparedSQL = this.connection.replaceParameterMarkers(this.userSQL, paramArrayOfParameter, this.bReturnValueSyntax);
/*  227 */     if (this.bRequestedGeneratedKeys) {
/*  228 */       this.preparedSQL = new StringBuilder().append(this.preparedSQL).append(" select SCOPE_IDENTITY() AS GENERATED_KEYS").toString();
/*      */     }
/*  230 */     return true;
/*      */   }
/*      */ 
/*      */   private String buildParamTypeDefinitions(Parameter[] paramArrayOfParameter)
/*      */     throws SQLServerException
/*      */   {
/*  242 */     StringBuilder localStringBuilder = new StringBuilder();
/*  243 */     int i = paramArrayOfParameter.length;
/*  244 */     char[] arrayOfChar = new char[10];
/*      */ 
/*  246 */     for (int j = 0; j < i; j++) {
/*  247 */       if (j > 0) {
/*  248 */         localStringBuilder.append(',');
/*      */       }
/*  250 */       int k = SQLServerConnection.makeParamName(j, arrayOfChar, 0);
/*  251 */       for (int m = 0; m < k; m++)
/*  252 */         localStringBuilder.append(arrayOfChar[m]);
/*  253 */       localStringBuilder.append(' ');
/*      */ 
/*  255 */       String str = paramArrayOfParameter[j].getTypeDefinition(this.connection, resultsReader());
/*  256 */       if (null == str)
/*      */       {
/*  258 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_valueNotSetForParameter"));
/*  259 */         Object[] arrayOfObject = { new Integer(j + 1) };
/*  260 */         SQLServerException.makeFromDriverError(this.connection, this, localMessageFormat.format(arrayOfObject), null, false);
/*      */       }
/*      */ 
/*  263 */       localStringBuilder.append(str);
/*      */ 
/*  265 */       if (paramArrayOfParameter[j].isOutput())
/*  266 */         localStringBuilder.append(" OUTPUT");
/*      */     }
/*  268 */     return localStringBuilder.toString();
/*      */   }
/*      */ 
/*      */   public ResultSet executeQuery()
/*      */     throws SQLServerException
/*      */   {
/*  279 */     loggerExternal.entering(getClassNameLogging(), "executeQuery");
/*  280 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  282 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  284 */     checkClosed();
/*  285 */     executeStatement(new PrepStmtExecCmd(this, 1));
/*  286 */     loggerExternal.exiting(getClassNameLogging(), "executeQuery");
/*  287 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */   final ResultSet executeQueryInternal()
/*      */     throws SQLServerException
/*      */   {
/*  297 */     checkClosed();
/*  298 */     executeStatement(new PrepStmtExecCmd(this, 5));
/*  299 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLServerException
/*      */   {
/*  308 */     loggerExternal.entering(getClassNameLogging(), "executeUpdate");
/*  309 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  311 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  313 */     checkClosed();
/*  314 */     executeStatement(new PrepStmtExecCmd(this, 2));
/*  315 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Integer(this.updateCount));
/*  316 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */   public boolean execute()
/*      */     throws SQLServerException
/*      */   {
/*  326 */     loggerExternal.entering(getClassNameLogging(), "execute");
/*  327 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  329 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*  331 */     checkClosed();
/*  332 */     executeStatement(new PrepStmtExecCmd(this, 3));
/*  333 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf(null != this.resultSet));
/*  334 */     return null != this.resultSet;
/*      */   }
/*      */ 
/*      */   final void doExecutePreparedStatement(PrepStmtExecCmd paramPrepStmtExecCmd)
/*      */     throws SQLServerException
/*      */   {
/*  363 */     resetForReexecute();
/*      */ 
/*  375 */     if ((1 == this.executeMethod) || (3 == this.executeMethod))
/*      */     {
/*  377 */       this.connection.setMaxRows(this.maxRows);
/*  378 */       this.connection.setMaxFieldSize(this.maxFieldSize);
/*      */     }
/*      */     else
/*      */     {
/*  382 */       assert ((2 == this.executeMethod) || (4 == this.executeMethod) || (5 == this.executeMethod));
/*      */ 
/*  389 */       this.connection.setMaxRows(0);
/*      */     }
/*      */ 
/*  392 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  394 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*      */ 
/*  398 */     TDSWriter localTDSWriter = paramPrepStmtExecCmd.startRequest(3);
/*      */ 
/*  400 */     doPrepExec(localTDSWriter, this.inOutParam);
/*      */ 
/*  402 */     ensureExecuteResultsReader(paramPrepStmtExecCmd.startResponse(getIsResponseBufferingAdaptive()));
/*  403 */     startResults();
/*  404 */     getNextResult();
/*      */ 
/*  406 */     if ((1 == this.executeMethod) && (null == this.resultSet))
/*      */     {
/*  408 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_noResultset"), null, true);
/*      */     }
/*  415 */     else if ((2 == this.executeMethod) && (null != this.resultSet))
/*      */     {
/*  417 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), null, false);
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean consumeExecOutParam(TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/*  458 */     if ((this.expectPrepStmtHandle) || (this.expectCursorOutParams))
/*      */     {
/*  460 */       TDSParser.parse(paramTDSReader, new SQLServerStatement.StmtExecOutParamHandler()
/*      */       {
/*      */         boolean onRetValue(TDSReader paramTDSReader)
/*      */           throws SQLServerException
/*      */         {
/*  441 */           if (!SQLServerPreparedStatement.this.expectPrepStmtHandle) {
/*  442 */             return super.onRetValue(paramTDSReader);
/*      */           }
/*      */ 
/*  446 */           SQLServerPreparedStatement.access$102(SQLServerPreparedStatement.this, false);
/*  447 */           Parameter localParameter = new Parameter();
/*  448 */           localParameter.skipRetValStatus(paramTDSReader);
/*  449 */           SQLServerPreparedStatement.access$002(SQLServerPreparedStatement.this, localParameter.getInt(paramTDSReader));
/*  450 */           localParameter.skipValue(paramTDSReader, true);
/*  451 */           if (SQLServerPreparedStatement.this.getStatementLogger().isLoggable(Level.FINER)) {
/*  452 */             SQLServerPreparedStatement.this.getStatementLogger().finer(toString() + ": Setting PreparedHandle:" + SQLServerPreparedStatement.this.prepStmtHandle);
/*      */           }
/*  454 */           return true;
/*      */         }
/*      */       });
/*  461 */       return true;
/*      */     }
/*      */ 
/*  464 */     return false;
/*      */   }
/*      */ 
/*      */   void sendParamsByRPC(TDSWriter paramTDSWriter, Parameter[] paramArrayOfParameter)
/*      */     throws SQLServerException
/*      */   {
/*  472 */     for (int i = 0; i < this.inOutParam.length; i++)
/*  473 */       paramArrayOfParameter[i].sendByRPC(paramTDSWriter, this.connection);
/*      */   }
/*      */ 
/*      */   private final void buildServerCursorPrepExecParams(TDSWriter paramTDSWriter) throws SQLServerException
/*      */   {
/*  478 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  479 */       getStatementLogger().fine(new StringBuilder().append(toString()).append(": calling sp_cursorprepexec: PreparedHandle:").append(this.prepStmtHandle).append(", SQL:").append(this.preparedSQL).toString());
/*      */     }
/*  481 */     this.expectPrepStmtHandle = true;
/*  482 */     this.executedSqlDirectly = false;
/*  483 */     this.expectCursorOutParams = true;
/*  484 */     this.outParamIndexAdjustment = 7;
/*      */ 
/*  486 */     paramTDSWriter.writeShort(-1);
/*  487 */     paramTDSWriter.writeShort(5);
/*  488 */     paramTDSWriter.writeByte(0);
/*  489 */     paramTDSWriter.writeByte(0);
/*      */ 
/*  494 */     paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), true);
/*  495 */     this.prepStmtHandle = 0;
/*      */ 
/*  498 */     paramTDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */ 
/*  501 */     paramTDSWriter.writeRPCStringUnicode(this.preparedTypeDefinitions.length() > 0 ? this.preparedTypeDefinitions : null);
/*      */ 
/*  504 */     paramTDSWriter.writeRPCStringUnicode(this.preparedSQL);
/*      */ 
/*  509 */     paramTDSWriter.writeRPCInt(null, new Integer(getResultSetScrollOpt() & ((0 == this.preparedTypeDefinitions.length() ? 4096 : 0) ^ 0xFFFFFFFF)), false);
/*      */ 
/*  512 */     paramTDSWriter.writeRPCInt(null, new Integer(getResultSetCCOpt()), false);
/*      */ 
/*  515 */     paramTDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */   }
/*      */ 
/*      */   private final void buildPrepExecParams(TDSWriter paramTDSWriter) throws SQLServerException
/*      */   {
/*  520 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  521 */       getStatementLogger().fine(new StringBuilder().append(toString()).append(": calling sp_prepexec: PreparedHandle:").append(this.prepStmtHandle).append(", SQL:").append(this.preparedSQL).toString());
/*      */     }
/*  523 */     this.expectPrepStmtHandle = true;
/*  524 */     this.executedSqlDirectly = true;
/*  525 */     this.expectCursorOutParams = false;
/*  526 */     this.outParamIndexAdjustment = 3;
/*      */ 
/*  528 */     paramTDSWriter.writeShort(-1);
/*  529 */     paramTDSWriter.writeShort(13);
/*  530 */     paramTDSWriter.writeByte(0);
/*  531 */     paramTDSWriter.writeByte(0);
/*      */ 
/*  536 */     paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), true);
/*  537 */     this.prepStmtHandle = 0;
/*      */ 
/*  540 */     paramTDSWriter.writeRPCStringUnicode(this.preparedTypeDefinitions.length() > 0 ? this.preparedTypeDefinitions : null);
/*      */ 
/*  543 */     paramTDSWriter.writeRPCStringUnicode(this.preparedSQL);
/*      */   }
/*      */ 
/*      */   private final void buildServerCursorExecParams(TDSWriter paramTDSWriter) throws SQLServerException
/*      */   {
/*  548 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  549 */       getStatementLogger().fine(new StringBuilder().append(toString()).append(": calling sp_cursorexecute: PreparedHandle:").append(this.prepStmtHandle).append(", SQL:").append(this.preparedSQL).toString());
/*      */     }
/*  551 */     this.expectPrepStmtHandle = false;
/*  552 */     this.executedSqlDirectly = false;
/*  553 */     this.expectCursorOutParams = true;
/*  554 */     this.outParamIndexAdjustment = 5;
/*      */ 
/*  556 */     paramTDSWriter.writeShort(-1);
/*  557 */     paramTDSWriter.writeShort(4);
/*  558 */     paramTDSWriter.writeByte(0);
/*  559 */     paramTDSWriter.writeByte(0);
/*      */ 
/*  562 */     assert (0 != this.prepStmtHandle);
/*  563 */     paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), false);
/*      */ 
/*  566 */     paramTDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */ 
/*  569 */     paramTDSWriter.writeRPCInt(null, new Integer(getResultSetScrollOpt() & 0xFFFFEFFF), false);
/*      */ 
/*  572 */     paramTDSWriter.writeRPCInt(null, new Integer(getResultSetCCOpt()), false);
/*      */ 
/*  575 */     paramTDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */   }
/*      */ 
/*      */   private final void buildExecParams(TDSWriter paramTDSWriter) throws SQLServerException
/*      */   {
/*  580 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  581 */       getStatementLogger().fine(new StringBuilder().append(toString()).append(": calling sp_execute: PreparedHandle:").append(this.prepStmtHandle).append(", SQL:").append(this.preparedSQL).toString());
/*      */     }
/*  583 */     this.expectPrepStmtHandle = false;
/*  584 */     this.executedSqlDirectly = true;
/*  585 */     this.expectCursorOutParams = false;
/*  586 */     this.outParamIndexAdjustment = 1;
/*      */ 
/*  588 */     paramTDSWriter.writeShort(-1);
/*  589 */     paramTDSWriter.writeShort(12);
/*  590 */     paramTDSWriter.writeByte(0);
/*  591 */     paramTDSWriter.writeByte(0);
/*      */ 
/*  594 */     assert (0 != this.prepStmtHandle);
/*  595 */     paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), false);
/*      */   }
/*      */ 
/*      */   private final boolean doPrepExec(TDSWriter paramTDSWriter, Parameter[] paramArrayOfParameter)
/*      */     throws SQLServerException
/*      */   {
/*  612 */     int i = (buildPreparedStrings(paramArrayOfParameter)) || (0 == this.prepStmtHandle) ? 1 : 0;
/*  613 */     if (i != 0)
/*      */     {
/*  615 */       if (isCursorable(this.executeMethod))
/*  616 */         buildServerCursorPrepExecParams(paramTDSWriter);
/*      */       else {
/*  618 */         buildPrepExecParams(paramTDSWriter);
/*      */       }
/*      */ 
/*      */     }
/*  622 */     else if (isCursorable(this.executeMethod))
/*  623 */       buildServerCursorExecParams(paramTDSWriter);
/*      */     else {
/*  625 */       buildExecParams(paramTDSWriter);
/*      */     }
/*      */ 
/*  628 */     sendParamsByRPC(paramTDSWriter, paramArrayOfParameter);
/*  629 */     return i;
/*      */   }
/*      */ 
/*      */   public final ResultSetMetaData getMetaData() throws SQLServerException
/*      */   {
/*  634 */     loggerExternal.entering(getClassNameLogging(), "getMetaData");
/*  635 */     checkClosed();
/*  636 */     int i = 0;
/*  637 */     ResultSetMetaData localResultSetMetaData = null;
/*      */     try
/*      */     {
/*  641 */       if (this.resultSet != null)
/*  642 */         this.resultSet.checkClosed();
/*      */     }
/*      */     catch (SQLServerException localSQLServerException)
/*      */     {
/*  646 */       i = 1;
/*      */     }
/*  648 */     if ((this.resultSet == null) || (i != 0))
/*      */     {
/*  650 */       SQLServerResultSet localSQLServerResultSet = (SQLServerResultSet)buildExecuteMetaData();
/*  651 */       if (null != localSQLServerResultSet) {
/*  652 */         localResultSetMetaData = localSQLServerResultSet.getMetaData();
/*      */       }
/*      */     }
/*  655 */     else if (this.resultSet != null)
/*      */     {
/*  657 */       localResultSetMetaData = this.resultSet.getMetaData();
/*      */     }
/*  659 */     loggerExternal.exiting(getClassNameLogging(), "getMetaData", localResultSetMetaData);
/*  660 */     return localResultSetMetaData;
/*      */   }
/*      */ 
/*      */   private ResultSet buildExecuteMetaData()
/*      */     throws SQLServerException
/*      */   {
/*  672 */     String str = this.sqlCommand;
/*  673 */     if (str.indexOf(123) >= 0)
/*      */     {
/*  675 */       str = new JDBCCallSyntaxTranslator().translate(str);
/*      */     }
/*      */ 
/*  678 */     SQLServerResultSet localSQLServerResultSet = null;
/*      */     try {
/*  680 */       str = replaceMarkerWithNull(str);
/*  681 */       SQLServerStatement localSQLServerStatement = (SQLServerStatement)this.connection.createStatement();
/*  682 */       localSQLServerResultSet = localSQLServerStatement.executeQueryInternal(new StringBuilder().append("set fmtonly on ").append(str).append("\nset fmtonly off").toString());
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/*  686 */       if (false == localSQLException.getMessage().equals(SQLServerException.getErrString("R_noResultset")))
/*      */       {
/*  689 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_processingError"));
/*  690 */         Object[] arrayOfObject = { new String(localSQLException.getMessage()) };
/*      */ 
/*  692 */         SQLServerException.makeFromDriverError(this.connection, this, localMessageFormat.format(arrayOfObject), null, true);
/*      */       }
/*      */     }
/*      */ 
/*  696 */     return localSQLServerResultSet;
/*      */   }
/*      */ 
/*      */   final Parameter setterGetParam(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  711 */     if ((paramInt < 1) || (paramInt > this.inOutParam.length)) {
/*  712 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/*  713 */       Object[] arrayOfObject = { new Integer(paramInt) };
/*  714 */       SQLServerException.makeFromDriverError(this.connection, this, localMessageFormat.format(arrayOfObject), "07009", false);
/*      */     }
/*      */ 
/*  718 */     return this.inOutParam[(paramInt - 1)];
/*      */   }
/*      */ 
/*      */   final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType) throws SQLServerException
/*      */   {
/*  723 */     setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, null, null, this.connection);
/*      */   }
/*      */ 
/*      */   final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Calendar paramCalendar) throws SQLServerException
/*      */   {
/*  728 */     setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, paramCalendar, null, this.connection);
/*      */   }
/*      */ 
/*      */   final void setStream(int paramInt, StreamType paramStreamType, Object paramObject, JavaType paramJavaType, long paramLong) throws SQLServerException
/*      */   {
/*  733 */     setterGetParam(paramInt).setValue(paramStreamType.getJDBCType(), paramObject, paramJavaType, new StreamSetterArgs(paramStreamType, paramLong), null, null, this.connection);
/*      */   }
/*      */ 
/*      */   final void setSQLXMLInternal(int paramInt, SQLXML paramSQLXML)
/*      */     throws SQLServerException
/*      */   {
/*  744 */     setterGetParam(paramInt).setValue(JDBCType.SQLXML, paramSQLXML, JavaType.SQLXML, new StreamSetterArgs(StreamType.SQLXML, -1L), null, null, this.connection);
/*      */   }
/*      */ 
/*      */   public final void setAsciiStream(int paramInt, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/*  755 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  756 */     if (loggerExternal.isLoggable(Level.FINER))
/*  757 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream });
/*  758 */     checkClosed();
/*  759 */     setStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*  760 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   public final void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLServerException
/*      */   {
/*  765 */     if (loggerExternal.isLoggable(Level.FINER))
/*  766 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) });
/*  767 */     checkClosed();
/*  768 */     setStream(paramInt1, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
/*  769 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   public final void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/*  774 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  775 */     if (loggerExternal.isLoggable(Level.FINER))
/*  776 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
/*  777 */     checkClosed();
/*  778 */     setStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*  779 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   private final Parameter getParam(int paramInt) throws SQLServerException
/*      */   {
/*  784 */     paramInt--;
/*  785 */     if ((paramInt < 0) || (paramInt >= this.inOutParam.length))
/*      */     {
/*  787 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/*  788 */       Object[] arrayOfObject = { new Integer(paramInt + 1) };
/*  789 */       SQLServerException.makeFromDriverError(this.connection, this, localMessageFormat.format(arrayOfObject), "07009", false);
/*      */     }
/*      */ 
/*  792 */     return this.inOutParam[paramInt];
/*      */   }
/*      */ 
/*      */   public final void setBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*      */     throws SQLServerException
/*      */   {
/*  798 */     if (loggerExternal.isLoggable(Level.FINER))
/*  799 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal });
/*  800 */     checkClosed();
/*  801 */     setValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL);
/*  802 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   public final void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException
/*      */   {
/*  807 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  808 */     if (loggerExternal.isLoggable(Level.FINER))
/*  809 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStreaml", new Object[] { Integer.valueOf(paramInt), paramInputStream });
/*  810 */     checkClosed();
/*  811 */     setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*  812 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   public final void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLServerException
/*      */   {
/*  817 */     if (loggerExternal.isLoggable(Level.FINER))
/*  818 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) });
/*  819 */     checkClosed();
/*  820 */     setStream(paramInt1, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
/*  821 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   public final void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/*  826 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  827 */     if (loggerExternal.isLoggable(Level.FINER))
/*  828 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
/*  829 */     checkClosed();
/*  830 */     setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*  831 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   public final void setBoolean(int paramInt, boolean paramBoolean) throws SQLServerException
/*      */   {
/*  836 */     if (loggerExternal.isLoggable(Level.FINER))
/*  837 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/*  838 */     checkClosed();
/*  839 */     setValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN);
/*  840 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   public final void setByte(int paramInt, byte paramByte) throws SQLServerException
/*      */   {
/*  845 */     if (loggerExternal.isLoggable(Level.FINER))
/*  846 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte) });
/*  847 */     checkClosed();
/*  848 */     setValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE);
/*  849 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   public final void setBytes(int paramInt, byte[] paramArrayOfByte) throws SQLServerException
/*      */   {
/*  854 */     if (loggerExternal.isLoggable(Level.FINER))
/*  855 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfByte });
/*  856 */     checkClosed();
/*  857 */     setValue(paramInt, JDBCType.BINARY, paramArrayOfByte, JavaType.BYTEARRAY);
/*  858 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   public final void setDouble(int paramInt, double paramDouble) throws SQLServerException
/*      */   {
/*  863 */     if (loggerExternal.isLoggable(Level.FINER))
/*  864 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble) });
/*  865 */     checkClosed();
/*  866 */     setValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE);
/*  867 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   public final void setFloat(int paramInt, float paramFloat) throws SQLServerException
/*      */   {
/*  872 */     if (loggerExternal.isLoggable(Level.FINER))
/*  873 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat) });
/*  874 */     checkClosed();
/*  875 */     setValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT);
/*  876 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   public final void setInt(int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/*  881 */     if (loggerExternal.isLoggable(Level.FINER))
/*  882 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/*  883 */     checkClosed();
/*  884 */     setValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER);
/*  885 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   public final void setLong(int paramInt, long paramLong) throws SQLServerException
/*      */   {
/*  890 */     if (loggerExternal.isLoggable(Level.FINER))
/*  891 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong) });
/*  892 */     checkClosed();
/*  893 */     setValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG);
/*  894 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */   public final void setNull(int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/*  899 */     if (loggerExternal.isLoggable(Level.FINER))
/*  900 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/*  901 */     checkClosed();
/*  902 */     setObject(setterGetParam(paramInt1), null, JavaType.OBJECT, JDBCType.of(paramInt2), null);
/*  903 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */   final void setObjectNoType(int paramInt, Object paramObject)
/*      */     throws SQLServerException
/*      */   {
/*  910 */     Parameter localParameter = setterGetParam(paramInt);
/*  911 */     JDBCType localJDBCType = localParameter.getJdbcType();
/*      */ 
/*  913 */     if (null == paramObject)
/*      */     {
/*  917 */       if (JDBCType.UNKNOWN == localJDBCType) {
/*  918 */         localJDBCType = JDBCType.CHAR;
/*      */       }
/*  920 */       setObject(localParameter, null, JavaType.OBJECT, localJDBCType, null);
/*      */     }
/*      */     else
/*      */     {
/*  924 */       JavaType localJavaType = JavaType.of(paramObject);
/*  925 */       localJDBCType = localJavaType.getJDBCType(SSType.UNKNOWN, localJDBCType);
/*  926 */       setObject(localParameter, paramObject, localJavaType, localJDBCType, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void setObject(int paramInt, Object paramObject) throws SQLServerException
/*      */   {
/*  932 */     if (loggerExternal.isLoggable(Level.FINER))
/*  933 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt), paramObject });
/*  934 */     checkClosed();
/*  935 */     setObjectNoType(paramInt, paramObject);
/*  936 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   public final void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLServerException
/*      */   {
/*  941 */     if (loggerExternal.isLoggable(Level.FINER))
/*  942 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2) });
/*  943 */     checkClosed();
/*  944 */     setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), null);
/*  945 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   public final void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLServerException
/*      */   {
/*  950 */     if (loggerExternal.isLoggable(Level.FINER))
/*  951 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) });
/*  952 */     checkClosed();
/*      */ 
/*  959 */     setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), (2 == paramInt2) || (3 == paramInt2) || (InputStream.class.isInstance(paramObject)) || (Reader.class.isInstance(paramObject)) ? Integer.valueOf(paramInt3) : null);
/*      */ 
/*  971 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   final void setObject(Parameter paramParameter, Object paramObject, JavaType paramJavaType, JDBCType paramJDBCType, Integer paramInteger)
/*      */     throws SQLServerException
/*      */   {
/*  981 */     assert (JDBCType.UNKNOWN != paramJDBCType);
/*      */ 
/*  985 */     if (null != paramObject)
/*      */     {
/*  987 */       JDBCType localJDBCType = paramJavaType.getJDBCType(SSType.UNKNOWN, paramJDBCType);
/*      */ 
/*  990 */       if (!localJDBCType.convertsTo(paramJDBCType)) {
/*  991 */         DataTypes.throwConversionError(localJDBCType.toString(), paramJDBCType.toString());
/*      */       }
/*  993 */       StreamSetterArgs localStreamSetterArgs = null;
/*      */ 
/*  995 */       switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JavaType[paramJavaType.ordinal()])
/*      */       {
/*      */       case 1:
/*  998 */         localStreamSetterArgs = new StreamSetterArgs(StreamType.CHARACTER, -1L);
/*      */ 
/* 1001 */         break;
/*      */       case 2:
/* 1004 */         localStreamSetterArgs = new StreamSetterArgs(paramJDBCType.isTextual() ? StreamType.CHARACTER : StreamType.BINARY, -1L);
/*      */ 
/* 1009 */         break;
/*      */       case 3:
/* 1012 */         localStreamSetterArgs = new StreamSetterArgs(StreamType.SQLXML, -1L);
/*      */       }
/*      */ 
/* 1018 */       paramParameter.setValue(paramJDBCType, paramObject, paramJavaType, localStreamSetterArgs, null, paramInteger, this.connection);
/*      */     }
/*      */     else
/*      */     {
/* 1025 */       assert (JavaType.OBJECT == paramJavaType);
/*      */ 
/* 1027 */       if (paramJDBCType.isUnsupported()) {
/* 1028 */         paramJDBCType = JDBCType.BINARY;
/*      */       }
/* 1030 */       paramParameter.setValue(paramJDBCType, null, JavaType.OBJECT, null, null, paramInteger, this.connection);
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void setShort(int paramInt, short paramShort) throws SQLServerException
/*      */   {
/* 1036 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1037 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort) });
/* 1038 */     checkClosed();
/* 1039 */     setValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT);
/* 1040 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   public final void setString(int paramInt, String paramString) throws SQLServerException
/*      */   {
/* 1045 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1046 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { Integer.valueOf(paramInt), paramString });
/* 1047 */     checkClosed();
/* 1048 */     setValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING);
/* 1049 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   public final void setNString(int paramInt, String paramString) throws SQLException
/*      */   {
/* 1054 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1055 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1056 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { Integer.valueOf(paramInt), paramString });
/* 1057 */     checkClosed();
/* 1058 */     setValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING);
/* 1059 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   public final void setTime(int paramInt, Time paramTime) throws SQLServerException
/*      */   {
/* 1064 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1065 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt), paramTime });
/* 1066 */     checkClosed();
/* 1067 */     setValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME);
/* 1068 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   public final void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLServerException
/*      */   {
/* 1073 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1074 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp });
/* 1075 */     checkClosed();
/* 1076 */     setValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP);
/* 1077 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   public final void setDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLException
/*      */   {
/* 1082 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1083 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset });
/* 1084 */     checkClosed();
/* 1085 */     setValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET);
/* 1086 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   public final void setDate(int paramInt, Date paramDate) throws SQLServerException
/*      */   {
/* 1091 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1092 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(paramInt), paramDate });
/* 1093 */     checkClosed();
/* 1094 */     setValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE);
/* 1095 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */   @Deprecated
/*      */   public final void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 1100 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   public final void addBatch() throws SQLServerException
/*      */   {
/* 1105 */     loggerExternal.entering(getClassNameLogging(), "addBatch");
/* 1106 */     checkClosed();
/*      */ 
/* 1109 */     if (this.batchParamValues == null) {
/* 1110 */       this.batchParamValues = new ArrayList();
/*      */     }
/* 1112 */     int i = this.inOutParam.length;
/* 1113 */     Parameter[] arrayOfParameter = new Parameter[i];
/* 1114 */     for (int j = 0; j < i; j++)
/* 1115 */       arrayOfParameter[j] = this.inOutParam[j].cloneForBatch();
/* 1116 */     this.batchParamValues.add(arrayOfParameter);
/* 1117 */     loggerExternal.exiting(getClassNameLogging(), "addBatch");
/*      */   }
/*      */ 
/*      */   public final void clearBatch() throws SQLServerException
/*      */   {
/* 1122 */     loggerExternal.entering(getClassNameLogging(), "clearBatch");
/* 1123 */     checkClosed();
/* 1124 */     this.batchParamValues = null;
/* 1125 */     loggerExternal.exiting(getClassNameLogging(), "clearBatch");
/*      */   }
/*      */ 
/*      */   public int[] executeBatch() throws SQLServerException, BatchUpdateException
/*      */   {
/* 1130 */     loggerExternal.entering(getClassNameLogging(), "executeBatch");
/* 1131 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1133 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1135 */     checkClosed();
/* 1136 */     discardLastExecutionResults();
/*      */     int[] arrayOfInt;
/* 1140 */     if (this.batchParamValues == null) {
/* 1141 */       arrayOfInt = new int[0];
/*      */     }
/*      */     else
/*      */     {
/*      */       try
/*      */       {
/* 1155 */         for (int i = 0; i < this.batchParamValues.size(); i++)
/*      */         {
/* 1157 */           Parameter[] arrayOfParameter = (Parameter[])this.batchParamValues.get(i);
/* 1158 */           for (int j = 0; j < arrayOfParameter.length; j++)
/*      */           {
/* 1160 */             if (!arrayOfParameter[j].isOutput())
/*      */               continue;
/* 1162 */             throw new BatchUpdateException(SQLServerException.getErrString("R_outParamsNotPermittedinBatch"), null, 0, null);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1171 */         PrepStmtBatchExecCmd localPrepStmtBatchExecCmd = new PrepStmtBatchExecCmd(this);
/*      */ 
/* 1173 */         executeStatement(localPrepStmtBatchExecCmd);
/*      */ 
/* 1176 */         if (null != localPrepStmtBatchExecCmd.batchException)
/*      */         {
/* 1178 */           throw new BatchUpdateException(localPrepStmtBatchExecCmd.batchException.getMessage(), localPrepStmtBatchExecCmd.batchException.getSQLState(), localPrepStmtBatchExecCmd.batchException.getErrorCode(), localPrepStmtBatchExecCmd.updateCounts);
/*      */         }
/*      */ 
/* 1185 */         arrayOfInt = localPrepStmtBatchExecCmd.updateCounts;
/*      */       }
/*      */       finally
/*      */       {
/* 1189 */         this.batchParamValues = null;
/*      */       }
/*      */     }
/* 1191 */     loggerExternal.exiting(getClassNameLogging(), "executeBatch", arrayOfInt);
/* 1192 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   final void doExecutePreparedStatementBatch(PrepStmtBatchExecCmd paramPrepStmtBatchExecCmd)
/*      */     throws SQLServerException
/*      */   {
/* 1222 */     this.executeMethod = 4;
/*      */ 
/* 1224 */     paramPrepStmtBatchExecCmd.batchException = null;
/* 1225 */     int i = this.batchParamValues.size();
/* 1226 */     paramPrepStmtBatchExecCmd.updateCounts = new int[i];
/* 1227 */     for (int j = 0; j < i; j++) {
/* 1228 */       paramPrepStmtBatchExecCmd.updateCounts[j] = -3;
/*      */     }
/* 1230 */     j = 0;
/* 1231 */     int k = 0;
/*      */ 
/* 1233 */     if (isSelect(this.userSQL))
/*      */     {
/* 1235 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_selectNotPermittedinBatch"), null, true);
/*      */     }
/*      */ 
/* 1244 */     this.connection.setMaxRows(0);
/*      */ 
/* 1246 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1248 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*      */ 
/* 1251 */     Parameter[] arrayOfParameter1 = new Parameter[this.inOutParam.length];
/*      */ 
/* 1253 */     TDSWriter localTDSWriter = null;
/* 1254 */     while (k < i)
/*      */     {
/* 1257 */       Parameter[] arrayOfParameter2 = (Parameter[])this.batchParamValues.get(j);
/* 1258 */       assert (arrayOfParameter2.length == arrayOfParameter1.length);
/* 1259 */       for (int m = 0; m < arrayOfParameter2.length; m++) {
/* 1260 */         arrayOfParameter1[m] = arrayOfParameter2[m];
/*      */       }
/* 1262 */       if (k < j)
/*      */       {
/* 1265 */         localTDSWriter.writeByte(-1);
/*      */       }
/*      */       else
/*      */       {
/* 1269 */         resetForReexecute();
/* 1270 */         localTDSWriter = paramPrepStmtBatchExecCmd.startRequest(3);
/*      */       }
/*      */ 
/* 1281 */       j++;
/* 1282 */       if ((doPrepExec(localTDSWriter, arrayOfParameter1)) || (j == i))
/*      */       {
/* 1284 */         ensureExecuteResultsReader(paramPrepStmtBatchExecCmd.startResponse(getIsResponseBufferingAdaptive()));
/*      */ 
/* 1286 */         while (k < j)
/*      */         {
/* 1292 */           startResults();
/*      */           try
/*      */           {
/* 1299 */             if (!getNextResult()) {
/* 1300 */               return;
/*      */             }
/*      */ 
/* 1305 */             if (null != this.resultSet)
/*      */             {
/* 1307 */               SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), null, false);
/*      */             }
/*      */ 
/*      */           }
/*      */           catch (SQLServerException localSQLServerException)
/*      */           {
/* 1320 */             if ((this.connection.isSessionUnAvailable()) || (this.connection.rolledBackTransaction())) {
/* 1321 */               throw localSQLServerException;
/*      */             }
/*      */ 
/* 1325 */             this.updateCount = -3;
/* 1326 */             if (null == paramPrepStmtBatchExecCmd.batchException) {
/* 1327 */               paramPrepStmtBatchExecCmd.batchException = localSQLServerException;
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 1332 */           paramPrepStmtBatchExecCmd.updateCounts[(k++)] = (-1 == this.updateCount ? -2 : this.updateCount);
/*      */ 
/* 1335 */           processBatch();
/*      */         }
/*      */ 
/* 1340 */         assert (k == j);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void setCharacterStream(int paramInt, Reader paramReader) throws SQLException
/*      */   {
/* 1347 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1348 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1349 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader });
/* 1350 */     checkClosed();
/* 1351 */     setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/* 1352 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLServerException
/*      */   {
/* 1357 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1358 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(paramInt1), paramReader, Integer.valueOf(paramInt2) });
/* 1359 */     checkClosed();
/* 1360 */     setStream(paramInt1, StreamType.CHARACTER, paramReader, JavaType.READER, paramInt2);
/* 1361 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 1366 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1367 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1368 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/* 1369 */     checkClosed();
/* 1370 */     setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/* 1371 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException
/*      */   {
/* 1376 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1377 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1378 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader });
/* 1379 */     checkClosed();
/* 1380 */     setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/* 1381 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 1386 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1387 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1388 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/* 1389 */     checkClosed();
/* 1390 */     setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/* 1391 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setRef(int paramInt, Ref paramRef) throws SQLServerException {
/* 1395 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   public final void setBlob(int paramInt, Blob paramBlob) throws SQLException
/*      */   {
/* 1400 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1401 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(paramInt), paramBlob });
/* 1402 */     checkClosed();
/* 1403 */     setValue(paramInt, JDBCType.BLOB, paramBlob, JavaType.BLOB);
/* 1404 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   public final void setBlob(int paramInt, InputStream paramInputStream) throws SQLException
/*      */   {
/* 1409 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1410 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1411 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream });
/* 1412 */     checkClosed();
/* 1413 */     setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 1414 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   public final void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 1419 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1420 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1421 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
/* 1422 */     checkClosed();
/* 1423 */     setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 1424 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   public final void setClob(int paramInt, Clob paramClob) throws SQLException
/*      */   {
/* 1429 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1430 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(paramInt), paramClob });
/* 1431 */     checkClosed();
/* 1432 */     setValue(paramInt, JDBCType.CLOB, paramClob, JavaType.CLOB);
/* 1433 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   public final void setClob(int paramInt, Reader paramReader) throws SQLException
/*      */   {
/* 1438 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1439 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1440 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(paramInt), paramReader });
/* 1441 */     checkClosed();
/* 1442 */     setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/* 1443 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   public final void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 1448 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1449 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1450 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/* 1451 */     checkClosed();
/* 1452 */     setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/* 1453 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   public final void setNClob(int paramInt, NClob paramNClob) throws SQLException
/*      */   {
/* 1458 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1459 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1460 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(paramInt), paramNClob });
/* 1461 */     checkClosed();
/* 1462 */     setValue(paramInt, JDBCType.NCLOB, paramNClob, JavaType.NCLOB);
/* 1463 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   public final void setNClob(int paramInt, Reader paramReader) throws SQLException
/*      */   {
/* 1468 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1469 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1470 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(paramInt), paramReader });
/* 1471 */     checkClosed();
/* 1472 */     setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/* 1473 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   public final void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 1478 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1479 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1480 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/* 1481 */     checkClosed();
/* 1482 */     setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/* 1483 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   public final void setArray(int paramInt, Array paramArray) throws SQLServerException {
/* 1487 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   public final void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 1492 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1493 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(paramInt), paramDate, paramCalendar });
/* 1494 */     checkClosed();
/* 1495 */     setValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar);
/* 1496 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   public final void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 1501 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1502 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt), paramTime, paramCalendar });
/* 1503 */     checkClosed();
/* 1504 */     setValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar);
/* 1505 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   public final void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 1510 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1511 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramCalendar });
/* 1512 */     checkClosed();
/* 1513 */     setValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar);
/* 1514 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   public final void setNull(int paramInt1, int paramInt2, String paramString) throws SQLServerException
/*      */   {
/* 1519 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1520 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramString });
/* 1521 */     checkClosed();
/* 1522 */     setObject(setterGetParam(paramInt1), null, JavaType.OBJECT, JDBCType.of(paramInt2), null);
/* 1523 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */   public final ParameterMetaData getParameterMetaData()
/*      */     throws SQLServerException
/*      */   {
/* 1530 */     loggerExternal.entering(getClassNameLogging(), "getParameterMetaData");
/* 1531 */     checkClosed();
/* 1532 */     SQLServerParameterMetaData localSQLServerParameterMetaData = new SQLServerParameterMetaData(this, this.userSQL);
/* 1533 */     loggerExternal.exiting(getClassNameLogging(), "getParameterMetaData", localSQLServerParameterMetaData);
/* 1534 */     return localSQLServerParameterMetaData;
/*      */   }
/*      */ 
/*      */   public final void setURL(int paramInt, URL paramURL) throws SQLServerException {
/* 1538 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   public final void setRowId(int paramInt, RowId paramRowId) throws SQLException
/*      */   {
/* 1543 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 1546 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public final void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException
/*      */   {
/* 1551 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1552 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1553 */       loggerExternal.entering(getClassNameLogging(), "setSQLXML", new Object[] { Integer.valueOf(paramInt), paramSQLXML });
/* 1554 */     checkClosed();
/* 1555 */     setSQLXMLInternal(paramInt, paramSQLXML);
/* 1556 */     loggerExternal.exiting(getClassNameLogging(), "setSQLXML");
/*      */   }
/*      */ 
/*      */   public final int executeUpdate(String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 1563 */     loggerExternal.entering(getClassNameLogging(), "executeUpdate", paramString);
/* 1564 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 1565 */     Object[] arrayOfObject = { new String("executeUpdate()") };
/* 1566 */     throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */   }
/*      */   public final boolean execute(String paramString) throws SQLServerException {
/* 1569 */     loggerExternal.entering(getClassNameLogging(), "execute", paramString);
/* 1570 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 1571 */     Object[] arrayOfObject = { new String("execute()") };
/* 1572 */     throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */   }
/*      */   public final ResultSet executeQuery(String paramString) throws SQLServerException {
/* 1575 */     loggerExternal.entering(getClassNameLogging(), "executeQuery", paramString);
/* 1576 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 1577 */     Object[] arrayOfObject = { new String("executeQuery()") };
/* 1578 */     throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */   }
/*      */   public void addBatch(String paramString) throws SQLServerException {
/* 1581 */     loggerExternal.entering(getClassNameLogging(), "addBatch", paramString);
/* 1582 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 1583 */     Object[] arrayOfObject = { new String("addBatch()") };
/* 1584 */     throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */   }
/*      */ 
/*      */   private final class PrepStmtBatchExecCmd extends TDSCommand
/*      */   {
/*      */     private final SQLServerPreparedStatement stmt;
/*      */     SQLServerException batchException;
/*      */     int[] updateCounts;
/*      */ 
/*      */     PrepStmtBatchExecCmd(SQLServerPreparedStatement arg2)
/*      */     {
/* 1203 */       super(SQLServerPreparedStatement.this.queryTimeout);
/* 1204 */       this.stmt = localObject;
/*      */     }
/*      */ 
/*      */     final boolean doExecute() throws SQLServerException
/*      */     {
/* 1209 */       this.stmt.doExecutePreparedStatementBatch(this);
/* 1210 */       return true;
/*      */     }
/*      */ 
/*      */     final void processResponse(TDSReader paramTDSReader) throws SQLServerException
/*      */     {
/* 1215 */       SQLServerPreparedStatement.this.ensureExecuteResultsReader(paramTDSReader);
/* 1216 */       SQLServerPreparedStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */ 
/*      */   private final class PrepStmtExecCmd extends TDSCommand
/*      */   {
/*      */     private final SQLServerPreparedStatement stmt;
/*      */ 
/*      */     PrepStmtExecCmd(SQLServerPreparedStatement paramInt, int arg3)
/*      */     {
/*  343 */       super(SQLServerPreparedStatement.this.queryTimeout);
/*  344 */       this.stmt = paramInt;
/*      */       int i;
/*  345 */       paramInt.executeMethod = i;
/*      */     }
/*      */ 
/*      */     final boolean doExecute() throws SQLServerException
/*      */     {
/*  350 */       this.stmt.doExecutePreparedStatement(this);
/*  351 */       return false;
/*      */     }
/*      */ 
/*      */     final void processResponse(TDSReader paramTDSReader) throws SQLServerException
/*      */     {
/*  356 */       SQLServerPreparedStatement.this.ensureExecuteResultsReader(paramTDSReader);
/*  357 */       SQLServerPreparedStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement
 * JD-Core Version:    0.6.0
 */