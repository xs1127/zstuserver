/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ final class StreamSetterArgs
/*      */ {
/*      */   private long length;
/*      */   final StreamType streamType;
/*      */ 
/*      */   final long getLength()
/*      */   {
/* 1162 */     return this.length;
/*      */   }
/*      */ 
/*      */   final void setLength(long paramLong)
/*      */   {
/* 1167 */     assert (-1L == this.length);
/* 1168 */     assert (paramLong >= 0L);
/* 1169 */     this.length = paramLong;
/*      */   }
/*      */ 
/*      */   StreamSetterArgs(StreamType paramStreamType, long paramLong)
/*      */   {
/* 1176 */     this.streamType = paramStreamType;
/* 1177 */     this.length = paramLong;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamSetterArgs
 * JD-Core Version:    0.6.0
 */