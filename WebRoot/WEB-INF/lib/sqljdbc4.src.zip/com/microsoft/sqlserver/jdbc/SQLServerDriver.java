/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.sql.Connection;
/*      */ import java.sql.Driver;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.SQLException;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Properties;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ public final class SQLServerDriver
/*      */   implements Driver
/*      */ {
/*      */   static final String PRODUCT_NAME = "Microsoft JDBC Driver 4.0 for SQL Server";
/*      */   static final String DEFAULT_APP_NAME = "Microsoft JDBC Driver for SQL Server";
/*  836 */   private static final String[] TRUE_FALSE = { "true", "false" };
/*  837 */   private static final SQLServerDriverPropertyInfo[] DRIVER_PROPERTIES = { new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue(), false, new String[] { ApplicationIntent.READ_ONLY.toString(), ApplicationIntent.READ_WRITE.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.APPLICATION_NAME.toString(), SQLServerDriverStringProperty.APPLICATION_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.DATABASE_NAME.toString(), SQLServerDriverStringProperty.DATABASE_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString(), Boolean.toString(SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.getDefaultValue()), false, new String[] { "true" }), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.ENCRYPT.toString(), Boolean.toString(SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), SQLServerDriverStringProperty.FAILOVER_PARTNER.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), SQLServerDriverStringProperty.INSTANCE_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString(), Boolean.toString(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), Boolean.toString(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), Integer.toString(SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), Integer.toString(SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), Boolean.toString(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.PACKET_SIZE.toString(), Integer.toString(SQLServerDriverIntProperty.PACKET_SIZE.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.PASSWORD.toString(), SQLServerDriverStringProperty.PASSWORD.getDefaultValue(), true, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.PORT_NUMBER.toString(), Integer.toString(SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue(), false, new String[] { "adaptive", "full" }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SELECT_METHOD.toString(), SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue(), false, new String[] { "direct", "cursor" }), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), Boolean.toString(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SERVER_NAME.toString(), SQLServerDriverStringProperty.SERVER_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), Boolean.toString(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_STORE.toString(), SQLServerDriverStringProperty.TRUST_STORE.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString(), SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), Boolean.toString(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.USER.toString(), SQLServerDriverStringProperty.USER.getDefaultValue(), true, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.WORKSTATION_ID.toString(), SQLServerDriverStringProperty.WORKSTATION_ID.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), Boolean.toString(SQLServerDriverBooleanProperty.XOPEN_STATES.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString(), SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.getDefaultValue(), false, new String[] { AuthenticationScheme.javaKerberos.toString(), AuthenticationScheme.nativeAuthentication.toString() }) };
/*      */ 
/*  871 */   private static final String[][] driverPropertiesSynonyms = { { "database", SQLServerDriverStringProperty.DATABASE_NAME.toString() }, { "userName", SQLServerDriverStringProperty.USER.toString() }, { "server", SQLServerDriverStringProperty.SERVER_NAME.toString() }, { "port", SQLServerDriverIntProperty.PORT_NUMBER.toString() } };
/*      */ 
/*  877 */   private static int baseID = 0;
/*      */   private final int instanceID;
/*      */   private final String traceID;
/*  891 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Driver");
/*      */   private final String loggingClassName;
/*  899 */   private static final Logger drLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDriver");
/*      */ 
/*      */   private static synchronized int nextInstanceID()
/*      */   {
/*  884 */     baseID += 1;
/*  885 */     return baseID;
/*      */   }
/*      */ 
/*      */   public final String toString() {
/*  889 */     return this.traceID;
/*      */   }
/*      */ 
/*      */   String getClassNameLogging()
/*      */   {
/*  896 */     return this.loggingClassName;
/*      */   }
/*      */ 
/*      */   public SQLServerDriver()
/*      */   {
/*  912 */     this.instanceID = nextInstanceID();
/*  913 */     this.traceID = ("SQLServerDriver:" + this.instanceID);
/*  914 */     this.loggingClassName = ("com.microsoft.sqlserver.jdbc.SQLServerDriver:" + this.instanceID);
/*      */   }
/*      */ 
/*      */   static Properties fixupProperties(Properties paramProperties)
/*      */     throws SQLServerException
/*      */   {
/*  922 */     Properties localProperties = new Properties();
/*  923 */     Enumeration localEnumeration = paramProperties.keys();
/*  924 */     while (localEnumeration.hasMoreElements())
/*      */     {
/*  926 */       String str1 = (String)localEnumeration.nextElement();
/*  927 */       String str2 = getNormalizedPropertyName(str1, drLogger);
/*  928 */       if (null != str2)
/*      */       {
/*  930 */         String str3 = paramProperties.getProperty(str1);
/*  931 */         if (null != str3)
/*      */         {
/*  934 */           localProperties.setProperty(str2, str3);
/*      */         }
/*      */         else
/*      */         {
/*  938 */           MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidpropertyValue"));
/*  939 */           Object[] arrayOfObject = { str1 };
/*  940 */           throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  945 */     return localProperties;
/*      */   }
/*      */ 
/*      */   static Properties mergeURLAndSuppliedProperties(Properties paramProperties1, Properties paramProperties2)
/*      */     throws SQLServerException
/*      */   {
/*  952 */     if (null == paramProperties2) return paramProperties1;
/*  953 */     if (paramProperties2.isEmpty()) return paramProperties1;
/*      */ 
/*  955 */     Properties localProperties = fixupProperties(paramProperties2);
/*      */ 
/*  958 */     for (int i = 0; i < DRIVER_PROPERTIES.length; i++)
/*      */     {
/*  960 */       String str1 = DRIVER_PROPERTIES[i].getName();
/*  961 */       String str2 = localProperties.getProperty(str1);
/*  962 */       if (null == str2) {
/*      */         continue;
/*      */       }
/*  965 */       paramProperties1.put(str1, str2);
/*      */     }
/*      */ 
/*  970 */     return paramProperties1;
/*      */   }
/*      */ 
/*      */   static String getNormalizedPropertyName(String paramString, Logger paramLogger)
/*      */   {
/*  980 */     if (null == paramString) {
/*  981 */       return paramString;
/*      */     }
/*  983 */     for (int i = 0; i < driverPropertiesSynonyms.length; i++)
/*      */     {
/*  985 */       if (driverPropertiesSynonyms[i][0].equalsIgnoreCase(paramString))
/*      */       {
/*  987 */         return driverPropertiesSynonyms[i][1];
/*      */       }
/*      */     }
/*  990 */     for (i = 0; i < DRIVER_PROPERTIES.length; i++)
/*      */     {
/*  992 */       if (DRIVER_PROPERTIES[i].getName().equalsIgnoreCase(paramString))
/*      */       {
/*  994 */         return DRIVER_PROPERTIES[i].getName();
/*      */       }
/*      */     }
/*  997 */     if (paramLogger.isLoggable(Level.FINER))
/*  998 */       paramLogger.finer("Unknown property" + paramString);
/*  999 */     return null;
/*      */   }
/*      */ 
/*      */   public Connection connect(String paramString, Properties paramProperties) throws SQLServerException
/*      */   {
/* 1004 */     loggerExternal.entering(getClassNameLogging(), "connect", "Arguments not traced.");
/* 1005 */     SQLServerConnection localSQLServerConnection = null;
/*      */ 
/* 1008 */     Properties localProperties = parseAndMergeProperties(paramString, paramProperties);
/* 1009 */     if (localProperties != null)
/*      */     {
/* 1011 */       localSQLServerConnection = new SQLServerConnection(toString());
/* 1012 */       localSQLServerConnection.connect(localProperties, null);
/*      */     }
/* 1014 */     loggerExternal.exiting(getClassNameLogging(), "connect", localSQLServerConnection);
/* 1015 */     return localSQLServerConnection;
/*      */   }
/*      */ 
/*      */   private final Properties parseAndMergeProperties(String paramString, Properties paramProperties)
/*      */     throws SQLServerException
/*      */   {
/* 1021 */     if (paramString == null)
/*      */     {
/* 1023 */       throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
/*      */     }
/*      */ 
/* 1026 */     Properties localProperties = Util.parseUrl(paramString, drLogger);
/* 1027 */     if (localProperties == null) {
/* 1028 */       return null;
/*      */     }
/*      */ 
/* 1031 */     int i = DriverManager.getLoginTimeout();
/* 1032 */     if (i > 0)
/*      */     {
/* 1034 */       localProperties.put(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), new Integer(i).toString());
/*      */     }
/*      */ 
/* 1038 */     localProperties = mergeURLAndSuppliedProperties(localProperties, paramProperties);
/* 1039 */     return localProperties;
/*      */   }
/*      */ 
/*      */   public boolean acceptsURL(String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 1045 */     loggerExternal.entering(getClassNameLogging(), "acceptsURL", "Arguments not traced.");
/* 1046 */     boolean bool = false;
/*      */     try
/*      */     {
/* 1049 */       bool = Util.parseUrl(paramString, drLogger) != null;
/*      */     }
/*      */     catch (SQLServerException localSQLServerException)
/*      */     {
/* 1054 */       bool = false;
/*      */     }
/* 1056 */     loggerExternal.exiting(getClassNameLogging(), "acceptsURL", Boolean.valueOf(bool));
/* 1057 */     return bool;
/*      */   }
/*      */ 
/*      */   public DriverPropertyInfo[] getPropertyInfo(String paramString, Properties paramProperties) throws SQLServerException
/*      */   {
/* 1062 */     loggerExternal.entering(getClassNameLogging(), "getPropertyInfo", "Arguments not traced.");
/*      */ 
/* 1065 */     Properties localProperties = parseAndMergeProperties(paramString, paramProperties);
/*      */ 
/* 1067 */     if (null == localProperties)
/* 1068 */       throw new SQLServerException(null, SQLServerException.getErrString("R_invalidConnection"), null, 0, false);
/* 1069 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = getPropertyInfoFromProperties(localProperties);
/* 1070 */     loggerExternal.exiting(getClassNameLogging(), "getPropertyInfo");
/*      */ 
/* 1072 */     return arrayOfDriverPropertyInfo;
/*      */   }
/*      */ 
/*      */   static final DriverPropertyInfo[] getPropertyInfoFromProperties(Properties paramProperties)
/*      */   {
/* 1077 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = new DriverPropertyInfo[DRIVER_PROPERTIES.length];
/*      */ 
/* 1079 */     for (int i = 0; i < DRIVER_PROPERTIES.length; i++)
/* 1080 */       arrayOfDriverPropertyInfo[i] = DRIVER_PROPERTIES[i].build(paramProperties);
/* 1081 */     return arrayOfDriverPropertyInfo;
/*      */   }
/*      */ 
/*      */   public int getMajorVersion()
/*      */   {
/* 1086 */     loggerExternal.entering(getClassNameLogging(), "getMajorVersion");
/* 1087 */     loggerExternal.exiting(getClassNameLogging(), "getMajorVersion", new Integer(4));
/* 1088 */     return 4;
/*      */   }
/*      */ 
/*      */   public int getMinorVersion()
/*      */   {
/* 1093 */     loggerExternal.entering(getClassNameLogging(), "getMinorVersion");
/* 1094 */     loggerExternal.exiting(getClassNameLogging(), "getMinorVersion", new Integer(0));
/* 1095 */     return 0;
/*      */   }
/*      */ 
/*      */   public boolean jdbcCompliant() {
/* 1099 */     loggerExternal.entering(getClassNameLogging(), "jdbcCompliant");
/* 1100 */     loggerExternal.exiting(getClassNameLogging(), "jdbcCompliant", Boolean.valueOf(true));
/* 1101 */     return true;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*  903 */       DriverManager.registerDriver(new SQLServerDriver());
/*      */     }
/*      */     catch (SQLException localSQLException) {
/*  906 */       localSQLException.printStackTrace();
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerDriver
 * JD-Core Version:    0.6.0
 */