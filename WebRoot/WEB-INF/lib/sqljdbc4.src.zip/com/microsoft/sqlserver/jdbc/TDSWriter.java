/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ final class TDSWriter
/*      */ {
/*      */   private static Logger logger;
/*      */   private final String traceID;
/*      */   private final TDSChannel tdsChannel;
/*      */   private final SQLServerConnection con;
/* 2902 */   private boolean dataIsLoggable = true;
/*      */ 
/* 2905 */   private TDSCommand command = null;
/*      */   private byte tdsMessageType;
/* 2912 */   private volatile int sendResetConnection = 0;
/*      */ 
/* 2918 */   private int currentPacketSize = 0;
/*      */   private static final int TDS_PACKET_HEADER_SIZE = 8;
/*      */   private static final byte[] placeholderHeader;
/* 2933 */   private byte[] valueBytes = new byte[256];
/*      */ 
/* 2936 */   private volatile int packetNum = 0;
/*      */ 
/* 2941 */   private boolean isEOMSent = false;
/*      */   private ByteBuffer stagingBuffer;
/*      */   private ByteBuffer socketBuffer;
/*      */   private ByteBuffer logBuffer;
/*      */ 
/*      */   public final String toString()
/*      */   {
/* 2893 */     return this.traceID;
/*      */   }
/*      */ 
/*      */   void setDataLoggable(boolean paramBoolean)
/*      */   {
/* 2903 */     this.dataIsLoggable = paramBoolean;
/*      */   }
/*      */ 
/*      */   boolean isEOMSent()
/*      */   {
/* 2944 */     return this.isEOMSent;
/*      */   }
/*      */ 
/*      */   TDSWriter(TDSChannel paramTDSChannel, SQLServerConnection paramSQLServerConnection)
/*      */   {
/* 2954 */     this.tdsChannel = paramTDSChannel;
/* 2955 */     this.con = paramSQLServerConnection;
/* 2956 */     this.traceID = ("TDSWriter@" + Integer.toHexString(hashCode()) + " (" + paramSQLServerConnection.toString() + ")");
/*      */   }
/*      */ 
/*      */   void preparePacket()
/*      */     throws SQLServerException
/*      */   {
/* 2963 */     if (this.tdsChannel.isLoggingPackets())
/*      */     {
/* 2965 */       Arrays.fill(this.logBuffer.array(), -2);
/* 2966 */       this.logBuffer.clear();
/*      */     }
/*      */ 
/* 2971 */     writeBytes(placeholderHeader);
/*      */   }
/*      */ 
/*      */   void writeMessageHeader()
/*      */     throws SQLServerException
/*      */   {
/* 2983 */     if ((1 == this.tdsMessageType) || (14 == this.tdsMessageType) || (3 == this.tdsMessageType))
/*      */     {
/* 2987 */       int i = 0;
/* 2988 */       int j = 22;
/* 2989 */       if ((1 == this.tdsMessageType) || (3 == this.tdsMessageType))
/*      */       {
/* 2991 */         if ((this.con.isDenaliOrLater()) && (!ActivityCorrelator.getCurrent().IsSentToServer()) && (Util.IsActivityTraceOn()))
/*      */         {
/* 2993 */           i = 1;
/* 2994 */           j += 26;
/*      */         }
/*      */       }
/* 2997 */       writeInt(j);
/* 2998 */       writeInt(18);
/* 2999 */       writeShort(2);
/* 3000 */       writeBytes(this.con.getTransactionDescriptor());
/* 3001 */       writeInt(1);
/* 3002 */       if (i != 0)
/*      */       {
/* 3004 */         writeInt(26);
/* 3005 */         writeTraceHeaderData();
/* 3006 */         ActivityCorrelator.setCurrentActivityIdSentFlag();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeTraceHeaderData()
/*      */     throws SQLServerException
/*      */   {
/* 3014 */     ActivityId localActivityId = ActivityCorrelator.getCurrent();
/* 3015 */     byte[] arrayOfByte = Util.asGuidByteArray(localActivityId.getId());
/* 3016 */     long l = localActivityId.getSequence();
/* 3017 */     writeShort(3);
/* 3018 */     writeBytes(arrayOfByte, 0, arrayOfByte.length);
/* 3019 */     writeInt((int)l);
/*      */ 
/* 3021 */     if (logger.isLoggable(Level.FINER))
/* 3022 */       logger.finer("Send Trace Header - ActivityID: " + localActivityId.toString());
/*      */   }
/*      */ 
/*      */   void startMessage(TDSCommand paramTDSCommand, byte paramByte)
/*      */     throws SQLServerException
/*      */   {
/* 3033 */     this.command = paramTDSCommand;
/* 3034 */     this.tdsMessageType = paramByte;
/* 3035 */     this.packetNum = 0;
/* 3036 */     this.isEOMSent = false;
/* 3037 */     this.dataIsLoggable = true;
/*      */ 
/* 3042 */     int i = this.con.getTDSPacketSize();
/* 3043 */     if (this.currentPacketSize != i)
/*      */     {
/* 3045 */       this.socketBuffer = ByteBuffer.allocate(i).order(ByteOrder.LITTLE_ENDIAN);
/* 3046 */       this.stagingBuffer = ByteBuffer.allocate(i).order(ByteOrder.LITTLE_ENDIAN);
/* 3047 */       this.logBuffer = ByteBuffer.allocate(i).order(ByteOrder.LITTLE_ENDIAN);
/* 3048 */       this.currentPacketSize = i;
/*      */     }
/*      */ 
/* 3051 */     this.socketBuffer.position(this.socketBuffer.limit());
/* 3052 */     this.stagingBuffer.clear();
/*      */ 
/* 3054 */     preparePacket();
/* 3055 */     writeMessageHeader();
/*      */   }
/*      */ 
/*      */   final void endMessage() throws SQLServerException
/*      */   {
/* 3060 */     if (logger.isLoggable(Level.FINEST))
/* 3061 */       logger.finest(toString() + " Finishing TDS message");
/* 3062 */     writePacket(1);
/*      */   }
/*      */ 
/*      */   final boolean ignoreMessage()
/*      */     throws SQLServerException
/*      */   {
/* 3070 */     if (this.packetNum > 0)
/*      */     {
/* 3072 */       assert (!this.isEOMSent);
/*      */ 
/* 3074 */       if (logger.isLoggable(Level.FINER))
/* 3075 */         logger.finest(toString() + " Finishing TDS message by sending ignore bit and end of message");
/* 3076 */       writePacket(3);
/* 3077 */       return true;
/*      */     }
/* 3079 */     return false;
/*      */   }
/*      */ 
/*      */   final void resetPooledConnection()
/*      */   {
/* 3084 */     if (logger.isLoggable(Level.FINEST))
/* 3085 */       logger.finest(toString() + " resetPooledConnection");
/* 3086 */     this.sendResetConnection = 8;
/*      */   }
/*      */ 
/*      */   void writeByte(byte paramByte)
/*      */     throws SQLServerException
/*      */   {
/* 3093 */     if (this.stagingBuffer.remaining() >= 1)
/*      */     {
/* 3095 */       this.stagingBuffer.put(paramByte);
/* 3096 */       if (this.tdsChannel.isLoggingPackets())
/*      */       {
/* 3098 */         if (this.dataIsLoggable)
/* 3099 */           this.logBuffer.put(paramByte);
/*      */         else
/* 3101 */           this.logBuffer.position(this.logBuffer.position() + 1);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 3106 */       this.valueBytes[0] = paramByte;
/* 3107 */       writeWrappedBytes(this.valueBytes, 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeChar(char paramChar) throws SQLServerException
/*      */   {
/* 3113 */     if (this.stagingBuffer.remaining() >= 2)
/*      */     {
/* 3115 */       this.stagingBuffer.putChar(paramChar);
/* 3116 */       if (this.tdsChannel.isLoggingPackets())
/*      */       {
/* 3118 */         if (this.dataIsLoggable)
/* 3119 */           this.logBuffer.putChar(paramChar);
/*      */         else
/* 3121 */           this.logBuffer.position(this.logBuffer.position() + 2);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 3126 */       Util.writeShort((short)paramChar, this.valueBytes, 0);
/* 3127 */       writeWrappedBytes(this.valueBytes, 2);
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeShort(short paramShort) throws SQLServerException
/*      */   {
/* 3133 */     if (this.stagingBuffer.remaining() >= 2)
/*      */     {
/* 3135 */       this.stagingBuffer.putShort(paramShort);
/* 3136 */       if (this.tdsChannel.isLoggingPackets())
/*      */       {
/* 3138 */         if (this.dataIsLoggable)
/* 3139 */           this.logBuffer.putShort(paramShort);
/*      */         else
/* 3141 */           this.logBuffer.position(this.logBuffer.position() + 2);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 3146 */       Util.writeShort(paramShort, this.valueBytes, 0);
/* 3147 */       writeWrappedBytes(this.valueBytes, 2);
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeInt(int paramInt) throws SQLServerException
/*      */   {
/* 3153 */     if (this.stagingBuffer.remaining() >= 4)
/*      */     {
/* 3155 */       this.stagingBuffer.putInt(paramInt);
/* 3156 */       if (this.tdsChannel.isLoggingPackets())
/*      */       {
/* 3158 */         if (this.dataIsLoggable)
/* 3159 */           this.logBuffer.putInt(paramInt);
/*      */         else
/* 3161 */           this.logBuffer.position(this.logBuffer.position() + 4);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 3166 */       Util.writeInt(paramInt, this.valueBytes, 0);
/* 3167 */       writeWrappedBytes(this.valueBytes, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeLong(long paramLong) throws SQLServerException
/*      */   {
/* 3173 */     if (this.stagingBuffer.remaining() >= 8)
/*      */     {
/* 3175 */       this.stagingBuffer.putLong(paramLong);
/* 3176 */       if (this.tdsChannel.isLoggingPackets())
/*      */       {
/* 3178 */         if (this.dataIsLoggable)
/* 3179 */           this.logBuffer.putLong(paramLong);
/*      */         else
/* 3181 */           this.logBuffer.position(this.logBuffer.position() + 8);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 3186 */       this.valueBytes[0] = (byte)(int)(paramLong >> 0 & 0xFF);
/* 3187 */       this.valueBytes[1] = (byte)(int)(paramLong >> 8 & 0xFF);
/* 3188 */       this.valueBytes[2] = (byte)(int)(paramLong >> 16 & 0xFF);
/* 3189 */       this.valueBytes[3] = (byte)(int)(paramLong >> 24 & 0xFF);
/* 3190 */       this.valueBytes[4] = (byte)(int)(paramLong >> 32 & 0xFF);
/* 3191 */       this.valueBytes[5] = (byte)(int)(paramLong >> 40 & 0xFF);
/* 3192 */       this.valueBytes[6] = (byte)(int)(paramLong >> 48 & 0xFF);
/* 3193 */       this.valueBytes[7] = (byte)(int)(paramLong >> 56 & 0xFF);
/* 3194 */       writeWrappedBytes(this.valueBytes, 8);
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeBytes(byte[] paramArrayOfByte) throws SQLServerException
/*      */   {
/* 3200 */     writeBytes(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */   }
/*      */ 
/*      */   void writeBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 3205 */     assert (paramInt2 <= paramArrayOfByte.length);
/*      */ 
/* 3207 */     int i = 0;
/*      */ 
/* 3210 */     if (logger.isLoggable(Level.FINEST))
/* 3211 */       logger.finest(toString() + " Writing " + paramInt2 + " bytes");
/*      */     int j;
/* 3213 */     while ((j = paramInt2 - i) > 0)
/*      */     {
/* 3215 */       if (0 == this.stagingBuffer.remaining()) {
/* 3216 */         writePacket(0);
/*      */       }
/* 3218 */       if (j > this.stagingBuffer.remaining()) {
/* 3219 */         j = this.stagingBuffer.remaining();
/*      */       }
/* 3221 */       this.stagingBuffer.put(paramArrayOfByte, paramInt1 + i, j);
/* 3222 */       if (this.tdsChannel.isLoggingPackets())
/*      */       {
/* 3224 */         if (this.dataIsLoggable)
/* 3225 */           this.logBuffer.put(paramArrayOfByte, paramInt1 + i, j);
/*      */         else {
/* 3227 */           this.logBuffer.position(this.logBuffer.position() + j);
/*      */         }
/*      */       }
/* 3230 */       i += j;
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeWrappedBytes(byte[] paramArrayOfByte, int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 3239 */     assert (paramInt <= paramArrayOfByte.length);
/* 3240 */     assert (this.stagingBuffer.remaining() < paramInt);
/* 3241 */     assert (paramInt <= this.stagingBuffer.capacity());
/*      */ 
/* 3244 */     int i = this.stagingBuffer.remaining();
/* 3245 */     if (i > 0)
/*      */     {
/* 3247 */       this.stagingBuffer.put(paramArrayOfByte, 0, i);
/* 3248 */       if (this.tdsChannel.isLoggingPackets())
/*      */       {
/* 3250 */         if (this.dataIsLoggable)
/* 3251 */           this.logBuffer.put(paramArrayOfByte, 0, i);
/*      */         else {
/* 3253 */           this.logBuffer.position(this.logBuffer.position() + i);
/*      */         }
/*      */       }
/*      */     }
/* 3257 */     writePacket(0);
/*      */ 
/* 3261 */     this.stagingBuffer.put(paramArrayOfByte, i, paramInt - i);
/* 3262 */     if (this.tdsChannel.isLoggingPackets())
/*      */     {
/* 3264 */       if (this.dataIsLoggable)
/* 3265 */         this.logBuffer.put(paramArrayOfByte, i, paramInt - i);
/*      */       else
/* 3267 */         this.logBuffer.position(this.logBuffer.position() + i);
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeString(String paramString) throws SQLServerException
/*      */   {
/* 3273 */     int i = 0;
/* 3274 */     int j = paramString.length();
/* 3275 */     while (i < j)
/*      */     {
/* 3277 */       int k = 2 * (j - i);
/*      */ 
/* 3279 */       if (k > this.valueBytes.length) {
/* 3280 */         k = this.valueBytes.length;
/*      */       }
/* 3282 */       int m = 0;
/* 3283 */       while (m < k)
/*      */       {
/* 3285 */         int n = paramString.charAt(i++);
/* 3286 */         this.valueBytes[(m++)] = (byte)(n >> 0 & 0xFF);
/* 3287 */         this.valueBytes[(m++)] = (byte)(n >> 8 & 0xFF);
/*      */       }
/*      */ 
/* 3290 */       writeBytes(this.valueBytes, 0, m); } 
/*      */   }
/* 3299 */   void writeStream(InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLServerException { assert ((-1L == paramLong) || (paramLong >= 0L));
/*      */ 
/* 3301 */     long l = 0L;
/* 3302 */     byte[] arrayOfByte = new byte[4 * this.currentPacketSize];
/* 3303 */     int i = 0;
/*      */     int j;
/*      */     Object localObject;
/*      */     MessageFormat localMessageFormat;
/*      */     do { for (j = 0; (-1 != i) && (j < arrayOfByte.length); j += i)
/*      */       {
/*      */         try
/*      */         {
/* 3312 */           i = paramInputStream.read(arrayOfByte, j, arrayOfByte.length - j);
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3316 */           localObject = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 3317 */           Object[] arrayOfObject = { localIOException.toString() };
/* 3318 */           error(((MessageFormat)localObject).format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
/*      */         }
/*      */ 
/* 3321 */         if (-1 == i)
/*      */         {
/*      */           break;
/*      */         }
/* 3325 */         if ((i >= 0) && (i <= arrayOfByte.length - j))
/*      */           continue;
/* 3327 */         localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 3328 */         localObject = new Object[] { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
/* 3329 */         error(localMessageFormat.format(localObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
/*      */       }
/*      */ 
/* 3334 */       if (paramBoolean) {
/* 3335 */         writeInt(j);
/*      */       }
/* 3337 */       writeBytes(arrayOfByte, 0, j);
/* 3338 */       l += j;
/*      */     }
/* 3340 */     while ((-1 != i) || (j > 0));
/*      */ 
/* 3344 */     if ((-1L != paramLong) && (l != paramLong))
/*      */     {
/* 3346 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 3347 */       localObject = new Object[] { Long.valueOf(paramLong), Long.valueOf(l) };
/* 3348 */       error(localMessageFormat.format(localObject), SQLState.DATA_EXCEPTION_LENGTH_MISMATCH, DriverError.NOT_SET);
/*      */     } } 
/*      */   void writeReader(Reader paramReader, long paramLong, boolean paramBoolean) throws SQLServerException {
/* 3357 */     assert ((-1L == paramLong) || (paramLong >= 0L));
/*      */ 
/* 3359 */     long l = 0L;
/* 3360 */     char[] arrayOfChar = new char[2 * this.currentPacketSize];
/* 3361 */     byte[] arrayOfByte = new byte[4 * this.currentPacketSize];
/* 3362 */     int i = 0;
/*      */     int j;
/*      */     Object localObject;
/*      */     do { for (j = 0; (-1 != i) && (j < arrayOfChar.length); j += i)
/*      */       {
/*      */         try
/*      */         {
/* 3371 */           i = paramReader.read(arrayOfChar, j, arrayOfChar.length - j);
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3375 */           localObject = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 3376 */           Object[] arrayOfObject = { localIOException.toString() };
/* 3377 */           error(((MessageFormat)localObject).format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
/*      */         }
/*      */ 
/* 3380 */         if (-1 == i)
/*      */         {
/*      */           break;
/*      */         }
/* 3384 */         if ((i >= 0) && (i <= arrayOfChar.length - j))
/*      */           continue;
/* 3386 */         MessageFormat localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 3387 */         localObject = new Object[] { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
/* 3388 */         error(localMessageFormat1.format(localObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
/*      */       }
/*      */ 
/* 3393 */       if (paramBoolean) {
/* 3394 */         writeInt(2 * j);
/*      */       }
/*      */ 
/* 3401 */       for (int k = 0; k < j; k++)
/*      */       {
/* 3403 */         arrayOfByte[(2 * k)] = (byte)(arrayOfChar[k] >> '\000' & 0xFF);
/* 3404 */         arrayOfByte[(2 * k + 1)] = (byte)(arrayOfChar[k] >> '\b' & 0xFF);
/*      */       }
/*      */ 
/* 3407 */       writeBytes(arrayOfByte, 0, 2 * j);
/* 3408 */       l += j;
/*      */     }
/* 3410 */     while ((-1 != i) || (j > 0));
/*      */ 
/* 3414 */     if ((-1L != paramLong) && (l != paramLong))
/*      */     {
/* 3416 */       MessageFormat localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 3417 */       localObject = new Object[] { Long.valueOf(paramLong), Long.valueOf(l) };
/* 3418 */       error(localMessageFormat2.format(localObject), SQLState.DATA_EXCEPTION_LENGTH_MISMATCH, DriverError.NOT_SET);
/*      */     }
/*      */   }
/*      */ 
/*      */   final void error(String paramString, SQLState paramSQLState, DriverError paramDriverError) throws SQLServerException
/*      */   {
/* 3424 */     assert (null != this.command);
/* 3425 */     this.command.interrupt(paramString);
/* 3426 */     throw new SQLServerException(paramString, paramSQLState, paramDriverError, null);
/*      */   }
/*      */ 
/*      */   final boolean sendAttention()
/*      */     throws SQLServerException
/*      */   {
/* 3445 */     if (this.packetNum > 0)
/*      */     {
/* 3454 */       if (logger.isLoggable(Level.FINE)) {
/* 3455 */         logger.fine(this + ": sending attention...");
/*      */       }
/* 3457 */       this.tdsChannel.numMsgsSent += 1;
/*      */ 
/* 3459 */       startMessage(this.command, 6);
/* 3460 */       endMessage();
/*      */ 
/* 3462 */       return true;
/*      */     }
/*      */ 
/* 3465 */     return false;
/*      */   }
/*      */ 
/*      */   private final void writePacket(int paramInt) throws SQLServerException
/*      */   {
/* 3470 */     boolean bool = 1 == (0x1 & paramInt);
/* 3471 */     int i = (6 == this.tdsMessageType) || ((paramInt & 0x2) == 2) ? 1 : 0;
/*      */ 
/* 3476 */     if ((null != this.command) && (i == 0)) {
/* 3477 */       this.command.checkForInterrupt();
/*      */     }
/* 3479 */     writePacketHeader(paramInt | this.sendResetConnection);
/* 3480 */     this.sendResetConnection = 0;
/*      */ 
/* 3482 */     flush(bool);
/*      */ 
/* 3489 */     if (bool)
/*      */     {
/* 3491 */       flush(bool);
/* 3492 */       this.isEOMSent = true;
/* 3493 */       this.tdsChannel.numMsgsSent += 1;
/*      */     }
/*      */ 
/* 3498 */     if ((16 == this.tdsMessageType) && (1 == this.packetNum) && (0 == this.con.getNegotiatedEncryptionLevel()))
/*      */     {
/* 3502 */       this.tdsChannel.disableSSL();
/*      */     }
/*      */ 
/* 3507 */     if ((null != this.command) && (i == 0) && (bool))
/* 3508 */       this.command.onRequestComplete();
/*      */   }
/*      */ 
/*      */   private final void writePacketHeader(int paramInt)
/*      */   {
/* 3513 */     int i = this.stagingBuffer.position();
/* 3514 */     this.packetNum += 1;
/*      */ 
/* 3517 */     this.stagingBuffer.put(0, this.tdsMessageType);
/* 3518 */     this.stagingBuffer.put(1, (byte)paramInt);
/* 3519 */     this.stagingBuffer.put(2, (byte)(i >> 8 & 0xFF));
/* 3520 */     this.stagingBuffer.put(3, (byte)(i >> 0 & 0xFF));
/* 3521 */     this.stagingBuffer.put(4, (byte)(this.tdsChannel.getSPID() >> 8 & 0xFF));
/* 3522 */     this.stagingBuffer.put(5, (byte)(this.tdsChannel.getSPID() >> 0 & 0xFF));
/* 3523 */     this.stagingBuffer.put(6, (byte)(this.packetNum % 256));
/* 3524 */     this.stagingBuffer.put(7, 0);
/*      */ 
/* 3527 */     if (this.tdsChannel.isLoggingPackets())
/*      */     {
/* 3529 */       this.logBuffer.put(0, this.tdsMessageType);
/* 3530 */       this.logBuffer.put(1, (byte)paramInt);
/* 3531 */       this.logBuffer.put(2, (byte)(i >> 8 & 0xFF));
/* 3532 */       this.logBuffer.put(3, (byte)(i >> 0 & 0xFF));
/* 3533 */       this.logBuffer.put(4, (byte)(this.tdsChannel.getSPID() >> 8 & 0xFF));
/* 3534 */       this.logBuffer.put(5, (byte)(this.tdsChannel.getSPID() >> 0 & 0xFF));
/* 3535 */       this.logBuffer.put(6, (byte)(this.packetNum % 256));
/* 3536 */       this.logBuffer.put(7, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   void flush(boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3543 */     this.tdsChannel.write(this.socketBuffer.array(), this.socketBuffer.position(), this.socketBuffer.remaining());
/* 3544 */     this.socketBuffer.position(this.socketBuffer.limit());
/*      */ 
/* 3549 */     if (this.stagingBuffer.position() >= 8)
/*      */     {
/* 3552 */       ByteBuffer localByteBuffer = this.stagingBuffer;
/* 3553 */       this.stagingBuffer = this.socketBuffer;
/* 3554 */       this.socketBuffer = localByteBuffer;
/*      */ 
/* 3562 */       this.socketBuffer.flip();
/* 3563 */       this.stagingBuffer.clear();
/*      */ 
/* 3567 */       if (this.tdsChannel.isLoggingPackets())
/*      */       {
/* 3569 */         this.tdsChannel.logPacket(this.logBuffer.array(), 0, this.socketBuffer.limit(), toString() + " sending packet (" + this.socketBuffer.limit() + " bytes)");
/*      */       }
/*      */ 
/* 3577 */       if (!paramBoolean) {
/* 3578 */         preparePacket();
/*      */       }
/*      */ 
/* 3581 */       this.tdsChannel.write(this.socketBuffer.array(), this.socketBuffer.position(), this.socketBuffer.remaining());
/* 3582 */       this.socketBuffer.position(this.socketBuffer.limit());
/*      */     }
/*      */   }
/*      */ 
/*      */   private void writeRPCNameValType(String paramString, boolean paramBoolean, TDSType paramTDSType)
/*      */     throws SQLServerException
/*      */   {
/* 3597 */     int i = 0;
/*      */ 
/* 3599 */     if (null != paramString) {
/* 3600 */       i = paramString.length() + 1;
/*      */     }
/* 3602 */     writeByte((byte)i);
/* 3603 */     if (i > 0)
/*      */     {
/* 3605 */       writeChar('@');
/* 3606 */       writeString(paramString);
/*      */     }
/*      */ 
/* 3609 */     writeByte((byte)(paramBoolean ? 1 : 0));
/* 3610 */     writeByte(paramTDSType.byteValue());
/*      */   }
/*      */ 
/*      */   void writeRPCBit(String paramString, Boolean paramBoolean, boolean paramBoolean1)
/*      */     throws SQLServerException
/*      */   {
/* 3621 */     writeRPCNameValType(paramString, paramBoolean1, TDSType.BITN);
/* 3622 */     writeByte(1);
/* 3623 */     if (null == paramBoolean)
/*      */     {
/* 3625 */       writeByte(0);
/*      */     }
/*      */     else
/*      */     {
/* 3629 */       writeByte(1);
/* 3630 */       writeByte((byte)(paramBoolean.booleanValue() ? 1 : 0));
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCByte(String paramString, Byte paramByte, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3642 */     writeRPCNameValType(paramString, paramBoolean, TDSType.INTN);
/* 3643 */     writeByte(1);
/* 3644 */     if (null == paramByte)
/*      */     {
/* 3646 */       writeByte(0);
/*      */     }
/*      */     else
/*      */     {
/* 3650 */       writeByte(1);
/* 3651 */       writeByte(paramByte.byteValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCShort(String paramString, Short paramShort, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3663 */     writeRPCNameValType(paramString, paramBoolean, TDSType.INTN);
/* 3664 */     writeByte(2);
/* 3665 */     if (null == paramShort)
/*      */     {
/* 3667 */       writeByte(0);
/*      */     }
/*      */     else
/*      */     {
/* 3671 */       writeByte(2);
/* 3672 */       writeShort(paramShort.shortValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCInt(String paramString, Integer paramInteger, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3684 */     writeRPCNameValType(paramString, paramBoolean, TDSType.INTN);
/* 3685 */     writeByte(4);
/* 3686 */     if (null == paramInteger)
/*      */     {
/* 3688 */       writeByte(0);
/*      */     }
/*      */     else
/*      */     {
/* 3692 */       writeByte(4);
/* 3693 */       writeInt(paramInteger.intValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCLong(String paramString, Long paramLong, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3705 */     writeRPCNameValType(paramString, paramBoolean, TDSType.INTN);
/* 3706 */     writeByte(8);
/* 3707 */     if (null == paramLong)
/*      */     {
/* 3709 */       writeByte(0);
/*      */     }
/*      */     else
/*      */     {
/* 3713 */       writeByte(8);
/* 3714 */       writeLong(paramLong.longValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCReal(String paramString, Float paramFloat, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3727 */     writeRPCNameValType(paramString, paramBoolean, TDSType.FLOATN);
/*      */ 
/* 3730 */     if (null == paramFloat)
/*      */     {
/* 3732 */       writeByte(4);
/* 3733 */       writeByte(0);
/*      */     }
/*      */     else
/*      */     {
/* 3737 */       writeByte(4);
/* 3738 */       writeByte(4);
/* 3739 */       writeInt(Float.floatToRawIntBits(paramFloat.floatValue()));
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCDouble(String paramString, Double paramDouble, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3751 */     writeRPCNameValType(paramString, paramBoolean, TDSType.FLOATN);
/*      */ 
/* 3753 */     int i = 8;
/* 3754 */     writeByte((byte)i);
/*      */ 
/* 3757 */     if (null == paramDouble)
/*      */     {
/* 3759 */       writeByte(0);
/*      */     }
/*      */     else
/*      */     {
/* 3763 */       writeByte((byte)i);
/* 3764 */       long l1 = Double.doubleToLongBits(paramDouble.doubleValue());
/* 3765 */       long l2 = 255L;
/* 3766 */       int j = 0;
/* 3767 */       for (int k = 0; k < 8; k++)
/*      */       {
/* 3769 */         writeByte((byte)(int)((l1 & l2) >> j));
/* 3770 */         j += 8;
/* 3771 */         l2 <<= 8;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCBigDecimal(String paramString, BigDecimal paramBigDecimal, int paramInt, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3785 */     writeRPCNameValType(paramString, paramBoolean, TDSType.DECIMALN);
/* 3786 */     writeByte(17);
/* 3787 */     writeByte(38);
/*      */ 
/* 3789 */     byte[] arrayOfByte = DDC.convertBigDecimalToBytes(paramBigDecimal, paramInt);
/* 3790 */     writeBytes(arrayOfByte, 0, arrayOfByte.length);
/*      */   }
/*      */ 
/*      */   void writeVMaxHeader(long paramLong, boolean paramBoolean, SQLCollation paramSQLCollation)
/*      */     throws SQLServerException
/*      */   {
/* 3802 */     writeShort(-1);
/*      */ 
/* 3805 */     if (null != paramSQLCollation) {
/* 3806 */       paramSQLCollation.writeCollation(this);
/*      */     }
/*      */ 
/* 3809 */     if (paramBoolean)
/*      */     {
/* 3812 */       writeLong(-1L);
/*      */     }
/* 3814 */     else if (-1L == paramLong)
/*      */     {
/* 3818 */       writeLong(-2L);
/*      */     }
/*      */     else
/*      */     {
/* 3826 */       writeLong(paramLong);
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCStringUnicode(String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 3835 */     writeRPCStringUnicode(null, paramString, false, null);
/*      */   }
/*      */ 
/*      */   void writeRPCStringUnicode(String paramString1, String paramString2, boolean paramBoolean, SQLCollation paramSQLCollation)
/*      */     throws SQLServerException
/*      */   {
/* 3851 */     boolean bool = paramString2 == null;
/* 3852 */     int i = bool ? 0 : 2 * paramString2.length();
/* 3853 */     int j = i <= 8000 ? 1 : 0;
/*      */ 
/* 3857 */     if (null == paramSQLCollation) {
/* 3858 */       paramSQLCollation = this.con.getDatabaseCollation();
/*      */     }
/*      */ 
/* 3861 */     int k = (j == 0) || (paramBoolean) ? 1 : 0;
/* 3862 */     if (k != 0)
/*      */     {
/* 3864 */       writeRPCNameValType(paramString1, paramBoolean, TDSType.NVARCHAR);
/*      */ 
/* 3867 */       writeVMaxHeader(i, bool, paramSQLCollation);
/*      */ 
/* 3873 */       if (!bool)
/*      */       {
/* 3875 */         if (i > 0)
/*      */         {
/* 3877 */           writeInt(i);
/* 3878 */           writeString(paramString2);
/*      */         }
/*      */ 
/* 3882 */         writeInt(0);
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 3888 */       if (j != 0)
/*      */       {
/* 3890 */         writeRPCNameValType(paramString1, paramBoolean, TDSType.NVARCHAR);
/* 3891 */         writeShort(8000);
/*      */       }
/*      */       else
/*      */       {
/* 3895 */         writeRPCNameValType(paramString1, paramBoolean, TDSType.NTEXT);
/* 3896 */         writeInt(2147483647);
/*      */       }
/*      */ 
/* 3899 */       paramSQLCollation.writeCollation(this);
/*      */ 
/* 3902 */       if (bool)
/*      */       {
/* 3904 */         writeShort(-1);
/*      */       }
/*      */       else
/*      */       {
/* 3909 */         if (j != 0)
/* 3910 */           writeShort((short)i);
/*      */         else {
/* 3912 */           writeInt(i);
/*      */         }
/*      */ 
/* 3915 */         if (0 != i)
/* 3916 */           writeString(paramString2);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCByteArray(String paramString, byte[] paramArrayOfByte, boolean paramBoolean, JDBCType paramJDBCType, SQLCollation paramSQLCollation)
/*      */     throws SQLServerException
/*      */   {
/* 3937 */     boolean bool = paramArrayOfByte == null;
/* 3938 */     int i = bool ? 0 : paramArrayOfByte.length;
/* 3939 */     int j = i <= 8000 ? 1 : 0;
/*      */ 
/* 3942 */     int k = (j == 0) || (paramBoolean) ? 1 : 0;
/*      */     TDSType localTDSType;
/* 3946 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*      */     {
/*      */     case 1:
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*      */     default:
/* 3953 */       localTDSType = (j != 0) || (k != 0) ? TDSType.BIGVARBINARY : TDSType.IMAGE;
/* 3954 */       paramSQLCollation = null;
/* 3955 */       break;
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*      */     case 8:
/* 3961 */       localTDSType = (j != 0) || (k != 0) ? TDSType.BIGVARCHAR : TDSType.TEXT;
/* 3962 */       if (null != paramSQLCollation) break;
/* 3963 */       paramSQLCollation = this.con.getDatabaseCollation(); break;
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/* 3970 */       localTDSType = (j != 0) || (k != 0) ? TDSType.NVARCHAR : TDSType.NTEXT;
/* 3971 */       if (null != paramSQLCollation) break;
/* 3972 */       paramSQLCollation = this.con.getDatabaseCollation();
/*      */     }
/*      */ 
/* 3976 */     writeRPCNameValType(paramString, paramBoolean, localTDSType);
/*      */ 
/* 3978 */     if (k != 0)
/*      */     {
/* 3981 */       writeVMaxHeader(i, bool, paramSQLCollation);
/*      */ 
/* 3984 */       if (!bool)
/*      */       {
/* 3986 */         if (i > 0)
/*      */         {
/* 3988 */           writeInt(i);
/* 3989 */           writeBytes(paramArrayOfByte);
/*      */         }
/*      */ 
/* 3993 */         writeInt(0);
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 3999 */       if (j != 0)
/*      */       {
/* 4001 */         writeShort(8000);
/*      */       }
/*      */       else
/*      */       {
/* 4005 */         writeInt(2147483647);
/*      */       }
/*      */ 
/* 4008 */       if (null != paramSQLCollation) {
/* 4009 */         paramSQLCollation.writeCollation(this);
/*      */       }
/*      */ 
/* 4012 */       if (bool)
/*      */       {
/* 4014 */         writeShort(-1);
/*      */       }
/*      */       else
/*      */       {
/* 4018 */         if (j != 0)
/* 4019 */           writeShort((short)i);
/*      */         else {
/* 4021 */           writeInt(i);
/*      */         }
/*      */ 
/* 4024 */         if (0 != i)
/* 4025 */           writeBytes(paramArrayOfByte);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCDateTime(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 4044 */     assert ((paramInt >= 0) && (paramInt < 1000000000)) : ("Invalid subNanoSeconds value: " + paramInt);
/* 4045 */     assert ((paramGregorianCalendar != null) || ((paramGregorianCalendar == null) && (paramInt == 0))) : ("Invalid subNanoSeconds value when calendar is null: " + paramInt);
/*      */ 
/* 4047 */     writeRPCNameValType(paramString, paramBoolean, TDSType.DATETIMEN);
/* 4048 */     writeByte(8);
/*      */ 
/* 4050 */     if (null == paramGregorianCalendar)
/*      */     {
/* 4052 */       writeByte(0);
/* 4053 */       return;
/*      */     }
/*      */ 
/* 4056 */     writeByte(8);
/*      */ 
/* 4075 */     int i = DDC.daysSinceBaseDate(paramGregorianCalendar.get(1), paramGregorianCalendar.get(6), 1900);
/*      */ 
/* 4082 */     int j = (paramInt + 500000) / 1000000 + 1000 * paramGregorianCalendar.get(13) + 60000 * paramGregorianCalendar.get(12) + 3600000 * paramGregorianCalendar.get(11);
/*      */ 
/* 4090 */     if (j >= 86399999)
/*      */     {
/* 4092 */       i++;
/* 4093 */       j = 0;
/*      */     }
/*      */ 
/* 4102 */     if ((i < DDC.daysSinceBaseDate(1753, 1, 1900)) || (i >= DDC.daysSinceBaseDate(10000, 1, 1900)))
/*      */     {
/* 4105 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 4106 */       Object[] arrayOfObject = { SSType.DATETIME };
/* 4107 */       throw new SQLServerException(localMessageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/* 4117 */     writeInt(i);
/*      */ 
/* 4120 */     writeInt((3 * j + 5) / 10);
/*      */   }
/*      */ 
/*      */   void writeRPCTime(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 4130 */     writeRPCNameValType(paramString, paramBoolean, TDSType.TIMEN);
/* 4131 */     writeByte((byte)paramInt2);
/*      */ 
/* 4133 */     if (null == paramGregorianCalendar)
/*      */     {
/* 4135 */       writeByte(0);
/* 4136 */       return;
/*      */     }
/*      */ 
/* 4139 */     writeByte((byte)TDS.timeValueLength(paramInt2));
/* 4140 */     writeScaledTemporal(paramGregorianCalendar, paramInt1, paramInt2, SSType.TIME);
/*      */   }
/*      */ 
/*      */   void writeRPCDate(String paramString, GregorianCalendar paramGregorianCalendar, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 4152 */     writeRPCNameValType(paramString, paramBoolean, TDSType.DATEN);
/* 4153 */     if (null == paramGregorianCalendar)
/*      */     {
/* 4155 */       writeByte(0);
/* 4156 */       return;
/*      */     }
/*      */ 
/* 4159 */     writeByte(3);
/* 4160 */     writeScaledTemporal(paramGregorianCalendar, 0, 0, SSType.DATE);
/*      */   }
/*      */ 
/*      */   void writeRPCDateTime2(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 4174 */     writeRPCNameValType(paramString, paramBoolean, TDSType.DATETIME2N);
/* 4175 */     writeByte((byte)paramInt2);
/*      */ 
/* 4177 */     if (null == paramGregorianCalendar)
/*      */     {
/* 4179 */       writeByte(0);
/* 4180 */       return;
/*      */     }
/*      */ 
/* 4183 */     writeByte((byte)TDS.datetime2ValueLength(paramInt2));
/* 4184 */     writeScaledTemporal(paramGregorianCalendar, paramInt1, paramInt2, SSType.DATETIME2);
/*      */   }
/*      */ 
/*      */   void writeRPCDateTimeOffset(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 4199 */     writeRPCNameValType(paramString, paramBoolean, TDSType.DATETIMEOFFSETN);
/* 4200 */     writeByte((byte)paramInt3);
/*      */ 
/* 4202 */     if (null == paramGregorianCalendar)
/*      */     {
/* 4204 */       writeByte(0);
/* 4205 */       return;
/*      */     }
/*      */ 
/* 4208 */     assert (0 == paramGregorianCalendar.get(15));
/*      */ 
/* 4210 */     writeByte((byte)TDS.datetimeoffsetValueLength(paramInt3));
/* 4211 */     writeScaledTemporal(paramGregorianCalendar, paramInt2, paramInt3, SSType.DATETIMEOFFSET);
/*      */ 
/* 4217 */     writeShort((short)paramInt1);
/*      */   }
/*      */ 
/*      */   private int getRoundedSubSecondNanos(int paramInt)
/*      */   {
/* 4231 */     int i = (paramInt + Nanos.PER_MAX_SCALE_INTERVAL / 2) / Nanos.PER_MAX_SCALE_INTERVAL * Nanos.PER_MAX_SCALE_INTERVAL;
/* 4232 */     return i;
/*      */   }
/*      */ 
/*      */   private void writeScaledTemporal(GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, SSType paramSSType)
/*      */     throws SQLServerException
/*      */   {
/* 4253 */     assert (this.con.isKatmaiOrLater());
/*      */ 
/* 4260 */     assert ((SSType.DATE == paramSSType) || (SSType.TIME == paramSSType) || (SSType.DATETIME2 == paramSSType) || (SSType.DATETIMEOFFSET == paramSSType)) : ("Unexpected SSType: " + paramSSType);
/*      */     int i;
/* 4263 */     if ((SSType.TIME == paramSSType) || (SSType.DATETIME2 == paramSSType) || (SSType.DATETIMEOFFSET == paramSSType))
/*      */     {
/* 4267 */       assert (paramInt1 >= 0);
/* 4268 */       assert (paramInt1 < 1000000000);
/* 4269 */       assert (paramInt2 >= 0);
/* 4270 */       assert (paramInt2 <= 7);
/*      */ 
/* 4272 */       i = paramGregorianCalendar.get(13) + 60 * paramGregorianCalendar.get(12) + 3600 * paramGregorianCalendar.get(11);
/*      */ 
/* 4278 */       long l1 = Nanos.PER_MAX_SCALE_INTERVAL * ()Math.pow(10.0D, 7 - paramInt2);
/*      */ 
/* 4284 */       long l2 = (1000000000L * i + getRoundedSubSecondNanos(paramInt1) + l1 / 2L) / l1;
/*      */ 
/* 4291 */       if (86400000000000L / l1 == l2)
/*      */       {
/* 4295 */         if (SSType.TIME == paramSSType)
/*      */         {
/* 4297 */           l2 -= 1L;
/*      */         }
/*      */         else
/*      */         {
/* 4303 */           assert ((SSType.DATETIME2 == paramSSType) || (SSType.DATETIMEOFFSET == paramSSType)) : ("Unexpected SSType: " + paramSSType);
/*      */ 
/* 4316 */           paramGregorianCalendar.add(13, 1);
/*      */ 
/* 4318 */           if (paramGregorianCalendar.get(1) <= 9999)
/*      */           {
/* 4320 */             l2 = 0L;
/*      */           }
/*      */           else
/*      */           {
/* 4324 */             paramGregorianCalendar.add(13, -1);
/* 4325 */             l2 -= 1L;
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4331 */       int m = TDS.nanosSinceMidnightLength(paramInt2);
/* 4332 */       byte[] arrayOfByte = new byte[m];
/* 4333 */       for (int n = 0; n < m; n++) {
/* 4334 */         arrayOfByte[n] = (byte)(int)(l2 >> 8 * n & 0xFF);
/*      */       }
/* 4336 */       writeBytes(arrayOfByte);
/*      */     }
/*      */ 
/* 4340 */     if ((SSType.DATE == paramSSType) || (SSType.DATETIME2 == paramSSType) || (SSType.DATETIMEOFFSET == paramSSType))
/*      */     {
/* 4352 */       if ((paramGregorianCalendar.getTimeInMillis() < GregorianChange.STANDARD_CHANGE_DATE.getTime()) || (paramGregorianCalendar.getActualMaximum(6) < 365))
/*      */       {
/* 4355 */         i = paramGregorianCalendar.get(1);
/* 4356 */         int j = paramGregorianCalendar.get(2);
/* 4357 */         int k = paramGregorianCalendar.get(5);
/*      */ 
/* 4360 */         paramGregorianCalendar.setGregorianChange(GregorianChange.PURE_CHANGE_DATE);
/*      */ 
/* 4363 */         paramGregorianCalendar.set(i, j, k);
/*      */       }
/*      */ 
/* 4366 */       i = DDC.daysSinceBaseDate(paramGregorianCalendar.get(1), paramGregorianCalendar.get(6), 1);
/*      */ 
/* 4377 */       if ((i < 0) || (i >= DDC.daysSinceBaseDate(10000, 1, 1)))
/*      */       {
/* 4379 */         localObject = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 4380 */         Object[] arrayOfObject = { paramSSType };
/* 4381 */         throw new SQLServerException(((MessageFormat)localObject).format(arrayOfObject), SQLState.DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW, DriverError.NOT_SET, null);
/*      */       }
/*      */ 
/* 4388 */       Object localObject = new byte[3];
/* 4389 */       localObject[0] = (byte)(i >> 0 & 0xFF);
/* 4390 */       localObject[1] = (byte)(i >> 8 & 0xFF);
/* 4391 */       localObject[2] = (byte)(i >> 16 & 0xFF);
/* 4392 */       writeBytes(localObject);
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCInputStream(String paramString, InputStream paramInputStream, long paramLong, boolean paramBoolean, JDBCType paramJDBCType, SQLCollation paramSQLCollation)
/*      */     throws SQLServerException
/*      */   {
/* 4413 */     assert (null != paramInputStream);
/* 4414 */     assert ((-1L == paramLong) || (paramLong >= 0L));
/*      */ 
/* 4418 */     boolean bool = (-1L == paramLong) || (paramLong > 8000L);
/* 4419 */     if (bool)
/*      */     {
/* 4421 */       assert ((-1L == paramLong) || (paramLong <= 2147483647L));
/*      */ 
/* 4423 */       writeRPCNameValType(paramString, paramBoolean, paramJDBCType.isTextual() ? TDSType.BIGVARCHAR : TDSType.BIGVARBINARY);
/*      */ 
/* 4431 */       writeVMaxHeader(paramLong, false, paramJDBCType.isTextual() ? paramSQLCollation : null);
/*      */     }
/*      */     else
/*      */     {
/* 4443 */       if (-1L == paramLong)
/*      */       {
/* 4447 */         ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(8000);
/* 4448 */         paramLong = 0L;
/*      */ 
/* 4452 */         long l = 65535L * this.con.getTDSPacketSize();
/*      */         try
/*      */         {
/* 4456 */           byte[] arrayOfByte = new byte[8000];
/*      */           int j;
/* 4459 */           while ((paramLong < l) && (-1 != (j = paramInputStream.read(arrayOfByte, 0, arrayOfByte.length))))
/*      */           {
/* 4461 */             localByteArrayOutputStream.write(arrayOfByte);
/* 4462 */             paramLong += j;
/*      */           }
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 4467 */           throw new SQLServerException(localIOException.getMessage(), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, localIOException);
/*      */         }
/*      */ 
/* 4474 */         if (paramLong >= l)
/*      */         {
/* 4476 */           MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 4477 */           Object[] arrayOfObject = { Long.valueOf(paramLong) };
/* 4478 */           SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject), "", true);
/*      */         }
/*      */ 
/* 4481 */         assert (paramLong <= 2147483647L);
/* 4482 */         paramInputStream = new ByteArrayInputStream(localByteArrayOutputStream.toByteArray(), 0, (int)paramLong);
/*      */       }
/*      */ 
/* 4485 */       assert ((0L <= paramLong) && (paramLong <= 2147483647L));
/*      */ 
/* 4487 */       int i = paramLong <= 8000L ? 1 : 0;
/*      */ 
/* 4489 */       writeRPCNameValType(paramString, paramBoolean, i != 0 ? TDSType.BIGVARBINARY : paramJDBCType.isTextual() ? TDSType.TEXT : i != 0 ? TDSType.BIGVARCHAR : TDSType.IMAGE);
/*      */ 
/* 4497 */       if (i != 0)
/*      */       {
/* 4499 */         writeShort(8000);
/* 4500 */         if (paramJDBCType.isTextual())
/* 4501 */           paramSQLCollation.writeCollation(this);
/* 4502 */         writeShort((short)(int)paramLong);
/*      */       }
/*      */       else
/*      */       {
/* 4506 */         writeInt(2147483647);
/* 4507 */         if (paramJDBCType.isTextual())
/* 4508 */           paramSQLCollation.writeCollation(this);
/* 4509 */         writeInt((int)paramLong);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4514 */     writeStream(paramInputStream, paramLong, bool);
/*      */   }
/*      */ 
/*      */   void writeRPCXML(String paramString, InputStream paramInputStream, long paramLong, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 4531 */     assert ((-1L == paramLong) || (paramLong >= 0L));
/* 4532 */     assert ((-1L == paramLong) || (paramLong <= 2147483647L));
/*      */ 
/* 4534 */     writeRPCNameValType(paramString, paramBoolean, TDSType.XML);
/*      */ 
/* 4538 */     writeByte(0);
/*      */ 
/* 4540 */     if (null == paramInputStream)
/*      */     {
/* 4543 */       writeLong(-1L);
/*      */     }
/* 4545 */     else if (-1L == paramLong)
/*      */     {
/* 4549 */       writeLong(-2L);
/*      */     }
/*      */     else
/*      */     {
/* 4557 */       writeLong(paramLong);
/*      */     }
/* 4559 */     if (null != paramInputStream)
/*      */     {
/* 4561 */       writeStream(paramInputStream, paramLong, true);
/*      */     }
/*      */   }
/*      */ 
/*      */   void writeRPCReaderUnicode(String paramString, Reader paramReader, long paramLong, boolean paramBoolean, SQLCollation paramSQLCollation)
/*      */     throws SQLServerException
/*      */   {
/* 4580 */     assert (null != paramReader);
/* 4581 */     assert ((-1L == paramLong) || (paramLong >= 0L));
/*      */ 
/* 4585 */     if (null == paramSQLCollation) {
/* 4586 */       paramSQLCollation = this.con.getDatabaseCollation();
/*      */     }
/*      */ 
/* 4590 */     boolean bool = (-1L == paramLong) || (paramLong > 4000L);
/* 4591 */     if (bool)
/*      */     {
/* 4593 */       assert ((-1L == paramLong) || (paramLong <= 1073741823L));
/*      */ 
/* 4595 */       writeRPCNameValType(paramString, paramBoolean, TDSType.NVARCHAR);
/*      */ 
/* 4601 */       writeVMaxHeader(-1L == paramLong ? -1L : 2L * paramLong, false, paramSQLCollation);
/*      */     }
/*      */     else
/*      */     {
/* 4613 */       assert ((0L <= paramLong) && (paramLong <= 1073741823L));
/*      */ 
/* 4618 */       int i = paramLong <= 4000L ? 1 : 0;
/*      */ 
/* 4620 */       writeRPCNameValType(paramString, paramBoolean, i != 0 ? TDSType.NVARCHAR : TDSType.NTEXT);
/*      */ 
/* 4626 */       if (i != 0)
/*      */       {
/* 4628 */         writeShort(8000);
/* 4629 */         paramSQLCollation.writeCollation(this);
/* 4630 */         writeShort((short)(int)(2L * paramLong));
/*      */       }
/*      */       else
/*      */       {
/* 4634 */         writeInt(1073741823);
/* 4635 */         paramSQLCollation.writeCollation(this);
/* 4636 */         writeInt((int)(2L * paramLong));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4641 */     writeReader(paramReader, paramLong, bool);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 2891 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.Writer");
/*      */ 
/* 2928 */     placeholderHeader = new byte[8];
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TDSWriter
 * JD-Core Version:    0.6.0
 */