/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ public final class SQLServerXAResource
/*     */   implements XAResource
/*     */ {
/*     */   private int timeoutSeconds;
/*     */   static final int XA_START = 0;
/*     */   static final int XA_END = 1;
/*     */   static final int XA_PREPARE = 2;
/*     */   static final int XA_COMMIT = 3;
/*     */   static final int XA_ROLLBACK = 4;
/*     */   static final int XA_FORGET = 5;
/*     */   static final int XA_RECOVER = 6;
/*     */   static final int XA_PREPARE_EX = 7;
/*     */   static final int XA_ROLLBACK_EX = 8;
/*     */   static final int XA_FORGET_EX = 9;
/*     */   static final int XA_INIT = 10;
/*     */   private SQLServerConnection controlConnection;
/*     */   private SQLServerConnection con;
/*     */   private static boolean xaInitDone;
/*     */   private static Integer xaInitLock;
/*     */   private String sResourceManagerId;
/*     */   private int enlistedTransactionCount;
/*     */   private final Logger xaLogger;
/*     */   private static int baseResourceID;
/* 140 */   private int tightlyCoupled = 0;
/*     */   public static final int SSTRANSTIGHTLYCPLD = 32768;
/* 143 */   private SQLServerCallableStatement[] xaStatements = { null, null, null, null, null, null, null, null, null, null };
/*     */   private final String traceID;
/*     */ 
/*     */   public String toString()
/*     */   {
/* 154 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   SQLServerXAResource(SQLServerConnection paramSQLServerConnection1, SQLServerConnection paramSQLServerConnection2, String paramString)
/*     */   {
/* 159 */     this.traceID = new StringBuilder().append(" XAResourceID:").append(nextResourceID()).toString();
/*     */ 
/* 161 */     this.xaLogger = SQLServerXADataSource.xaLogger;
/* 162 */     this.controlConnection = paramSQLServerConnection2;
/* 163 */     this.con = paramSQLServerConnection1;
/* 164 */     Properties localProperties = paramSQLServerConnection1.activeConnectionProperties;
/* 165 */     if (localProperties == null) {
/* 166 */       this.sResourceManagerId = "";
/*     */     }
/*     */     else {
/* 169 */       this.sResourceManagerId = new StringBuilder().append(localProperties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString())).append(".").append(localProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString())).append(".").append(localProperties.getProperty(SQLServerDriverIntProperty.PORT_NUMBER.toString())).toString();
/*     */     }
/*     */ 
/* 173 */     if (this.xaLogger.isLoggable(Level.FINE))
/* 174 */       this.xaLogger.fine(new StringBuilder().append(toString()).append(" created by (").append(paramString).append(")").toString());
/*     */   }
/*     */ 
/*     */   private synchronized SQLServerCallableStatement getXACallableStatementHandle(int paramInt) throws SQLServerException
/*     */   {
/* 179 */     assert ((paramInt >= 0) && (paramInt <= 9));
/* 180 */     assert (paramInt < this.xaStatements.length);
/* 181 */     if (null != this.xaStatements[paramInt]) {
/* 182 */       return this.xaStatements[paramInt];
/*     */     }
/* 184 */     CallableStatement localCallableStatement = null;
/*     */ 
/* 186 */     switch (paramInt)
/*     */     {
/*     */     case 0:
/* 189 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_start(?, ?, ?, ?, ?, ?, ?, ?, ?)}");
/* 190 */       break;
/*     */     case 1:
/* 192 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_end(?, ?, ?, ?, ?, ?)}");
/* 193 */       break;
/*     */     case 2:
/* 195 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare(?, ?, ?, ?, ?)}");
/* 196 */       break;
/*     */     case 3:
/* 198 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_commit(?, ?, ?, ?, ?, ?)}");
/* 199 */       break;
/*     */     case 4:
/* 201 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback(?, ?, ?, ?, ?)}");
/* 202 */       break;
/*     */     case 5:
/* 204 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget(?, ?, ?, ?, ?)}");
/* 205 */       break;
/*     */     case 6:
/* 207 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_recover(?, ?, ?, ?)}");
/* 208 */       break;
/*     */     case 7:
/* 210 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare_ex(?, ?, ?, ?, ?, ?)}");
/* 211 */       break;
/*     */     case 8:
/* 213 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback_ex(?, ?, ?, ?, ?, ?)}");
/* 214 */       break;
/*     */     case 9:
/* 216 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget_ex(?, ?, ?, ?, ?, ?)}");
/* 217 */       break;
/*     */     default:
/* 219 */       if ($assertionsDisabled) break; throw new AssertionError(new StringBuilder().append("Bad handle request:").append(paramInt).toString());
/*     */     }
/*     */ 
/* 223 */     this.xaStatements[paramInt] = ((SQLServerCallableStatement)localCallableStatement);
/* 224 */     return this.xaStatements[paramInt];
/*     */   }
/*     */ 
/*     */   private synchronized void closeXAStatements() throws SQLServerException {
/* 228 */     for (int i = 0; i < this.xaStatements.length; i++) {
/* 229 */       if (null == this.xaStatements[i])
/*     */         continue;
/* 231 */       this.xaStatements[i].close();
/* 232 */       this.xaStatements[i] = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   final synchronized void close() throws SQLServerException
/*     */   {
/*     */     try {
/* 239 */       closeXAStatements();
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 243 */       if (this.xaLogger.isLoggable(Level.WARNING)) {
/* 244 */         this.xaLogger.warning(new StringBuilder().append(toString()).append("Closing exception ignored: ").append(localException).toString());
/*     */       }
/*     */     }
/* 247 */     if (null != this.controlConnection)
/* 248 */       this.controlConnection.close();
/*     */   }
/*     */ 
/*     */   private String flagsDisplay(int paramInt)
/*     */   {
/* 258 */     if (0 == paramInt) return "TMNOFLAGS";
/*     */ 
/* 261 */     StringBuilder localStringBuilder = new StringBuilder(100);
/*     */ 
/* 263 */     if (0 != (0x800000 & paramInt)) localStringBuilder.append("TMENDRSCAN");
/*     */ 
/* 265 */     if (0 != (0x20000000 & paramInt))
/*     */     {
/* 267 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 268 */       localStringBuilder.append("TMFAIL");
/*     */     }
/* 270 */     if (0 != (0x200000 & paramInt))
/*     */     {
/* 272 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 273 */       localStringBuilder.append("TMJOIN");
/*     */     }
/* 275 */     if (0 != (0x40000000 & paramInt))
/*     */     {
/* 277 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 278 */       localStringBuilder.append("TMONEPHASE");
/*     */     }
/* 280 */     if (0 != (0x8000000 & paramInt))
/*     */     {
/* 282 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 283 */       localStringBuilder.append("TMRESUME");
/*     */     }
/* 285 */     if (0 != (0x1000000 & paramInt))
/*     */     {
/* 287 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 288 */       localStringBuilder.append("TMSTARTRSCAN");
/*     */     }
/* 290 */     if (0 != (0x4000000 & paramInt))
/*     */     {
/* 292 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 293 */       localStringBuilder.append("TMSUCCESS");
/*     */     }
/* 295 */     if (0 != (0x2000000 & paramInt))
/*     */     {
/* 297 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 298 */       localStringBuilder.append("TMSUSPEND");
/*     */     }
/*     */ 
/* 301 */     if (0 != (0x8000 & paramInt))
/*     */     {
/* 303 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 304 */       localStringBuilder.append("SSTRANSTIGHTLYCPLD");
/*     */     }
/* 306 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   private String cookieDisplay(byte[] paramArrayOfByte)
/*     */   {
/* 312 */     return Util.byteToHexDisplayString(paramArrayOfByte);
/*     */   }
/*     */ 
/*     */   private String typeDisplay(int paramInt)
/*     */   {
/* 318 */     switch (paramInt) {
/*     */     case 0:
/* 320 */       return "XA_START";
/*     */     case 1:
/* 321 */       return "XA_END";
/*     */     case 2:
/* 322 */       return "XA_PREPARE";
/*     */     case 3:
/* 323 */       return "XA_COMMIT";
/*     */     case 4:
/* 324 */       return "XA_ROLLBACK";
/*     */     case 5:
/* 325 */       return "XA_FORGET";
/*     */     case 6:
/* 326 */       return "XA_RECOVER";
/* 327 */     }return new StringBuilder().append("UNKNOWN").append(paramInt).toString();
/*     */   }
/*     */ 
/*     */   private final XAReturnValue DTC_XA_Interface(int paramInt1, Xid paramXid, int paramInt2)
/*     */     throws XAException
/*     */   {
/* 336 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 337 */       this.xaLogger.finer(new StringBuilder().append(toString()).append(" Calling XA function for type:").append(typeDisplay(paramInt1)).append(" flags:").append(flagsDisplay(paramInt2)).append(" xid:").append(XidImpl.xidDisplay(paramXid)).toString());
/*     */     }
/* 339 */     int i = 0;
/* 340 */     byte[] arrayOfByte1 = null;
/* 341 */     byte[] arrayOfByte2 = null;
/* 342 */     if (paramXid != null)
/*     */     {
/* 344 */       i = paramXid.getFormatId();
/* 345 */       arrayOfByte1 = paramXid.getGlobalTransactionId();
/* 346 */       arrayOfByte2 = paramXid.getBranchQualifier();
/*     */     }
/*     */ 
/* 349 */     String str1 = "DTC_XA_";
/* 350 */     int j = 1;
/* 351 */     int k = 0;
/* 352 */     XAReturnValue localXAReturnValue = new XAReturnValue();
/*     */ 
/* 354 */     SQLServerCallableStatement localSQLServerCallableStatement = null;
/*     */     try
/*     */     {
/*     */       Object localObject2;
/*     */       Object localObject3;
/* 357 */       synchronized (this)
/*     */       {
/* 359 */         if (this.controlConnection == null)
/*     */         {
/*     */           try
/*     */           {
/* 363 */             synchronized (xaInitLock)
/*     */             {
/* 365 */               if (!xaInitDone)
/*     */               {
/* 367 */                 localObject2 = null;
/*     */ 
/* 369 */                 localObject2 = (SQLServerCallableStatement)this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_init_ex(?, ?,?)}");
/* 370 */                 ((SQLServerCallableStatement)localObject2).registerOutParameter(1, 4);
/* 371 */                 ((SQLServerCallableStatement)localObject2).registerOutParameter(2, 1);
/* 372 */                 ((SQLServerCallableStatement)localObject2).registerOutParameter(3, 1);
/*     */                 try
/*     */                 {
/* 375 */                   ((SQLServerCallableStatement)localObject2).execute();
/*     */                 }
/*     */                 catch (SQLServerException localSQLServerException6)
/*     */                 {
/*     */                   try
/*     */                   {
/* 381 */                     ((SQLServerCallableStatement)localObject2).close();
/*     */ 
/* 383 */                     this.controlConnection.close();
/*     */                   }
/*     */                   catch (SQLException localSQLException)
/*     */                   {
/* 388 */                     if (this.xaLogger.isLoggable(Level.FINER))
/* 389 */                       this.xaLogger.finer(new StringBuilder().append(toString()).append(" Ignoring exception when closing failed execution. exception:").append(localSQLException).toString());
/*     */                   }
/* 391 */                   if (this.xaLogger.isLoggable(Level.FINER))
/* 392 */                     this.xaLogger.finer(new StringBuilder().append(toString()).append(" exception:").append(localSQLServerException6).toString());
/* 393 */                   throw localSQLServerException6;
/*     */                 }
/*     */ 
/* 397 */                 int m = ((SQLServerCallableStatement)localObject2).getInt(1);
/* 398 */                 String str2 = ((SQLServerCallableStatement)localObject2).getString(2);
/* 399 */                 String str3 = ((SQLServerCallableStatement)localObject2).getString(3);
/* 400 */                 if (this.xaLogger.isLoggable(Level.FINE))
/* 401 */                   this.xaLogger.fine(new StringBuilder().append(toString()).append(" Server XA DLL version:").append(str3).toString());
/* 402 */                 ((SQLServerCallableStatement)localObject2).close();
/* 403 */                 if (0 != m)
/*     */                 {
/* 405 */                   assert ((null != str2) && (str2.length() > 1));
/* 406 */                   this.controlConnection.close();
/*     */ 
/* 408 */                   MessageFormat localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_failedToInitializeXA"));
/* 409 */                   Object[] arrayOfObject2 = { String.valueOf(m), str2 };
/* 410 */                   XAException localXAException2 = new XAException(localMessageFormat2.format(arrayOfObject2));
/* 411 */                   localXAException2.errorCode = m;
/* 412 */                   if (this.xaLogger.isLoggable(Level.FINER))
/* 413 */                     this.xaLogger.finer(new StringBuilder().append(toString()).append(" exception:").append(localXAException2).toString());
/* 414 */                   throw localXAException2;
/*     */                 }
/*     */ 
/* 417 */                 xaInitDone = true;
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (SQLServerException localSQLServerException2)
/*     */           {
/* 423 */             localObject2 = new MessageFormat(SQLServerException.getErrString("R_failedToCreateXAConnection"));
/* 424 */             localObject3 = new Object[] { new String(localSQLServerException2.getMessage()) };
/* 425 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 426 */               this.xaLogger.finer(new StringBuilder().append(toString()).append(" exception:").append(((MessageFormat)localObject2).format(localObject3)).toString());
/* 427 */             SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject2).format(localObject3), null, true);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 432 */       switch (paramInt1) {
/*     */       case 0:
/* 434 */         str1 = "START:";
/* 435 */         localSQLServerCallableStatement = getXACallableStatementHandle(0);
/* 436 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 437 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 438 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 439 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 440 */         localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 441 */         localSQLServerCallableStatement.registerOutParameter(j++, -2);
/* 442 */         localSQLServerCallableStatement.setInt(j++, this.timeoutSeconds);
/* 443 */         localSQLServerCallableStatement.setInt(j++, i);
/* 444 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 445 */         break;
/*     */       case 1:
/* 448 */         str1 = "END:";
/* 449 */         localSQLServerCallableStatement = getXACallableStatementHandle(1);
/* 450 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 451 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 452 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 453 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 454 */         localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 455 */         localSQLServerCallableStatement.setInt(j++, i);
/* 456 */         break;
/*     */       case 2:
/* 459 */         str1 = "PREPARE:";
/* 460 */         if ((0x8000 & paramInt2) == 32768)
/* 461 */           localSQLServerCallableStatement = getXACallableStatementHandle(7);
/*     */         else {
/* 463 */           localSQLServerCallableStatement = getXACallableStatementHandle(2);
/*     */         }
/* 465 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 466 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 467 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 468 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 469 */         if ((0x8000 & paramInt2) == 32768)
/* 470 */           localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 471 */         localSQLServerCallableStatement.setInt(j++, i);
/* 472 */         break;
/*     */       case 3:
/* 475 */         str1 = "COMMIT:";
/* 476 */         localSQLServerCallableStatement = getXACallableStatementHandle(3);
/* 477 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 478 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 479 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 480 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 481 */         localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 482 */         localSQLServerCallableStatement.setInt(j++, i);
/* 483 */         break;
/*     */       case 4:
/* 486 */         str1 = "ROLLBACK:";
/* 487 */         if ((0x8000 & paramInt2) == 32768)
/* 488 */           localSQLServerCallableStatement = getXACallableStatementHandle(8);
/*     */         else {
/* 490 */           localSQLServerCallableStatement = getXACallableStatementHandle(4);
/*     */         }
/* 492 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 493 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 494 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 495 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 496 */         if ((0x8000 & paramInt2) == 32768)
/* 497 */           localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 498 */         localSQLServerCallableStatement.setInt(j++, i);
/* 499 */         break;
/*     */       case 5:
/* 502 */         str1 = "FORGET:";
/* 503 */         if ((0x8000 & paramInt2) == 32768)
/* 504 */           localSQLServerCallableStatement = getXACallableStatementHandle(9);
/*     */         else
/* 506 */           localSQLServerCallableStatement = getXACallableStatementHandle(5);
/* 507 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 508 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 509 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 510 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 511 */         if ((0x8000 & paramInt2) == 32768)
/* 512 */           localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 513 */         localSQLServerCallableStatement.setInt(j++, i);
/* 514 */         break;
/*     */       case 6:
/* 517 */         str1 = "RECOVER:";
/* 518 */         localSQLServerCallableStatement = getXACallableStatementHandle(6);
/* 519 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 520 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 521 */         localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 522 */         localSQLServerCallableStatement.registerOutParameter(j++, -2);
/*     */ 
/* 524 */         break;
/*     */       default:
/* 526 */         if ($assertionsDisabled) break; throw new AssertionError(new StringBuilder().append("Unknown execution type:").append(paramInt1).toString());
/*     */       }
/*     */ 
/* 533 */       localSQLServerCallableStatement.execute();
/* 534 */       k = localSQLServerCallableStatement.getInt(1);
/* 535 */       ??? = localSQLServerCallableStatement.getString(2);
/*     */       Object localObject1;
/* 536 */       if (paramInt1 == 0)
/*     */       {
/* 538 */         localObject1 = localSQLServerCallableStatement.getString(9);
/* 539 */         if (this.xaLogger.isLoggable(Level.FINE)) {
/* 540 */           this.xaLogger.fine(new StringBuilder().append(toString()).append(" Server XA DLL version:").append((String)localObject1).toString());
/*     */         }
/*     */       }
/*     */ 
/* 544 */       if (((3 == k) && (1 != paramInt1) && (2 != paramInt1)) || ((0 != k) && (3 != k)))
/*     */       {
/* 547 */         assert ((null != ???) && (((String)???).length() > 1));
/* 548 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_failedFunctionXA"));
/* 549 */         localObject2 = new Object[] { str1, String.valueOf(k), ??? };
/* 550 */         localObject3 = new XAException(((MessageFormat)localObject1).format(localObject2));
/* 551 */         ((XAException)localObject3).errorCode = k;
/*     */ 
/* 553 */         if ((paramInt1 == 1) && (-7 == k))
/*     */         {
/*     */           try
/*     */           {
/* 557 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 558 */               this.xaLogger.finer(new StringBuilder().append(toString()).append(" Begin un-enlist, enlisted count:").append(this.enlistedTransactionCount).toString());
/* 559 */             this.con.JTAUnenlistConnection();
/* 560 */             this.enlistedTransactionCount -= 1;
/* 561 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 562 */               this.xaLogger.finer(new StringBuilder().append(toString()).append(" End un-enlist, enlisted count:").append(this.enlistedTransactionCount).toString());
/*     */             }
/*     */           }
/*     */           catch (SQLServerException localSQLServerException7)
/*     */           {
/* 567 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 568 */               this.xaLogger.finer(new StringBuilder().append(toString()).append(" Ignoring exception:").append(localSQLServerException7).toString());
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 573 */         throw ((Throwable)localObject3);
/*     */       }
/*     */ 
/* 577 */       if (paramInt1 == 0)
/*     */       {
/* 581 */         localObject1 = localSQLServerCallableStatement.getBytes(6);
/* 582 */         if (localObject1 == null)
/*     */         {
/* 584 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_noTransactionCookie"));
/* 585 */           localObject3 = new Object[] { str1 };
/* 586 */           SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject2).format(localObject3), null, true);
/*     */         }
/*     */         else
/*     */         {
/*     */           try
/*     */           {
/* 593 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 594 */               this.xaLogger.finer(new StringBuilder().append(toString()).append(" Begin enlisting, cookie:").append(cookieDisplay(localObject1)).append(" enlisted count:").append(this.enlistedTransactionCount).toString());
/* 595 */             this.con.JTAEnlistConnection(localObject1);
/* 596 */             this.enlistedTransactionCount += 1;
/* 597 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 598 */               this.xaLogger.finer(new StringBuilder().append(toString()).append(" End enlisting, cookie:").append(cookieDisplay(localObject1)).append(" enlisted count:").append(this.enlistedTransactionCount).toString());
/*     */           }
/*     */           catch (SQLServerException localSQLServerException5)
/*     */           {
/* 602 */             localObject3 = new MessageFormat(SQLServerException.getErrString("R_failedToEnlist"));
/* 603 */             Object[] arrayOfObject1 = { localSQLServerException5.getMessage() };
/* 604 */             SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject3).format(arrayOfObject1), null, true);
/*     */           }
/*     */         }
/*     */       }
/*     */       MessageFormat localMessageFormat1;
/* 609 */       if (paramInt1 == 1)
/*     */       {
/*     */         try
/*     */         {
/* 613 */           if (this.xaLogger.isLoggable(Level.FINER))
/* 614 */             this.xaLogger.finer(new StringBuilder().append(toString()).append(" Begin un-enlist, enlisted count:").append(this.enlistedTransactionCount).toString());
/* 615 */           this.con.JTAUnenlistConnection();
/* 616 */           this.enlistedTransactionCount -= 1;
/* 617 */           if (this.xaLogger.isLoggable(Level.FINER))
/* 618 */             this.xaLogger.finer(new StringBuilder().append(toString()).append(" End un-enlist, enlisted count:").append(this.enlistedTransactionCount).toString());
/*     */         }
/*     */         catch (SQLServerException localSQLServerException3)
/*     */         {
/* 622 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_failedToUnEnlist"));
/* 623 */           localObject3 = new Object[] { localSQLServerException3.getMessage() };
/* 624 */           SQLServerException.makeFromDriverError(null, null, localMessageFormat1.format(localObject3), null, true);
/*     */         }
/*     */       }
/* 627 */       if (paramInt1 == 6)
/*     */       {
/*     */         try
/*     */         {
/* 632 */           localXAReturnValue.bData = localSQLServerCallableStatement.getBytes(4);
/*     */         }
/*     */         catch (SQLServerException localSQLServerException4)
/*     */         {
/* 636 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_failedToReadRecoveryXIDs"));
/* 637 */           localObject3 = new Object[] { localSQLServerException4.getMessage() };
/* 638 */           SQLServerException.makeFromDriverError(null, null, localMessageFormat1.format(localObject3), null, true);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLServerException localSQLServerException1)
/*     */     {
/* 645 */       if (this.xaLogger.isLoggable(Level.FINER))
/* 646 */         this.xaLogger.finer(new StringBuilder().append(toString()).append(" exception:").append(localSQLServerException1).toString());
/* 647 */       XAException localXAException1 = new XAException(localSQLServerException1.toString());
/* 648 */       localXAException1.errorCode = -3;
/* 649 */       throw localXAException1;
/*     */     }
/*     */ 
/* 652 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 653 */       this.xaLogger.finer(new StringBuilder().append(toString()).append(" Status:").append(k).toString());
/*     */     }
/* 655 */     localXAReturnValue.nStatus = k;
/* 656 */     return (XAReturnValue)(XAReturnValue)(XAReturnValue)(XAReturnValue)localXAReturnValue;
/*     */   }
/*     */ 
/*     */   public void start(Xid paramXid, int paramInt)
/*     */     throws XAException
/*     */   {
/* 678 */     this.tightlyCoupled = (paramInt & 0x8000);
/* 679 */     DTC_XA_Interface(0, paramXid, paramInt);
/*     */   }
/*     */ 
/*     */   public void end(Xid paramXid, int paramInt)
/*     */     throws XAException
/*     */   {
/* 692 */     DTC_XA_Interface(1, paramXid, paramInt | this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   public int prepare(Xid paramXid)
/*     */     throws XAException
/*     */   {
/* 704 */     int i = 0;
/* 705 */     XAReturnValue localXAReturnValue = DTC_XA_Interface(2, paramXid, this.tightlyCoupled);
/* 706 */     i = localXAReturnValue.nStatus;
/*     */ 
/* 708 */     return i;
/*     */   }
/*     */ 
/*     */   public void commit(Xid paramXid, boolean paramBoolean) throws XAException
/*     */   {
/* 713 */     DTC_XA_Interface(3, paramXid, (paramBoolean ? 1073741824 : 0) | this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   public void rollback(Xid paramXid) throws XAException
/*     */   {
/* 718 */     DTC_XA_Interface(4, paramXid, this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   public void forget(Xid paramXid) throws XAException
/*     */   {
/* 723 */     DTC_XA_Interface(5, paramXid, this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   public Xid[] recover(int paramInt) throws XAException
/*     */   {
/* 728 */     XAReturnValue localXAReturnValue = DTC_XA_Interface(6, null, paramInt | this.tightlyCoupled);
/* 729 */     int i = 0;
/* 730 */     Vector localVector = new Vector();
/*     */ 
/* 741 */     if (null == localXAReturnValue.bData) return new XidImpl[0];
/*     */ 
/* 743 */     while (i < localXAReturnValue.bData.length)
/*     */     {
/* 745 */       int j = 1;
/* 746 */       k = 0;
/* 747 */       for (int m = 0; m < 4; m++)
/*     */       {
/* 749 */         n = localXAReturnValue.bData[(i + m)] & 0xFF;
/* 750 */         n *= j;
/* 751 */         k += n;
/* 752 */         j *= 256;
/*     */       }
/* 754 */       i += 4;
/* 755 */       m = localXAReturnValue.bData[(i++)] & 0xFF;
/* 756 */       int n = localXAReturnValue.bData[(i++)] & 0xFF;
/* 757 */       byte[] arrayOfByte1 = new byte[m];
/* 758 */       byte[] arrayOfByte2 = new byte[n];
/* 759 */       System.arraycopy(localXAReturnValue.bData, i, arrayOfByte1, 0, m);
/* 760 */       i += m;
/* 761 */       System.arraycopy(localXAReturnValue.bData, i, arrayOfByte2, 0, n);
/* 762 */       i += n;
/* 763 */       XidImpl localXidImpl = new XidImpl(k, arrayOfByte1, arrayOfByte2);
/* 764 */       localVector.add(localXidImpl);
/*     */     }
/* 766 */     XidImpl[] arrayOfXidImpl = new XidImpl[localVector.size()];
/* 767 */     for (int k = 0; k < localVector.size(); k++)
/*     */     {
/* 769 */       arrayOfXidImpl[k] = ((XidImpl)localVector.elementAt(k));
/* 770 */       if (this.xaLogger.isLoggable(Level.FINER))
/* 771 */         this.xaLogger.finer(new StringBuilder().append(toString()).append(arrayOfXidImpl[k].toString()).toString());
/*     */     }
/* 773 */     return arrayOfXidImpl;
/*     */   }
/*     */ 
/*     */   public boolean isSameRM(XAResource paramXAResource)
/*     */     throws XAException
/*     */   {
/* 780 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 781 */       this.xaLogger.finer(new StringBuilder().append(toString()).append(" xares:").append(paramXAResource).toString());
/*     */     }
/*     */ 
/* 784 */     if (!(paramXAResource instanceof SQLServerXAResource))
/* 785 */       return false;
/* 786 */     SQLServerXAResource localSQLServerXAResource = (SQLServerXAResource)paramXAResource;
/* 787 */     return localSQLServerXAResource.sResourceManagerId.equals(this.sResourceManagerId);
/*     */   }
/*     */ 
/*     */   public boolean setTransactionTimeout(int paramInt)
/*     */     throws XAException
/*     */   {
/* 794 */     this.timeoutSeconds = paramInt;
/* 795 */     if (this.xaLogger.isLoggable(Level.FINER))
/* 796 */       this.xaLogger.finer(new StringBuilder().append(toString()).append(" TransactionTimeout:").append(paramInt).toString());
/* 797 */     return true;
/*     */   }
/*     */ 
/*     */   public int getTransactionTimeout() throws XAException
/*     */   {
/* 802 */     return this.timeoutSeconds;
/*     */   }
/*     */ 
/*     */   private static synchronized int nextResourceID()
/*     */   {
/* 808 */     baseResourceID += 1;
/* 809 */     return baseResourceID;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 139 */     baseResourceID = 0;
/*     */ 
/* 149 */     xaInitLock = new Integer(0);
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerXAResource
 * JD-Core Version:    0.6.0
 */