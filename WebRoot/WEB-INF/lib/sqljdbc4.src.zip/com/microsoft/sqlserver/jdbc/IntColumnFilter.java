/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ abstract class IntColumnFilter extends ColumnFilter
/*      */ {
/*      */   abstract int oneValueToAnother(int paramInt);
/*      */ 
/*      */   final Object apply(Object paramObject, JDBCType paramJDBCType)
/*      */     throws SQLServerException
/*      */   {
/* 2348 */     if (paramObject == null) {
/* 2349 */       return paramObject;
/*      */     }
/*      */ 
/* 2354 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*      */     {
/*      */     case 1:
/* 2357 */       return new Integer(oneValueToAnother(((Integer)paramObject).intValue()));
/*      */     case 2:
/*      */     case 3:
/* 2360 */       return new Short((short)oneValueToAnother(((Short)paramObject).intValue()));
/*      */     case 4:
/* 2362 */       return new Long(oneValueToAnother(((Long)paramObject).intValue()));
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/* 2366 */       return Integer.toString(oneValueToAnother(Integer.parseInt((String)paramObject)));
/*      */     }
/* 2368 */     DataTypes.throwConversionError("int", paramJDBCType.toString());
/* 2369 */     return paramObject;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.IntColumnFilter
 * JD-Core Version:    0.6.0
 */