/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.SimpleTimeZone;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */  enum UTC
/*     */ {
/* 406 */   INSTANCE;
/*     */ 
/*     */   static final TimeZone timeZone;
/*     */ 
/* 408 */   static { timeZone = new SimpleTimeZone(0, "UTC");
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.UTC
 * JD-Core Version:    0.6.0
 */