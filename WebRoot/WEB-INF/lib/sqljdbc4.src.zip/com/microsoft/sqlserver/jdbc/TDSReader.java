/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Locale;
/*      */ import java.util.SimpleTimeZone;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ final class TDSReader
/*      */ {
/*      */   private static final Logger logger;
/*      */   private final String traceID;
/*      */   private final TDSChannel tdsChannel;
/*      */   private final SQLServerConnection con;
/*      */   private final TDSCommand command;
/* 4718 */   private TDSPacket currentPacket = new TDSPacket(0);
/* 4719 */   private TDSPacket lastPacket = this.currentPacket;
/* 4720 */   private int payloadOffset = 0;
/* 4721 */   private int packetNum = 0;
/*      */ 
/* 4723 */   private boolean isStreaming = true;
/*      */ 
/* 4725 */   private final byte[] valueBytes = new byte[256];
/*      */   private static int lastReaderID;
/*      */   private static final int[] SCALED_MULTIPLIERS;
/*      */   static final String guidTemplate = "NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN";
/*      */ 
/*      */   public final String toString()
/*      */   {
/* 4708 */     return this.traceID;
/*      */   }
/*      */ 
/*      */   final TDSCommand getCommand()
/*      */   {
/* 4714 */     assert (null != this.command); return this.command;
/*      */   }
/* 4716 */   final SQLServerConnection getConnection() { return this.con;
/*      */   }
/*      */ 
/*      */   private static synchronized int nextReaderID()
/*      */   {
/* 4727 */     return ++lastReaderID;
/*      */   }
/*      */ 
/*      */   TDSReader(TDSChannel paramTDSChannel, SQLServerConnection paramSQLServerConnection, TDSCommand paramTDSCommand)
/*      */   {
/* 4732 */     this.tdsChannel = paramTDSChannel;
/* 4733 */     this.con = paramSQLServerConnection;
/* 4734 */     this.command = paramTDSCommand;
/*      */ 
/* 4736 */     if (logger.isLoggable(Level.FINE))
/* 4737 */       this.traceID = new StringBuilder().append("TDSReader@").append(nextReaderID()).append(" (").append(paramSQLServerConnection.toString()).append(")").toString();
/*      */     else
/* 4739 */       this.traceID = paramSQLServerConnection.toString();
/*      */   }
/*      */ 
/*      */   final void throwInvalidTDS()
/*      */     throws SQLServerException
/*      */   {
/* 4745 */     if (logger.isLoggable(Level.SEVERE))
/* 4746 */       logger.severe(new StringBuilder().append(toString()).append(" got unexpected value in TDS response at offset:").append(this.payloadOffset).toString());
/* 4747 */     this.con.throwInvalidTDS();
/*      */   }
/*      */ 
/*      */   final void throwInvalidTDSToken(String paramString) throws SQLServerException
/*      */   {
/* 4752 */     if (logger.isLoggable(Level.SEVERE))
/* 4753 */       logger.severe(new StringBuilder().append(toString()).append(" got unexpected value in TDS response at offset:").append(this.payloadOffset).toString());
/* 4754 */     this.con.throwInvalidTDSToken(paramString);
/*      */   }
/*      */ 
/*      */   private final boolean ensurePayload()
/*      */     throws SQLServerException
/*      */   {
/* 4766 */     if ((this.payloadOffset == this.currentPacket.payloadLength) && 
/* 4767 */       (!nextPacket())) return false;
/* 4768 */     assert (this.payloadOffset < this.currentPacket.payloadLength);
/* 4769 */     return true;
/*      */   }
/*      */ 
/*      */   private final boolean nextPacket()
/*      */     throws SQLServerException
/*      */   {
/* 4780 */     assert (null != this.currentPacket);
/*      */ 
/* 4783 */     TDSPacket localTDSPacket1 = this.currentPacket;
/* 4784 */     assert (this.payloadOffset == localTDSPacket1.payloadLength);
/*      */ 
/* 4789 */     if (null == localTDSPacket1.next)
/*      */     {
/* 4791 */       readPacket();
/*      */ 
/* 4793 */       if (null == localTDSPacket1.next) {
/* 4794 */         return false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4800 */     TDSPacket localTDSPacket2 = localTDSPacket1.next;
/* 4801 */     if (this.isStreaming)
/*      */     {
/* 4803 */       if (logger.isLoggable(Level.FINEST)) {
/* 4804 */         logger.finest(new StringBuilder().append(toString()).append(" Moving to next packet -- unlinking consumed packet").toString());
/*      */       }
/* 4806 */       localTDSPacket1.next = null;
/*      */     }
/* 4808 */     this.currentPacket = localTDSPacket2;
/* 4809 */     this.payloadOffset = 0;
/* 4810 */     return true;
/*      */   }
/*      */ 
/*      */   final synchronized boolean readPacket()
/*      */     throws SQLServerException
/*      */   {
/* 4822 */     if ((null != this.command) && (!this.command.readingResponse())) {
/* 4823 */       return false;
/*      */     }
/*      */ 
/* 4830 */     assert (this.tdsChannel.numMsgsRcvd < this.tdsChannel.numMsgsSent) : new StringBuilder().append("numMsgsRcvd:").append(this.tdsChannel.numMsgsRcvd).append(" should be less than numMsgsSent:").append(this.tdsChannel.numMsgsSent).toString();
/*      */ 
/* 4833 */     TDSPacket localTDSPacket = new TDSPacket(this.con.getTDSPacketSize());
/*      */ 
/* 4836 */     for (int i = 0; i < 8; )
/*      */     {
/* 4838 */       int j = this.tdsChannel.read(localTDSPacket.header, i, 8 - i);
/* 4839 */       if (j < 0)
/*      */       {
/* 4841 */         if (logger.isLoggable(Level.FINER)) {
/* 4842 */           logger.finer(new StringBuilder().append(toString()).append(" Premature EOS in response. packetNum:").append(this.packetNum).append(" headerBytesRead:").append(i).toString());
/*      */         }
/* 4844 */         this.con.terminate(3, (0 == this.packetNum) && (0 == i) ? SQLServerException.getErrString("R_noServerResponse") : SQLServerException.getErrString("R_truncatedServerResponse"));
/*      */       }
/*      */ 
/* 4851 */       i += j;
/*      */     }
/*      */ 
/* 4855 */     i = Util.readUnsignedShortBigEndian(localTDSPacket.header, 2);
/*      */ 
/* 4858 */     if ((i < 8) || (i > this.con.getTDSPacketSize()))
/*      */     {
/* 4860 */       logger.warning(new StringBuilder().append(toString()).append(" TDS header contained invalid packet length:").append(i).append("; packet size:").append(this.con.getTDSPacketSize()).toString());
/* 4861 */       throwInvalidTDS();
/*      */     }
/*      */ 
/* 4864 */     localTDSPacket.payloadLength = (i - 8);
/*      */ 
/* 4867 */     this.tdsChannel.setSPID(Util.readUnsignedShortBigEndian(localTDSPacket.header, 4));
/*      */ 
/* 4871 */     byte[] arrayOfByte = null;
/* 4872 */     if (this.tdsChannel.isLoggingPackets())
/*      */     {
/* 4874 */       arrayOfByte = new byte[i];
/* 4875 */       System.arraycopy(localTDSPacket.header, 0, arrayOfByte, 0, 8);
/*      */     }
/*      */ 
/* 4879 */     for (int k = 0; k < localTDSPacket.payloadLength; )
/*      */     {
/* 4881 */       int m = this.tdsChannel.read(localTDSPacket.payload, k, localTDSPacket.payloadLength - k);
/* 4882 */       if (m < 0) {
/* 4883 */         this.con.terminate(3, SQLServerException.getErrString("R_truncatedServerResponse"));
/*      */       }
/* 4885 */       k += m;
/*      */     }
/*      */ 
/* 4888 */     this.packetNum += 1;
/*      */ 
/* 4890 */     this.lastPacket.next = localTDSPacket;
/* 4891 */     this.lastPacket = localTDSPacket;
/*      */ 
/* 4894 */     if (this.tdsChannel.isLoggingPackets())
/*      */     {
/* 4896 */       System.arraycopy(localTDSPacket.payload, 0, arrayOfByte, 8, localTDSPacket.payloadLength);
/* 4897 */       this.tdsChannel.logPacket(arrayOfByte, 0, i, new StringBuilder().append(toString()).append(" received Packet:").append(this.packetNum).append(" (").append(localTDSPacket.payloadLength).append(" bytes)").toString());
/*      */     }
/*      */ 
/* 4904 */     if (localTDSPacket.isEOM())
/*      */     {
/* 4906 */       this.tdsChannel.numMsgsRcvd += 1;
/*      */ 
/* 4909 */       if (null != this.command) {
/* 4910 */         this.command.onResponseEOM();
/*      */       }
/*      */     }
/* 4913 */     return true;
/*      */   }
/*      */ 
/*      */   final TDSReaderMark mark()
/*      */   {
/* 4918 */     TDSReaderMark localTDSReaderMark = new TDSReaderMark(this.currentPacket, this.payloadOffset);
/* 4919 */     this.isStreaming = false;
/*      */ 
/* 4921 */     if (logger.isLoggable(Level.FINEST)) {
/* 4922 */       logger.finest(new StringBuilder().append(toString()).append(": Buffering from: ").append(localTDSReaderMark.toString()).toString());
/*      */     }
/* 4924 */     return localTDSReaderMark;
/*      */   }
/*      */ 
/*      */   final void reset(TDSReaderMark paramTDSReaderMark)
/*      */   {
/* 4929 */     if (logger.isLoggable(Level.FINEST)) {
/* 4930 */       logger.finest(new StringBuilder().append(toString()).append(": Resetting to: ").append(paramTDSReaderMark.toString()).toString());
/*      */     }
/* 4932 */     this.currentPacket = paramTDSReaderMark.packet;
/* 4933 */     this.payloadOffset = paramTDSReaderMark.payloadOffset;
/*      */   }
/*      */ 
/*      */   final void stream()
/*      */   {
/* 4938 */     this.isStreaming = true;
/*      */   }
/*      */ 
/*      */   final int available()
/*      */   {
/* 4952 */     int i = this.currentPacket.payloadLength - this.payloadOffset;
/* 4953 */     for (TDSPacket localTDSPacket = this.currentPacket.next; null != localTDSPacket; localTDSPacket = localTDSPacket.next)
/* 4954 */       i += localTDSPacket.payloadLength;
/* 4955 */     return i;
/*      */   }
/*      */ 
/*      */   final int peekTokenType()
/*      */     throws SQLServerException
/*      */   {
/* 4961 */     if (!ensurePayload()) return -1;
/*      */ 
/* 4964 */     return this.currentPacket.payload[this.payloadOffset] & 0xFF;
/*      */   }
/*      */ 
/*      */   final int readUnsignedByte()
/*      */     throws SQLServerException
/*      */   {
/* 4970 */     if (!ensurePayload()) {
/* 4971 */       throwInvalidTDS();
/*      */     }
/* 4973 */     return this.currentPacket.payload[(this.payloadOffset++)] & 0xFF;
/*      */   }
/*      */ 
/*      */   final short readShort() throws SQLServerException
/*      */   {
/* 4978 */     if (this.payloadOffset + 2 <= this.currentPacket.payloadLength)
/*      */     {
/* 4980 */       int i = Util.readShort(this.currentPacket.payload, this.payloadOffset);
/* 4981 */       this.payloadOffset += 2;
/* 4982 */       return i;
/*      */     }
/*      */ 
/* 4985 */     return Util.readShort(readWrappedBytes(2), 0);
/*      */   }
/*      */ 
/*      */   final int readUnsignedShort() throws SQLServerException
/*      */   {
/* 4990 */     if (this.payloadOffset + 2 <= this.currentPacket.payloadLength)
/*      */     {
/* 4992 */       int i = Util.readUnsignedShort(this.currentPacket.payload, this.payloadOffset);
/* 4993 */       this.payloadOffset += 2;
/* 4994 */       return i;
/*      */     }
/*      */ 
/* 4997 */     return Util.readUnsignedShort(readWrappedBytes(2), 0);
/*      */   }
/*      */ 
/*      */   final String readUnicodeString(int paramInt) throws SQLServerException
/*      */   {
/* 5002 */     int i = 2 * paramInt;
/* 5003 */     byte[] arrayOfByte = new byte[i];
/* 5004 */     readBytes(arrayOfByte, 0, i);
/* 5005 */     return Util.readUnicodeString(arrayOfByte, 0, i, this.con);
/*      */   }
/*      */ 
/*      */   final char readChar()
/*      */     throws SQLServerException
/*      */   {
/* 5011 */     return (char)readShort();
/*      */   }
/*      */ 
/*      */   final int readInt() throws SQLServerException
/*      */   {
/* 5016 */     if (this.payloadOffset + 4 <= this.currentPacket.payloadLength)
/*      */     {
/* 5018 */       int i = Util.readInt(this.currentPacket.payload, this.payloadOffset);
/* 5019 */       this.payloadOffset += 4;
/* 5020 */       return i;
/*      */     }
/*      */ 
/* 5023 */     return Util.readInt(readWrappedBytes(4), 0);
/*      */   }
/*      */ 
/*      */   final int readIntBigEndian() throws SQLServerException
/*      */   {
/* 5028 */     if (this.payloadOffset + 4 <= this.currentPacket.payloadLength)
/*      */     {
/* 5030 */       int i = Util.readIntBigEndian(this.currentPacket.payload, this.payloadOffset);
/* 5031 */       this.payloadOffset += 4;
/* 5032 */       return i;
/*      */     }
/*      */ 
/* 5035 */     return Util.readIntBigEndian(readWrappedBytes(4), 0);
/*      */   }
/*      */ 
/*      */   final long readUnsignedInt() throws SQLServerException
/*      */   {
/* 5040 */     return readInt() & 0xFFFFFFFF;
/*      */   }
/*      */ 
/*      */   final long readLong() throws SQLServerException
/*      */   {
/* 5045 */     if (this.payloadOffset + 8 <= this.currentPacket.payloadLength)
/*      */     {
/* 5047 */       long l = Util.readLong(this.currentPacket.payload, this.payloadOffset);
/* 5048 */       this.payloadOffset += 8;
/* 5049 */       return l;
/*      */     }
/*      */ 
/* 5052 */     return Util.readLong(readWrappedBytes(8), 0);
/*      */   }
/*      */ 
/*      */   final void readBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 5057 */     for (int i = 0; i < paramInt2; )
/*      */     {
/* 5060 */       if (!ensurePayload()) {
/* 5061 */         throwInvalidTDS();
/*      */       }
/*      */ 
/* 5065 */       int j = paramInt2 - i;
/* 5066 */       if (j > this.currentPacket.payloadLength - this.payloadOffset) {
/* 5067 */         j = this.currentPacket.payloadLength - this.payloadOffset;
/*      */       }
/*      */ 
/* 5070 */       if (logger.isLoggable(Level.FINEST)) {
/* 5071 */         logger.finest(new StringBuilder().append(toString()).append(" Reading ").append(j).append(" bytes from offset ").append(this.payloadOffset).toString());
/*      */       }
/* 5073 */       System.arraycopy(this.currentPacket.payload, this.payloadOffset, paramArrayOfByte, paramInt1 + i, j);
/* 5074 */       i += j;
/* 5075 */       this.payloadOffset += j;
/*      */     }
/*      */   }
/*      */ 
/*      */   final byte[] readWrappedBytes(int paramInt) throws SQLServerException
/*      */   {
/* 5081 */     assert (paramInt <= this.valueBytes.length);
/* 5082 */     readBytes(this.valueBytes, 0, paramInt);
/* 5083 */     return this.valueBytes;
/*      */   }
/*      */ 
/*      */   final Object readDecimal(int paramInt, TypeInfo paramTypeInfo, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */     throws SQLServerException
/*      */   {
/* 5092 */     if (paramInt > this.valueBytes.length)
/*      */     {
/* 5094 */       logger.warning(new StringBuilder().append(toString()).append(" Invalid value length:").append(paramInt).toString());
/* 5095 */       throwInvalidTDS();
/*      */     }
/*      */ 
/* 5098 */     readBytes(this.valueBytes, 0, paramInt);
/* 5099 */     int i = 0 == this.valueBytes[0] ? -1 : 1;
/* 5100 */     byte[] arrayOfByte = new byte[paramInt - 1];
/* 5101 */     for (int j = 1; j <= arrayOfByte.length; j++)
/* 5102 */       arrayOfByte[(arrayOfByte.length - j)] = this.valueBytes[j];
/* 5103 */     BigDecimal localBigDecimal = new BigDecimal(new BigInteger(i, arrayOfByte), paramTypeInfo.getScale());
/* 5104 */     return DDC.convertBigDecimalToObject(localBigDecimal, paramJDBCType, paramStreamType);
/*      */   }
/*      */ 
/*      */   final Object readMoney(int paramInt, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */     throws SQLServerException
/*      */   {
/*      */     BigInteger localBigInteger;
/* 5110 */     switch (paramInt)
/*      */     {
/*      */     case 8:
/* 5114 */       int i = readInt();
/* 5115 */       int j = readInt();
/*      */ 
/* 5117 */       if (JDBCType.BINARY == paramJDBCType)
/*      */       {
/* 5119 */         byte[] arrayOfByte2 = new byte[8];
/* 5120 */         Util.writeIntBigEndian(i, arrayOfByte2, 0);
/* 5121 */         Util.writeIntBigEndian(j, arrayOfByte2, 4);
/* 5122 */         return arrayOfByte2;
/*      */       }
/*      */ 
/* 5125 */       localBigInteger = BigInteger.valueOf(i << 32 | j & 0xFFFFFFFF);
/* 5126 */       break;
/*      */     case 4:
/* 5130 */       if (JDBCType.BINARY == paramJDBCType)
/*      */       {
/* 5132 */         byte[] arrayOfByte1 = new byte[4];
/* 5133 */         Util.writeIntBigEndian(readInt(), arrayOfByte1, 0);
/* 5134 */         return arrayOfByte1;
/*      */       }
/*      */ 
/* 5137 */       localBigInteger = BigInteger.valueOf(readInt());
/* 5138 */       break;
/*      */     default:
/* 5141 */       throwInvalidTDS();
/* 5142 */       return null;
/*      */     }
/*      */ 
/* 5145 */     return DDC.convertBigDecimalToObject(new BigDecimal(localBigInteger, 4), paramJDBCType, paramStreamType);
/*      */   }
/*      */ 
/*      */   final Object readReal(int paramInt, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */     throws SQLServerException
/*      */   {
/* 5153 */     if (4 != paramInt) {
/* 5154 */       throwInvalidTDS();
/*      */     }
/* 5156 */     return DDC.convertFloatToObject(Float.intBitsToFloat(readInt()), paramJDBCType, paramStreamType);
/*      */   }
/*      */ 
/*      */   final Object readFloat(int paramInt, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */     throws SQLServerException
/*      */   {
/* 5164 */     if (8 != paramInt) {
/* 5165 */       throwInvalidTDS();
/*      */     }
/* 5167 */     return DDC.convertDoubleToObject(Double.longBitsToDouble(readLong()), paramJDBCType, paramStreamType);
/*      */   }
/*      */ 
/*      */   final Object readDateTime(int paramInt, Calendar paramCalendar, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */     throws SQLServerException
/*      */   {
/*      */     int i;
/*      */     int j;
/*      */     byte[] arrayOfByte;
/*      */     int k;
/* 5181 */     switch (paramInt)
/*      */     {
/*      */     case 8:
/* 5188 */       i = readInt();
/* 5189 */       j = readInt();
/*      */ 
/* 5191 */       if (JDBCType.BINARY == paramJDBCType)
/*      */       {
/* 5193 */         arrayOfByte = new byte[8];
/* 5194 */         Util.writeIntBigEndian(i, arrayOfByte, 0);
/* 5195 */         Util.writeIntBigEndian(j, arrayOfByte, 4);
/* 5196 */         return arrayOfByte;
/*      */       }
/*      */ 
/* 5199 */       k = (j * 10 + 1) / 3;
/* 5200 */       break;
/*      */     case 4:
/* 5206 */       i = readUnsignedShort();
/* 5207 */       j = readUnsignedShort();
/*      */ 
/* 5209 */       if (JDBCType.BINARY == paramJDBCType)
/*      */       {
/* 5211 */         arrayOfByte = new byte[4];
/* 5212 */         Util.writeShortBigEndian((short)i, arrayOfByte, 0);
/* 5213 */         Util.writeShortBigEndian((short)j, arrayOfByte, 2);
/* 5214 */         return arrayOfByte;
/*      */       }
/*      */ 
/* 5217 */       k = j * 60 * 1000;
/* 5218 */       break;
/*      */     default:
/* 5221 */       throwInvalidTDS();
/* 5222 */       return null;
/*      */     }
/*      */ 
/* 5226 */     return DDC.convertTemporalToObject(paramJDBCType, SSType.DATETIME, paramCalendar, i, k, 0);
/*      */   }
/*      */ 
/*      */   final Object readDate(int paramInt, Calendar paramCalendar, JDBCType paramJDBCType)
/*      */     throws SQLServerException
/*      */   {
/* 5240 */     if (3 != paramInt) {
/* 5241 */       throwInvalidTDS();
/*      */     }
/*      */ 
/* 5244 */     int i = readDaysIntoCE();
/*      */ 
/* 5247 */     return DDC.convertTemporalToObject(paramJDBCType, SSType.DATE, paramCalendar, i, 0L, 0);
/*      */   }
/*      */ 
/*      */   final Object readTime(int paramInt, TypeInfo paramTypeInfo, Calendar paramCalendar, JDBCType paramJDBCType)
/*      */     throws SQLServerException
/*      */   {
/* 5262 */     if (TDS.timeValueLength(paramTypeInfo.getScale()) != paramInt) {
/* 5263 */       throwInvalidTDS();
/*      */     }
/*      */ 
/* 5266 */     long l = readNanosSinceMidnight(paramTypeInfo.getScale());
/*      */ 
/* 5269 */     return DDC.convertTemporalToObject(paramJDBCType, SSType.TIME, paramCalendar, 0, l, paramTypeInfo.getScale());
/*      */   }
/*      */ 
/*      */   final Object readDateTime2(int paramInt, TypeInfo paramTypeInfo, Calendar paramCalendar, JDBCType paramJDBCType)
/*      */     throws SQLServerException
/*      */   {
/* 5284 */     if (TDS.datetime2ValueLength(paramTypeInfo.getScale()) != paramInt) {
/* 5285 */       throwInvalidTDS();
/*      */     }
/*      */ 
/* 5288 */     long l = readNanosSinceMidnight(paramTypeInfo.getScale());
/* 5289 */     int i = readDaysIntoCE();
/*      */ 
/* 5292 */     return DDC.convertTemporalToObject(paramJDBCType, SSType.DATETIME2, paramCalendar, i, l, paramTypeInfo.getScale());
/*      */   }
/*      */ 
/*      */   final Object readDateTimeOffset(int paramInt, TypeInfo paramTypeInfo, JDBCType paramJDBCType)
/*      */     throws SQLServerException
/*      */   {
/* 5306 */     if (TDS.datetimeoffsetValueLength(paramTypeInfo.getScale()) != paramInt) {
/* 5307 */       throwInvalidTDS();
/*      */     }
/*      */ 
/* 5311 */     long l = readNanosSinceMidnight(paramTypeInfo.getScale());
/* 5312 */     int i = readDaysIntoCE();
/* 5313 */     int j = readShort();
/*      */ 
/* 5316 */     return DDC.convertTemporalToObject(paramJDBCType, SSType.DATETIMEOFFSET, new GregorianCalendar(new SimpleTimeZone(j * 60 * 1000, ""), Locale.US), i, l, paramTypeInfo.getScale());
/*      */   }
/*      */ 
/*      */   private int readDaysIntoCE()
/*      */     throws SQLServerException
/*      */   {
/* 5327 */     byte[] arrayOfByte = new byte[3];
/* 5328 */     readBytes(arrayOfByte, 0, arrayOfByte.length);
/*      */ 
/* 5330 */     int i = 0;
/* 5331 */     for (int j = 0; j < arrayOfByte.length; j++) {
/* 5332 */       i |= (arrayOfByte[j] & 0xFF) << 8 * j;
/*      */     }
/*      */ 
/* 5337 */     if (i < 0) {
/* 5338 */       throwInvalidTDS();
/*      */     }
/* 5340 */     return i;
/*      */   }
/*      */ 
/*      */   private long readNanosSinceMidnight(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 5360 */     assert ((0 <= paramInt) && (paramInt <= 7));
/*      */ 
/* 5362 */     byte[] arrayOfByte = new byte[TDS.nanosSinceMidnightLength(paramInt)];
/* 5363 */     readBytes(arrayOfByte, 0, arrayOfByte.length);
/*      */ 
/* 5365 */     long l = 0L;
/* 5366 */     for (int i = 0; i < arrayOfByte.length; i++) {
/* 5367 */       l |= (arrayOfByte[i] & 0xFF) << 8 * i;
/*      */     }
/* 5369 */     l *= SCALED_MULTIPLIERS[paramInt];
/*      */ 
/* 5371 */     if ((0L > l) || (l >= 864000000000L)) {
/* 5372 */       throwInvalidTDS();
/*      */     }
/* 5374 */     return 100L * l;
/*      */   }
/*      */ 
/*      */   final Object readGUID(int paramInt, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */     throws SQLServerException
/*      */   {
/* 5381 */     if (16 != paramInt) {
/* 5382 */       throwInvalidTDS();
/*      */     }
/*      */ 
/* 5385 */     byte[] arrayOfByte = new byte[16];
/* 5386 */     readBytes(arrayOfByte, 0, 16);
/*      */ 
/* 5388 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramJDBCType.ordinal()])
/*      */     {
/*      */     case 1:
/*      */     case 2:
/*      */     case 3:
/* 5394 */       StringBuilder localStringBuilder = new StringBuilder("NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN".length());
/* 5395 */       for (int i = 0; i < 4; i++)
/*      */       {
/* 5397 */         localStringBuilder.append(Util.hexChars[((arrayOfByte[(3 - i)] & 0xF0) >> 4)]);
/* 5398 */         localStringBuilder.append(Util.hexChars[(arrayOfByte[(3 - i)] & 0xF)]);
/*      */       }
/* 5400 */       localStringBuilder.append('-');
/* 5401 */       for (i = 0; i < 2; i++)
/*      */       {
/* 5403 */         localStringBuilder.append(Util.hexChars[((arrayOfByte[(5 - i)] & 0xF0) >> 4)]);
/* 5404 */         localStringBuilder.append(Util.hexChars[(arrayOfByte[(5 - i)] & 0xF)]);
/*      */       }
/* 5406 */       localStringBuilder.append('-');
/* 5407 */       for (i = 0; i < 2; i++)
/*      */       {
/* 5409 */         localStringBuilder.append(Util.hexChars[((arrayOfByte[(7 - i)] & 0xF0) >> 4)]);
/* 5410 */         localStringBuilder.append(Util.hexChars[(arrayOfByte[(7 - i)] & 0xF)]);
/*      */       }
/* 5412 */       localStringBuilder.append('-');
/* 5413 */       for (i = 0; i < 2; i++)
/*      */       {
/* 5415 */         localStringBuilder.append(Util.hexChars[((arrayOfByte[(8 + i)] & 0xF0) >> 4)]);
/* 5416 */         localStringBuilder.append(Util.hexChars[(arrayOfByte[(8 + i)] & 0xF)]);
/*      */       }
/* 5418 */       localStringBuilder.append('-');
/* 5419 */       for (i = 0; i < 6; i++)
/*      */       {
/* 5421 */         localStringBuilder.append(Util.hexChars[((arrayOfByte[(10 + i)] & 0xF0) >> 4)]);
/* 5422 */         localStringBuilder.append(Util.hexChars[(arrayOfByte[(10 + i)] & 0xF)]);
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 5427 */         return DDC.convertStringToObject(localStringBuilder.toString(), Encoding.UNICODE.charsetName(), paramJDBCType, paramStreamType);
/*      */       }
/*      */       catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */       {
/* 5431 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/* 5432 */         throw new SQLServerException(localMessageFormat.format(new Object[] { "UNIQUEIDENTIFIER", paramJDBCType }), null, 0, localUnsupportedEncodingException);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 5438 */     if ((StreamType.BINARY == paramStreamType) || (StreamType.ASCII == paramStreamType)) {
/* 5439 */       return new ByteArrayInputStream(arrayOfByte);
/*      */     }
/* 5441 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   final SQLIdentifier readSQLIdentifier()
/*      */     throws SQLServerException
/*      */   {
/* 5452 */     int i = readUnsignedByte();
/* 5453 */     if ((1 > i) || (i > 4)) {
/* 5454 */       throwInvalidTDS();
/*      */     }
/*      */ 
/* 5457 */     String[] arrayOfString = new String[i];
/* 5458 */     for (int j = 0; j < i; j++) {
/* 5459 */       arrayOfString[j] = readUnicodeString(readUnsignedShort());
/*      */     }
/*      */ 
/* 5462 */     SQLIdentifier localSQLIdentifier = new SQLIdentifier();
/* 5463 */     localSQLIdentifier.setObjectName(arrayOfString[(i - 1)]);
/* 5464 */     if (i >= 2)
/* 5465 */       localSQLIdentifier.setSchemaName(arrayOfString[(i - 2)]);
/* 5466 */     if (i >= 3)
/* 5467 */       localSQLIdentifier.setDatabaseName(arrayOfString[(i - 3)]);
/* 5468 */     if (4 == i) {
/* 5469 */       localSQLIdentifier.setServerName(arrayOfString[(i - 4)]);
/*      */     }
/* 5471 */     return localSQLIdentifier;
/*      */   }
/*      */ 
/*      */   final SQLCollation readCollation() throws SQLServerException
/*      */   {
/* 5476 */     SQLCollation localSQLCollation = null;
/*      */     try
/*      */     {
/* 5480 */       localSQLCollation = new SQLCollation(this);
/*      */     }
/*      */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */     {
/* 5484 */       this.con.terminate(4, localUnsupportedEncodingException.getMessage(), localUnsupportedEncodingException);
/*      */     }
/*      */ 
/* 5488 */     return localSQLCollation;
/*      */   }
/*      */ 
/*      */   final void skip(int paramInt) throws SQLServerException
/*      */   {
/* 5493 */     assert (paramInt >= 0);
/*      */ 
/* 5495 */     while (paramInt > 0)
/*      */     {
/* 5498 */       if (!ensurePayload()) {
/* 5499 */         throwInvalidTDS();
/*      */       }
/* 5501 */       int i = paramInt;
/* 5502 */       if (i > this.currentPacket.payloadLength - this.payloadOffset) {
/* 5503 */         i = this.currentPacket.payloadLength - this.payloadOffset;
/*      */       }
/* 5505 */       paramInt -= i;
/* 5506 */       this.payloadOffset += i;
/*      */     }
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 4706 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.Reader");
/*      */ 
/* 4726 */     lastReaderID = 0;
/*      */ 
/* 5346 */     SCALED_MULTIPLIERS = new int[] { 10000000, 1000000, 100000, 10000, 1000, 100, 10, 1 };
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TDSReader
 * JD-Core Version:    0.6.0
 */