/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ final class DataTypeFilter extends IntColumnFilter
/*      */ {
/*      */   private static final int ODBC_SQL_GUID = -11;
/*      */   private static final int ODBC_SQL_WCHAR = -8;
/*      */   private static final int ODBC_SQL_WVARCHAR = -9;
/*      */   private static final int ODBC_SQL_WLONGVARCHAR = -10;
/*      */   private static final int ODBC_SQL_FLOAT = 6;
/*      */   private static final int ODBC_SQL_TIME = -154;
/*      */   private static final int ODBC_SQL_XML = -152;
/*      */   private static final int ODBC_SQL_UDT = -151;
/*      */ 
/*      */   int oneValueToAnother(int paramInt)
/*      */   {
/* 2311 */     switch (paramInt) {
/*      */     case 6:
/* 2313 */       return JDBCType.DOUBLE.asJavaSqlType();
/*      */     case -11:
/* 2314 */       return JDBCType.CHAR.asJavaSqlType();
/*      */     case -8:
/* 2315 */       return JDBCType.NCHAR.asJavaSqlType();
/*      */     case -9:
/* 2316 */       return JDBCType.NVARCHAR.asJavaSqlType();
/*      */     case -10:
/* 2317 */       return JDBCType.LONGNVARCHAR.asJavaSqlType();
/*      */     case -154:
/* 2318 */       return JDBCType.TIME.asJavaSqlType();
/*      */     case -152:
/* 2319 */       return SSType.XML.getJDBCType().asJavaSqlType();
/*      */     case -151:
/* 2320 */       return SSType.UDT.getJDBCType().asJavaSqlType();
/*      */     }
/* 2322 */     return paramInt;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.DataTypeFilter
 * JD-Core Version:    0.6.0
 */