package com.microsoft.sqlserver.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import microsoft.sql.DateTimeOffset;

abstract class DTVExecuteOp
{
  abstract void execute(DTV paramDTV, String paramString)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Clob paramClob)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Byte paramByte)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Integer paramInteger)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Time paramTime)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Date paramDate)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Timestamp paramTimestamp)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, DateTimeOffset paramDateTimeOffset)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Float paramFloat)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Double paramDouble)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, BigDecimal paramBigDecimal)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Long paramLong)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Short paramShort)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Boolean paramBoolean)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, byte[] paramArrayOfByte)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Blob paramBlob)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, InputStream paramInputStream)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, Reader paramReader)
    throws SQLServerException;

  abstract void execute(DTV paramDTV, SQLServerSQLXML paramSQLServerSQLXML)
    throws SQLServerException;
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.DTVExecuteOp
 * JD-Core Version:    0.6.0
 */