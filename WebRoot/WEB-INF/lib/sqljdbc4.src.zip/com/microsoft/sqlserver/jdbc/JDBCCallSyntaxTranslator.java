/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ final class JDBCCallSyntaxTranslator
/*      */ {
/* 2218 */   private String procedureName = null;
/*      */ 
/* 2222 */   private boolean hasReturnValueSyntax = false;
/*      */   private static final String sqlIdentifierPart = "(?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))";
/*      */   private static final String sqlIdentifierWithoutGroups = "((?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))(?:\\.(?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))){0,3}?)";
/*      */   private static final String sqlIdentifierWithGroups = "((?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?)))(?:\\.((?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))))?";
/* 2258 */   private static final Pattern jdbcCallSyntax = Pattern.compile("(?s)\\s*?\\{\\s*?(\\?\\s*?=)?\\s*?[cC][aA][lL][lL]\\s+?((?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))(?:\\.(?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))){0,3}?)(?:\\s*?\\((.*)\\))?\\s*\\}.*+");
/*      */ 
/* 2268 */   private static final Pattern sqlExecSyntax = Pattern.compile("\\s*?[eE][xX][eE][cC](?:[uU][tT][eE])??\\s+?(((?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))(?:\\.(?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))){0,3}?)\\s*?=\\s+?)??((?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))(?:\\.(?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))){0,3}?)(?:$|(?:\\s+?.*+))");
/*      */ 
/*      */   String getProcedureName()
/*      */   {
/* 2220 */     return this.procedureName;
/*      */   }
/*      */   boolean hasReturnValueSyntax() {
/* 2223 */     return this.hasReturnValueSyntax;
/*      */   }
/*      */ 
/*      */   static String getSQLIdentifierWithGroups()
/*      */   {
/* 2245 */     return "((?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?)))(?:\\.((?:(?:\\[(?:[^\\]]|(?:\\]\\]))+?\\])|(?:\"(?:[^\"]|(?:\"\"))+?\")|(?:\\S+?))))?";
/*      */   }
/*      */ 
/*      */   String translate(String paramString)
/*      */   {
/* 2275 */     Matcher localMatcher = jdbcCallSyntax.matcher(paramString);
/* 2276 */     if (localMatcher.matches())
/*      */     {
/* 2284 */       this.hasReturnValueSyntax = (null != localMatcher.group(1));
/* 2285 */       this.procedureName = localMatcher.group(2);
/* 2286 */       String str = localMatcher.group(3);
/* 2287 */       return new StringBuilder().append("EXEC ").append(this.hasReturnValueSyntax ? "? = " : "").append(this.procedureName).append(null != str ? new StringBuilder().append(" ").append(str).toString() : "").toString();
/*      */     }
/*      */ 
/* 2290 */     localMatcher = sqlExecSyntax.matcher(paramString);
/* 2291 */     if (localMatcher.matches())
/*      */     {
/* 2299 */       this.hasReturnValueSyntax = (null != localMatcher.group(1));
/* 2300 */       this.procedureName = localMatcher.group(3);
/* 2301 */       return paramString;
/*      */     }
/*      */ 
/* 2306 */     return paramString;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.JDBCCallSyntaxTranslator
 * JD-Core Version:    0.6.0
 */