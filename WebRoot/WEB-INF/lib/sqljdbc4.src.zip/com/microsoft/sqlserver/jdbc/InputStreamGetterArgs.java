/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ final class InputStreamGetterArgs
/*      */ {
/*      */   final StreamType streamType;
/*      */   final boolean isAdaptive;
/*      */   final boolean isStreaming;
/*      */   final String logContext;
/* 1189 */   static final InputStreamGetterArgs defaultArgs = new InputStreamGetterArgs(StreamType.NONE, false, false, "");
/*      */ 
/* 1190 */   static final InputStreamGetterArgs getDefaultArgs() { return defaultArgs; }
/*      */ 
/*      */   InputStreamGetterArgs(StreamType paramStreamType, boolean paramBoolean1, boolean paramBoolean2, String paramString)
/*      */   {
/* 1194 */     this.streamType = paramStreamType;
/* 1195 */     this.isAdaptive = paramBoolean1;
/* 1196 */     this.isStreaming = paramBoolean2;
/* 1197 */     this.logContext = paramString;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.InputStreamGetterArgs
 * JD-Core Version:    0.6.0
 */