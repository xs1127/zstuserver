/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ abstract class UninterruptableTDSCommand extends TDSCommand
/*      */ {
/*      */   UninterruptableTDSCommand(String paramString)
/*      */   {
/* 6194 */     super(paramString, 0);
/*      */   }
/*      */ 
/*      */   final void interrupt(String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 6201 */     logger.finest(toString() + " Ignoring interrupt of uninterruptable TDS command; Reason:" + paramString);
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.UninterruptableTDSCommand
 * JD-Core Version:    0.6.0
 */