/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ 
/*     */  enum SSType
/*     */ {
/* 107 */   UNKNOWN(Category.UNKNOWN, "unknown", JDBCType.UNKNOWN), 
/* 108 */   TINYINT(Category.NUMERIC, "tinyint", JDBCType.TINYINT), 
/* 109 */   BIT(Category.NUMERIC, "bit", JDBCType.BIT), 
/* 110 */   SMALLINT(Category.NUMERIC, "smallint", JDBCType.SMALLINT), 
/* 111 */   INTEGER(Category.NUMERIC, "int", JDBCType.INTEGER), 
/* 112 */   BIGINT(Category.NUMERIC, "bigint", JDBCType.BIGINT), 
/* 113 */   FLOAT(Category.NUMERIC, "float", JDBCType.DOUBLE), 
/* 114 */   REAL(Category.NUMERIC, "real", JDBCType.REAL), 
/* 115 */   SMALLDATETIME(Category.DATETIME, "smalldatetime", JDBCType.TIMESTAMP), 
/* 116 */   DATETIME(Category.DATETIME, "datetime", JDBCType.TIMESTAMP), 
/* 117 */   DATE(Category.DATE, "date", JDBCType.DATE), 
/* 118 */   TIME(Category.TIME, "time", JDBCType.TIME), 
/* 119 */   DATETIME2(Category.DATETIME2, "datetime2", JDBCType.TIMESTAMP), 
/* 120 */   DATETIMEOFFSET(Category.DATETIMEOFFSET, "datetimeoffset", JDBCType.DATETIMEOFFSET), 
/* 121 */   SMALLMONEY(Category.NUMERIC, "smallmoney", JDBCType.DECIMAL), 
/* 122 */   MONEY(Category.NUMERIC, "money", JDBCType.DECIMAL), 
/* 123 */   CHAR(Category.CHARACTER, "char", JDBCType.CHAR), 
/* 124 */   VARCHAR(Category.CHARACTER, "varchar", JDBCType.VARCHAR), 
/* 125 */   VARCHARMAX(Category.LONG_CHARACTER, "varchar", JDBCType.LONGVARCHAR), 
/* 126 */   TEXT(Category.LONG_CHARACTER, "text", JDBCType.LONGVARCHAR), 
/* 127 */   NCHAR(Category.NCHARACTER, "nchar", JDBCType.NCHAR), 
/* 128 */   NVARCHAR(Category.NCHARACTER, "nvarchar", JDBCType.NVARCHAR), 
/* 129 */   NVARCHARMAX(Category.LONG_NCHARACTER, "nvarchar", JDBCType.LONGNVARCHAR), 
/* 130 */   NTEXT(Category.LONG_NCHARACTER, "ntext", JDBCType.LONGNVARCHAR), 
/* 131 */   BINARY(Category.BINARY, "binary", JDBCType.BINARY), 
/* 132 */   VARBINARY(Category.BINARY, "varbinary", JDBCType.VARBINARY), 
/* 133 */   VARBINARYMAX(Category.LONG_BINARY, "varbinary", JDBCType.LONGVARBINARY), 
/* 134 */   IMAGE(Category.LONG_BINARY, "image", JDBCType.LONGVARBINARY), 
/* 135 */   DECIMAL(Category.NUMERIC, "decimal", JDBCType.DECIMAL), 
/* 136 */   NUMERIC(Category.NUMERIC, "numeric", JDBCType.NUMERIC), 
/* 137 */   GUID(Category.GUID, "uniqueidentifier", JDBCType.CHAR), 
/* 138 */   SQL_VARIANT(Category.VARIANT, "sql_variant", JDBCType.VARCHAR), 
/* 139 */   UDT(Category.UDT, "udt", JDBCType.VARBINARY), 
/* 140 */   XML(Category.XML, "xml", JDBCType.LONGNVARCHAR), 
/* 141 */   TIMESTAMP(Category.TIMESTAMP, "timestamp", JDBCType.BINARY);
/*     */ 
/*     */   final Category category;
/*     */   private final String name;
/*     */   private final JDBCType jdbcType;
/*     */ 
/* 149 */   private SSType(Category paramCategory, String paramString, JDBCType paramJDBCType) { this.category = paramCategory;
/* 150 */     this.name = paramString;
/* 151 */     this.jdbcType = paramJDBCType; }
/*     */ 
/*     */   public String toString() {
/* 154 */     return this.name; } 
/* 155 */   final JDBCType getJDBCType() { return this.jdbcType;
/*     */   }
/*     */ 
/*     */   boolean convertsTo(JDBCType paramJDBCType)
/*     */   {
/* 361 */     return GetterConversion.converts(this, paramJDBCType);
/*     */   }
/*     */ 
/*     */   static enum GetterConversion
/*     */   {
/* 181 */     NUMERIC(SSType.Category.NUMERIC, EnumSet.of(JDBCType.Category.NUMERIC, JDBCType.Category.CHARACTER, JDBCType.Category.BINARY)), 
/*     */ 
/* 188 */     DATETIME(SSType.Category.DATETIME, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.BINARY)), 
/*     */ 
/* 197 */     DATETIME2(SSType.Category.DATETIME2, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER)), 
/*     */ 
/* 205 */     DATE(SSType.Category.DATE, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER)), 
/*     */ 
/* 212 */     TIME(SSType.Category.TIME, EnumSet.of(JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER)), 
/*     */ 
/* 219 */     DATETIMEOFFSET(SSType.Category.DATETIMEOFFSET, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER)), 
/*     */ 
/* 228 */     CHARACTER(SSType.Category.CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.BINARY })), 
/*     */ 
/* 239 */     LONG_CHARACTER(SSType.Category.LONG_CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.BINARY, JDBCType.Category.CLOB })), 
/*     */ 
/* 251 */     NCHARACTER(SSType.Category.NCHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP })), 
/*     */ 
/* 264 */     LONG_NCHARACTER(SSType.Category.LONG_NCHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CLOB, JDBCType.Category.NCLOB })), 
/*     */ 
/* 279 */     BINARY(SSType.Category.BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER)), 
/*     */ 
/* 287 */     LONG_BINARY(SSType.Category.LONG_BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.BLOB)), 
/*     */ 
/* 296 */     TIMESTAMP(SSType.Category.TIMESTAMP, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER)), 
/*     */ 
/* 303 */     XML(SSType.Category.XML, EnumSet.of(JDBCType.Category.CHARACTER, new JDBCType.Category[] { JDBCType.Category.LONG_CHARACTER, JDBCType.Category.CLOB, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB, JDBCType.Category.SQLXML })), 
/*     */ 
/* 317 */     UDT(SSType.Category.UDT, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER)), 
/*     */ 
/* 324 */     GUID(SSType.Category.GUID, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.CHARACTER));
/*     */ 
/*     */     private final SSType.Category from;
/*     */     private final EnumSet<JDBCType.Category> to;
/*     */     private static final EnumMap<SSType.Category, EnumSet<JDBCType.Category>> conversionMap;
/*     */ 
/*     */     private GetterConversion(SSType.Category paramCategory, EnumSet<JDBCType.Category> paramEnumSet)
/*     */     {
/* 337 */       this.from = paramCategory;
/* 338 */       this.to = paramEnumSet;
/*     */     }
/*     */ 
/*     */     static final boolean converts(SSType paramSSType, JDBCType paramJDBCType)
/*     */     {
/* 355 */       return ((EnumSet)conversionMap.get(paramSSType.category)).contains(paramJDBCType.category);
/*     */     }
/*     */ 
/*     */     static
/*     */     {
/* 341 */       conversionMap = new EnumMap(SSType.Category.class);
/*     */       Enum localEnum;
/* 346 */       for (localEnum : SSType.Category.values()) {
/* 347 */         conversionMap.put(localEnum, EnumSet.noneOf(JDBCType.Category.class));
/*     */       }
/* 349 */       for (localEnum : values())
/* 350 */         ((EnumSet)conversionMap.get(localEnum.from)).addAll(localEnum.to);
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum Category
/*     */   {
/* 159 */     BINARY, 
/* 160 */     CHARACTER, 
/* 161 */     DATE, 
/* 162 */     DATETIME, 
/* 163 */     DATETIME2, 
/* 164 */     DATETIMEOFFSET, 
/* 165 */     GUID, 
/* 166 */     LONG_BINARY, 
/* 167 */     LONG_CHARACTER, 
/* 168 */     LONG_NCHARACTER, 
/* 169 */     NCHARACTER, 
/* 170 */     NUMERIC, 
/* 171 */     UNKNOWN, 
/* 172 */     TIME, 
/* 173 */     TIMESTAMP, 
/* 174 */     UDT, 
/* 175 */     VARIANT, 
/* 176 */     XML;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SSType
 * JD-Core Version:    0.6.0
 */