/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import B;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Blob;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public final class SQLServerBlob
/*     */   implements Blob, Serializable
/*     */ {
/*     */   private byte[] value;
/*     */   private SQLServerConnection con;
/*  21 */   private boolean isClosed = false;
/*     */ 
/*  28 */   ArrayList<Closeable> activeStreams = new ArrayList(1);
/*     */   private static final Logger logger;
/*     */   private static int baseID;
/*     */   private final String traceID;
/*     */ 
/*     */   public final String toString()
/*     */   {
/*  36 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   private static synchronized int nextInstanceID()
/*     */   {
/*  42 */     baseID += 1;
/*  43 */     return baseID;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public SQLServerBlob(SQLServerConnection paramSQLServerConnection, byte[] paramArrayOfByte)
/*     */   {
/*  54 */     this.traceID = (" SQLServerBlob:" + nextInstanceID());
/*  55 */     this.con = paramSQLServerConnection;
/*     */ 
/*  60 */     if (null == paramArrayOfByte) {
/*  61 */       throw new NullPointerException(SQLServerException.getErrString("R_cantSetNull"));
/*     */     }
/*  63 */     this.value = paramArrayOfByte;
/*     */ 
/*  65 */     if (logger.isLoggable(Level.FINE))
/*     */     {
/*  67 */       String str = null != paramSQLServerConnection ? paramSQLServerConnection.toString() : "null connection";
/*  68 */       logger.fine(toString() + " created by (" + str + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */   SQLServerBlob(SQLServerConnection paramSQLServerConnection)
/*     */   {
/*  74 */     this.traceID = (" SQLServerBlob:" + nextInstanceID());
/*  75 */     this.con = paramSQLServerConnection;
/*  76 */     this.value = new byte[0];
/*  77 */     if (logger.isLoggable(Level.FINE))
/*  78 */       logger.fine(toString() + " created by (" + paramSQLServerConnection.toString() + ")");
/*     */   }
/*     */ 
/*     */   SQLServerBlob(BaseInputStream paramBaseInputStream) throws SQLServerException
/*     */   {
/*  83 */     this.traceID = (" SQLServerBlob:" + nextInstanceID());
/*  84 */     this.value = paramBaseInputStream.getBytes();
/*  85 */     if (logger.isLoggable(Level.FINE))
/*  86 */       logger.fine(toString() + " created by (null connection)");
/*     */   }
/*     */ 
/*     */   public void free()
/*     */     throws SQLException
/*     */   {
/*  98 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 100 */     if (!this.isClosed)
/*     */     {
/* 103 */       if (null != this.activeStreams)
/*     */       {
/* 105 */         for (Closeable localCloseable : this.activeStreams)
/*     */         {
/*     */           try
/*     */           {
/* 109 */             localCloseable.close();
/*     */           }
/*     */           catch (IOException localIOException)
/*     */           {
/* 113 */             logger.fine(toString() + " ignored IOException closing stream " + localCloseable + ": " + localIOException.getMessage());
/*     */           }
/*     */         }
/* 116 */         this.activeStreams = null;
/*     */       }
/*     */ 
/* 120 */       this.value = null;
/*     */ 
/* 122 */       this.isClosed = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void checkClosed()
/*     */     throws SQLServerException
/*     */   {
/* 131 */     if (this.isClosed)
/*     */     {
/* 133 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 134 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(new Object[] { "Blob" }), null, true);
/*     */     }
/*     */   }
/*     */ 
/*     */   public InputStream getBinaryStream()
/*     */     throws SQLException
/*     */   {
/* 145 */     checkClosed();
/*     */ 
/* 147 */     return getBinaryStreamInternal(0, this.value.length);
/*     */   }
/*     */ 
/*     */   public InputStream getBinaryStream(long paramLong1, long paramLong2) throws SQLException
/*     */   {
/* 152 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/* 155 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */   private InputStream getBinaryStreamInternal(int paramInt1, int paramInt2)
/*     */   {
/* 160 */     assert (null != this.value);
/* 161 */     assert (paramInt1 >= 0);
/* 162 */     assert ((0 <= paramInt2) && (paramInt2 <= this.value.length - paramInt1));
/* 163 */     assert (null != this.activeStreams);
/*     */ 
/* 165 */     ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(this.value, paramInt1, paramInt2);
/* 166 */     this.activeStreams.add(localByteArrayInputStream);
/* 167 */     return localByteArrayInputStream;
/*     */   }
/*     */ 
/*     */   public byte[] getBytes(long paramLong, int paramInt)
/*     */     throws SQLException
/*     */   {
/* 182 */     checkClosed();
/*     */     Object[] arrayOfObject;
/* 184 */     if (paramLong < 1L)
/*     */     {
/* 186 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 187 */       arrayOfObject = new Object[] { new Long(paramLong) };
/* 188 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/*     */ 
/* 191 */     if (paramInt < 0)
/*     */     {
/* 193 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 194 */       arrayOfObject = new Object[] { new Integer(paramInt) };
/* 195 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/*     */ 
/* 199 */     paramLong -= 1L;
/*     */ 
/* 202 */     if (paramLong > this.value.length) {
/* 203 */       paramLong = this.value.length;
/*     */     }
/*     */ 
/* 206 */     if (paramInt > this.value.length - paramLong) {
/* 207 */       paramInt = (int)(this.value.length - paramLong);
/*     */     }
/* 209 */     Object localObject = new byte[paramInt];
/* 210 */     System.arraycopy(this.value, (int)paramLong, localObject, 0, paramInt);
/* 211 */     return (B)localObject;
/*     */   }
/*     */ 
/*     */   public long length()
/*     */     throws SQLException
/*     */   {
/* 221 */     checkClosed();
/*     */ 
/* 223 */     return this.value.length;
/*     */   }
/*     */ 
/*     */   public long position(Blob paramBlob, long paramLong)
/*     */     throws SQLException
/*     */   {
/* 237 */     checkClosed();
/*     */ 
/* 239 */     if (paramLong < 1L)
/*     */     {
/* 241 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 242 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 243 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */ 
/* 246 */     if (null == paramBlob) {
/* 247 */       return -1L;
/*     */     }
/* 249 */     return position(paramBlob.getBytes(1L, (int)paramBlob.length()), paramLong);
/*     */   }
/*     */ 
/*     */   public long position(byte[] paramArrayOfByte, long paramLong)
/*     */     throws SQLException
/*     */   {
/* 263 */     checkClosed();
/*     */ 
/* 265 */     if (paramLong < 1L)
/*     */     {
/* 267 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 268 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 269 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */ 
/* 274 */     if (null == paramArrayOfByte) {
/* 275 */       return -1L;
/*     */     }
/*     */ 
/* 278 */     paramLong -= 1L;
/*     */ 
/* 281 */     for (int i = (int)paramLong; i <= this.value.length - paramArrayOfByte.length; i++)
/*     */     {
/* 283 */       int j = 1;
/* 284 */       for (int k = 0; k < paramArrayOfByte.length; k++)
/*     */       {
/* 286 */         if (this.value[(i + k)] == paramArrayOfByte[k])
/*     */           continue;
/* 288 */         j = 0;
/* 289 */         break;
/*     */       }
/*     */ 
/* 293 */       if (j != 0) {
/* 294 */         return i + 1;
/*     */       }
/*     */     }
/* 297 */     return -1L;
/*     */   }
/*     */ 
/*     */   public void truncate(long paramLong)
/*     */     throws SQLException
/*     */   {
/* 309 */     checkClosed();
/*     */     Object localObject;
/* 311 */     if (paramLong < 0L)
/*     */     {
/* 313 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 314 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 315 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/*     */ 
/* 318 */     if (this.value.length > paramLong)
/*     */     {
/* 320 */       localObject = new byte[(int)paramLong];
/* 321 */       System.arraycopy(this.value, 0, localObject, 0, (int)paramLong);
/* 322 */       this.value = ((B)localObject);
/*     */     }
/*     */   }
/*     */ 
/*     */   public OutputStream setBinaryStream(long paramLong)
/*     */     throws SQLException
/*     */   {
/* 334 */     checkClosed();
/*     */ 
/* 336 */     if (paramLong < 1L)
/*     */     {
/* 338 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 339 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(new Object[] { Long.valueOf(paramLong) }), null, true);
/*     */     }
/*     */ 
/* 342 */     return new SQLServerBlobOutputStream(this, paramLong);
/*     */   }
/*     */ 
/*     */   public int setBytes(long paramLong, byte[] paramArrayOfByte)
/*     */     throws SQLException
/*     */   {
/* 355 */     checkClosed();
/*     */ 
/* 357 */     if (null == paramArrayOfByte) {
/* 358 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     }
/* 360 */     return setBytes(paramLong, paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */   }
/*     */ 
/*     */   public int setBytes(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 384 */     checkClosed();
/*     */ 
/* 386 */     if (null == paramArrayOfByte)
/* 387 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     Object localObject;
/*     */     Object[] arrayOfObject;
/* 390 */     if ((paramInt1 < 0) || (paramInt1 > paramArrayOfByte.length))
/*     */     {
/* 392 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidOffset"));
/* 393 */       arrayOfObject = new Object[] { new Integer(paramInt1) };
/* 394 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/*     */ 
/* 398 */     if ((paramInt2 < 0) || (paramInt2 > paramArrayOfByte.length - paramInt1))
/*     */     {
/* 400 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 401 */       arrayOfObject = new Object[] { new Integer(paramInt2) };
/* 402 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/*     */ 
/* 408 */     if ((paramLong <= 0L) || (paramLong > this.value.length + 1))
/*     */     {
/* 410 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 411 */       arrayOfObject = new Object[] { new Long(paramLong) };
/* 412 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/*     */ 
/* 416 */     paramLong -= 1L;
/*     */ 
/* 419 */     if (paramInt2 >= this.value.length - paramLong)
/*     */     {
/* 422 */       DataTypes.getCheckedLength(this.con, JDBCType.BLOB, paramLong + paramInt2, false);
/* 423 */       assert (paramLong + paramInt2 <= 2147483647L);
/*     */ 
/* 426 */       localObject = new byte[(int)paramLong + paramInt2];
/* 427 */       System.arraycopy(this.value, 0, localObject, 0, (int)paramLong);
/*     */ 
/* 430 */       System.arraycopy(paramArrayOfByte, paramInt1, localObject, (int)paramLong, paramInt2);
/* 431 */       this.value = ((B)localObject);
/*     */     }
/*     */     else
/*     */     {
/* 436 */       System.arraycopy(paramArrayOfByte, paramInt1, this.value, (int)paramLong, paramInt2);
/*     */     }
/*     */ 
/* 439 */     return paramInt2;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  30 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerBlob");
/*     */ 
/*  32 */     baseID = 0;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerBlob
 * JD-Core Version:    0.6.0
 */