/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public final class SQLServerResultSetMetaData
/*     */   implements ResultSetMetaData
/*     */ {
/*     */   private SQLServerConnection con;
/*     */   private final SQLServerResultSet rs;
/*     */   public int nBeforeExecuteCols;
/*     */   private static final Logger logger;
/*     */   private static int baseID;
/*     */   private final String traceID;
/*     */ 
/*     */   private static synchronized int nextInstanceID()
/*     */   {
/*  29 */     baseID += 1;
/*  30 */     return baseID;
/*     */   }
/*     */ 
/*     */   public final String toString() {
/*  34 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   SQLServerResultSetMetaData(SQLServerConnection paramSQLServerConnection, SQLServerResultSet paramSQLServerResultSet)
/*     */   {
/*  45 */     this.traceID = (" SQLServerResultSetMetaData:" + nextInstanceID());
/*  46 */     this.con = paramSQLServerConnection;
/*  47 */     this.rs = paramSQLServerResultSet;
/*  48 */     assert (paramSQLServerResultSet != null);
/*  49 */     if (logger.isLoggable(Level.FINE))
/*     */     {
/*  51 */       logger.fine(toString() + " created by (" + paramSQLServerResultSet.toString() + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkClosed() throws SQLServerException {
/*  56 */     this.rs.checkClosed();
/*     */   }
/*     */ 
/*     */   public boolean isWrapperFor(Class paramClass)
/*     */     throws SQLException
/*     */   {
/*  65 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/*  67 */     return false;
/*     */   }
/*     */ 
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException
/*     */   {
/*  72 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  73 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */   public String getCatalogName(int paramInt) throws SQLServerException
/*     */   {
/*  78 */     checkClosed();
/*  79 */     return this.rs.getColumn(paramInt).getTableName().getDatabaseName();
/*     */   }
/*     */ 
/*     */   public int getColumnCount() throws SQLServerException {
/*  83 */     checkClosed();
/*  84 */     if (this.rs == null)
/*  85 */       return 0;
/*  86 */     return this.rs.getColumnCount();
/*     */   }
/*     */ 
/*     */   public int getColumnDisplaySize(int paramInt) throws SQLServerException
/*     */   {
/*  91 */     checkClosed();
/*  92 */     return this.rs.getColumn(paramInt).getTypeInfo().getDisplaySize();
/*     */   }
/*     */ 
/*     */   public String getColumnLabel(int paramInt) throws SQLServerException
/*     */   {
/*  97 */     checkClosed();
/*  98 */     return this.rs.getColumn(paramInt).getColumnName();
/*     */   }
/*     */ 
/*     */   public String getColumnName(int paramInt) throws SQLServerException
/*     */   {
/* 103 */     checkClosed();
/* 104 */     return this.rs.getColumn(paramInt).getColumnName();
/*     */   }
/*     */ 
/*     */   public int getColumnType(int paramInt) throws SQLServerException
/*     */   {
/* 109 */     checkClosed();
/*     */ 
/* 111 */     TypeInfo localTypeInfo = this.rs.getColumn(paramInt).getTypeInfo();
/* 112 */     JDBCType localJDBCType = localTypeInfo.getSSType().getJDBCType();
/* 113 */     int i = localJDBCType.asJavaSqlType();
/* 114 */     if (this.con.isKatmaiOrLater())
/*     */     {
/* 116 */       SSType localSSType = localTypeInfo.getSSType();
/*     */ 
/* 118 */       switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSType[localSSType.ordinal()])
/*     */       {
/*     */       case 1:
/* 121 */         i = SSType.VARCHAR.getJDBCType().asJavaSqlType();
/* 122 */         break;
/*     */       case 2:
/* 124 */         i = SSType.NVARCHAR.getJDBCType().asJavaSqlType();
/* 125 */         break;
/*     */       case 3:
/* 127 */         i = SSType.VARBINARY.getJDBCType().asJavaSqlType();
/*     */       }
/*     */     }
/*     */ 
/* 131 */     return i;
/*     */   }
/*     */ 
/*     */   public String getColumnTypeName(int paramInt) throws SQLServerException
/*     */   {
/* 136 */     checkClosed();
/* 137 */     return this.rs.getColumn(paramInt).getTypeInfo().getSSTypeName();
/*     */   }
/*     */ 
/*     */   public int getPrecision(int paramInt) throws SQLServerException
/*     */   {
/* 142 */     checkClosed();
/* 143 */     return this.rs.getColumn(paramInt).getTypeInfo().getPrecision();
/*     */   }
/*     */ 
/*     */   public int getScale(int paramInt) throws SQLServerException
/*     */   {
/* 148 */     checkClosed();
/* 149 */     return this.rs.getColumn(paramInt).getTypeInfo().getScale();
/*     */   }
/*     */ 
/*     */   public String getSchemaName(int paramInt) throws SQLServerException
/*     */   {
/* 154 */     checkClosed();
/* 155 */     return this.rs.getColumn(paramInt).getTableName().getSchemaName();
/*     */   }
/*     */ 
/*     */   public String getTableName(int paramInt) throws SQLServerException
/*     */   {
/* 160 */     checkClosed();
/* 161 */     return this.rs.getColumn(paramInt).getTableName().getObjectName();
/*     */   }
/*     */ 
/*     */   public boolean isAutoIncrement(int paramInt) throws SQLServerException
/*     */   {
/* 166 */     checkClosed();
/* 167 */     return this.rs.getColumn(paramInt).getTypeInfo().isIdentity();
/*     */   }
/*     */ 
/*     */   public boolean isCaseSensitive(int paramInt) throws SQLServerException
/*     */   {
/* 172 */     checkClosed();
/* 173 */     return this.rs.getColumn(paramInt).getTypeInfo().isCaseSensitive();
/*     */   }
/*     */ 
/*     */   public boolean isCurrency(int paramInt) throws SQLServerException
/*     */   {
/* 178 */     checkClosed();
/* 179 */     SSType localSSType = this.rs.getColumn(paramInt).getTypeInfo().getSSType();
/* 180 */     return (SSType.MONEY == localSSType) || (SSType.SMALLMONEY == localSSType);
/*     */   }
/*     */ 
/*     */   public boolean isDefinitelyWritable(int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 186 */     checkClosed();
/* 187 */     return TypeInfo.UPDATABLE_READ_WRITE == this.rs.getColumn(paramInt).getTypeInfo().getUpdatability();
/*     */   }
/*     */ 
/*     */   public int isNullable(int paramInt) throws SQLServerException
/*     */   {
/* 192 */     checkClosed();
/* 193 */     return this.rs.getColumn(paramInt).getTypeInfo().isNullable() ? 1 : 0;
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly(int paramInt) throws SQLServerException
/*     */   {
/* 198 */     checkClosed();
/* 199 */     return TypeInfo.UPDATABLE_READ_ONLY == this.rs.getColumn(paramInt).getTypeInfo().getUpdatability();
/*     */   }
/*     */ 
/*     */   public boolean isSearchable(int paramInt) throws SQLServerException
/*     */   {
/* 204 */     checkClosed();
/* 205 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSType[this.rs.getColumn(paramInt).getTypeInfo().getSSType().ordinal()])
/*     */     {
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/* 212 */       return false;
/*     */     }
/*     */ 
/* 215 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isSigned(int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 221 */     checkClosed();
/* 222 */     return this.rs.getColumn(paramInt).getTypeInfo().getSSType().getJDBCType().isSigned();
/*     */   }
/*     */ 
/*     */   public boolean isSparseColumnSet(int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 233 */     checkClosed();
/* 234 */     return this.rs.getColumn(paramInt).getTypeInfo().isSparseColumnSet();
/*     */   }
/*     */ 
/*     */   public boolean isWritable(int paramInt) throws SQLServerException
/*     */   {
/* 239 */     checkClosed();
/* 240 */     int i = this.rs.getColumn(paramInt).getTypeInfo().getUpdatability();
/* 241 */     return (TypeInfo.UPDATABLE_READ_WRITE == i) || (TypeInfo.UPDATABLE_UNKNOWN == i);
/*     */   }
/*     */ 
/*     */   public String getColumnClassName(int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 247 */     checkClosed();
/* 248 */     return this.rs.getColumn(paramInt).getTypeInfo().getSSType().getJDBCType().className();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  21 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerResultSetMetaData");
/*     */ 
/*  24 */     baseID = 0;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerResultSetMetaData
 * JD-Core Version:    0.6.0
 */