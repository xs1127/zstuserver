/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ final class FailoverMapSingleton
/*    */ {
/* 17 */   private static int INITIALHASHMAPSIZE = 5;
/* 18 */   private static HashMap<String, FailoverInfo> failoverMap = new HashMap(INITIALHASHMAPSIZE);
/*    */ 
/*    */   private static String concatPrimaryDatabase(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 22 */     StringBuilder localStringBuilder = new StringBuilder();
/* 23 */     localStringBuilder.append(paramString1);
/* 24 */     if (null != paramString2)
/*    */     {
/* 26 */       localStringBuilder.append("\\");
/* 27 */       localStringBuilder.append(paramString2);
/*    */     }
/* 29 */     localStringBuilder.append(";");
/* 30 */     localStringBuilder.append(paramString3);
/* 31 */     return localStringBuilder.toString();
/*    */   }
/*    */ 
/*    */   static FailoverInfo getFailoverInfo(SQLServerConnection paramSQLServerConnection, String paramString1, String paramString2, String paramString3) {
/* 35 */     synchronized (FailoverMapSingleton.class)
/*    */     {
/* 37 */       if (true == failoverMap.isEmpty())
/*    */       {
/* 39 */         return null;
/*    */       }
/*    */ 
/* 43 */       String str = concatPrimaryDatabase(paramString1, paramString2, paramString3);
/* 44 */       if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINER))
/* 45 */         paramSQLServerConnection.getConnectionLogger().finer(new StringBuilder().append(paramSQLServerConnection.toString()).append(" Looking up info in the map using key: ").append(str).toString());
/* 46 */       FailoverInfo localFailoverInfo = (FailoverInfo)failoverMap.get(str);
/* 47 */       if (null != localFailoverInfo)
/* 48 */         localFailoverInfo.log(paramSQLServerConnection);
/* 49 */       return localFailoverInfo;
/*    */     }
/*    */   }
/*    */ 
/*    */   static void putFailoverInfo(SQLServerConnection paramSQLServerConnection, String paramString1, String paramString2, String paramString3, FailoverInfo paramFailoverInfo, boolean paramBoolean, String paramString4)
/*    */     throws SQLServerException
/*    */   {
/* 61 */     synchronized (FailoverMapSingleton.class)
/*    */     {
/*    */       FailoverInfo localFailoverInfo;
/* 64 */       if (null == (localFailoverInfo = getFailoverInfo(paramSQLServerConnection, paramString1, paramString2, paramString3)))
/*    */       {
/* 66 */         if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE)) {
/* 67 */           paramSQLServerConnection.getConnectionLogger().fine(new StringBuilder().append(paramSQLServerConnection.toString()).append(" Failover map add server: ").append(paramString1).append("; database:").append(paramString3).append("; Mirror:").append(paramString4).toString());
/*    */         }
/* 69 */         failoverMap.put(concatPrimaryDatabase(paramString1, paramString2, paramString3), paramFailoverInfo);
/*    */       }
/*    */       else
/*    */       {
/* 73 */         localFailoverInfo.failoverAdd(paramSQLServerConnection, paramBoolean, paramString4);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.FailoverMapSingleton
 * JD-Core Version:    0.6.0
 */