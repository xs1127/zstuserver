/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.text.MessageFormat;
/*      */ import java.util.EnumMap;
/*      */ import java.util.EnumSet;
/*      */ 
/*      */  enum JDBCType
/*      */ {
/*  576 */   UNKNOWN(Category.UNKNOWN, 999, "java.lang.Object"), 
/*  577 */   ARRAY(Category.UNKNOWN, 2003, "java.lang.Object"), 
/*  578 */   BIGINT(Category.NUMERIC, -5, "java.lang.Long"), 
/*  579 */   BINARY(Category.BINARY, -2, "[B"), 
/*  580 */   BIT(Category.NUMERIC, -7, "java.lang.Boolean"), 
/*  581 */   BLOB(Category.BLOB, 2004, "java.sql.Blob"), 
/*  582 */   BOOLEAN(Category.NUMERIC, 16, "java.lang.Boolean"), 
/*  583 */   CHAR(Category.CHARACTER, 1, "java.lang.String"), 
/*  584 */   CLOB(Category.CLOB, 2005, "java.sql.Clob"), 
/*  585 */   DATALINK(Category.UNKNOWN, 70, "java.lang.Object"), 
/*  586 */   DATE(Category.DATE, 91, "java.sql.Date"), 
/*  587 */   DATETIMEOFFSET(Category.DATETIMEOFFSET, -155, "microsoft.sql.DateTimeOffset"), 
/*  588 */   DECIMAL(Category.NUMERIC, 3, "java.math.BigDecimal"), 
/*  589 */   DISTINCT(Category.UNKNOWN, 2001, "java.lang.Object"), 
/*  590 */   DOUBLE(Category.NUMERIC, 8, "java.lang.Double"), 
/*  591 */   FLOAT(Category.NUMERIC, 6, "java.lang.Double"), 
/*  592 */   INTEGER(Category.NUMERIC, 4, "java.lang.Integer"), 
/*  593 */   JAVA_OBJECT(Category.UNKNOWN, 2000, "java.lang.Object"), 
/*  594 */   LONGNVARCHAR(Category.LONG_NCHARACTER, -16, "java.lang.String"), 
/*  595 */   LONGVARBINARY(Category.LONG_BINARY, -4, "[B"), 
/*  596 */   LONGVARCHAR(Category.LONG_CHARACTER, -1, "java.lang.String"), 
/*  597 */   NCHAR(Category.NCHARACTER, -15, "java.lang.String"), 
/*  598 */   NCLOB(Category.NCLOB, 2011, "java.sql.NClob"), 
/*  599 */   NULL(Category.UNKNOWN, 0, "java.lang.Object"), 
/*  600 */   NUMERIC(Category.NUMERIC, 2, "java.math.BigDecimal"), 
/*  601 */   NVARCHAR(Category.NCHARACTER, -9, "java.lang.String"), 
/*  602 */   OTHER(Category.UNKNOWN, 1111, "java.lang.Object"), 
/*  603 */   REAL(Category.NUMERIC, 7, "java.lang.Float"), 
/*  604 */   REF(Category.UNKNOWN, 2006, "java.lang.Object"), 
/*  605 */   ROWID(Category.UNKNOWN, -8, "java.lang.Object"), 
/*  606 */   SMALLINT(Category.NUMERIC, 5, "java.lang.Short"), 
/*  607 */   SQLXML(Category.SQLXML, 2009, "java.lang.Object"), 
/*  608 */   STRUCT(Category.UNKNOWN, 2002, "java.lang.Object"), 
/*  609 */   TIME(Category.TIME, 92, "java.sql.Time"), 
/*  610 */   TIMESTAMP(Category.TIMESTAMP, 93, "java.sql.Timestamp"), 
/*  611 */   TINYINT(Category.NUMERIC, -6, "java.lang.Short"), 
/*  612 */   VARBINARY(Category.BINARY, -3, "[B"), 
/*  613 */   VARCHAR(Category.CHARACTER, 12, "java.lang.String");
/*      */ 
/*      */   final Category category;
/*      */   private final int intValue;
/*      */   private final String className;
/*      */   private static final EnumSet<JDBCType> signedTypes;
/*      */   private static final EnumSet<JDBCType> binaryTypes;
/*      */   private static final EnumSet<Category> textualCategories;
/*      */ 
/*  618 */   final String className() { return this.className; }
/*      */ 
/*      */   private JDBCType(Category paramCategory, int paramInt, String paramString)
/*      */   {
/*  622 */     this.category = paramCategory;
/*  623 */     this.intValue = paramInt;
/*  624 */     this.className = paramString;
/*      */   }
/*      */ 
/*      */   boolean convertsTo(JDBCType paramJDBCType)
/*      */   {
/*  815 */     return SetterConversion.converts(this, paramJDBCType);
/*      */   }
/*      */ 
/*      */   boolean convertsTo(SSType paramSSType)
/*      */   {
/*  998 */     return UpdaterConversion.converts(this, paramSSType);
/*      */   }
/*      */ 
/*      */   static JDBCType of(int paramInt) throws SQLServerException
/*      */   {
/* 1003 */     for (Object localObject2 : values()) {
/* 1004 */       if (localObject2.intValue == paramInt)
/* 1005 */         return localObject2;
/*      */     }
/* 1007 */     ??? = new MessageFormat(SQLServerException.getErrString("R_unknownJDBCType"));
/* 1008 */     Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/* 1009 */     SQLServerException.makeFromDriverError(null, null, ((MessageFormat)???).format(arrayOfObject), null, true);
/* 1010 */     return (JDBCType)UNKNOWN;
/*      */   }
/*      */ 
/*      */   boolean isSigned()
/*      */   {
/* 1030 */     return signedTypes.contains(this);
/*      */   }
/*      */ 
/*      */   boolean isBinary()
/*      */   {
/* 1046 */     return binaryTypes.contains(this);
/*      */   }
/*      */ 
/*      */   boolean isTextual()
/*      */   {
/* 1069 */     return textualCategories.contains(this.category);
/*      */   }
/*      */ 
/*      */   boolean isUnsupported()
/*      */   {
/* 1079 */     return Category.UNKNOWN == this.category;
/*      */   }
/*      */ 
/*      */   int asJavaSqlType()
/*      */   {
/* 1090 */     if (Util.SYSTEM_SPEC_VERSION.equals("1.5"))
/*      */     {
/* 1092 */       switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[ordinal()]) {
/*      */       case 1:
/* 1094 */         return 1;
/*      */       case 2:
/* 1095 */         return 12;
/*      */       case 3:
/* 1096 */         return -1;
/*      */       case 4:
/* 1097 */         return 2005;
/*      */       case 5:
/* 1098 */         return 1111;
/*      */       case 6:
/* 1099 */         return 12;
/* 1100 */       }return this.intValue;
/*      */     }
/*      */ 
/* 1105 */     return this.intValue;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 1017 */     signedTypes = EnumSet.of(SMALLINT, new JDBCType[] { INTEGER, BIGINT, REAL, FLOAT, DOUBLE, DECIMAL, NUMERIC });
/*      */ 
/* 1037 */     binaryTypes = EnumSet.of(BINARY, VARBINARY, LONGVARBINARY, BLOB);
/*      */ 
/* 1058 */     textualCategories = EnumSet.of(Category.CHARACTER, new Category[] { Category.LONG_CHARACTER, Category.CLOB, Category.NCHARACTER, Category.LONG_NCHARACTER, Category.NCLOB });
/*      */   }
/*      */ 
/*      */   static enum UpdaterConversion
/*      */   {
/*  820 */     CHARACTER(JDBCType.Category.CHARACTER, EnumSet.of(SSType.Category.NUMERIC, new SSType.Category[] { SSType.Category.DATE, SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT, SSType.Category.GUID, SSType.Category.TIMESTAMP })), 
/*      */ 
/*  840 */     LONG_CHARACTER(JDBCType.Category.LONG_CHARACTER, EnumSet.of(SSType.Category.CHARACTER, new SSType.Category[] { SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY })), 
/*      */ 
/*  851 */     CLOB(JDBCType.Category.CLOB, EnumSet.of(SSType.Category.LONG_CHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)), 
/*      */ 
/*  858 */     NCHARACTER(JDBCType.Category.NCHARACTER, EnumSet.of(SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)), 
/*      */ 
/*  865 */     LONG_NCHARACTER(JDBCType.Category.LONG_NCHARACTER, EnumSet.of(SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)), 
/*      */ 
/*  872 */     NCLOB(JDBCType.Category.NCLOB, EnumSet.of(SSType.Category.LONG_NCHARACTER, SSType.Category.XML)), 
/*      */ 
/*  878 */     BINARY(JDBCType.Category.BINARY, EnumSet.of(SSType.Category.NUMERIC, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT, SSType.Category.TIMESTAMP, SSType.Category.GUID })), 
/*      */ 
/*  894 */     LONG_BINARY(JDBCType.Category.LONG_BINARY, EnumSet.of(SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT)), 
/*      */ 
/*  902 */     BLOB(JDBCType.Category.BLOB, EnumSet.of(SSType.Category.LONG_BINARY, SSType.Category.XML)), 
/*      */ 
/*  907 */     SQLXML(JDBCType.Category.SQLXML, EnumSet.of(SSType.Category.XML)), 
/*      */ 
/*  912 */     NUMERIC(JDBCType.Category.NUMERIC, EnumSet.of(SSType.Category.NUMERIC, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER)), 
/*      */ 
/*  921 */     DATE(JDBCType.Category.DATE, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER })), 
/*      */ 
/*  933 */     TIME(JDBCType.Category.TIME, EnumSet.of(SSType.Category.TIME, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER })), 
/*      */ 
/*  945 */     TIMESTAMP(JDBCType.Category.TIMESTAMP, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER })), 
/*      */ 
/*  958 */     DATETIMEOFFSET(JDBCType.Category.DATETIMEOFFSET, EnumSet.of(SSType.Category.DATE, SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET));
/*      */ 
/*      */     private final JDBCType.Category from;
/*      */     private final EnumSet<SSType.Category> to;
/*      */     private static final EnumMap<JDBCType.Category, EnumSet<SSType.Category>> conversionMap;
/*      */ 
/*      */     private UpdaterConversion(JDBCType.Category paramCategory, EnumSet<SSType.Category> paramEnumSet)
/*      */     {
/*  974 */       this.from = paramCategory;
/*  975 */       this.to = paramEnumSet;
/*      */     }
/*      */ 
/*      */     static boolean converts(JDBCType paramJDBCType, SSType paramSSType)
/*      */     {
/*  992 */       return ((EnumSet)conversionMap.get(paramJDBCType.category)).contains(paramSSType.category);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  978 */       conversionMap = new EnumMap(JDBCType.Category.class);
/*      */       Enum localEnum;
/*  983 */       for (localEnum : JDBCType.Category.values()) {
/*  984 */         conversionMap.put(localEnum, EnumSet.noneOf(SSType.Category.class));
/*      */       }
/*  986 */       for (localEnum : values())
/*  987 */         ((EnumSet)conversionMap.get(localEnum.from)).addAll(localEnum.to);
/*      */     }
/*      */   }
/*      */ 
/*      */   static enum SetterConversion
/*      */   {
/*  649 */     CHARACTER(JDBCType.Category.CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY })), 
/*      */ 
/*  664 */     LONG_CHARACTER(JDBCType.Category.LONG_CHARACTER, EnumSet.of(JDBCType.Category.CHARACTER, new JDBCType.Category[] { JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY })), 
/*      */ 
/*  674 */     CLOB(JDBCType.Category.CLOB, EnumSet.of(JDBCType.Category.CLOB, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.LONG_NCHARACTER)), 
/*      */ 
/*  681 */     NCHARACTER(JDBCType.Category.NCHARACTER, EnumSet.of(JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB)), 
/*      */ 
/*  688 */     LONG_NCHARACTER(JDBCType.Category.LONG_NCHARACTER, EnumSet.of(JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)), 
/*      */ 
/*  694 */     NCLOB(JDBCType.Category.NCLOB, EnumSet.of(JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB)), 
/*      */ 
/*  700 */     BINARY(JDBCType.Category.BINARY, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB })), 
/*      */ 
/*  715 */     LONG_BINARY(JDBCType.Category.LONG_BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY)), 
/*      */ 
/*  721 */     BLOB(JDBCType.Category.BLOB, EnumSet.of(JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB)), 
/*      */ 
/*  727 */     NUMERIC(JDBCType.Category.NUMERIC, EnumSet.of(JDBCType.Category.NUMERIC, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)), 
/*      */ 
/*  736 */     DATE(JDBCType.Category.DATE, EnumSet.of(JDBCType.Category.DATE, new JDBCType.Category[] { JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER })), 
/*      */ 
/*  747 */     TIME(JDBCType.Category.TIME, EnumSet.of(JDBCType.Category.TIME, new JDBCType.Category[] { JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER })), 
/*      */ 
/*  758 */     TIMESTAMP(JDBCType.Category.TIMESTAMP, EnumSet.of(JDBCType.Category.DATE, new JDBCType.Category[] { JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER })), 
/*      */ 
/*  770 */     DATETIMEOFFSET(JDBCType.Category.DATETIMEOFFSET, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET)), 
/*      */ 
/*  778 */     SQLXML(JDBCType.Category.SQLXML, EnumSet.of(JDBCType.Category.SQLXML));
/*      */ 
/*      */     private final JDBCType.Category from;
/*      */     private final EnumSet<JDBCType.Category> to;
/*      */     private static final EnumMap<JDBCType.Category, EnumSet<JDBCType.Category>> conversionMap;
/*      */ 
/*      */     private SetterConversion(JDBCType.Category paramCategory, EnumSet<JDBCType.Category> paramEnumSet)
/*      */     {
/*  791 */       this.from = paramCategory;
/*  792 */       this.to = paramEnumSet;
/*      */     }
/*      */ 
/*      */     static boolean converts(JDBCType paramJDBCType1, JDBCType paramJDBCType2)
/*      */     {
/*  809 */       return ((EnumSet)conversionMap.get(paramJDBCType1.category)).contains(paramJDBCType2.category);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  795 */       conversionMap = new EnumMap(JDBCType.Category.class);
/*      */       Enum localEnum;
/*  800 */       for (localEnum : JDBCType.Category.values()) {
/*  801 */         conversionMap.put(localEnum, EnumSet.noneOf(JDBCType.Category.class));
/*      */       }
/*  803 */       for (localEnum : values())
/*  804 */         ((EnumSet)conversionMap.get(localEnum.from)).addAll(localEnum.to);
/*      */     }
/*      */   }
/*      */ 
/*      */   static enum Category
/*      */   {
/*  629 */     CHARACTER, 
/*  630 */     LONG_CHARACTER, 
/*  631 */     CLOB, 
/*  632 */     NCHARACTER, 
/*  633 */     LONG_NCHARACTER, 
/*  634 */     NCLOB, 
/*  635 */     BINARY, 
/*  636 */     LONG_BINARY, 
/*  637 */     BLOB, 
/*  638 */     NUMERIC, 
/*  639 */     DATE, 
/*  640 */     TIME, 
/*  641 */     TIMESTAMP, 
/*  642 */     DATETIMEOFFSET, 
/*  643 */     SQLXML, 
/*  644 */     UNKNOWN;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.JDBCType
 * JD-Core Version:    0.6.0
 */