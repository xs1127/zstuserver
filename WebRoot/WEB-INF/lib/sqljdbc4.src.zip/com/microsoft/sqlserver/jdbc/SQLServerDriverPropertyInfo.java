/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.util.Properties;
/*     */ 
/*     */ final class SQLServerDriverPropertyInfo
/*     */ {
/*     */   private final String name;
/*     */   private final String description;
/*     */   private final String defaultValue;
/*     */   private final boolean required;
/*     */   private final String[] choices;
/*     */ 
/*     */   final String getName()
/*     */   {
/* 628 */     return this.name;
/*     */   }
/*     */ 
/*     */   SQLServerDriverPropertyInfo(String paramString1, String paramString2, boolean paramBoolean, String[] paramArrayOfString)
/*     */   {
/* 640 */     this.name = paramString1;
/* 641 */     this.description = SQLServerResource.getResource("R_" + paramString1 + "PropertyDescription");
/* 642 */     this.defaultValue = paramString2;
/* 643 */     this.required = paramBoolean;
/* 644 */     this.choices = paramArrayOfString;
/*     */   }
/*     */ 
/*     */   DriverPropertyInfo build(Properties paramProperties)
/*     */   {
/* 649 */     String str = this.name.equals(SQLServerDriverStringProperty.PASSWORD.toString()) ? "" : paramProperties.getProperty(this.name);
/*     */ 
/* 652 */     if (null == str) {
/* 653 */       str = this.defaultValue;
/*     */     }
/* 655 */     DriverPropertyInfo localDriverPropertyInfo = new DriverPropertyInfo(this.name, str);
/* 656 */     localDriverPropertyInfo.description = this.description;
/* 657 */     localDriverPropertyInfo.required = this.required;
/* 658 */     localDriverPropertyInfo.choices = this.choices;
/*     */ 
/* 660 */     return localDriverPropertyInfo;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerDriverPropertyInfo
 * JD-Core Version:    0.6.0
 */