/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public final class SQLServerException extends SQLException
/*     */ {
/*     */   static final String EXCEPTION_XOPEN_CONNECTION_CANT_ESTABLISH = "08001";
/*     */   static final String EXCEPTION_XOPEN_CONNECTION_DOES_NOT_EXIST = "08003";
/*     */   static final String EXCEPTION_XOPEN_CONNECTION_FAILURE = "08006";
/*     */   static final int LOGON_FAILED = 18456;
/*     */   static final int PASSWORD_EXPIRED = 18488;
/*     */   static Logger exLogger;
/*     */   static final int DRIVER_ERROR_NONE = 0;
/*     */   static final int DRIVER_ERROR_FROM_DATABASE = 2;
/*     */   static final int DRIVER_ERROR_IO_FAILED = 3;
/*     */   static final int DRIVER_ERROR_INVALID_TDS = 4;
/*     */   static final int DRIVER_ERROR_SSL_FAILED = 5;
/*     */   static final int DRIVER_ERROR_UNSUPPORTED_CONFIG = 6;
/*  64 */   private int driverErrorCode = 0;
/*     */ 
/*  65 */   final int getDriverErrorCode() { return this.driverErrorCode; } 
/*  66 */   final void setDriverErrorCode(int paramInt) { this.driverErrorCode = paramInt;
/*     */   }
/*     */ 
/*     */   private void logException(Object paramObject, String paramString, boolean paramBoolean)
/*     */   {
/*  77 */     String str = "";
/*  78 */     if (paramObject != null) {
/*  79 */       str = paramObject.toString();
/*     */     }
/*  81 */     if (exLogger.isLoggable(Level.FINE))
/*  82 */       exLogger.fine(new StringBuilder().append("*** SQLException:").append(str).append(" ").append(toString()).append(" ").append(paramString).toString());
/*  83 */     if (paramBoolean)
/*     */     {
/*  85 */       if (exLogger.isLoggable(Level.FINE))
/*     */       {
/*  87 */         StringBuilder localStringBuilder = new StringBuilder(100);
/*  88 */         StackTraceElement[] arrayOfStackTraceElement1 = getStackTrace();
/*  89 */         for (int i = 0; i < arrayOfStackTraceElement1.length; i++)
/*  90 */           localStringBuilder.append(arrayOfStackTraceElement1[i].toString());
/*  91 */         Throwable localThrowable = getCause();
/*  92 */         if (localThrowable != null)
/*     */         {
/*  94 */           localStringBuilder.append(new StringBuilder().append("\n caused by ").append(localThrowable).append("\n").toString());
/*  95 */           StackTraceElement[] arrayOfStackTraceElement2 = localThrowable.getStackTrace();
/*  96 */           for (int j = 0; j < arrayOfStackTraceElement2.length; j++)
/*  97 */             localStringBuilder.append(arrayOfStackTraceElement2[j].toString());
/*     */         }
/*  99 */         exLogger.fine(localStringBuilder.toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static String getErrString(String paramString)
/*     */   {
/* 106 */     return SQLServerResource.getResource(paramString);
/*     */   }
/*     */ 
/*     */   SQLServerException(String paramString, SQLState paramSQLState, DriverError paramDriverError, Throwable paramThrowable)
/*     */   {
/* 120 */     this(paramString, paramSQLState.getSQLStateCode(), paramDriverError.getErrorCode(), paramThrowable);
/*     */   }
/*     */ 
/*     */   SQLServerException(String paramString1, String paramString2, int paramInt, Throwable paramThrowable)
/*     */   {
/* 125 */     super(paramString1, paramString2, paramInt);
/* 126 */     initCause(paramThrowable);
/* 127 */     logException(null, paramString1, true);
/* 128 */     ActivityCorrelator.setCurrentActivityIdSentFlag();
/*     */   }
/*     */ 
/*     */   SQLServerException(String paramString, Throwable paramThrowable)
/*     */   {
/* 133 */     super(paramString);
/* 134 */     initCause(paramThrowable);
/* 135 */     logException(null, paramString, true);
/* 136 */     ActivityCorrelator.setCurrentActivityIdSentFlag();
/*     */   }
/*     */ 
/*     */   SQLServerException(Object paramObject, String paramString1, String paramString2, int paramInt, boolean paramBoolean)
/*     */   {
/* 142 */     super(paramString1, paramString2, paramInt);
/* 143 */     logException(paramObject, paramString1, paramBoolean);
/* 144 */     ActivityCorrelator.setCurrentActivityIdSentFlag();
/*     */   }
/*     */ 
/*     */   SQLServerException(Object paramObject, String paramString1, String paramString2, StreamError paramStreamError, boolean paramBoolean)
/*     */   {
/* 158 */     super(paramString1, paramString2, paramStreamError.getErrorNumber());
/*     */ 
/* 162 */     paramString1 = new StringBuilder().append("Msg ").append(paramStreamError.getErrorNumber()).append(", Level ").append(paramStreamError.getErrorSeverity()).append(", State ").append(paramStreamError.getErrorState()).append(", ").append(paramString1).toString();
/* 163 */     logException(paramObject, paramString1, paramBoolean);
/*     */   }
/*     */ 
/*     */   static void makeFromDriverError(SQLServerConnection paramSQLServerConnection, Object paramObject, String paramString1, String paramString2, boolean paramBoolean)
/*     */     throws SQLServerException
/*     */   {
/* 182 */     String str = "";
/*     */ 
/* 185 */     if (paramString2 != null)
/* 186 */       str = paramString2;
/* 187 */     if ((paramSQLServerConnection == null) || (!paramSQLServerConnection.xopenStates)) {
/* 188 */       str = mapFromXopen(paramString2);
/*     */     }
/* 190 */     SQLServerException localSQLServerException = new SQLServerException(paramObject, checkAndAppendClientConnId(paramString1, paramSQLServerConnection), str, 0, paramBoolean);
/* 191 */     if ((null != paramString2) && (paramString2.equals("08006")) && (null != paramSQLServerConnection))
/*     */     {
/* 193 */       paramSQLServerConnection.notifyPooledConnection(localSQLServerException);
/*     */ 
/* 195 */       paramSQLServerConnection.close();
/*     */     }
/*     */ 
/* 198 */     throw localSQLServerException;
/*     */   }
/*     */ 
/*     */   static void makeFromDatabaseError(SQLServerConnection paramSQLServerConnection, Object paramObject, String paramString, StreamError paramStreamError, boolean paramBoolean)
/*     */     throws SQLServerException
/*     */   {
/* 214 */     String str = generateStateCode(paramSQLServerConnection, paramStreamError.getErrorNumber(), paramStreamError.getErrorState());
/*     */ 
/* 216 */     SQLServerException localSQLServerException = new SQLServerException(paramObject, checkAndAppendClientConnId(paramString, paramSQLServerConnection), str, paramStreamError, paramBoolean);
/* 217 */     localSQLServerException.setDriverErrorCode(2);
/*     */ 
/* 220 */     if ((paramStreamError.getErrorSeverity() >= 20) && (null != paramSQLServerConnection))
/*     */     {
/* 222 */       paramSQLServerConnection.notifyPooledConnection(localSQLServerException);
/* 223 */       paramSQLServerConnection.close();
/*     */     }
/*     */ 
/* 226 */     throw localSQLServerException;
/*     */   }
/*     */ 
/*     */   static void ConvertConnectExceptionToSQLServerException(String paramString, int paramInt, SQLServerConnection paramSQLServerConnection, Exception paramException)
/*     */     throws SQLServerException
/*     */   {
/* 232 */     Exception localException = paramException;
/*     */ 
/* 234 */     if (localException != null)
/*     */     {
/* 236 */       MessageFormat localMessageFormat1 = new MessageFormat(getErrString("R_tcpOpenFailed"));
/* 237 */       Object[] arrayOfObject1 = { localException.getMessage() };
/* 238 */       MessageFormat localMessageFormat2 = new MessageFormat(getErrString("R_tcpipConnectionFailed"));
/* 239 */       Object[] arrayOfObject2 = { paramString, Integer.toString(paramInt), localMessageFormat1.format(arrayOfObject1) };
/* 240 */       String str = localMessageFormat2.format(arrayOfObject2);
/* 241 */       makeFromDriverError(paramSQLServerConnection, paramSQLServerConnection, str, "08001", false);
/*     */     }
/*     */   }
/*     */ 
/*     */   static String mapFromXopen(String paramString)
/*     */   {
/* 259 */     if (paramString == null)
/* 260 */       return null;
/* 261 */     if (paramString.equals("07009")) {
/* 262 */       return "S1093";
/*     */     }
/*     */ 
/* 265 */     if (paramString.equals("08001"))
/* 266 */       return "08S01";
/* 267 */     if (paramString.equals("08006")) {
/* 268 */       return "08S01";
/*     */     }
/*     */ 
/* 273 */     return "";
/*     */   }
/*     */ 
/*     */   static String generateStateCode(SQLServerConnection paramSQLServerConnection, int paramInt1, int paramInt2)
/*     */   {
/* 286 */     int i = (paramSQLServerConnection != null) && (paramSQLServerConnection.xopenStates) ? 1 : 0;
/* 287 */     if (i != 0)
/*     */     {
/* 289 */       switch (paramInt1) {
/*     */       case 4060:
/* 291 */         return "08001";
/*     */       case 18456:
/* 292 */         return "08001";
/*     */       case 2714:
/* 293 */         return "42S01";
/*     */       case 208:
/* 294 */         return "42S02";
/*     */       case 207:
/* 295 */         return "42S22";
/*     */       }
/*     */ 
/* 298 */       return "42000";
/*     */     }
/*     */ 
/* 303 */     switch (paramInt1)
/*     */     {
/*     */     case 8152:
/* 306 */       return "22001";
/*     */     case 515:
/*     */     case 547:
/* 308 */       return "23000";
/*     */     case 2601:
/* 309 */       return "23000";
/*     */     case 2714:
/* 310 */       return "S0001";
/*     */     case 208:
/* 311 */       return "S0002";
/*     */     case 1205:
/* 312 */       return "40001";
/*     */     case 2627:
/* 313 */       return "23000";
/*     */     }
/* 315 */     return new StringBuilder().append("S000").append(paramInt2).toString();
/*     */   }
/*     */ 
/*     */   static String checkAndAppendClientConnId(String paramString, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/* 328 */     if ((null != paramSQLServerConnection) && (paramSQLServerConnection.attachConnId()))
/*     */     {
/* 330 */       UUID localUUID = paramSQLServerConnection.getClientConIdInternal();
/* 331 */       assert (null != localUUID);
/* 332 */       StringBuilder localStringBuilder = new StringBuilder(paramString);
/* 333 */       localStringBuilder.append(" ClientConnectionId:");
/* 334 */       localStringBuilder.append(localUUID.toString());
/* 335 */       return localStringBuilder.toString();
/*     */     }
/*     */ 
/* 338 */     return paramString;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  55 */     exLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerException");
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerException
 * JD-Core Version:    0.6.0
 */