/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ public final class SQLServerCallableStatement extends SQLServerPreparedStatement
/*      */   implements ISQLServerCallableStatement
/*      */ {
/*      */   private ArrayList<String> paramNames;
/*   32 */   int nOutParams = 0;
/*      */ 
/*   35 */   int nOutParamsAssigned = 0;
/*      */ 
/*   37 */   private int outParamIndex = -1;
/*      */   private Parameter lastParamAccessed;
/*      */   private Closeable activeStream;
/*      */ 
/*      */   String getClassNameInternal()
/*      */   {
/*   48 */     return "SQLServerCallableStatement";
/*      */   }
/*      */ 
/*      */   SQLServerCallableStatement(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLServerException
/*      */   {
/*   63 */     super(paramSQLServerConnection, paramString, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/*   68 */     if (loggerExternal.isLoggable(Level.FINER))
/*   69 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2) });
/*   70 */     checkClosed();
/*   71 */     if ((paramInt1 < 1) || (paramInt1 > this.inOutParam.length))
/*      */     {
/*   73 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/*   74 */       localObject2 = new Object[] { new Integer(paramInt1) };
/*   75 */       SQLServerException.makeFromDriverError(this.connection, this, ((MessageFormat)localObject1).format(localObject2), "7009", false);
/*      */     }
/*      */ 
/*   78 */     Object localObject1 = JDBCType.of(paramInt2);
/*      */ 
/*   82 */     discardLastExecutionResults();
/*      */ 
/*   86 */     if (((JDBCType)localObject1).isUnsupported()) {
/*   87 */       localObject1 = JDBCType.BINARY;
/*      */     }
/*   89 */     Object localObject2 = this.inOutParam[(paramInt1 - 1)];
/*   90 */     assert (null != localObject2);
/*      */ 
/*   94 */     if (!((Parameter)localObject2).isOutput()) {
/*   95 */       this.nOutParams += 1;
/*      */     }
/*      */ 
/*   99 */     ((Parameter)localObject2).registerForOutput((JDBCType)localObject1, this.connection);
/*  100 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   private final Parameter getOutParameter(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  112 */     processResults();
/*      */ 
/*  115 */     if ((this.inOutParam[(paramInt - 1)] == this.lastParamAccessed) || (this.inOutParam[(paramInt - 1)].isValueGotten())) {
/*  116 */       return this.inOutParam[(paramInt - 1)];
/*      */     }
/*      */ 
/*  120 */     while (this.outParamIndex != paramInt - 1) {
/*  121 */       skipOutParameters(1, false);
/*      */     }
/*  123 */     return this.inOutParam[(paramInt - 1)];
/*      */   }
/*      */ 
/*      */   void startResults()
/*      */   {
/*  128 */     super.startResults();
/*  129 */     this.outParamIndex = -1;
/*  130 */     this.nOutParamsAssigned = 0;
/*  131 */     this.lastParamAccessed = null;
/*  132 */     assert (null == this.activeStream);
/*      */   }
/*      */ 
/*      */   void processBatch() throws SQLServerException
/*      */   {
/*  137 */     processResults();
/*      */ 
/*  143 */     assert (this.nOutParams >= 0);
/*  144 */     if (this.nOutParams > 0)
/*      */     {
/*  146 */       processOutParameters();
/*  147 */       processBatchRemainder();
/*      */     }
/*      */   }
/*      */ 
/*      */   final void processOutParameters() throws SQLServerException
/*      */   {
/*  153 */     assert (this.nOutParams > 0);
/*  154 */     assert (null != this.inOutParam);
/*      */ 
/*  157 */     closeActiveStream();
/*      */ 
/*  161 */     if (this.outParamIndex >= 0)
/*      */     {
/*  167 */       for (int i = 0; i < this.inOutParam.length; i++)
/*      */       {
/*  169 */         if ((i == this.outParamIndex) || (!this.inOutParam[i].isValueGotten()))
/*      */           continue;
/*  171 */         assert (this.inOutParam[i].isOutput());
/*  172 */         this.inOutParam[i].resetOutputValue();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  178 */     assert (this.nOutParamsAssigned <= this.nOutParams);
/*  179 */     if (this.nOutParamsAssigned < this.nOutParams) {
/*  180 */       skipOutParameters(this.nOutParams - this.nOutParamsAssigned, true);
/*      */     }
/*      */ 
/*  186 */     if (this.outParamIndex >= 0)
/*      */     {
/*  188 */       this.inOutParam[this.outParamIndex].skipValue(resultsReader(), true);
/*  189 */       this.inOutParam[this.outParamIndex].resetOutputValue();
/*  190 */       this.outParamIndex = -1;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void processBatchRemainder()
/*      */     throws SQLServerException
/*      */   {
/*  228 */     1ExecDoneHandler local1ExecDoneHandler = new TDSTokenHandler()
/*      */     {
/*      */       boolean onDone(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/*  210 */         StreamDone localStreamDone = new StreamDone();
/*  211 */         localStreamDone.setFromTDS(paramTDSReader);
/*      */ 
/*  216 */         if (localStreamDone.wasRPCInBatch())
/*      */         {
/*  218 */           SQLServerCallableStatement.this.startResults();
/*  219 */           return false;
/*      */         }
/*      */ 
/*  224 */         return true;
/*      */       }
/*      */     };
/*  229 */     TDSParser.parse(resultsReader(), local1ExecDoneHandler);
/*      */   }
/*      */ 
/*      */   private void skipOutParameters(int paramInt, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/*  260 */     1OutParamHandler local1OutParamHandler = new TDSTokenHandler()
/*      */     {
/*  237 */       final StreamRetValue srv = new StreamRetValue();
/*      */       private boolean foundParam;
/*      */ 
/*      */       final boolean foundParam()
/*      */       {
/*  240 */         return this.foundParam;
/*      */       }
/*      */ 
/*      */       final void reset()
/*      */       {
/*  249 */         this.foundParam = false;
/*      */       }
/*      */ 
/*      */       boolean onRetValue(TDSReader paramTDSReader) throws SQLServerException
/*      */       {
/*  254 */         this.srv.setFromTDS(paramTDSReader);
/*  255 */         this.foundParam = true;
/*  256 */         return false;
/*      */       }
/*      */     };
/*  263 */     assert (paramInt <= this.nOutParams - this.nOutParamsAssigned);
/*  264 */     for (int i = 0; i < paramInt; i++)
/*      */     {
/*  268 */       if (-1 != this.outParamIndex)
/*      */       {
/*  270 */         this.inOutParam[this.outParamIndex].skipValue(resultsReader(), paramBoolean);
/*  271 */         if (paramBoolean) {
/*  272 */           this.inOutParam[this.outParamIndex].resetOutputValue();
/*      */         }
/*      */       }
/*      */ 
/*  276 */       local1OutParamHandler.reset();
/*  277 */       TDSParser.parse(resultsReader(), local1OutParamHandler);
/*      */ 
/*  282 */       if (!local1OutParamHandler.foundParam())
/*      */       {
/*  289 */         if (paramBoolean)
/*      */         {
/*      */           break;
/*      */         }
/*      */ 
/*  296 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_valueNotSetForParameter"));
/*  297 */         Object[] arrayOfObject = { new Integer(this.outParamIndex + 1) };
/*  298 */         SQLServerException.makeFromDriverError(this.connection, this, localMessageFormat.format(arrayOfObject), null, false);
/*      */       }
/*      */ 
/*  308 */       this.outParamIndex = local1OutParamHandler.srv.getOrdinalOrLength();
/*      */ 
/*  312 */       this.outParamIndex -= this.outParamIndexAdjustment;
/*  313 */       if ((this.outParamIndex < 0) || (this.outParamIndex >= this.inOutParam.length) || (!this.inOutParam[this.outParamIndex].isOutput()))
/*      */       {
/*  315 */         getStatementLogger().info(new StringBuilder().append(toString()).append(" Unexpected outParamIndex: ").append(this.outParamIndex).append("; adjustment: ").append(this.outParamIndexAdjustment).toString());
/*  316 */         this.connection.throwInvalidTDS();
/*      */       }
/*      */ 
/*  320 */       this.nOutParamsAssigned += 1;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLServerException
/*      */   {
/*  326 */     if (loggerExternal.isLoggable(Level.FINER))
/*  327 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2), paramString });
/*  328 */     checkClosed();
/*  329 */     registerOutParameter(paramInt1, paramInt2);
/*  330 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*      */   {
/*  335 */     if (loggerExternal.isLoggable(Level.FINER))
/*  336 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2), new Integer(paramInt3) });
/*  337 */     checkClosed();
/*  338 */     registerOutParameter(paramInt1, paramInt2);
/*  339 */     this.inOutParam[(paramInt1 - 1)].setOutScale(paramInt3);
/*  340 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   private Parameter getterGetParam(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  347 */     checkClosed();
/*      */     MessageFormat localMessageFormat;
/*      */     Object[] arrayOfObject;
/*  350 */     if ((paramInt < 1) || (paramInt > this.inOutParam.length))
/*      */     {
/*  352 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidOutputParameter"));
/*  353 */       arrayOfObject = new Object[] { new Integer(paramInt) };
/*  354 */       SQLServerException.makeFromDriverError(this.connection, this, localMessageFormat.format(arrayOfObject), "07009", false);
/*      */     }
/*      */ 
/*  358 */     if (!this.inOutParam[(paramInt - 1)].isOutput())
/*      */     {
/*  360 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_outputParameterNotRegisteredForOutput"));
/*  361 */       arrayOfObject = new Object[] { new Integer(paramInt) };
/*  362 */       SQLServerException.makeFromDriverError(this.connection, this, localMessageFormat.format(arrayOfObject), "07009", true);
/*      */     }
/*      */ 
/*  366 */     if (!wasExecuted()) {
/*  367 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_statementMustBeExecuted"), "07009", false);
/*      */     }
/*  369 */     resultsReader().getCommand().checkForInterrupt();
/*      */ 
/*  371 */     closeActiveStream();
/*  372 */     if (getStatementLogger().isLoggable(Level.FINER)) {
/*  373 */       getStatementLogger().finer(new StringBuilder().append(toString()).append(" Getting Param:").append(paramInt).toString());
/*      */     }
/*      */ 
/*  376 */     this.lastParamAccessed = getOutParameter(paramInt);
/*  377 */     return this.lastParamAccessed;
/*      */   }
/*      */ 
/*      */   private Object getValue(int paramInt, JDBCType paramJDBCType) throws SQLServerException
/*      */   {
/*  382 */     return getterGetParam(paramInt).getValue(paramJDBCType, null, null, resultsReader());
/*      */   }
/*      */ 
/*      */   private Object getValue(int paramInt, JDBCType paramJDBCType, Calendar paramCalendar) throws SQLServerException
/*      */   {
/*  387 */     return getterGetParam(paramInt).getValue(paramJDBCType, null, paramCalendar, resultsReader());
/*      */   }
/*      */ 
/*      */   private Object getStream(int paramInt, StreamType paramStreamType) throws SQLServerException
/*      */   {
/*  392 */     Object localObject = getterGetParam(paramInt).getValue(paramStreamType.getJDBCType(), new InputStreamGetterArgs(paramStreamType, getIsResponseBufferingAdaptive(), getIsResponseBufferingAdaptive(), toString()), null, resultsReader());
/*      */ 
/*  402 */     this.activeStream = ((Closeable)localObject);
/*  403 */     return localObject;
/*      */   }
/*      */ 
/*      */   private Object getSQLXMLInternal(int paramInt) throws SQLServerException {
/*  407 */     SQLServerSQLXML localSQLServerSQLXML = (SQLServerSQLXML)getterGetParam(paramInt).getValue(JDBCType.SQLXML, new InputStreamGetterArgs(StreamType.SQLXML, getIsResponseBufferingAdaptive(), getIsResponseBufferingAdaptive(), toString()), null, resultsReader());
/*      */ 
/*  417 */     if (null != localSQLServerSQLXML)
/*  418 */       this.activeStream = localSQLServerSQLXML.getStream();
/*  419 */     return localSQLServerSQLXML;
/*      */   }
/*      */ 
/*      */   public int getInt(int paramInt) throws SQLServerException
/*      */   {
/*  424 */     loggerExternal.entering(getClassNameLogging(), "getInt", Integer.valueOf(paramInt));
/*  425 */     checkClosed();
/*  426 */     Integer localInteger = (Integer)getValue(paramInt, JDBCType.INTEGER);
/*  427 */     loggerExternal.exiting(getClassNameLogging(), "getInt", localInteger);
/*  428 */     return null != localInteger ? localInteger.intValue() : 0;
/*      */   }
/*      */ 
/*      */   public int getInt(String paramString) throws SQLServerException
/*      */   {
/*  433 */     loggerExternal.entering(getClassNameLogging(), "getInt", paramString);
/*  434 */     checkClosed();
/*  435 */     Integer localInteger = (Integer)getValue(findColumn(paramString), JDBCType.INTEGER);
/*  436 */     loggerExternal.exiting(getClassNameLogging(), "getInt", localInteger);
/*  437 */     return null != localInteger ? localInteger.intValue() : 0;
/*      */   }
/*      */ 
/*      */   public String getString(int paramInt) throws SQLServerException
/*      */   {
/*  442 */     loggerExternal.entering(getClassNameLogging(), "getString", Integer.valueOf(paramInt));
/*  443 */     checkClosed();
/*  444 */     String str = (String)getValue(paramInt, JDBCType.CHAR);
/*  445 */     loggerExternal.exiting(getClassNameLogging(), "getString", str);
/*  446 */     return str;
/*      */   }
/*      */ 
/*      */   public String getString(String paramString) throws SQLServerException
/*      */   {
/*  451 */     loggerExternal.entering(getClassNameLogging(), "getString", paramString);
/*  452 */     checkClosed();
/*  453 */     String str = (String)getValue(findColumn(paramString), JDBCType.CHAR);
/*  454 */     loggerExternal.exiting(getClassNameLogging(), "getString", str);
/*  455 */     return str;
/*      */   }
/*      */ 
/*      */   public final String getNString(int paramInt) throws SQLException
/*      */   {
/*  460 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*  462 */     loggerExternal.entering(getClassNameLogging(), "getNString", Integer.valueOf(paramInt));
/*  463 */     checkClosed();
/*  464 */     String str = (String)getValue(paramInt, JDBCType.NCHAR);
/*  465 */     loggerExternal.exiting(getClassNameLogging(), "getNString", str);
/*  466 */     return str;
/*      */   }
/*      */ 
/*      */   public final String getNString(String paramString) throws SQLException
/*      */   {
/*  471 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*  473 */     loggerExternal.entering(getClassNameLogging(), "getNString", paramString);
/*  474 */     checkClosed();
/*  475 */     String str = (String)getValue(findColumn(paramString), JDBCType.NCHAR);
/*  476 */     loggerExternal.exiting(getClassNameLogging(), "getNString", str);
/*  477 */     return str;
/*      */   }
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  482 */     if (loggerExternal.isLoggable(Level.FINER))
/*  483 */       loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/*  484 */     checkClosed();
/*  485 */     BigDecimal localBigDecimal = (BigDecimal)getValue(paramInt1, JDBCType.DECIMAL);
/*  486 */     if (null != localBigDecimal)
/*  487 */       localBigDecimal = localBigDecimal.setScale(paramInt2, 1);
/*  488 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", localBigDecimal);
/*  489 */     return localBigDecimal;
/*      */   }
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/*  494 */     if (loggerExternal.isLoggable(Level.FINER))
/*  495 */       loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { paramString, Integer.valueOf(paramInt) });
/*  496 */     checkClosed();
/*  497 */     BigDecimal localBigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/*  498 */     if (null != localBigDecimal)
/*  499 */       localBigDecimal = localBigDecimal.setScale(paramInt, 1);
/*  500 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", localBigDecimal);
/*  501 */     return localBigDecimal;
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(int paramInt) throws SQLServerException
/*      */   {
/*  506 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", Integer.valueOf(paramInt));
/*  507 */     checkClosed();
/*  508 */     Boolean localBoolean = (Boolean)getValue(paramInt, JDBCType.BIT);
/*  509 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", localBoolean);
/*  510 */     return null != localBoolean ? localBoolean.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(String paramString) throws SQLServerException
/*      */   {
/*  515 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", paramString);
/*  516 */     checkClosed();
/*  517 */     Boolean localBoolean = (Boolean)getValue(findColumn(paramString), JDBCType.BIT);
/*  518 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", localBoolean);
/*  519 */     return null != localBoolean ? localBoolean.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   public byte getByte(int paramInt) throws SQLServerException
/*      */   {
/*  524 */     loggerExternal.entering(getClassNameLogging(), "getByte", Integer.valueOf(paramInt));
/*  525 */     checkClosed();
/*  526 */     Short localShort = (Short)getValue(paramInt, JDBCType.TINYINT);
/*  527 */     byte b = null != localShort ? localShort.byteValue() : 0;
/*  528 */     loggerExternal.exiting(getClassNameLogging(), "getByte", Byte.valueOf(b));
/*  529 */     return b;
/*      */   }
/*      */ 
/*      */   public byte getByte(String paramString) throws SQLServerException
/*      */   {
/*  534 */     loggerExternal.entering(getClassNameLogging(), "getByte", paramString);
/*  535 */     checkClosed();
/*  536 */     Short localShort = (Short)getValue(findColumn(paramString), JDBCType.TINYINT);
/*  537 */     byte b = null != localShort ? localShort.byteValue() : 0;
/*  538 */     loggerExternal.exiting(getClassNameLogging(), "getByte", Byte.valueOf(b));
/*  539 */     return b;
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(int paramInt) throws SQLServerException
/*      */   {
/*  544 */     loggerExternal.entering(getClassNameLogging(), "getBytes", Integer.valueOf(paramInt));
/*  545 */     checkClosed();
/*  546 */     byte[] arrayOfByte = (byte[])(byte[])getValue(paramInt, JDBCType.BINARY);
/*  547 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
/*  548 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(String paramString) throws SQLServerException
/*      */   {
/*  553 */     loggerExternal.entering(getClassNameLogging(), "getBytes", paramString);
/*  554 */     checkClosed();
/*  555 */     byte[] arrayOfByte = (byte[])(byte[])getValue(findColumn(paramString), JDBCType.BINARY);
/*  556 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
/*  557 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public Date getDate(int paramInt) throws SQLServerException
/*      */   {
/*  562 */     loggerExternal.entering(getClassNameLogging(), "getDate", Integer.valueOf(paramInt));
/*  563 */     checkClosed();
/*  564 */     Date localDate = (Date)getValue(paramInt, JDBCType.DATE);
/*  565 */     loggerExternal.exiting(getClassNameLogging(), "getDate", localDate);
/*  566 */     return localDate;
/*      */   }
/*      */ 
/*      */   public Date getDate(String paramString) throws SQLServerException
/*      */   {
/*  571 */     loggerExternal.entering(getClassNameLogging(), "getDate", paramString);
/*  572 */     checkClosed();
/*  573 */     Date localDate = (Date)getValue(findColumn(paramString), JDBCType.DATE);
/*  574 */     loggerExternal.exiting(getClassNameLogging(), "getDate", localDate);
/*  575 */     return localDate;
/*      */   }
/*      */ 
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLServerException
/*      */   {
/*  580 */     if (loggerExternal.isLoggable(Level.FINER))
/*  581 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { Integer.valueOf(paramInt), paramCalendar });
/*  582 */     checkClosed();
/*  583 */     Date localDate = (Date)getValue(paramInt, JDBCType.DATE, paramCalendar);
/*  584 */     loggerExternal.exiting(getClassNameLogging(), "getDate", localDate);
/*  585 */     return localDate;
/*      */   }
/*      */ 
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLServerException
/*      */   {
/*  590 */     if (loggerExternal.isLoggable(Level.FINER))
/*  591 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { paramString, paramCalendar });
/*  592 */     checkClosed();
/*  593 */     Date localDate = (Date)getValue(findColumn(paramString), JDBCType.DATE, paramCalendar);
/*  594 */     loggerExternal.exiting(getClassNameLogging(), "getDate", localDate);
/*  595 */     return localDate;
/*      */   }
/*      */ 
/*      */   public double getDouble(int paramInt) throws SQLServerException
/*      */   {
/*  600 */     loggerExternal.entering(getClassNameLogging(), "getDouble", Integer.valueOf(paramInt));
/*  601 */     checkClosed();
/*  602 */     Double localDouble = (Double)getValue(paramInt, JDBCType.DOUBLE);
/*  603 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", localDouble);
/*  604 */     return null != localDouble ? localDouble.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   public double getDouble(String paramString) throws SQLServerException
/*      */   {
/*  609 */     loggerExternal.entering(getClassNameLogging(), "getDouble", paramString);
/*  610 */     checkClosed();
/*  611 */     Double localDouble = (Double)getValue(findColumn(paramString), JDBCType.DOUBLE);
/*  612 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", localDouble);
/*  613 */     return null != localDouble ? localDouble.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   public float getFloat(int paramInt) throws SQLServerException
/*      */   {
/*  618 */     loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(paramInt));
/*  619 */     checkClosed();
/*  620 */     Float localFloat = (Float)getValue(paramInt, JDBCType.REAL);
/*  621 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", localFloat);
/*  622 */     return null != localFloat ? localFloat.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */   public float getFloat(String paramString)
/*      */     throws SQLServerException
/*      */   {
/*  628 */     loggerExternal.entering(getClassNameLogging(), "getFloat", paramString);
/*  629 */     checkClosed();
/*  630 */     Float localFloat = (Float)getValue(findColumn(paramString), JDBCType.REAL);
/*  631 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", localFloat);
/*  632 */     return null != localFloat ? localFloat.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */   public long getLong(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  638 */     loggerExternal.entering(getClassNameLogging(), "getLong", Integer.valueOf(paramInt));
/*  639 */     checkClosed();
/*  640 */     Long localLong = (Long)getValue(paramInt, JDBCType.BIGINT);
/*  641 */     loggerExternal.exiting(getClassNameLogging(), "getLong", localLong);
/*  642 */     return null != localLong ? localLong.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   public long getLong(String paramString) throws SQLServerException
/*      */   {
/*  647 */     loggerExternal.entering(getClassNameLogging(), "getLong", paramString);
/*  648 */     checkClosed();
/*  649 */     Long localLong = (Long)getValue(findColumn(paramString), JDBCType.BIGINT);
/*  650 */     loggerExternal.exiting(getClassNameLogging(), "getLong", localLong);
/*  651 */     return null != localLong ? localLong.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   public Object getObject(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  657 */     loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(paramInt));
/*  658 */     checkClosed();
/*  659 */     Object localObject = getValue(paramInt, getterGetParam(paramInt).getJdbcType());
/*  660 */     loggerExternal.exiting(getClassNameLogging(), "getObject", localObject);
/*  661 */     return localObject;
/*      */   }
/*      */ 
/*      */   public Object getObject(String paramString) throws SQLServerException
/*      */   {
/*  666 */     loggerExternal.entering(getClassNameLogging(), "getObject", paramString);
/*  667 */     checkClosed();
/*  668 */     int i = findColumn(paramString);
/*  669 */     Object localObject = getValue(i, getterGetParam(i).getJdbcType());
/*  670 */     loggerExternal.exiting(getClassNameLogging(), "getObject", localObject);
/*  671 */     return localObject;
/*      */   }
/*      */ 
/*      */   public short getShort(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  677 */     loggerExternal.entering(getClassNameLogging(), "getShort", Integer.valueOf(paramInt));
/*  678 */     checkClosed();
/*  679 */     Short localShort = (Short)getValue(paramInt, JDBCType.SMALLINT);
/*  680 */     loggerExternal.exiting(getClassNameLogging(), "getShort", localShort);
/*  681 */     return null != localShort ? localShort.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   public short getShort(String paramString) throws SQLServerException
/*      */   {
/*  686 */     loggerExternal.entering(getClassNameLogging(), "getShort", paramString);
/*  687 */     checkClosed();
/*  688 */     Short localShort = (Short)getValue(findColumn(paramString), JDBCType.SMALLINT);
/*  689 */     loggerExternal.exiting(getClassNameLogging(), "getShort", localShort);
/*  690 */     return null != localShort ? localShort.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   public Time getTime(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  696 */     loggerExternal.entering(getClassNameLogging(), "getTime", Integer.valueOf(paramInt));
/*  697 */     checkClosed();
/*  698 */     Time localTime = (Time)getValue(paramInt, JDBCType.TIME);
/*  699 */     loggerExternal.exiting(getClassNameLogging(), "getTime", localTime);
/*  700 */     return localTime;
/*      */   }
/*      */ 
/*      */   public Time getTime(String paramString) throws SQLServerException
/*      */   {
/*  705 */     loggerExternal.entering(getClassNameLogging(), "getTime", paramString);
/*  706 */     checkClosed();
/*  707 */     Time localTime = (Time)getValue(findColumn(paramString), JDBCType.TIME);
/*  708 */     loggerExternal.exiting(getClassNameLogging(), "getTime", localTime);
/*  709 */     return localTime;
/*      */   }
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLServerException
/*      */   {
/*  714 */     if (loggerExternal.isLoggable(Level.FINER))
/*  715 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { Integer.valueOf(paramInt), paramCalendar });
/*  716 */     checkClosed();
/*  717 */     Time localTime = (Time)getValue(paramInt, JDBCType.TIME, paramCalendar);
/*  718 */     loggerExternal.exiting(getClassNameLogging(), "getTime", localTime);
/*  719 */     return localTime;
/*      */   }
/*      */ 
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLServerException
/*      */   {
/*  724 */     if (loggerExternal.isLoggable(Level.FINER))
/*  725 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { paramString, paramCalendar });
/*  726 */     checkClosed();
/*  727 */     Time localTime = (Time)getValue(findColumn(paramString), JDBCType.TIME, paramCalendar);
/*  728 */     loggerExternal.exiting(getClassNameLogging(), "getTime", localTime);
/*  729 */     return localTime;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLServerException
/*      */   {
/*  734 */     if (loggerExternal.isLoggable(Level.FINER))
/*  735 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", Integer.valueOf(paramInt));
/*  736 */     checkClosed();
/*  737 */     Timestamp localTimestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
/*  738 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", localTimestamp);
/*  739 */     return localTimestamp;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString) throws SQLServerException
/*      */   {
/*  744 */     loggerExternal.entering(getClassNameLogging(), "getTimestamp", paramString);
/*  745 */     checkClosed();
/*  746 */     Timestamp localTimestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
/*  747 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", localTimestamp);
/*  748 */     return localTimestamp;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLServerException
/*      */   {
/*  753 */     if (loggerExternal.isLoggable(Level.FINER))
/*  754 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { Integer.valueOf(paramInt), paramCalendar });
/*  755 */     checkClosed();
/*  756 */     Timestamp localTimestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
/*  757 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", localTimestamp);
/*  758 */     return localTimestamp;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLServerException
/*      */   {
/*  763 */     if (loggerExternal.isLoggable(Level.FINER))
/*  764 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { paramString, paramCalendar });
/*  765 */     checkClosed();
/*  766 */     Timestamp localTimestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
/*  767 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", localTimestamp);
/*  768 */     return localTimestamp;
/*      */   }
/*      */ 
/*      */   public DateTimeOffset getDateTimeOffset(int paramInt) throws SQLException
/*      */   {
/*  773 */     if (loggerExternal.isLoggable(Level.FINER))
/*  774 */       loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", Integer.valueOf(paramInt));
/*  775 */     checkClosed();
/*      */ 
/*  778 */     if (!this.connection.isKatmaiOrLater()) {
/*  779 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*  785 */     DateTimeOffset localDateTimeOffset = (DateTimeOffset)getValue(paramInt, JDBCType.DATETIMEOFFSET);
/*  786 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", localDateTimeOffset);
/*  787 */     return localDateTimeOffset;
/*      */   }
/*      */ 
/*      */   public DateTimeOffset getDateTimeOffset(String paramString) throws SQLException
/*      */   {
/*  792 */     loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", paramString);
/*  793 */     checkClosed();
/*      */ 
/*  796 */     if (!this.connection.isKatmaiOrLater()) {
/*  797 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*  803 */     DateTimeOffset localDateTimeOffset = (DateTimeOffset)getValue(findColumn(paramString), JDBCType.DATETIMEOFFSET);
/*  804 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", localDateTimeOffset);
/*  805 */     return localDateTimeOffset;
/*      */   }
/*      */ 
/*      */   public boolean wasNull() throws SQLServerException
/*      */   {
/*  810 */     loggerExternal.entering(getClassNameLogging(), "wasNull");
/*  811 */     checkClosed();
/*  812 */     boolean bool = false;
/*  813 */     if (null != this.lastParamAccessed)
/*      */     {
/*  815 */       bool = this.lastParamAccessed.isNull();
/*      */     }
/*  817 */     loggerExternal.exiting(getClassNameLogging(), "wasNull", Boolean.valueOf(bool));
/*  818 */     return bool;
/*      */   }
/*      */ 
/*      */   public final InputStream getAsciiStream(int paramInt) throws SQLServerException
/*      */   {
/*  823 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", Integer.valueOf(paramInt));
/*  824 */     checkClosed();
/*  825 */     InputStream localInputStream = (InputStream)getStream(paramInt, StreamType.ASCII);
/*  826 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", localInputStream);
/*  827 */     return localInputStream;
/*      */   }
/*      */ 
/*      */   public final InputStream getAsciiStream(String paramString) throws SQLServerException
/*      */   {
/*  832 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", paramString);
/*  833 */     checkClosed();
/*  834 */     InputStream localInputStream = (InputStream)getStream(findColumn(paramString), StreamType.ASCII);
/*  835 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", localInputStream);
/*  836 */     return localInputStream;
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLServerException
/*      */   {
/*  841 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", Integer.valueOf(paramInt));
/*  842 */     checkClosed();
/*  843 */     BigDecimal localBigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
/*  844 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", localBigDecimal);
/*  845 */     return localBigDecimal;
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLServerException
/*      */   {
/*  850 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", paramString);
/*  851 */     checkClosed();
/*  852 */     BigDecimal localBigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/*  853 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", localBigDecimal);
/*  854 */     return localBigDecimal;
/*      */   }
/*      */ 
/*      */   public final InputStream getBinaryStream(int paramInt) throws SQLServerException
/*      */   {
/*  859 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", Integer.valueOf(paramInt));
/*  860 */     checkClosed();
/*  861 */     InputStream localInputStream = (InputStream)getStream(paramInt, StreamType.BINARY);
/*  862 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", localInputStream);
/*  863 */     return localInputStream;
/*      */   }
/*      */ 
/*      */   public final InputStream getBinaryStream(String paramString) throws SQLServerException
/*      */   {
/*  868 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", paramString);
/*  869 */     checkClosed();
/*  870 */     InputStream localInputStream = (InputStream)getStream(findColumn(paramString), StreamType.BINARY);
/*  871 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", localInputStream);
/*  872 */     return localInputStream;
/*      */   }
/*      */ 
/*      */   public Blob getBlob(int paramInt) throws SQLServerException
/*      */   {
/*  877 */     loggerExternal.entering(getClassNameLogging(), "getBlob", Integer.valueOf(paramInt));
/*  878 */     checkClosed();
/*  879 */     Blob localBlob = (Blob)getValue(paramInt, JDBCType.BLOB);
/*  880 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", localBlob);
/*  881 */     return localBlob;
/*      */   }
/*      */ 
/*      */   public Blob getBlob(String paramString) throws SQLServerException
/*      */   {
/*  886 */     loggerExternal.entering(getClassNameLogging(), "getBlob", paramString);
/*  887 */     checkClosed();
/*  888 */     Blob localBlob = (Blob)getValue(findColumn(paramString), JDBCType.BLOB);
/*  889 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", localBlob);
/*  890 */     return localBlob;
/*      */   }
/*      */ 
/*      */   public final Reader getCharacterStream(int paramInt) throws SQLServerException
/*      */   {
/*  895 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", Integer.valueOf(paramInt));
/*  896 */     checkClosed();
/*  897 */     Reader localReader = (Reader)getStream(paramInt, StreamType.CHARACTER);
/*  898 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", localReader);
/*  899 */     return localReader;
/*      */   }
/*      */ 
/*      */   public final Reader getCharacterStream(String paramString) throws SQLException
/*      */   {
/*  904 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*  906 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", paramString);
/*  907 */     checkClosed();
/*  908 */     Reader localReader = (Reader)getStream(findColumn(paramString), StreamType.CHARACTER);
/*  909 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterSream", localReader);
/*  910 */     return localReader;
/*      */   }
/*      */ 
/*      */   public final Reader getNCharacterStream(int paramInt) throws SQLException
/*      */   {
/*  915 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  916 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", Integer.valueOf(paramInt));
/*  917 */     checkClosed();
/*  918 */     Reader localReader = (Reader)getStream(paramInt, StreamType.NCHARACTER);
/*  919 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", localReader);
/*  920 */     return localReader;
/*      */   }
/*      */ 
/*      */   public final Reader getNCharacterStream(String paramString) throws SQLException
/*      */   {
/*  925 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*  927 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", paramString);
/*  928 */     checkClosed();
/*  929 */     Reader localReader = (Reader)getStream(findColumn(paramString), StreamType.NCHARACTER);
/*  930 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", localReader);
/*  931 */     return localReader;
/*      */   }
/*      */ 
/*      */   void closeActiveStream() throws SQLServerException
/*      */   {
/*  936 */     if (null != this.activeStream)
/*      */     {
/*      */       try
/*      */       {
/*  940 */         this.activeStream.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*  944 */         SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*      */       }
/*      */       finally
/*      */       {
/*  948 */         this.activeStream = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public Clob getClob(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  956 */     loggerExternal.entering(getClassNameLogging(), "getClob", Integer.valueOf(paramInt));
/*  957 */     checkClosed();
/*  958 */     Clob localClob = (Clob)getValue(paramInt, JDBCType.CLOB);
/*  959 */     loggerExternal.exiting(getClassNameLogging(), "getClob", localClob);
/*  960 */     return localClob;
/*      */   }
/*      */ 
/*      */   public Clob getClob(String paramString) throws SQLServerException
/*      */   {
/*  965 */     loggerExternal.entering(getClassNameLogging(), "getClob", paramString);
/*  966 */     checkClosed();
/*  967 */     Clob localClob = (Clob)getValue(findColumn(paramString), JDBCType.CLOB);
/*  968 */     loggerExternal.exiting(getClassNameLogging(), "getClob", localClob);
/*  969 */     return localClob;
/*      */   }
/*      */ 
/*      */   public NClob getNClob(int paramInt) throws SQLException
/*      */   {
/*  974 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  975 */     loggerExternal.entering(getClassNameLogging(), "getNClob", Integer.valueOf(paramInt));
/*  976 */     checkClosed();
/*  977 */     NClob localNClob = (NClob)getValue(paramInt, JDBCType.NCLOB);
/*  978 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", localNClob);
/*  979 */     return localNClob;
/*      */   }
/*      */ 
/*      */   public NClob getNClob(String paramString) throws SQLException
/*      */   {
/*  984 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  985 */     loggerExternal.entering(getClassNameLogging(), "getNClob", paramString);
/*  986 */     checkClosed();
/*  987 */     NClob localNClob = (NClob)getValue(findColumn(paramString), JDBCType.NCLOB);
/*  988 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", localNClob);
/*  989 */     return localNClob;
/*      */   }
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLServerException {
/*  993 */     NotImplemented();
/*  994 */     return null;
/*      */   }
/*      */ 
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLServerException {
/*  998 */     checkClosed();
/*  999 */     return getObject(findColumn(paramString), paramMap);
/*      */   }
/*      */ 
/*      */   public Ref getRef(int paramInt) throws SQLServerException {
/* 1003 */     NotImplemented();
/* 1004 */     return null;
/*      */   }
/*      */   public Ref getRef(String paramString) throws SQLServerException {
/* 1007 */     checkClosed();
/* 1008 */     return getRef(findColumn(paramString));
/*      */   }
/*      */ 
/*      */   public Array getArray(int paramInt) throws SQLServerException {
/* 1012 */     NotImplemented();
/* 1013 */     return null;
/*      */   }
/*      */   public Array getArray(String paramString) throws SQLServerException {
/* 1016 */     checkClosed();
/* 1017 */     return getArray(findColumn(paramString));
/*      */   }
/*      */ 
/*      */   private int findColumn(String paramString)
/*      */     throws SQLServerException
/*      */   {
/*      */     Object localObject1;
/*      */     Object localObject2;
/* 1107 */     if (this.paramNames == null)
/*      */     {
/*      */       try
/*      */       {
/* 1114 */         SQLServerStatement localSQLServerStatement = (SQLServerStatement)this.connection.createStatement();
/* 1115 */         1ThreePartNamesParser local1ThreePartNamesParser = new Object()
/*      */         {
/* 1034 */           private String procedurePart = null;
/* 1035 */           private String ownerPart = null;
/* 1036 */           private String databasePart = null;
/*      */ 
/* 1051 */           private final Pattern threePartName = Pattern.compile(JDBCCallSyntaxTranslator.getSQLIdentifierWithGroups());
/*      */ 
/*      */           String getProcedurePart()
/*      */           {
/* 1038 */             return this.procedurePart; } 
/* 1039 */           String getOwnerPart() { return this.ownerPart; } 
/* 1040 */           String getDatabasePart() { return this.databasePart;
/*      */           }
/*      */ 
/*      */           final void parseProcedureNameIntoParts(String paramString)
/*      */           {
/* 1057 */             if (null != paramString)
/*      */             {
/* 1059 */               Matcher localMatcher = this.threePartName.matcher(paramString);
/* 1060 */               if (localMatcher.matches())
/*      */               {
/* 1066 */                 if (localMatcher.group(2) != null)
/*      */                 {
/* 1068 */                   this.databasePart = localMatcher.group(1);
/*      */ 
/* 1071 */                   localMatcher = this.threePartName.matcher(localMatcher.group(2));
/* 1072 */                   if (localMatcher.matches())
/*      */                   {
/* 1074 */                     if (null != localMatcher.group(2))
/*      */                     {
/* 1076 */                       this.ownerPart = localMatcher.group(1);
/* 1077 */                       this.procedurePart = localMatcher.group(2);
/*      */                     }
/*      */                     else
/*      */                     {
/* 1081 */                       this.ownerPart = this.databasePart;
/* 1082 */                       this.databasePart = null;
/* 1083 */                       this.procedurePart = localMatcher.group(1);
/*      */                     }
/*      */ 
/*      */                   }
/*      */ 
/*      */                 }
/*      */                 else
/*      */                 {
/* 1093 */                   this.procedurePart = localMatcher.group(1);
/*      */                 }
/*      */               }
/*      */               else
/*      */               {
/* 1098 */                 this.procedurePart = paramString;
/*      */               }
/*      */             }
/*      */           }
/*      */         };
/* 1116 */         local1ThreePartNamesParser.parseProcedureNameIntoParts(this.procedureName);
/* 1117 */         StringBuilder localStringBuilder = new StringBuilder("exec sp_sproc_columns ");
/* 1118 */         if (null != local1ThreePartNamesParser.getDatabasePart())
/*      */         {
/* 1120 */           localStringBuilder.append("@procedure_qualifier=");
/* 1121 */           localStringBuilder.append(local1ThreePartNamesParser.getDatabasePart());
/* 1122 */           localStringBuilder.append(", ");
/*      */         }
/* 1124 */         if (null != local1ThreePartNamesParser.getOwnerPart())
/*      */         {
/* 1126 */           localStringBuilder.append("@procedure_owner=");
/* 1127 */           localStringBuilder.append(local1ThreePartNamesParser.getOwnerPart());
/* 1128 */           localStringBuilder.append(", ");
/*      */         }
/* 1130 */         if (null != local1ThreePartNamesParser.getProcedurePart())
/*      */         {
/* 1133 */           localStringBuilder.append("@procedure_name=");
/* 1134 */           localStringBuilder.append(local1ThreePartNamesParser.getProcedurePart());
/* 1135 */           localStringBuilder.append(" , @ODBCVer=3");
/*      */         }
/*      */         else
/*      */         {
/* 1141 */           localObject1 = new MessageFormat(SQLServerException.getErrString("R_parameterNotDefinedForProcedure"));
/* 1142 */           localObject2 = new Object[] { paramString, "" };
/* 1143 */           SQLServerException.makeFromDriverError(this.connection, this, ((MessageFormat)localObject1).format(localObject2), "07009", false);
/*      */         }
/*      */ 
/* 1146 */         localObject1 = localSQLServerStatement.executeQueryInternal(localStringBuilder.toString());
/* 1147 */         this.paramNames = new ArrayList();
/* 1148 */         while (((ResultSet)localObject1).next())
/*      */         {
/* 1150 */           localObject2 = ((ResultSet)localObject1).getString(4);
/* 1151 */           this.paramNames.add(((String)localObject2).trim());
/*      */         }
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/* 1156 */         SQLServerException.makeFromDriverError(this.connection, this, localSQLException.toString(), null, false);
/*      */       }
/*      */     }
/*      */ 
/* 1160 */     int i = 0;
/* 1161 */     if (this.paramNames != null) {
/* 1162 */       i = this.paramNames.size();
/*      */     }
/*      */ 
/* 1171 */     int j = 0;
/* 1172 */     int k = -1;
/*      */ 
/* 1175 */     for (j = 0; j < i; j++)
/*      */     {
/* 1177 */       localObject1 = (String)this.paramNames.get(j);
/* 1178 */       localObject1 = ((String)localObject1).substring(1, ((String)localObject1).length());
/* 1179 */       if (!((String)localObject1).equals(paramString))
/*      */         continue;
/* 1181 */       k = j;
/* 1182 */       break;
/*      */     }
/*      */ 
/* 1186 */     if (-1 == k)
/*      */     {
/* 1190 */       for (j = 0; j < i; j++)
/*      */       {
/* 1192 */         localObject1 = (String)this.paramNames.get(j);
/* 1193 */         localObject1 = ((String)localObject1).substring(1, ((String)localObject1).length());
/* 1194 */         if (!((String)localObject1).equalsIgnoreCase(paramString))
/*      */           continue;
/* 1196 */         k = j;
/* 1197 */         break;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1202 */     if (-1 == k)
/*      */     {
/* 1204 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_parameterNotDefinedForProcedure"));
/* 1205 */       localObject2 = new Object[] { paramString, this.procedureName };
/* 1206 */       SQLServerException.makeFromDriverError(this.connection, this, ((MessageFormat)localObject1).format(localObject2), "07009", false);
/*      */     }
/*      */ 
/* 1210 */     if (this.bReturnValueSyntax) {
/* 1211 */       return k + 1;
/*      */     }
/* 1213 */     return k;
/*      */   }
/*      */ 
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 1218 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1219 */       loggerExternal.entering(getClassNameLogging(), "setTimeStamp", new Object[] { paramString, paramTimestamp, paramCalendar });
/* 1220 */     checkClosed();
/* 1221 */     setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar);
/* 1222 */     loggerExternal.exiting(getClassNameLogging(), "setTimeStamp");
/*      */   }
/*      */ 
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 1227 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1228 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime, paramCalendar });
/* 1229 */     checkClosed();
/* 1230 */     setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar);
/* 1231 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 1236 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1237 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { paramString, paramDate, paramCalendar });
/* 1238 */     checkClosed();
/* 1239 */     setValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar);
/* 1240 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   public final void setCharacterStream(String paramString, Reader paramReader) throws SQLException
/*      */   {
/* 1245 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1246 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1247 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { paramString, paramReader });
/* 1248 */     checkClosed();
/* 1249 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/* 1250 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException
/*      */   {
/* 1255 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1256 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { paramString, paramReader, Integer.valueOf(paramInt) });
/* 1257 */     checkClosed();
/* 1258 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramInt);
/* 1259 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setCharacterStream(String paramString, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1265 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1266 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1267 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/* 1268 */     checkClosed();
/* 1269 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/* 1270 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setNCharacterStream(String paramString, Reader paramReader) throws SQLException
/*      */   {
/* 1275 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1276 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1277 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { paramString, paramReader });
/* 1278 */     checkClosed();
/* 1279 */     setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/* 1280 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 1285 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1286 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1287 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/* 1288 */     checkClosed();
/* 1289 */     setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/* 1290 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   public final void setClob(String paramString, Clob paramClob) throws SQLException
/*      */   {
/* 1295 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1296 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1297 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { paramString, paramClob });
/* 1298 */     checkClosed();
/* 1299 */     setValue(findColumn(paramString), JDBCType.CLOB, paramClob, JavaType.CLOB);
/* 1300 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   public final void setClob(String paramString, Reader paramReader) throws SQLException
/*      */   {
/* 1305 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1306 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1307 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { paramString, paramReader });
/* 1308 */     checkClosed();
/* 1309 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/* 1310 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   public final void setClob(String paramString, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 1315 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1316 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1317 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/* 1318 */     checkClosed();
/* 1319 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/* 1320 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   public final void setNClob(String paramString, NClob paramNClob) throws SQLException
/*      */   {
/* 1325 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1326 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1327 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { paramString, paramNClob });
/* 1328 */     checkClosed();
/* 1329 */     setValue(findColumn(paramString), JDBCType.NCLOB, paramNClob, JavaType.NCLOB);
/* 1330 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   public final void setNClob(String paramString, Reader paramReader) throws SQLException
/*      */   {
/* 1335 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1336 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1337 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { paramString, paramReader });
/* 1338 */     checkClosed();
/* 1339 */     setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/* 1340 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   public final void setNClob(String paramString, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 1345 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1346 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1347 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/* 1348 */     checkClosed();
/* 1349 */     setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/* 1350 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   public final void setNString(String paramString1, String paramString2) throws SQLException
/*      */   {
/* 1355 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1356 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1357 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { paramString1, paramString2 });
/* 1358 */     checkClosed();
/* 1359 */     setValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING);
/* 1360 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   public void setObject(String paramString, Object paramObject) throws SQLServerException
/*      */   {
/* 1365 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1366 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject });
/* 1367 */     checkClosed();
/* 1368 */     setObjectNoType(findColumn(paramString), paramObject);
/* 1369 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLServerException
/*      */   {
/* 1374 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1375 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt) });
/* 1376 */     checkClosed();
/* 1377 */     setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt), null);
/* 1378 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 1383 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1384 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/* 1385 */     checkClosed();
/*      */ 
/* 1391 */     setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt1), (2 == paramInt1) || (3 == paramInt1) ? Integer.valueOf(paramInt2) : null);
/*      */ 
/* 1400 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   public final void setAsciiStream(String paramString, InputStream paramInputStream) throws SQLException
/*      */   {
/* 1405 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1406 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { paramString, paramInputStream });
/* 1407 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1408 */     checkClosed();
/* 1409 */     setStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 1410 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   public final void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException
/*      */   {
/* 1415 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1416 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) });
/* 1417 */     checkClosed();
/* 1418 */     setStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt);
/* 1419 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   public final void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 1424 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1425 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
/* 1426 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1427 */     checkClosed();
/* 1428 */     setStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 1429 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   public final void setBinaryStream(String paramString, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 1435 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1436 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1437 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { paramString, paramInputStream });
/* 1438 */     checkClosed();
/* 1439 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 1440 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   public final void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException
/*      */   {
/* 1445 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1446 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) });
/* 1447 */     checkClosed();
/* 1448 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt);
/* 1449 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   public final void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 1454 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1455 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1456 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
/* 1457 */     checkClosed();
/* 1458 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 1459 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   public final void setBlob(String paramString, Blob paramBlob) throws SQLException
/*      */   {
/* 1464 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1465 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1466 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { paramString, paramBlob });
/* 1467 */     checkClosed();
/* 1468 */     setValue(findColumn(paramString), JDBCType.BLOB, paramBlob, JavaType.BLOB);
/* 1469 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   public final void setBlob(String paramString, InputStream paramInputStream) throws SQLException
/*      */   {
/* 1474 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 1476 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1477 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { paramString, paramInputStream });
/* 1478 */     checkClosed();
/* 1479 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 1480 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   public final void setBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 1485 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1486 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1487 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
/* 1488 */     checkClosed();
/* 1489 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 1490 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLServerException
/*      */   {
/* 1495 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1496 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { paramString, paramTimestamp });
/* 1497 */     checkClosed();
/* 1498 */     setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP);
/* 1499 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   public void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset) throws SQLException
/*      */   {
/* 1504 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1505 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { paramString, paramDateTimeOffset });
/* 1506 */     checkClosed();
/* 1507 */     setValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET);
/* 1508 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   public void setDate(String paramString, Date paramDate) throws SQLServerException
/*      */   {
/* 1513 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1514 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { paramString, paramDate });
/* 1515 */     checkClosed();
/* 1516 */     setValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE);
/* 1517 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   public void setTime(String paramString, Time paramTime) throws SQLServerException
/*      */   {
/* 1522 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1523 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime });
/* 1524 */     checkClosed();
/* 1525 */     setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME);
/* 1526 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   public void setBytes(String paramString, byte[] paramArrayOfByte) throws SQLServerException
/*      */   {
/* 1531 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1532 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { paramString, paramArrayOfByte });
/* 1533 */     checkClosed();
/* 1534 */     setValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfByte, JavaType.BYTEARRAY);
/* 1535 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   public void setByte(String paramString, byte paramByte) throws SQLServerException
/*      */   {
/* 1540 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1541 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { paramString, Byte.valueOf(paramByte) });
/* 1542 */     checkClosed();
/* 1543 */     setValue(findColumn(paramString), JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE);
/* 1544 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   public void setString(String paramString1, String paramString2) throws SQLServerException
/*      */   {
/* 1549 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1550 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { paramString1, paramString2 });
/* 1551 */     checkClosed();
/* 1552 */     setValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING);
/* 1553 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLServerException
/*      */   {
/* 1558 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1559 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { paramString, paramBigDecimal });
/* 1560 */     checkClosed();
/* 1561 */     setValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL);
/* 1562 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   public void setDouble(String paramString, double paramDouble) throws SQLServerException
/*      */   {
/* 1567 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1568 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { paramString, Double.valueOf(paramDouble) });
/* 1569 */     checkClosed();
/* 1570 */     setValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE);
/* 1571 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   public void setFloat(String paramString, float paramFloat) throws SQLServerException
/*      */   {
/* 1576 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1577 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { paramString, Float.valueOf(paramFloat) });
/* 1578 */     checkClosed();
/* 1579 */     setValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT);
/* 1580 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   public void setInt(String paramString, int paramInt) throws SQLServerException
/*      */   {
/* 1585 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1586 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { paramString, Integer.valueOf(paramInt) });
/* 1587 */     checkClosed();
/* 1588 */     setValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER);
/* 1589 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   public void setLong(String paramString, long paramLong) throws SQLServerException
/*      */   {
/* 1594 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1595 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { paramString, Long.valueOf(paramLong) });
/* 1596 */     checkClosed();
/* 1597 */     setValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG);
/* 1598 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */   public void setShort(String paramString, short paramShort) throws SQLServerException
/*      */   {
/* 1603 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1604 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { paramString, Short.valueOf(paramShort) });
/* 1605 */     checkClosed();
/* 1606 */     setValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT);
/* 1607 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLServerException
/*      */   {
/* 1612 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1613 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean) });
/* 1614 */     checkClosed();
/* 1615 */     setValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN);
/* 1616 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   public void setNull(String paramString, int paramInt) throws SQLServerException
/*      */   {
/* 1621 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1622 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { paramString, Integer.valueOf(paramInt) });
/* 1623 */     checkClosed();
/* 1624 */     setObject(setterGetParam(findColumn(paramString)), null, JavaType.OBJECT, JDBCType.of(paramInt), null);
/* 1625 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLServerException
/*      */   {
/* 1630 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1631 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { paramString1, Integer.valueOf(paramInt), paramString2 });
/* 1632 */     checkClosed();
/* 1633 */     setObject(setterGetParam(findColumn(paramString1)), null, JavaType.OBJECT, JDBCType.of(paramInt), null);
/* 1634 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */   public void setURL(String paramString, URL paramURL) throws SQLServerException
/*      */   {
/* 1639 */     loggerExternal.entering(getClassNameLogging(), "setURL", paramString);
/* 1640 */     checkClosed();
/* 1641 */     setURL(findColumn(paramString), paramURL);
/* 1642 */     loggerExternal.exiting(getClassNameLogging(), "setURL");
/*      */   }
/*      */ 
/*      */   public URL getURL(int paramInt) throws SQLServerException
/*      */   {
/* 1647 */     NotImplemented();
/* 1648 */     return null;
/*      */   }
/*      */ 
/*      */   public URL getURL(String paramString) throws SQLServerException
/*      */   {
/* 1653 */     NotImplemented();
/* 1654 */     return null;
/*      */   }
/*      */ 
/*      */   public final void setSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException
/*      */   {
/* 1659 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1660 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1661 */       loggerExternal.entering(getClassNameLogging(), "setSQLXML", new Object[] { paramString, paramSQLXML });
/* 1662 */     checkClosed();
/* 1663 */     setSQLXMLInternal(findColumn(paramString), paramSQLXML);
/* 1664 */     loggerExternal.exiting(getClassNameLogging(), "setSQLXML");
/*      */   }
/*      */ 
/*      */   public final SQLXML getSQLXML(int paramInt) throws SQLException
/*      */   {
/* 1669 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1670 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", Integer.valueOf(paramInt));
/* 1671 */     checkClosed();
/* 1672 */     SQLServerSQLXML localSQLServerSQLXML = (SQLServerSQLXML)getSQLXMLInternal(paramInt);
/* 1673 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", localSQLServerSQLXML);
/* 1674 */     return localSQLServerSQLXML;
/*      */   }
/*      */ 
/*      */   public final SQLXML getSQLXML(String paramString) throws SQLException
/*      */   {
/* 1679 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1680 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", paramString);
/* 1681 */     checkClosed();
/* 1682 */     SQLServerSQLXML localSQLServerSQLXML = (SQLServerSQLXML)getSQLXMLInternal(findColumn(paramString));
/* 1683 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", localSQLServerSQLXML);
/* 1684 */     return localSQLServerSQLXML;
/*      */   }
/*      */ 
/*      */   public final void setRowId(String paramString, RowId paramRowId) throws SQLException
/*      */   {
/* 1689 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 1692 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public final RowId getRowId(int paramInt) throws SQLException
/*      */   {
/* 1697 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 1700 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public final RowId getRowId(String paramString) throws SQLException
/*      */   {
/* 1705 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 1708 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLServerException
/*      */   {
/* 1713 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1714 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString1, new Integer(paramInt), paramString2 });
/* 1715 */     checkClosed();
/* 1716 */     registerOutParameter(findColumn(paramString1), paramInt, paramString2);
/* 1717 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 1722 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1723 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) });
/*      */     }
/* 1725 */     checkClosed();
/* 1726 */     registerOutParameter(findColumn(paramString), paramInt1, paramInt2);
/* 1727 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(String paramString, int paramInt) throws SQLServerException
/*      */   {
/* 1732 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1733 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, new Integer(paramInt) });
/* 1734 */     checkClosed();
/* 1735 */     registerOutParameter(findColumn(paramString), paramInt);
/* 1736 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerCallableStatement
 * JD-Core Version:    0.6.0
 */