/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ 
/*     */ final class Column
/*     */ {
/*     */   private TypeInfo typeInfo;
/*     */   private DTV updaterDTV;
/*  17 */   private final DTV getterDTV = new DTV();
/*     */   private String columnName;
/*     */   private String baseColumnName;
/*     */   private int tableNum;
/*     */   private int infoStatus;
/*     */   private SQLIdentifier tableName;
/*     */   ColumnFilter filter;
/*     */ 
/*     */   final TypeInfo getTypeInfo()
/*     */   {
/*  15 */     return this.typeInfo;
/*     */   }
/*     */ 
/*     */   final void setColumnName(String paramString)
/*     */   {
/*  21 */     this.columnName = paramString; } 
/*  22 */   final String getColumnName() { return this.columnName;
/*     */   }
/*     */ 
/*     */   final void setBaseColumnName(String paramString)
/*     */   {
/*  28 */     this.baseColumnName = paramString; } 
/*  29 */   final String getBaseColumnName() { return this.baseColumnName; }
/*     */ 
/*     */   final void setTableNum(int paramInt) {
/*  32 */     this.tableNum = paramInt; } 
/*  33 */   final int getTableNum() { return this.tableNum; }
/*     */ 
/*     */   final void setInfoStatus(int paramInt) {
/*  36 */     this.infoStatus = paramInt; } 
/*  37 */   final boolean hasDifferentName() { return 0 != (this.infoStatus & 0x20); } 
/*  38 */   final boolean isHidden() { return 0 != (this.infoStatus & 0x10); } 
/*  39 */   final boolean isKey() { return 0 != (this.infoStatus & 0x8); } 
/*  40 */   final boolean isExpression() { return 0 != (this.infoStatus & 0x4); }
/*     */ 
/*     */   final boolean isUpdatable() {
/*  43 */     return (!isExpression()) && (!isHidden()) && (this.tableName.getObjectName().length() > 0);
/*     */   }
/*     */ 
/*     */   final void setTableName(SQLIdentifier paramSQLIdentifier)
/*     */   {
/*  50 */     this.tableName = paramSQLIdentifier; } 
/*  51 */   final SQLIdentifier getTableName() { return this.tableName;
/*     */   }
/*     */ 
/*     */   Column(TypeInfo paramTypeInfo, String paramString, SQLIdentifier paramSQLIdentifier)
/*     */   {
/*  63 */     this.typeInfo = paramTypeInfo;
/*  64 */     this.columnName = paramString;
/*  65 */     this.baseColumnName = paramString;
/*  66 */     this.tableName = paramSQLIdentifier;
/*     */   }
/*     */ 
/*     */   final void clear()
/*     */   {
/*  74 */     this.getterDTV.clear();
/*     */   }
/*     */ 
/*     */   final void skipValue(TDSReader paramTDSReader, boolean paramBoolean)
/*     */     throws SQLServerException
/*     */   {
/*  86 */     this.getterDTV.skipValue(this.typeInfo, paramTDSReader, paramBoolean);
/*     */   }
/*     */ 
/*     */   final void initFromCompressedNull()
/*     */   {
/*  94 */     this.getterDTV.initFromCompressedNull();
/*     */   }
/*     */ 
/*     */   void setFilter(ColumnFilter paramColumnFilter)
/*     */   {
/*  99 */     this.filter = paramColumnFilter;
/*     */   }
/*     */ 
/*     */   final boolean isNull()
/*     */   {
/* 110 */     return this.getterDTV.isNull();
/*     */   }
/*     */ 
/*     */   final boolean isInitialized()
/*     */   {
/* 121 */     return this.getterDTV.isInitialized();
/*     */   }
/*     */ 
/*     */   Object getValue(JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/* 132 */     Object localObject = this.getterDTV.getValue(paramJDBCType, this.typeInfo.getScale(), paramInputStreamGetterArgs, paramCalendar, this.typeInfo, paramTDSReader);
/* 133 */     return null != this.filter ? this.filter.apply(localObject, paramJDBCType) : localObject;
/*     */   }
/*     */ 
/*     */   int getInt(TDSReader paramTDSReader) throws SQLServerException
/*     */   {
/* 138 */     return ((Integer)getValue(JDBCType.INTEGER, null, null, paramTDSReader)).intValue();
/*     */   }
/*     */ 
/*     */   void updateValue(JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/* 150 */     SSType localSSType = this.typeInfo.getSSType();
/*     */ 
/* 152 */     if (null != paramStreamSetterArgs)
/*     */     {
/* 154 */       if (!paramStreamSetterArgs.streamType.convertsTo(this.typeInfo)) {
/* 155 */         DataTypes.throwConversionError(paramStreamSetterArgs.streamType.toString(), localSSType.toString());
/*     */       }
/*     */ 
/*     */     }
/* 159 */     else if (!paramJDBCType.convertsTo(localSSType)) {
/* 160 */       DataTypes.throwConversionError(paramJDBCType.toString(), localSSType.toString());
/*     */     }
/*     */ 
/* 164 */     if (((JDBCType.DATETIMEOFFSET == paramJDBCType) || (JavaType.DATETIMEOFFSET == paramJavaType)) && (!paramSQLServerConnection.isKatmaiOrLater()))
/*     */     {
/* 167 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*     */     }
/*     */ 
/* 184 */     if (((SSType.NCHAR == localSSType) || (SSType.NVARCHAR == localSSType) || (SSType.NVARCHARMAX == localSSType) || (SSType.NTEXT == localSSType) || (SSType.XML == localSSType)) && ((JDBCType.CHAR == paramJDBCType) || (JDBCType.VARCHAR == paramJDBCType) || (JDBCType.LONGVARCHAR == paramJDBCType) || (JDBCType.CLOB == paramJDBCType)))
/*     */     {
/* 197 */       paramJDBCType = JDBCType.CLOB == paramJDBCType ? JDBCType.NCLOB : JDBCType.NVARCHAR;
/*     */     }
/* 201 */     else if (((SSType.BINARY == localSSType) || (SSType.VARBINARY == localSSType) || (SSType.VARBINARYMAX == localSSType) || (SSType.IMAGE == localSSType) || (SSType.UDT == localSSType)) && ((JDBCType.CHAR == paramJDBCType) || (JDBCType.VARCHAR == paramJDBCType) || (JDBCType.LONGVARCHAR == paramJDBCType)))
/*     */     {
/* 213 */       paramJDBCType = JDBCType.VARBINARY;
/*     */     }
/* 218 */     else if (((JDBCType.TIMESTAMP == paramJDBCType) || (JDBCType.DATE == paramJDBCType) || (JDBCType.TIME == paramJDBCType)) && ((SSType.CHAR == localSSType) || (SSType.VARCHAR == localSSType) || (SSType.VARCHARMAX == localSSType) || (SSType.TEXT == localSSType) || (SSType.NCHAR == localSSType) || (SSType.NVARCHAR == localSSType) || (SSType.NVARCHARMAX == localSSType) || (SSType.NTEXT == localSSType)))
/*     */     {
/* 235 */       paramJDBCType = JDBCType.NCHAR;
/*     */     }
/*     */ 
/* 239 */     if (null == this.updaterDTV) {
/* 240 */       this.updaterDTV = new DTV();
/*     */     }
/*     */ 
/* 243 */     this.updaterDTV.setValue(this.typeInfo.getSQLCollation(), paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger, paramSQLServerConnection);
/*     */   }
/*     */ 
/*     */   boolean hasUpdates()
/*     */   {
/* 248 */     return null != this.updaterDTV;
/*     */   }
/*     */ 
/*     */   void cancelUpdates()
/*     */   {
/* 253 */     this.updaterDTV = null;
/*     */   }
/*     */ 
/*     */   void sendByRPC(TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/* 261 */     if (null == this.updaterDTV) {
/* 262 */       return;
/*     */     }
/*     */ 
/* 265 */     this.updaterDTV.sendByRPC(this.baseColumnName, this.typeInfo, this.typeInfo.getSQLCollation(), this.typeInfo.getScale(), false, paramTDSWriter, paramSQLServerConnection);
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.Column
 * JD-Core Version:    0.6.0
 */