/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ final class ScrollWindow
/*     */ {
/*     */   private TDSReaderMark[] rowMark;
/*     */   private boolean[] updatedRow;
/*     */   private boolean[] deletedRow;
/*     */   private RowType[] rowType;
/*  26 */   private int size = 0;
/*     */ 
/*  29 */   private int maxRows = 0;
/*     */   private int currentRow;
/*     */ 
/*     */   final int getMaxRows()
/*     */   {
/*  30 */     return this.maxRows;
/*     */   }
/*     */ 
/*     */   final int getRow() {
/*  34 */     return this.currentRow;
/*     */   }
/*     */ 
/*     */   ScrollWindow(int paramInt) {
/*  38 */     setSize(paramInt);
/*  39 */     reset();
/*     */   }
/*     */ 
/*     */   private final void setSize(int paramInt)
/*     */   {
/*  44 */     assert (this.size != paramInt);
/*  45 */     this.size = paramInt;
/*  46 */     this.maxRows = paramInt;
/*  47 */     this.rowMark = new TDSReaderMark[paramInt];
/*  48 */     this.updatedRow = new boolean[paramInt];
/*  49 */     this.deletedRow = new boolean[paramInt];
/*  50 */     this.rowType = new RowType[paramInt];
/*  51 */     for (int i = 0; i < paramInt; i++)
/*     */     {
/*  53 */       this.rowType[i] = RowType.UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */   final void clear()
/*     */   {
/*  59 */     for (int i = 0; i < this.rowMark.length; i++)
/*     */     {
/*  61 */       this.rowMark[i] = null;
/*  62 */       this.updatedRow[i] = false;
/*  63 */       this.deletedRow[i] = false;
/*  64 */       this.rowType[i] = RowType.UNKNOWN;
/*     */     }
/*     */ 
/*  67 */     assert (this.size > 0);
/*  68 */     this.maxRows = this.size;
/*  69 */     reset();
/*     */   }
/*     */ 
/*     */   final void reset()
/*     */   {
/*  74 */     this.currentRow = 0;
/*     */   }
/*     */ 
/*     */   final void resize(int paramInt)
/*     */   {
/*  79 */     assert (paramInt > 0);
/*  80 */     if (paramInt != this.size)
/*  81 */       setSize(paramInt);
/*     */   }
/*     */ 
/*     */   final String logCursorState()
/*     */   {
/*  86 */     return " currentRow:" + this.currentRow + " maxRows:" + this.maxRows;
/*     */   }
/*     */ 
/*     */   final boolean next(SQLServerResultSet paramSQLServerResultSet) throws SQLServerException
/*     */   {
/*  91 */     if (SQLServerResultSet.logger.isLoggable(Level.FINER)) {
/*  92 */       SQLServerResultSet.logger.finer(paramSQLServerResultSet.toString() + logCursorState());
/*     */     }
/*     */ 
/*  97 */     assert ((0 <= this.currentRow) && (this.currentRow <= this.maxRows + 1));
/*     */ 
/* 101 */     if (this.maxRows + 1 == this.currentRow) {
/* 102 */       return false;
/*     */     }
/*     */ 
/* 108 */     if (this.currentRow >= 1)
/*     */     {
/* 110 */       this.updatedRow[(this.currentRow - 1)] = paramSQLServerResultSet.getUpdatedCurrentRow();
/* 111 */       this.deletedRow[(this.currentRow - 1)] = paramSQLServerResultSet.getDeletedCurrentRow();
/* 112 */       this.rowType[(this.currentRow - 1)] = paramSQLServerResultSet.getCurrentRowType();
/*     */     }
/*     */ 
/* 116 */     this.currentRow += 1;
/*     */ 
/* 123 */     if (this.maxRows + 1 == this.currentRow)
/*     */     {
/* 125 */       paramSQLServerResultSet.fetchBufferNext();
/* 126 */       return false;
/*     */     }
/*     */ 
/* 133 */     if (null != this.rowMark[(this.currentRow - 1)])
/*     */     {
/* 135 */       paramSQLServerResultSet.fetchBufferReset(this.rowMark[(this.currentRow - 1)]);
/* 136 */       paramSQLServerResultSet.setCurrentRowType(this.rowType[(this.currentRow - 1)]);
/* 137 */       paramSQLServerResultSet.setUpdatedCurrentRow(this.updatedRow[(this.currentRow - 1)]);
/* 138 */       paramSQLServerResultSet.setDeletedCurrentRow(this.deletedRow[(this.currentRow - 1)]);
/* 139 */       return true;
/*     */     }
/*     */ 
/* 147 */     if (paramSQLServerResultSet.fetchBufferNext())
/*     */     {
/* 149 */       this.rowMark[(this.currentRow - 1)] = paramSQLServerResultSet.fetchBufferMark();
/* 150 */       this.rowType[(this.currentRow - 1)] = paramSQLServerResultSet.getCurrentRowType();
/*     */ 
/* 152 */       if (SQLServerResultSet.logger.isLoggable(Level.FINEST)) {
/* 153 */         SQLServerResultSet.logger.finest(paramSQLServerResultSet.toString() + " Set mark " + this.rowMark[(this.currentRow - 1)] + " for row " + this.currentRow + " of type " + this.rowType[(this.currentRow - 1)]);
/*     */       }
/* 155 */       return true;
/*     */     }
/*     */ 
/* 161 */     this.maxRows = (this.currentRow - 1);
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */   final void previous(SQLServerResultSet paramSQLServerResultSet) throws SQLServerException
/*     */   {
/* 167 */     if (SQLServerResultSet.logger.isLoggable(Level.FINER)) {
/* 168 */       SQLServerResultSet.logger.finer(paramSQLServerResultSet.toString() + logCursorState());
/*     */     }
/*     */ 
/* 173 */     assert ((0 <= this.currentRow) && (this.currentRow <= this.maxRows + 1));
/*     */ 
/* 177 */     if (0 == this.currentRow) {
/* 178 */       return;
/*     */     }
/*     */ 
/* 184 */     if (this.currentRow <= this.maxRows)
/*     */     {
/* 186 */       assert (this.currentRow >= 1);
/* 187 */       this.updatedRow[(this.currentRow - 1)] = paramSQLServerResultSet.getUpdatedCurrentRow();
/* 188 */       this.deletedRow[(this.currentRow - 1)] = paramSQLServerResultSet.getDeletedCurrentRow();
/* 189 */       this.rowType[(this.currentRow - 1)] = paramSQLServerResultSet.getCurrentRowType();
/*     */     }
/*     */ 
/* 193 */     this.currentRow -= 1;
/*     */ 
/* 197 */     if (0 == this.currentRow) {
/* 198 */       return;
/*     */     }
/*     */ 
/* 204 */     assert (null != this.rowMark[(this.currentRow - 1)]);
/* 205 */     paramSQLServerResultSet.fetchBufferReset(this.rowMark[(this.currentRow - 1)]);
/* 206 */     paramSQLServerResultSet.setCurrentRowType(this.rowType[(this.currentRow - 1)]);
/* 207 */     paramSQLServerResultSet.setUpdatedCurrentRow(this.updatedRow[(this.currentRow - 1)]);
/* 208 */     paramSQLServerResultSet.setDeletedCurrentRow(this.deletedRow[(this.currentRow - 1)]);
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ScrollWindow
 * JD-Core Version:    0.6.0
 */