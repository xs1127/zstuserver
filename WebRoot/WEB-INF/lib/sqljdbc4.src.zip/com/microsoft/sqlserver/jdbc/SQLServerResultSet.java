/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ public final class SQLServerResultSet
/*      */   implements ISQLServerResultSet
/*      */ {
/*      */   private static int lastResultSetID;
/*      */   private final String traceID;
/*      */   static final Logger logger;
/*      */   private static final Logger loggerExternal;
/*      */   private final String loggingClassName;
/*      */   private final SQLServerStatement stmt;
/*      */   private final int maxRows;
/*      */   private ResultSetMetaData metaData;
/*   58 */   private boolean isClosed = false;
/*      */   private final int serverCursorId;
/*      */   private int fetchDirection;
/*      */   private int fetchSize;
/*   69 */   private boolean isOnInsertRow = false;
/*      */ 
/*   72 */   private boolean lastValueWasNull = false;
/*      */   private int lastColumnIndex;
/*   79 */   private boolean areNullCompressedColumnsInitialized = false;
/*      */ 
/*   82 */   private RowType resultSetCurrentRowType = RowType.UNKNOWN;
/*      */   private Closeable activeStream;
/*      */   private final ScrollWindow scrollWindow;
/*      */   private static final int BEFORE_FIRST_ROW = 0;
/*      */   private static final int AFTER_LAST_ROW = -1;
/*      */   private static final int UNKNOWN_ROW = -2;
/*  113 */   private int currentRow = 0;
/*      */ 
/*  116 */   private boolean updatedCurrentRow = false;
/*      */ 
/*  121 */   private boolean deletedCurrentRow = false;
/*      */   static final int UNKNOWN_ROW_COUNT = -3;
/*      */   private int rowCount;
/*      */   private final Column[] columns;
/*      */   private TDSReader tdsReader;
/*      */   private final FetchBuffer fetchBuffer;
/*  363 */   private SQLServerException rowErrorException = null;
/*      */   private int numFetchedRows;
/*      */ 
/*      */   private static synchronized int nextResultSetID()
/*      */   {
/*   34 */     return ++lastResultSetID;
/*      */   }
/*   36 */   public String toString() { return this.traceID; } 
/*   37 */   String logCursorState() { return " currentRow:" + this.currentRow + " numFetchedRows:" + this.numFetchedRows + " rowCount:" + this.rowCount;
/*      */   }
/*      */ 
/*      */   String getClassNameLogging()
/*      */   {
/*   44 */     return this.loggingClassName;
/*      */   }
/*      */ 
/*      */   final RowType getCurrentRowType()
/*      */   {
/*   87 */     return this.resultSetCurrentRowType;
/*      */   }
/*      */ 
/*      */   final void setCurrentRowType(RowType paramRowType)
/*      */   {
/*   93 */     this.resultSetCurrentRowType = paramRowType;
/*      */   }
/*      */ 
/*      */   final boolean getUpdatedCurrentRow()
/*      */   {
/*  117 */     return this.updatedCurrentRow; } 
/*  118 */   final void setUpdatedCurrentRow(boolean paramBoolean) { this.updatedCurrentRow = paramBoolean; }
/*      */ 
/*      */   final boolean getDeletedCurrentRow()
/*      */   {
/*  122 */     return this.deletedCurrentRow; } 
/*  123 */   final void setDeletedCurrentRow(boolean paramBoolean) { this.deletedCurrentRow = paramBoolean;
/*      */   }
/*      */ 
/*      */   final void setColumnName(int paramInt, String paramString)
/*      */   {
/*  141 */     this.columns[(paramInt - 1)].setColumnName(paramString);
/*      */   }
/*      */ 
/*      */   private final void skipColumns(int paramInt, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/*  150 */     assert (this.lastColumnIndex >= 1);
/*  151 */     assert ((0 <= paramInt) && (paramInt <= this.columns.length));
/*      */ 
/*  153 */     for (int i = 0; i < paramInt; i++)
/*      */     {
/*  155 */       Column localColumn = getColumn(this.lastColumnIndex++);
/*  156 */       localColumn.skipValue(this.tdsReader, (paramBoolean) && (isForwardOnly()));
/*  157 */       if (paramBoolean)
/*  158 */         localColumn.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   SQLServerResultSet(SQLServerStatement paramSQLServerStatement)
/*      */     throws SQLServerException
/*      */   {
/*  174 */     int i = nextResultSetID();
/*  175 */     this.loggingClassName = ("com.microsoft.sqlserver.jdbc.SQLServerResultSet:" + i);
/*  176 */     this.traceID = ("SQLServerResultSet:" + i);
/*      */ 
/*  301 */     this.stmt = paramSQLServerStatement;
/*  302 */     this.maxRows = paramSQLServerStatement.maxRows;
/*  303 */     this.fetchSize = paramSQLServerStatement.nFetchSize;
/*  304 */     this.fetchDirection = paramSQLServerStatement.nFetchDirection;
/*      */ 
/*  306 */     1ServerCursorInitializer local1ServerCursorInitializer = paramSQLServerStatement.executedSqlDirectly ? new 1CursorInitializer()
/*      */     {
/*  262 */       private int rowCount = -3;
/*      */ 
/*  263 */       final int getRowCount() { return this.rowCount; } 
/*  264 */       final int getServerCursorId() { return 0;
/*      */       }
/*      */ 
/*      */       boolean onRow(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/*  274 */         return false;
/*      */       }
/*      */ 
/*      */       boolean onNBCRow(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/*  280 */         return false;
/*      */       }
/*      */ 
/*      */       boolean onError(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/*  288 */         this.rowCount = 0;
/*  289 */         return false;
/*      */       }
/*      */ 
/*      */       boolean onDone(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/*  296 */         this.rowCount = 0;
/*  297 */         return false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  306 */      : new 1CursorInitializer(paramSQLServerStatement)
/*      */     {
/*      */       private final SQLServerStatement stmt;
/*      */ 
/*      */       final int getRowCount()
/*      */       {
/*  229 */         return this.stmt.getServerCursorRowCount(); } 
/*  230 */       final int getServerCursorId() { return this.stmt.getServerCursorId();
/*      */       }
/*      */ 
/*      */       boolean onRetStatus(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/*  245 */         this.stmt.consumeExecOutParam(paramTDSReader);
/*  246 */         return true;
/*      */       }
/*      */ 
/*      */       boolean onRetValue(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/*  254 */         return false;
/*      */       }
/*      */     };
/*  311 */     TDSParser.parse(paramSQLServerStatement.resultsReader(), local1ServerCursorInitializer);
/*  312 */     this.columns = local1ServerCursorInitializer.buildColumns();
/*  313 */     this.rowCount = local1ServerCursorInitializer.getRowCount();
/*  314 */     this.serverCursorId = local1ServerCursorInitializer.getServerCursorId();
/*      */ 
/*  323 */     this.tdsReader = (0 == this.serverCursorId ? paramSQLServerStatement.resultsReader() : null);
/*      */ 
/*  325 */     this.fetchBuffer = new FetchBuffer();
/*      */ 
/*  327 */     this.scrollWindow = (isForwardOnly() ? null : new ScrollWindow(this.fetchSize));
/*  328 */     this.numFetchedRows = 0;
/*      */ 
/*  330 */     if (logger.isLoggable(Level.FINE))
/*      */     {
/*  332 */       logger.fine(toString() + " created by (" + paramSQLServerStatement.toString() + ")");
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isWrapperFor(Class paramClass) throws SQLException
/*      */   {
/*  338 */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor");
/*  339 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  340 */     boolean bool = paramClass.isInstance(this);
/*  341 */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
/*  342 */     return bool;
/*      */   }
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/*  347 */     loggerExternal.entering(getClassNameLogging(), "unwrap");
/*  348 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     Object localObject;
/*      */     try {
/*  352 */       localObject = paramClass.cast(this);
/*      */     }
/*      */     catch (ClassCastException localClassCastException)
/*      */     {
/*  356 */       throw new SQLServerException(localClassCastException.getMessage(), localClassCastException);
/*      */     }
/*  358 */     loggerExternal.exiting(getClassNameLogging(), "unwrap", localObject);
/*  359 */     return localObject;
/*      */   }
/*      */ 
/*      */   void checkClosed()
/*      */     throws SQLServerException
/*      */   {
/*  371 */     if (this.isClosed) {
/*  372 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_resultsetClosed"), null, false);
/*      */     }
/*      */ 
/*  375 */     this.stmt.checkClosed();
/*      */ 
/*  380 */     if (null != this.rowErrorException)
/*  381 */       throw this.rowErrorException;
/*      */   }
/*      */ 
/*      */   public boolean isClosed() throws SQLException
/*      */   {
/*  386 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*  388 */     loggerExternal.entering(getClassNameLogging(), "isClosed");
/*  389 */     boolean bool = (this.isClosed) || (this.stmt.isClosed());
/*  390 */     loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(bool));
/*  391 */     return bool;
/*      */   }
/*      */ 
/*      */   private final void throwNotScrollable()
/*      */     throws SQLServerException
/*      */   {
/*  402 */     SQLServerException.makeFromDriverError(this.stmt.connection, this, SQLServerException.getErrString("R_requestedOpNotSupportedOnForward"), null, true);
/*      */   }
/*      */ 
/*      */   private final boolean isForwardOnly()
/*      */   {
/*  412 */     return (2003 == this.stmt.getSQLResultSetType()) || (2004 == this.stmt.getSQLResultSetType());
/*      */   }
/*      */ 
/*      */   private final boolean isDynamic()
/*      */   {
/*  419 */     return (0 != this.serverCursorId) && (2 == this.stmt.getCursorType());
/*      */   }
/*      */ 
/*      */   private final void verifyResultSetIsScrollable() throws SQLServerException
/*      */   {
/*  424 */     if (isForwardOnly())
/*  425 */       throwNotScrollable();
/*      */   }
/*      */ 
/*      */   private final void throwNotUpdatable()
/*      */     throws SQLServerException
/*      */   {
/*  436 */     SQLServerException.makeFromDriverError(this.stmt.connection, this, SQLServerException.getErrString("R_resultsetNotUpdatable"), null, true);
/*      */   }
/*      */ 
/*      */   private final void verifyResultSetIsUpdatable()
/*      */     throws SQLServerException
/*      */   {
/*  446 */     if ((1007 == this.stmt.resultSetConcurrency) || (0 == this.serverCursorId))
/*  447 */       throwNotUpdatable();
/*      */   }
/*      */ 
/*      */   private boolean hasCurrentRow()
/*      */   {
/*  458 */     return (0 != this.currentRow) && (-1 != this.currentRow);
/*      */   }
/*      */ 
/*      */   private void verifyResultSetHasCurrentRow()
/*      */     throws SQLServerException
/*      */   {
/*  481 */     if (!hasCurrentRow())
/*      */     {
/*  483 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_resultsetNoCurrentRow"), null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void verifyCurrentRowIsNotDeleted(String paramString)
/*      */     throws SQLServerException
/*      */   {
/*  500 */     if (currentRowDeleted())
/*      */     {
/*  502 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString(paramString), null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void verifyValidColumnIndex(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  519 */     int i = this.columns.length;
/*      */ 
/*  524 */     if (0 != this.serverCursorId) {
/*  525 */       i--;
/*      */     }
/*  527 */     if ((paramInt < 1) || (paramInt > i))
/*      */     {
/*  529 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/*  530 */       Object[] arrayOfObject = { new Integer(paramInt) };
/*  531 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, localMessageFormat.format(arrayOfObject), "07009", false);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void verifyResultSetIsNotOnInsertRow()
/*      */     throws SQLServerException
/*      */   {
/*  544 */     if (this.isOnInsertRow)
/*      */     {
/*  546 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_mustNotBeOnInsertRow"), null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void throwUnsupportedCursorOp()
/*      */     throws SQLServerException
/*      */   {
/*  554 */     SQLServerException.makeFromDriverError(this.stmt.connection, this, SQLServerException.getErrString("R_unsupportedCursorOperation"), null, true);
/*      */   }
/*      */ 
/*      */   private void closeInternal()
/*      */   {
/*  574 */     if (this.isClosed) {
/*  575 */       return;
/*      */     }
/*      */ 
/*  578 */     this.isClosed = true;
/*      */ 
/*  581 */     discardFetchBuffer();
/*      */ 
/*  584 */     closeServerCursor();
/*      */ 
/*  587 */     this.metaData = null;
/*      */   }
/*      */ 
/*      */   public void close() throws SQLServerException
/*      */   {
/*  592 */     loggerExternal.entering(getClassNameLogging(), "close");
/*  593 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  595 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  597 */     closeInternal();
/*  598 */     loggerExternal.exiting(getClassNameLogging(), "close");
/*      */   }
/*      */ 
/*      */   public int findColumn(String paramString)
/*      */     throws SQLServerException
/*      */   {
/*  609 */     loggerExternal.entering(getClassNameLogging(), "findColumn", paramString);
/*  610 */     checkClosed();
/*      */ 
/*  633 */     for (int i = 0; i < this.columns.length; i++)
/*      */     {
/*  635 */       if (!this.columns[i].getColumnName().equals(paramString))
/*      */         continue;
/*  637 */       loggerExternal.exiting(getClassNameLogging(), "findColumn", Integer.valueOf(i + 1));
/*  638 */       return i + 1;
/*      */     }
/*      */ 
/*  646 */     for (i = 0; i < this.columns.length; i++)
/*      */     {
/*  648 */       if (!this.columns[i].getColumnName().equalsIgnoreCase(paramString))
/*      */         continue;
/*  650 */       loggerExternal.exiting(getClassNameLogging(), "findColumn", Integer.valueOf(i + 1));
/*  651 */       return i + 1;
/*      */     }
/*      */ 
/*  654 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumnName"));
/*  655 */     Object[] arrayOfObject = { paramString };
/*  656 */     SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, localMessageFormat.format(arrayOfObject), "07009", false);
/*      */ 
/*  659 */     return 0;
/*      */   }
/*      */ 
/*      */   final int getColumnCount()
/*      */   {
/*  664 */     int i = this.columns.length;
/*  665 */     if (0 != this.serverCursorId)
/*  666 */       i--;
/*  667 */     return i;
/*      */   }
/*      */ 
/*      */   final Column getColumn(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  674 */     if (null != this.activeStream)
/*      */     {
/*      */       try
/*      */       {
/*  678 */         this.activeStream.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*  682 */         SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*      */       }
/*      */       finally
/*      */       {
/*  686 */         this.activeStream = null;
/*      */       }
/*      */     }
/*      */ 
/*  690 */     return this.columns[(paramInt - 1)];
/*      */   }
/*      */ 
/*      */   private final void initializeNullCompressedColumns()
/*      */     throws SQLServerException
/*      */   {
/*  703 */     if ((this.resultSetCurrentRowType.equals(RowType.NBCROW)) && (!this.areNullCompressedColumnsInitialized))
/*      */     {
/*  705 */       int i = 0;
/*      */ 
/*  707 */       int j = (this.columns.length - 1 >> 3) + 1;
/*  708 */       for (int k = 0; k < j; k++)
/*      */       {
/*  711 */         int m = this.tdsReader.readUnsignedByte();
/*      */ 
/*  715 */         if (m == 0)
/*      */         {
/*  717 */           i += 8;
/*      */         }
/*      */         else
/*      */         {
/*  721 */           for (int n = 0; (n < 8) && (i < this.columns.length); n++)
/*      */           {
/*  723 */             if ((m & 1 << n) != 0)
/*      */             {
/*  725 */               this.columns[i].initFromCompressedNull();
/*      */             }
/*  727 */             i++;
/*      */           }
/*      */         }
/*      */       }
/*  730 */       this.areNullCompressedColumnsInitialized = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final Column loadColumn(int paramInt) throws SQLServerException
/*      */   {
/*  736 */     assert ((1 <= paramInt) && (paramInt <= this.columns.length));
/*      */ 
/*  738 */     initializeNullCompressedColumns();
/*      */ 
/*  742 */     if ((paramInt > this.lastColumnIndex) && (!this.columns[(paramInt - 1)].isInitialized())) {
/*  743 */       skipColumns(paramInt - this.lastColumnIndex, false);
/*      */     }
/*      */ 
/*  746 */     return getColumn(paramInt);
/*      */   }
/*      */ 
/*      */   private void NotImplemented() throws SQLServerException {
/*  750 */     SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_notSupported"), null, false);
/*      */   }
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLServerException
/*      */   {
/*  760 */     loggerExternal.entering(getClassNameLogging(), "clearWarnings");
/*  761 */     loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
/*      */   }
/*      */ 
/*      */   private void moverInit()
/*      */     throws SQLServerException
/*      */   {
/*  768 */     cancelInsert();
/*  769 */     cancelUpdates();
/*      */   }
/*      */ 
/*      */   public boolean relative(int paramInt) throws SQLServerException
/*      */   {
/*  774 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  775 */       loggerExternal.entering(getClassNameLogging(), "relative", Integer.valueOf(paramInt));
/*      */     }
/*  777 */     if (logger.isLoggable(Level.FINER)) {
/*  778 */       logger.finer(toString() + " rows:" + paramInt + logCursorState());
/*      */     }
/*  780 */     checkClosed();
/*      */ 
/*  785 */     verifyResultSetIsScrollable();
/*  786 */     verifyResultSetHasCurrentRow();
/*      */ 
/*  788 */     moverInit();
/*  789 */     moveRelative(paramInt);
/*  790 */     boolean bool = hasCurrentRow();
/*  791 */     loggerExternal.exiting(getClassNameLogging(), "relative", Boolean.valueOf(bool));
/*  792 */     return bool;
/*      */   }
/*      */ 
/*      */   private final void moveRelative(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  798 */     assert (hasCurrentRow());
/*      */ 
/*  801 */     if (0 == paramInt) {
/*  802 */       return;
/*      */     }
/*  804 */     if (paramInt > 0)
/*  805 */       moveForward(paramInt);
/*      */     else
/*  807 */       moveBackward(paramInt);
/*      */   }
/*      */ 
/*      */   private final void moveForward(int paramInt) throws SQLServerException
/*      */   {
/*  812 */     assert (hasCurrentRow());
/*  813 */     assert (paramInt > 0);
/*      */ 
/*  816 */     if (this.scrollWindow.getRow() + paramInt <= this.scrollWindow.getMaxRows())
/*      */     {
/*  818 */       int i = 0;
/*  819 */       while ((paramInt > 0) && (this.scrollWindow.next(this)))
/*      */       {
/*  821 */         i++;
/*  822 */         paramInt--;
/*      */       }
/*      */ 
/*  826 */       updateCurrentRow(i);
/*      */ 
/*  829 */       if (0 == paramInt) {
/*  830 */         return;
/*      */       }
/*      */     }
/*      */ 
/*  834 */     assert (paramInt > 0);
/*      */ 
/*  838 */     if (0 == this.serverCursorId)
/*      */     {
/*  840 */       assert (-2 != this.currentRow);
/*  841 */       this.currentRow = clientMoveAbsolute(this.currentRow + paramInt);
/*  842 */       return;
/*      */     }
/*      */ 
/*  856 */     if (1 == paramInt)
/*  857 */       doServerFetch(2, 0, this.fetchSize);
/*      */     else {
/*  859 */       doServerFetch(32, paramInt + this.scrollWindow.getRow() - 1, this.fetchSize);
/*      */     }
/*      */ 
/*  862 */     if (!this.scrollWindow.next(this))
/*      */     {
/*  864 */       this.currentRow = -1;
/*  865 */       return;
/*      */     }
/*      */ 
/*  869 */     updateCurrentRow(paramInt);
/*      */   }
/*      */ 
/*      */   private final void moveBackward(int paramInt) throws SQLServerException
/*      */   {
/*  874 */     assert (hasCurrentRow());
/*  875 */     assert (paramInt < 0);
/*      */ 
/*  878 */     if (this.scrollWindow.getRow() + paramInt >= 1)
/*      */     {
/*  880 */       for (int i = 0; i > paramInt; i--) {
/*  881 */         this.scrollWindow.previous(this);
/*      */       }
/*  883 */       updateCurrentRow(paramInt);
/*  884 */       return;
/*      */     }
/*      */ 
/*  891 */     if (0 == this.serverCursorId)
/*      */     {
/*  893 */       assert (-2 != this.currentRow);
/*      */ 
/*  897 */       if (this.currentRow + paramInt < 1)
/*      */       {
/*  899 */         moveBeforeFirst();
/*      */       }
/*      */       else
/*      */       {
/*  903 */         this.currentRow = clientMoveAbsolute(this.currentRow + paramInt);
/*      */       }
/*      */ 
/*  906 */       return;
/*      */     }
/*      */ 
/*  927 */     if (-1 == paramInt)
/*      */     {
/*  929 */       doServerFetch(512, 0, this.fetchSize);
/*      */ 
/*  932 */       if (!this.scrollWindow.next(this))
/*      */       {
/*  934 */         this.currentRow = 0;
/*  935 */         return;
/*      */       }
/*      */ 
/*  939 */       while (this.scrollWindow.next(this));
/*  943 */       this.scrollWindow.previous(this);
/*      */     }
/*      */     else
/*      */     {
/*  947 */       doServerFetch(32, paramInt + this.scrollWindow.getRow() - 1, this.fetchSize);
/*      */ 
/*  950 */       if (!this.scrollWindow.next(this))
/*      */       {
/*  952 */         this.currentRow = 0;
/*  953 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  958 */     updateCurrentRow(paramInt);
/*      */   }
/*      */ 
/*      */   private final void updateCurrentRow(int paramInt)
/*      */   {
/*  969 */     if (-2 != this.currentRow)
/*      */     {
/*  971 */       assert (this.currentRow >= 1);
/*  972 */       this.currentRow += paramInt;
/*  973 */       assert (this.currentRow >= 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean next()
/*      */     throws SQLServerException
/*      */   {
/*  986 */     loggerExternal.entering(getClassNameLogging(), "next");
/*  987 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  989 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  991 */     if (logger.isLoggable(Level.FINER)) {
/*  992 */       logger.finer(toString() + logCursorState());
/*      */     }
/*  994 */     checkClosed();
/*      */ 
/*  996 */     moverInit();
/*      */ 
/* 1000 */     if (-1 == this.currentRow)
/*      */     {
/* 1002 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
/* 1003 */       return false;
/*      */     }
/*      */ 
/* 1007 */     if (!isForwardOnly())
/*      */     {
/* 1009 */       if (0 == this.currentRow)
/* 1010 */         moveFirst();
/*      */       else
/* 1012 */         moveForward(1);
/* 1013 */       boolean bool = hasCurrentRow();
/* 1014 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(bool));
/* 1015 */       return bool;
/*      */     }
/*      */ 
/* 1022 */     if ((0 != this.serverCursorId) && (this.maxRows > 0))
/*      */     {
/* 1024 */       if (this.currentRow == this.maxRows)
/*      */       {
/* 1026 */         this.currentRow = -1;
/* 1027 */         loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
/* 1028 */         return false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1034 */     if (fetchBufferNext())
/*      */     {
/* 1039 */       if (0 == this.currentRow)
/* 1040 */         this.currentRow = 1;
/*      */       else {
/* 1042 */         updateCurrentRow(1);
/*      */       }
/*      */ 
/* 1047 */       assert ((0 == this.maxRows) || (this.currentRow <= this.maxRows));
/* 1048 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(true));
/*      */ 
/* 1050 */       return true;
/*      */     }
/*      */ 
/* 1056 */     if (0 != this.serverCursorId)
/*      */     {
/* 1058 */       doServerFetch(2, 0, this.fetchSize);
/*      */ 
/* 1062 */       if (fetchBufferNext())
/*      */       {
/* 1064 */         if (0 == this.currentRow)
/* 1065 */           this.currentRow = 1;
/*      */         else {
/* 1067 */           updateCurrentRow(1);
/*      */         }
/* 1069 */         assert ((0 == this.maxRows) || (this.currentRow <= this.maxRows));
/* 1070 */         loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(true));
/* 1071 */         return true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1076 */     if (-3 == this.rowCount) {
/* 1077 */       this.rowCount = this.currentRow;
/*      */     }
/* 1079 */     this.currentRow = -1;
/* 1080 */     loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
/* 1081 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean wasNull() throws SQLServerException
/*      */   {
/* 1086 */     loggerExternal.entering(getClassNameLogging(), "wasNull");
/* 1087 */     checkClosed();
/* 1088 */     loggerExternal.exiting(getClassNameLogging(), "wasNull", Boolean.valueOf(this.lastValueWasNull));
/* 1089 */     return this.lastValueWasNull;
/*      */   }
/*      */ 
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLServerException
/*      */   {
/* 1098 */     loggerExternal.entering(getClassNameLogging(), "isBeforeFirst");
/* 1099 */     if (logger.isLoggable(Level.FINER)) {
/* 1100 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1102 */     checkClosed();
/*      */ 
/* 1111 */     if (0 != this.serverCursorId)
/*      */     {
/* 1113 */       switch (this.stmt.getCursorType())
/*      */       {
/*      */       case 4:
/* 1116 */         throwNotScrollable();
/* 1117 */         break;
/*      */       case 2:
/* 1120 */         throwUnsupportedCursorOp();
/* 1121 */         break;
/*      */       case 16:
/* 1127 */         throwNotScrollable();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1135 */     if (this.isOnInsertRow) {
/* 1136 */       return false;
/*      */     }
/*      */ 
/* 1140 */     if (0 != this.currentRow) {
/* 1141 */       return false;
/*      */     }
/*      */ 
/* 1148 */     if (0 == this.serverCursorId) {
/* 1149 */       return fetchBufferHasRows();
/*      */     }
/*      */ 
/* 1154 */     assert (this.rowCount >= 0);
/* 1155 */     boolean bool = this.rowCount > 0;
/* 1156 */     loggerExternal.exiting(getClassNameLogging(), "isBeforeFirst", Boolean.valueOf(bool));
/* 1157 */     return bool;
/*      */   }
/*      */ 
/*      */   public boolean isAfterLast() throws SQLServerException
/*      */   {
/* 1162 */     loggerExternal.entering(getClassNameLogging(), "isAfterLast");
/* 1163 */     if (logger.isLoggable(Level.FINER)) {
/* 1164 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1166 */     checkClosed();
/*      */ 
/* 1173 */     if (0 != this.serverCursorId)
/*      */     {
/* 1175 */       verifyResultSetIsScrollable();
/*      */ 
/* 1180 */       if ((2 == this.stmt.getCursorType()) && (!isForwardOnly())) {
/* 1181 */         throwUnsupportedCursorOp();
/*      */       }
/*      */     }
/*      */ 
/* 1185 */     if (this.isOnInsertRow) {
/* 1186 */       return false;
/*      */     }
/*      */ 
/* 1190 */     assert ((-1 != this.currentRow) || (-3 != this.rowCount));
/*      */ 
/* 1192 */     boolean bool = (-1 == this.currentRow) && (this.rowCount > 0);
/* 1193 */     loggerExternal.exiting(getClassNameLogging(), "isAfterLast", Boolean.valueOf(bool));
/* 1194 */     return bool;
/*      */   }
/*      */ 
/*      */   public boolean isFirst()
/*      */     throws SQLServerException
/*      */   {
/* 1212 */     loggerExternal.entering(getClassNameLogging(), "isFirst");
/* 1213 */     if (logger.isLoggable(Level.FINER)) {
/* 1214 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1216 */     checkClosed();
/*      */ 
/* 1220 */     verifyResultSetIsScrollable();
/*      */ 
/* 1224 */     if (isDynamic()) {
/* 1225 */       throwUnsupportedCursorOp();
/*      */     }
/*      */ 
/* 1228 */     if (this.isOnInsertRow) {
/* 1229 */       return false;
/*      */     }
/*      */ 
/* 1233 */     assert (-2 != this.currentRow);
/*      */ 
/* 1236 */     boolean bool = 1 == this.currentRow;
/* 1237 */     loggerExternal.exiting(getClassNameLogging(), "isFirst", Boolean.valueOf(bool));
/* 1238 */     return bool;
/*      */   }
/*      */ 
/*      */   public boolean isLast()
/*      */     throws SQLServerException
/*      */   {
/* 1256 */     loggerExternal.entering(getClassNameLogging(), "isLast");
/* 1257 */     if (logger.isLoggable(Level.FINER)) {
/* 1258 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1260 */     checkClosed();
/*      */ 
/* 1264 */     verifyResultSetIsScrollable();
/*      */ 
/* 1268 */     if (isDynamic()) {
/* 1269 */       throwUnsupportedCursorOp();
/*      */     }
/*      */ 
/* 1272 */     if (this.isOnInsertRow) {
/* 1273 */       return false;
/*      */     }
/*      */ 
/* 1277 */     if (!hasCurrentRow()) {
/* 1278 */       return false;
/*      */     }
/*      */ 
/* 1281 */     assert (this.currentRow >= 1);
/*      */ 
/* 1284 */     if (-3 != this.rowCount)
/*      */     {
/* 1286 */       assert (this.currentRow <= this.rowCount);
/* 1287 */       return this.currentRow == this.rowCount;
/*      */     }
/*      */ 
/* 1294 */     assert (0 == this.serverCursorId);
/*      */ 
/* 1301 */     boolean bool = !next();
/* 1302 */     previous();
/* 1303 */     loggerExternal.exiting(getClassNameLogging(), "isLast", Boolean.valueOf(bool));
/* 1304 */     return bool;
/*      */   }
/*      */ 
/*      */   public void beforeFirst() throws SQLServerException
/*      */   {
/* 1309 */     loggerExternal.entering(getClassNameLogging(), "beforeFirst");
/* 1310 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1312 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1314 */     if (logger.isLoggable(Level.FINER)) {
/* 1315 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1317 */     checkClosed();
/*      */ 
/* 1321 */     verifyResultSetIsScrollable();
/*      */ 
/* 1323 */     moverInit();
/* 1324 */     moveBeforeFirst();
/* 1325 */     loggerExternal.exiting(getClassNameLogging(), "beforeFirst");
/*      */   }
/*      */ 
/*      */   private final void moveBeforeFirst() throws SQLServerException
/*      */   {
/* 1330 */     if (0 == this.serverCursorId)
/*      */     {
/* 1332 */       fetchBufferBeforeFirst();
/* 1333 */       this.scrollWindow.clear();
/*      */     }
/*      */     else
/*      */     {
/* 1337 */       doServerFetch(1, 0, 0);
/*      */     }
/*      */ 
/* 1340 */     this.currentRow = 0;
/*      */   }
/*      */ 
/*      */   public void afterLast() throws SQLServerException
/*      */   {
/* 1345 */     loggerExternal.entering(getClassNameLogging(), "afterLast");
/* 1346 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1348 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */ 
/* 1351 */     if (logger.isLoggable(Level.FINER)) {
/* 1352 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1354 */     checkClosed();
/*      */ 
/* 1358 */     verifyResultSetIsScrollable();
/*      */ 
/* 1360 */     moverInit();
/* 1361 */     moveAfterLast();
/* 1362 */     loggerExternal.exiting(getClassNameLogging(), "afterLast");
/*      */   }
/*      */ 
/*      */   private void moveAfterLast() throws SQLServerException
/*      */   {
/* 1367 */     assert (!isForwardOnly());
/*      */ 
/* 1369 */     if (0 == this.serverCursorId)
/* 1370 */       clientMoveAfterLast();
/*      */     else {
/* 1372 */       doServerFetch(8, 0, 0);
/*      */     }
/* 1374 */     this.currentRow = -1;
/*      */   }
/*      */ 
/*      */   public boolean first()
/*      */     throws SQLServerException
/*      */   {
/* 1392 */     loggerExternal.entering(getClassNameLogging(), "first");
/* 1393 */     if (logger.isLoggable(Level.FINER)) {
/* 1394 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1396 */     checkClosed();
/*      */ 
/* 1400 */     verifyResultSetIsScrollable();
/*      */ 
/* 1402 */     moverInit();
/* 1403 */     moveFirst();
/* 1404 */     boolean bool = hasCurrentRow();
/* 1405 */     loggerExternal.exiting(getClassNameLogging(), "first", Boolean.valueOf(bool));
/* 1406 */     return bool;
/*      */   }
/*      */ 
/*      */   private final void moveFirst() throws SQLServerException
/*      */   {
/* 1411 */     if (0 == this.serverCursorId)
/*      */     {
/* 1413 */       moveBeforeFirst();
/*      */     }
/*      */     else
/*      */     {
/* 1418 */       doServerFetch(1, 0, this.fetchSize);
/*      */     }
/*      */ 
/* 1422 */     if (!this.scrollWindow.next(this))
/*      */     {
/* 1429 */       this.currentRow = -1;
/* 1430 */       return;
/*      */     }
/*      */ 
/* 1434 */     this.currentRow = (isDynamic() ? -2 : 1);
/*      */   }
/*      */ 
/*      */   public boolean last()
/*      */     throws SQLServerException
/*      */   {
/* 1452 */     loggerExternal.entering(getClassNameLogging(), "last");
/* 1453 */     if (logger.isLoggable(Level.FINER)) {
/* 1454 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1456 */     checkClosed();
/*      */ 
/* 1460 */     verifyResultSetIsScrollable();
/*      */ 
/* 1462 */     moverInit();
/* 1463 */     moveLast();
/* 1464 */     boolean bool = hasCurrentRow();
/* 1465 */     loggerExternal.exiting(getClassNameLogging(), "last", Boolean.valueOf(bool));
/* 1466 */     return bool;
/*      */   }
/*      */ 
/*      */   private final void moveLast() throws SQLServerException
/*      */   {
/* 1471 */     if (0 == this.serverCursorId)
/*      */     {
/* 1473 */       this.currentRow = clientMoveAbsolute(-1);
/* 1474 */       return;
/*      */     }
/*      */ 
/* 1478 */     doServerFetch(8, 0, this.fetchSize);
/*      */ 
/* 1481 */     if (!this.scrollWindow.next(this))
/*      */     {
/* 1488 */       this.currentRow = -1;
/* 1489 */       return;
/*      */     }
/*      */ 
/* 1493 */     while (this.scrollWindow.next(this));
/* 1495 */     this.scrollWindow.previous(this);
/*      */ 
/* 1498 */     this.currentRow = (isDynamic() ? -2 : this.rowCount);
/*      */   }
/*      */ 
/*      */   public int getRow()
/*      */     throws SQLServerException
/*      */   {
/* 1509 */     loggerExternal.entering(getClassNameLogging(), "getRow");
/* 1510 */     if (logger.isLoggable(Level.FINER)) {
/* 1511 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1513 */     checkClosed();
/*      */ 
/* 1517 */     if ((isDynamic()) && (!isForwardOnly())) {
/* 1518 */       throwUnsupportedCursorOp();
/*      */     }
/*      */ 
/* 1525 */     if ((!hasCurrentRow()) || (this.isOnInsertRow)) {
/* 1526 */       return 0;
/*      */     }
/*      */ 
/* 1529 */     assert (this.currentRow >= 1);
/*      */ 
/* 1532 */     loggerExternal.exiting(getClassNameLogging(), "getRow", Integer.valueOf(this.currentRow));
/* 1533 */     return this.currentRow;
/*      */   }
/*      */ 
/*      */   public boolean absolute(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1552 */     loggerExternal.entering(getClassNameLogging(), "absolute");
/* 1553 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1555 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1557 */     if (logger.isLoggable(Level.FINER)) {
/* 1558 */       logger.finer(toString() + " row:" + paramInt + logCursorState());
/*      */     }
/* 1560 */     checkClosed();
/*      */ 
/* 1564 */     verifyResultSetIsScrollable();
/*      */ 
/* 1568 */     if (isDynamic()) {
/* 1569 */       throwUnsupportedCursorOp();
/*      */     }
/* 1571 */     moverInit();
/* 1572 */     moveAbsolute(paramInt);
/* 1573 */     boolean bool = hasCurrentRow();
/* 1574 */     loggerExternal.exiting(getClassNameLogging(), "absolute", Boolean.valueOf(bool));
/* 1575 */     return bool;
/*      */   }
/*      */ 
/*      */   private void moveAbsolute(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1582 */     assert (-2 != this.currentRow);
/* 1583 */     assert (!isDynamic());
/*      */ 
/* 1585 */     switch (paramInt)
/*      */     {
/*      */     case 0:
/* 1589 */       moveBeforeFirst();
/* 1590 */       return;
/*      */     case 1:
/* 1594 */       moveFirst();
/* 1595 */       return;
/*      */     case -1:
/* 1599 */       moveLast();
/* 1600 */       return;
/*      */     }
/*      */ 
/* 1608 */     if (hasCurrentRow())
/*      */     {
/* 1610 */       assert (this.currentRow >= 1);
/*      */ 
/* 1616 */       if (paramInt > 0)
/*      */       {
/* 1618 */         moveRelative(paramInt - this.currentRow);
/* 1619 */         return;
/*      */       }
/*      */ 
/* 1626 */       if (-3 != this.rowCount)
/*      */       {
/* 1628 */         assert (paramInt < 0);
/* 1629 */         moveRelative(this.rowCount + paramInt + 1 - this.currentRow);
/* 1630 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1641 */     if (0 == this.serverCursorId)
/*      */     {
/* 1643 */       this.currentRow = clientMoveAbsolute(paramInt);
/* 1644 */       return;
/*      */     }
/*      */ 
/* 1647 */     doServerFetch(16, paramInt, this.fetchSize);
/*      */ 
/* 1651 */     if (!this.scrollWindow.next(this))
/*      */     {
/* 1653 */       this.currentRow = (paramInt < 0 ? 0 : -1);
/* 1654 */       return;
/*      */     }
/*      */ 
/* 1659 */     if (paramInt > 0)
/*      */     {
/* 1662 */       this.currentRow = paramInt;
/*      */     }
/*      */     else
/*      */     {
/* 1667 */       assert (paramInt < 0);
/* 1668 */       assert (this.rowCount + paramInt + 1 >= 1);
/* 1669 */       this.currentRow = (this.rowCount + paramInt + 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final boolean fetchBufferHasRows()
/*      */     throws SQLServerException
/*      */   {
/* 1677 */     assert (0 == this.serverCursorId);
/* 1678 */     assert (null != this.tdsReader);
/*      */ 
/* 1680 */     assert (this.lastColumnIndex >= 0);
/*      */ 
/* 1683 */     if (this.lastColumnIndex >= 1) {
/* 1684 */       return true;
/*      */     }
/*      */ 
/* 1688 */     int i = this.tdsReader.peekTokenType();
/*      */ 
/* 1695 */     return (209 == i) || (210 == i) || (171 == i) || (170 == i);
/*      */   }
/*      */ 
/*      */   final void discardCurrentRow()
/*      */     throws SQLServerException
/*      */   {
/* 1703 */     assert (this.lastColumnIndex >= 0);
/*      */ 
/* 1705 */     this.updatedCurrentRow = false;
/* 1706 */     this.deletedCurrentRow = false;
/* 1707 */     if (this.lastColumnIndex >= 1)
/*      */     {
/* 1709 */       initializeNullCompressedColumns();
/*      */ 
/* 1711 */       for (int i = 1; i < this.lastColumnIndex; i++) {
/* 1712 */         getColumn(i).clear();
/*      */       }
/*      */ 
/* 1716 */       skipColumns(this.columns.length + 1 - this.lastColumnIndex, true);
/*      */     }
/*      */ 
/* 1720 */     this.resultSetCurrentRowType = RowType.UNKNOWN;
/* 1721 */     this.areNullCompressedColumnsInitialized = false;
/*      */   }
/*      */ 
/*      */   final int fetchBufferGetRow()
/*      */   {
/* 1726 */     if (isForwardOnly()) {
/* 1727 */       return this.numFetchedRows;
/*      */     }
/* 1729 */     return this.scrollWindow.getRow();
/*      */   }
/*      */ 
/*      */   final void fetchBufferBeforeFirst()
/*      */     throws SQLServerException
/*      */   {
/* 1736 */     assert (0 == this.serverCursorId);
/* 1737 */     assert (null != this.tdsReader);
/*      */ 
/* 1739 */     discardCurrentRow();
/*      */ 
/* 1741 */     this.fetchBuffer.reset();
/* 1742 */     this.lastColumnIndex = 0;
/*      */   }
/*      */ 
/*      */   final TDSReaderMark fetchBufferMark()
/*      */   {
/* 1748 */     assert (null != this.tdsReader);
/*      */ 
/* 1750 */     return this.tdsReader.mark();
/*      */   }
/*      */ 
/*      */   final void fetchBufferReset(TDSReaderMark paramTDSReaderMark)
/*      */     throws SQLServerException
/*      */   {
/* 1756 */     assert (null != this.tdsReader);
/*      */ 
/* 1758 */     assert (null != paramTDSReaderMark);
/*      */ 
/* 1760 */     discardCurrentRow();
/*      */ 
/* 1762 */     this.tdsReader.reset(paramTDSReaderMark);
/*      */ 
/* 1764 */     this.lastColumnIndex = 1;
/*      */   }
/*      */ 
/*      */   final boolean fetchBufferNext()
/*      */     throws SQLServerException
/*      */   {
/* 1770 */     if (null == this.tdsReader) {
/* 1771 */       return false;
/*      */     }
/*      */ 
/* 1774 */     discardCurrentRow();
/*      */ 
/* 1778 */     RowType localRowType = RowType.UNKNOWN;
/*      */     try
/*      */     {
/* 1781 */       localRowType = this.fetchBuffer.nextRow();
/* 1782 */       if (localRowType.equals(RowType.UNKNOWN)) {
/* 1783 */         int i = 0;
/*      */         return i;
/*      */       }
/*      */     }
/*      */     catch (SQLServerException localSQLServerException)
/*      */     {
/* 1787 */       this.currentRow = -1;
/* 1788 */       this.rowErrorException = localSQLServerException;
/* 1789 */       throw localSQLServerException;
/*      */     }
/*      */     finally
/*      */     {
/* 1793 */       this.lastColumnIndex = 0;
/* 1794 */       this.resultSetCurrentRowType = localRowType;
/*      */     }
/*      */ 
/* 1798 */     this.numFetchedRows += 1;
/* 1799 */     this.lastColumnIndex = 1;
/* 1800 */     return true;
/*      */   }
/*      */ 
/*      */   private final void clientMoveAfterLast() throws SQLServerException
/*      */   {
/* 1805 */     assert (-2 != this.currentRow);
/*      */ 
/* 1807 */     int i = 0;
/* 1808 */     while (fetchBufferNext()) {
/* 1809 */       i++;
/*      */     }
/* 1811 */     if (-3 == this.rowCount)
/*      */     {
/* 1813 */       assert (-1 != this.currentRow);
/* 1814 */       this.rowCount = ((0 == this.currentRow ? 0 : this.currentRow) + i);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final int clientMoveAbsolute(int paramInt) throws SQLServerException
/*      */   {
/* 1820 */     assert (0 == this.serverCursorId);
/*      */ 
/* 1822 */     this.scrollWindow.clear();
/*      */ 
/* 1829 */     if (paramInt < 0)
/*      */     {
/* 1835 */       if (-3 == this.rowCount)
/*      */       {
/* 1837 */         clientMoveAfterLast();
/* 1838 */         this.currentRow = -1;
/*      */       }
/*      */ 
/* 1843 */       assert (this.rowCount >= 0);
/*      */ 
/* 1847 */       if (this.rowCount + paramInt < 0)
/*      */       {
/* 1849 */         moveBeforeFirst();
/* 1850 */         return 0;
/*      */       }
/*      */ 
/* 1853 */       paramInt = this.rowCount + paramInt + 1;
/*      */     }
/*      */ 
/* 1860 */     assert (paramInt > 0);
/*      */ 
/* 1866 */     if ((-1 == this.currentRow) || (paramInt <= this.currentRow)) {
/* 1867 */       moveBeforeFirst();
/*      */     }
/*      */ 
/* 1871 */     assert ((0 == this.currentRow) || (this.currentRow < paramInt));
/* 1872 */     while (this.currentRow != paramInt)
/*      */     {
/* 1874 */       if (!fetchBufferNext())
/*      */       {
/* 1876 */         if (-3 == this.rowCount)
/* 1877 */           this.rowCount = this.currentRow;
/* 1878 */         return -1;
/*      */       }
/*      */ 
/* 1884 */       if (0 == this.currentRow) {
/* 1885 */         this.currentRow = 1; continue;
/*      */       }
/* 1887 */       updateCurrentRow(1);
/*      */     }
/*      */ 
/* 1890 */     return paramInt;
/*      */   }
/*      */ 
/*      */   public boolean previous()
/*      */     throws SQLServerException
/*      */   {
/* 1908 */     loggerExternal.entering(getClassNameLogging(), "previous");
/* 1909 */     if (logger.isLoggable(Level.FINER)) {
/* 1910 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1912 */     checkClosed();
/*      */ 
/* 1916 */     verifyResultSetIsScrollable();
/*      */ 
/* 1918 */     moverInit();
/*      */ 
/* 1920 */     if (0 == this.currentRow) {
/* 1921 */       return false;
/*      */     }
/* 1923 */     if (-1 == this.currentRow)
/* 1924 */       moveLast();
/*      */     else {
/* 1926 */       moveBackward(-1);
/*      */     }
/* 1928 */     boolean bool = hasCurrentRow();
/* 1929 */     loggerExternal.exiting(getClassNameLogging(), "previous", Boolean.valueOf(bool));
/* 1930 */     return bool;
/*      */   }
/*      */ 
/*      */   private final void cancelInsert()
/*      */   {
/* 1935 */     if (this.isOnInsertRow)
/*      */     {
/* 1937 */       this.isOnInsertRow = false;
/* 1938 */       clearColumnsValues();
/*      */     }
/*      */   }
/*      */ 
/*      */   final void clearColumnsValues()
/*      */   {
/* 1945 */     int i = this.columns.length;
/* 1946 */     for (int j = 0; j < i; j++)
/* 1947 */       this.columns[j].cancelUpdates();
/*      */   }
/*      */ 
/*      */   public SQLWarning getWarnings() throws SQLServerException
/*      */   {
/* 1952 */     loggerExternal.entering(getClassNameLogging(), "getWarnings");
/* 1953 */     loggerExternal.exiting(getClassNameLogging(), "getWarnings", null);
/* 1954 */     return null;
/*      */   }
/*      */ 
/*      */   public void setFetchDirection(int paramInt) throws SQLServerException
/*      */   {
/* 1959 */     loggerExternal.entering(getClassNameLogging(), "setFetchDirection", Integer.valueOf(paramInt));
/* 1960 */     checkClosed();
/*      */ 
/* 1964 */     verifyResultSetIsScrollable();
/*      */ 
/* 1966 */     if (((1000 != paramInt) && (1001 != paramInt) && (1002 != paramInt)) || ((1000 != paramInt) && ((2003 == this.stmt.resultSetType) || (2004 == this.stmt.resultSetType))))
/*      */     {
/* 1974 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidFetchDirection"));
/* 1975 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 1976 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, localMessageFormat.format(arrayOfObject), null, false);
/*      */     }
/*      */ 
/* 1979 */     this.fetchDirection = paramInt;
/* 1980 */     loggerExternal.exiting(getClassNameLogging(), "setFetchDirection");
/*      */   }
/*      */ 
/*      */   public int getFetchDirection() throws SQLServerException
/*      */   {
/* 1985 */     loggerExternal.entering(getClassNameLogging(), "getFetchDirection");
/* 1986 */     checkClosed();
/* 1987 */     loggerExternal.exiting(getClassNameLogging(), "getFetchDirection", Integer.valueOf(this.fetchDirection));
/* 1988 */     return this.fetchDirection;
/*      */   }
/*      */ 
/*      */   public void setFetchSize(int paramInt) throws SQLServerException
/*      */   {
/* 1993 */     loggerExternal.entering(getClassNameLogging(), "setFetchSize", Integer.valueOf(paramInt));
/* 1994 */     checkClosed();
/* 1995 */     if (paramInt < 0) {
/* 1996 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_invalidFetchSize"), null, false);
/*      */     }
/* 1998 */     this.fetchSize = (0 == paramInt ? this.stmt.defaultFetchSize : paramInt);
/* 1999 */     loggerExternal.exiting(getClassNameLogging(), "setFetchSize");
/*      */   }
/*      */ 
/*      */   public int getFetchSize() throws SQLServerException {
/* 2003 */     loggerExternal.entering(getClassNameLogging(), "getFetchSize");
/* 2004 */     checkClosed();
/* 2005 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", Integer.valueOf(this.fetchSize));
/* 2006 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */   public int getType() throws SQLServerException {
/* 2010 */     loggerExternal.entering(getClassNameLogging(), "getType");
/* 2011 */     checkClosed();
/*      */ 
/* 2013 */     int i = this.stmt.getResultSetType();
/* 2014 */     loggerExternal.exiting(getClassNameLogging(), "getType", Integer.valueOf(i));
/* 2015 */     return i;
/*      */   }
/*      */ 
/*      */   public int getConcurrency() throws SQLServerException
/*      */   {
/* 2020 */     loggerExternal.entering(getClassNameLogging(), "getConcurrency");
/* 2021 */     checkClosed();
/* 2022 */     int i = this.stmt.getResultSetConcurrency();
/* 2023 */     loggerExternal.exiting(getClassNameLogging(), "getConcurrency", Integer.valueOf(i));
/* 2024 */     return i;
/*      */   }
/*      */ 
/*      */   private Column getterGetColumn(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2047 */     verifyResultSetHasCurrentRow();
/* 2048 */     verifyCurrentRowIsNotDeleted("R_cantGetColumnValueFromDeletedRow");
/* 2049 */     verifyValidColumnIndex(paramInt);
/*      */ 
/* 2052 */     if (this.updatedCurrentRow)
/*      */     {
/* 2054 */       doRefreshRow();
/* 2055 */       verifyResultSetHasCurrentRow();
/*      */     }
/*      */ 
/* 2059 */     if (logger.isLoggable(Level.FINER)) {
/* 2060 */       logger.finer(toString() + " Getting Column:" + paramInt);
/*      */     }
/* 2062 */     return loadColumn(paramInt);
/*      */   }
/*      */ 
/*      */   private final Object getValue(int paramInt, JDBCType paramJDBCType) throws SQLServerException
/*      */   {
/* 2067 */     return getValue(paramInt, paramJDBCType, null, null);
/*      */   }
/*      */ 
/*      */   private final Object getValue(int paramInt, JDBCType paramJDBCType, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 2072 */     return getValue(paramInt, paramJDBCType, null, paramCalendar);
/*      */   }
/*      */ 
/*      */   private final Object getValue(int paramInt, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs) throws SQLServerException
/*      */   {
/* 2077 */     return getValue(paramInt, paramJDBCType, paramInputStreamGetterArgs, null);
/*      */   }
/*      */ 
/*      */   private final Object getValue(int paramInt, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 2082 */     Object localObject = getterGetColumn(paramInt).getValue(paramJDBCType, paramInputStreamGetterArgs, paramCalendar, this.tdsReader);
/* 2083 */     this.lastValueWasNull = (null == localObject);
/* 2084 */     return localObject;
/*      */   }
/*      */ 
/*      */   private Object getStream(int paramInt, StreamType paramStreamType) throws SQLServerException
/*      */   {
/* 2089 */     Object localObject = getValue(paramInt, paramStreamType.getJDBCType(), new InputStreamGetterArgs(paramStreamType, this.stmt.getExecProps().isResponseBufferingAdaptive(), isForwardOnly(), toString()));
/*      */ 
/* 2098 */     this.activeStream = ((Closeable)localObject);
/* 2099 */     return localObject;
/*      */   }
/*      */ 
/*      */   private SQLXML getSQLXMLInternal(int paramInt) throws SQLServerException {
/* 2103 */     SQLServerSQLXML localSQLServerSQLXML = (SQLServerSQLXML)getValue(paramInt, JDBCType.SQLXML, new InputStreamGetterArgs(StreamType.SQLXML, this.stmt.getExecProps().isResponseBufferingAdaptive(), isForwardOnly(), toString()));
/*      */ 
/* 2112 */     if (null != localSQLServerSQLXML)
/* 2113 */       this.activeStream = localSQLServerSQLXML.getStream();
/* 2114 */     return localSQLServerSQLXML;
/*      */   }
/*      */ 
/*      */   public InputStream getAsciiStream(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2120 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", Integer.valueOf(paramInt));
/* 2121 */     checkClosed();
/* 2122 */     InputStream localInputStream = (InputStream)getStream(paramInt, StreamType.ASCII);
/* 2123 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", localInputStream);
/* 2124 */     return localInputStream;
/*      */   }
/*      */ 
/*      */   public InputStream getAsciiStream(String paramString) throws SQLServerException
/*      */   {
/* 2129 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", paramString);
/* 2130 */     checkClosed();
/* 2131 */     InputStream localInputStream = (InputStream)getStream(findColumn(paramString), StreamType.ASCII);
/* 2132 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", localInputStream);
/* 2133 */     return localInputStream;
/*      */   }
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLServerException {
/* 2138 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2139 */       loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/* 2140 */     checkClosed();
/* 2141 */     BigDecimal localBigDecimal = (BigDecimal)getValue(paramInt1, JDBCType.DECIMAL);
/* 2142 */     if (null != localBigDecimal)
/* 2143 */       localBigDecimal = localBigDecimal.setScale(paramInt2, 1);
/* 2144 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", localBigDecimal);
/* 2145 */     return localBigDecimal;
/*      */   }
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLServerException {
/* 2150 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2151 */       loggerExternal.entering(getClassNameLogging(), "columnName", new Object[] { paramString, Integer.valueOf(paramInt) });
/* 2152 */     checkClosed();
/* 2153 */     BigDecimal localBigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/* 2154 */     if (null != localBigDecimal)
/* 2155 */       localBigDecimal = localBigDecimal.setScale(paramInt, 1);
/* 2156 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", localBigDecimal);
/* 2157 */     return localBigDecimal;
/*      */   }
/*      */ 
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLServerException
/*      */   {
/* 2162 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", Integer.valueOf(paramInt));
/* 2163 */     checkClosed();
/* 2164 */     InputStream localInputStream = (InputStream)getStream(paramInt, StreamType.BINARY);
/* 2165 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", localInputStream);
/* 2166 */     return localInputStream;
/*      */   }
/*      */ 
/*      */   public InputStream getBinaryStream(String paramString) throws SQLServerException
/*      */   {
/* 2171 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", paramString);
/* 2172 */     checkClosed();
/* 2173 */     InputStream localInputStream = (InputStream)getStream(findColumn(paramString), StreamType.BINARY);
/* 2174 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", localInputStream);
/* 2175 */     return localInputStream;
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(int paramInt) throws SQLServerException
/*      */   {
/* 2180 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", Integer.valueOf(paramInt));
/* 2181 */     checkClosed();
/* 2182 */     Boolean localBoolean = (Boolean)getValue(paramInt, JDBCType.BIT);
/* 2183 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", localBoolean);
/* 2184 */     return null != localBoolean ? localBoolean.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(String paramString) throws SQLServerException
/*      */   {
/* 2189 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", paramString);
/* 2190 */     checkClosed();
/* 2191 */     Boolean localBoolean = (Boolean)getValue(findColumn(paramString), JDBCType.BIT);
/* 2192 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", localBoolean);
/* 2193 */     return null != localBoolean ? localBoolean.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   public byte getByte(int paramInt) throws SQLServerException
/*      */   {
/* 2198 */     loggerExternal.entering(getClassNameLogging(), "getByte", Integer.valueOf(paramInt));
/* 2199 */     checkClosed();
/* 2200 */     Short localShort = (Short)getValue(paramInt, JDBCType.TINYINT);
/* 2201 */     loggerExternal.exiting(getClassNameLogging(), "getByte", localShort);
/* 2202 */     return null != localShort ? localShort.byteValue() : 0;
/*      */   }
/*      */ 
/*      */   public byte getByte(String paramString) throws SQLServerException
/*      */   {
/* 2207 */     loggerExternal.entering(getClassNameLogging(), "getByte", paramString);
/* 2208 */     checkClosed();
/* 2209 */     Short localShort = (Short)getValue(findColumn(paramString), JDBCType.TINYINT);
/* 2210 */     loggerExternal.exiting(getClassNameLogging(), "getByte", localShort);
/* 2211 */     return null != localShort ? localShort.byteValue() : 0;
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(int paramInt) throws SQLServerException
/*      */   {
/* 2216 */     loggerExternal.entering(getClassNameLogging(), "getBytes", Integer.valueOf(paramInt));
/* 2217 */     checkClosed();
/* 2218 */     byte[] arrayOfByte = (byte[])(byte[])getValue(paramInt, JDBCType.BINARY);
/* 2219 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
/* 2220 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(String paramString) throws SQLServerException
/*      */   {
/* 2225 */     loggerExternal.entering(getClassNameLogging(), "getBytes", paramString);
/* 2226 */     checkClosed();
/* 2227 */     byte[] arrayOfByte = (byte[])(byte[])getValue(findColumn(paramString), JDBCType.BINARY);
/* 2228 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
/* 2229 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public Date getDate(int paramInt) throws SQLServerException
/*      */   {
/* 2234 */     loggerExternal.entering(getClassNameLogging(), "getDate", Integer.valueOf(paramInt));
/* 2235 */     checkClosed();
/* 2236 */     Date localDate = (Date)getValue(paramInt, JDBCType.DATE);
/* 2237 */     loggerExternal.exiting(getClassNameLogging(), "getDate", localDate);
/* 2238 */     return localDate;
/*      */   }
/*      */ 
/*      */   public Date getDate(String paramString) throws SQLServerException
/*      */   {
/* 2243 */     loggerExternal.entering(getClassNameLogging(), "getDate", paramString);
/* 2244 */     checkClosed();
/* 2245 */     Date localDate = (Date)getValue(findColumn(paramString), JDBCType.DATE);
/* 2246 */     loggerExternal.exiting(getClassNameLogging(), "getDate", localDate);
/* 2247 */     return localDate;
/*      */   }
/*      */ 
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 2252 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2253 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { Integer.valueOf(paramInt), paramCalendar });
/* 2254 */     checkClosed();
/* 2255 */     Date localDate = (Date)getValue(paramInt, JDBCType.DATE, paramCalendar);
/* 2256 */     loggerExternal.exiting(getClassNameLogging(), "getDate", localDate);
/* 2257 */     return localDate;
/*      */   }
/*      */ 
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 2262 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2263 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { paramString, paramCalendar });
/* 2264 */     checkClosed();
/* 2265 */     Date localDate = (Date)getValue(findColumn(paramString), JDBCType.DATE, paramCalendar);
/* 2266 */     loggerExternal.exiting(getClassNameLogging(), "getDate", localDate);
/* 2267 */     return localDate;
/*      */   }
/*      */ 
/*      */   public double getDouble(int paramInt) throws SQLServerException
/*      */   {
/* 2272 */     loggerExternal.entering(getClassNameLogging(), "getDouble", Integer.valueOf(paramInt));
/* 2273 */     checkClosed();
/* 2274 */     Double localDouble = (Double)getValue(paramInt, JDBCType.DOUBLE);
/* 2275 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", localDouble);
/* 2276 */     return null != localDouble ? localDouble.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   public double getDouble(String paramString) throws SQLServerException
/*      */   {
/* 2281 */     loggerExternal.entering(getClassNameLogging(), "getDouble", paramString);
/* 2282 */     checkClosed();
/* 2283 */     Double localDouble = (Double)getValue(findColumn(paramString), JDBCType.DOUBLE);
/* 2284 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", localDouble);
/* 2285 */     return null != localDouble ? localDouble.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   public float getFloat(int paramInt) throws SQLServerException
/*      */   {
/* 2290 */     loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(paramInt));
/* 2291 */     checkClosed();
/* 2292 */     Float localFloat = (Float)getValue(paramInt, JDBCType.REAL);
/* 2293 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", localFloat);
/* 2294 */     return null != localFloat ? localFloat.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */   public float getFloat(String paramString) throws SQLServerException
/*      */   {
/* 2299 */     loggerExternal.entering(getClassNameLogging(), "getFloat", paramString);
/* 2300 */     checkClosed();
/* 2301 */     Float localFloat = (Float)getValue(findColumn(paramString), JDBCType.REAL);
/* 2302 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", localFloat);
/* 2303 */     return null != localFloat ? localFloat.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */   public int getInt(int paramInt) throws SQLServerException
/*      */   {
/* 2308 */     loggerExternal.entering(getClassNameLogging(), "getInt", Integer.valueOf(paramInt));
/* 2309 */     checkClosed();
/* 2310 */     Integer localInteger = (Integer)getValue(paramInt, JDBCType.INTEGER);
/* 2311 */     loggerExternal.exiting(getClassNameLogging(), "getInt", localInteger);
/* 2312 */     return null != localInteger ? localInteger.intValue() : 0;
/*      */   }
/*      */ 
/*      */   public int getInt(String paramString) throws SQLServerException
/*      */   {
/* 2317 */     loggerExternal.entering(getClassNameLogging(), "getInt", paramString);
/* 2318 */     checkClosed();
/* 2319 */     Integer localInteger = (Integer)getValue(findColumn(paramString), JDBCType.INTEGER);
/* 2320 */     loggerExternal.exiting(getClassNameLogging(), "getInt", localInteger);
/* 2321 */     return null != localInteger ? localInteger.intValue() : 0;
/*      */   }
/*      */ 
/*      */   public long getLong(int paramInt) throws SQLServerException
/*      */   {
/* 2326 */     loggerExternal.entering(getClassNameLogging(), "getLong", Integer.valueOf(paramInt));
/* 2327 */     checkClosed();
/* 2328 */     Long localLong = (Long)getValue(paramInt, JDBCType.BIGINT);
/* 2329 */     loggerExternal.exiting(getClassNameLogging(), "getLong", localLong);
/* 2330 */     return null != localLong ? localLong.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   public long getLong(String paramString) throws SQLServerException
/*      */   {
/* 2335 */     loggerExternal.entering(getClassNameLogging(), "getLong", paramString);
/* 2336 */     checkClosed();
/* 2337 */     Long localLong = (Long)getValue(findColumn(paramString), JDBCType.BIGINT);
/* 2338 */     loggerExternal.exiting(getClassNameLogging(), "getLong", localLong);
/* 2339 */     return null != localLong ? localLong.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   public ResultSetMetaData getMetaData() throws SQLServerException
/*      */   {
/* 2344 */     loggerExternal.entering(getClassNameLogging(), "getMetaData");
/* 2345 */     checkClosed();
/* 2346 */     if (this.metaData == null)
/* 2347 */       this.metaData = new SQLServerResultSetMetaData(this.stmt.connection, this);
/* 2348 */     loggerExternal.exiting(getClassNameLogging(), "getMetaData", this.metaData);
/* 2349 */     return this.metaData;
/*      */   }
/*      */ 
/*      */   public Object getObject(int paramInt) throws SQLServerException
/*      */   {
/* 2354 */     loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(paramInt));
/* 2355 */     checkClosed();
/* 2356 */     Object localObject = getValue(paramInt, getterGetColumn(paramInt).getTypeInfo().getSSType().getJDBCType());
/* 2357 */     loggerExternal.exiting(getClassNameLogging(), "getObject", localObject);
/* 2358 */     return localObject;
/*      */   }
/*      */ 
/*      */   public Object getObject(String paramString) throws SQLServerException
/*      */   {
/* 2363 */     loggerExternal.entering(getClassNameLogging(), "getObject", paramString);
/* 2364 */     checkClosed();
/* 2365 */     Object localObject = getObject(findColumn(paramString));
/* 2366 */     loggerExternal.exiting(getClassNameLogging(), "getObject", localObject);
/* 2367 */     return localObject;
/*      */   }
/*      */ 
/*      */   public short getShort(int paramInt) throws SQLServerException
/*      */   {
/* 2372 */     loggerExternal.entering(getClassNameLogging(), "getShort", Integer.valueOf(paramInt));
/* 2373 */     checkClosed();
/* 2374 */     Short localShort = (Short)getValue(paramInt, JDBCType.SMALLINT);
/* 2375 */     loggerExternal.exiting(getClassNameLogging(), "getShort", localShort);
/* 2376 */     return null != localShort ? localShort.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   public short getShort(String paramString) throws SQLServerException
/*      */   {
/* 2381 */     loggerExternal.entering(getClassNameLogging(), "getShort", paramString);
/* 2382 */     checkClosed();
/* 2383 */     Short localShort = (Short)getValue(findColumn(paramString), JDBCType.SMALLINT);
/* 2384 */     loggerExternal.exiting(getClassNameLogging(), "getShort", localShort);
/* 2385 */     return null != localShort ? localShort.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   public String getString(int paramInt) throws SQLServerException
/*      */   {
/* 2390 */     loggerExternal.entering(getClassNameLogging(), "getString", Integer.valueOf(paramInt));
/* 2391 */     checkClosed();
/* 2392 */     String str = (String)getValue(paramInt, JDBCType.CHAR);
/* 2393 */     loggerExternal.exiting(getClassNameLogging(), "getString", str);
/* 2394 */     return str;
/*      */   }
/*      */ 
/*      */   public String getString(String paramString) throws SQLServerException
/*      */   {
/* 2399 */     loggerExternal.entering(getClassNameLogging(), "getString", paramString);
/* 2400 */     checkClosed();
/* 2401 */     String str = (String)getValue(findColumn(paramString), JDBCType.CHAR);
/* 2402 */     loggerExternal.exiting(getClassNameLogging(), "getString", str);
/* 2403 */     return str;
/*      */   }
/*      */ 
/*      */   public String getNString(int paramInt) throws SQLException
/*      */   {
/* 2408 */     loggerExternal.entering(getClassNameLogging(), "getNString", Integer.valueOf(paramInt));
/* 2409 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2410 */     checkClosed();
/* 2411 */     String str = (String)getValue(paramInt, JDBCType.NCHAR);
/* 2412 */     loggerExternal.exiting(getClassNameLogging(), "getNString", str);
/* 2413 */     return str;
/*      */   }
/*      */ 
/*      */   public String getNString(String paramString) throws SQLException
/*      */   {
/* 2418 */     loggerExternal.entering(getClassNameLogging(), "getNString", paramString);
/* 2419 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2420 */     checkClosed();
/* 2421 */     String str = (String)getValue(findColumn(paramString), JDBCType.NCHAR);
/* 2422 */     loggerExternal.exiting(getClassNameLogging(), "getNString", str);
/* 2423 */     return str;
/*      */   }
/*      */ 
/*      */   public Time getTime(int paramInt) throws SQLServerException
/*      */   {
/* 2428 */     loggerExternal.entering(getClassNameLogging(), "getTime", Integer.valueOf(paramInt));
/* 2429 */     checkClosed();
/* 2430 */     Time localTime = (Time)getValue(paramInt, JDBCType.TIME);
/* 2431 */     loggerExternal.exiting(getClassNameLogging(), "getTime", localTime);
/* 2432 */     return localTime;
/*      */   }
/*      */ 
/*      */   public Time getTime(String paramString) throws SQLServerException
/*      */   {
/* 2437 */     loggerExternal.entering(getClassNameLogging(), "getTime", paramString);
/* 2438 */     checkClosed();
/* 2439 */     Time localTime = (Time)getValue(findColumn(paramString), JDBCType.TIME);
/* 2440 */     loggerExternal.exiting(getClassNameLogging(), "getTime", localTime);
/* 2441 */     return localTime;
/*      */   }
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 2446 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2447 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { Integer.valueOf(paramInt), paramCalendar });
/* 2448 */     checkClosed();
/* 2449 */     Time localTime = (Time)getValue(paramInt, JDBCType.TIME, paramCalendar);
/* 2450 */     loggerExternal.exiting(getClassNameLogging(), "getTime", localTime);
/* 2451 */     return localTime;
/*      */   }
/*      */ 
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 2456 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2457 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { paramString, paramCalendar });
/* 2458 */     checkClosed();
/* 2459 */     Time localTime = (Time)getValue(findColumn(paramString), JDBCType.TIME, paramCalendar);
/* 2460 */     loggerExternal.exiting(getClassNameLogging(), "getTime", localTime);
/* 2461 */     return localTime;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLServerException
/*      */   {
/* 2466 */     loggerExternal.entering(getClassNameLogging(), "getTimestamp", Integer.valueOf(paramInt));
/* 2467 */     checkClosed();
/* 2468 */     Timestamp localTimestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
/* 2469 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", localTimestamp);
/* 2470 */     return localTimestamp;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString) throws SQLServerException
/*      */   {
/* 2475 */     loggerExternal.entering(getClassNameLogging(), "getTimestamp", paramString);
/* 2476 */     checkClosed();
/* 2477 */     Timestamp localTimestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
/* 2478 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", localTimestamp);
/* 2479 */     return localTimestamp;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 2484 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2485 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { Integer.valueOf(paramInt), paramCalendar });
/* 2486 */     checkClosed();
/* 2487 */     Timestamp localTimestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
/* 2488 */     loggerExternal.exiting(getClassNameLogging(), "getTimeStamp", localTimestamp);
/* 2489 */     return localTimestamp;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLServerException
/*      */   {
/* 2494 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2495 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { paramString, paramCalendar });
/* 2496 */     checkClosed();
/* 2497 */     Timestamp localTimestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
/* 2498 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", localTimestamp);
/* 2499 */     return localTimestamp;
/*      */   }
/*      */ 
/*      */   public DateTimeOffset getDateTimeOffset(int paramInt) throws SQLException
/*      */   {
/* 2504 */     loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", Integer.valueOf(paramInt));
/* 2505 */     checkClosed();
/*      */ 
/* 2508 */     if (!this.stmt.connection.isKatmaiOrLater()) {
/* 2509 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/* 2515 */     DateTimeOffset localDateTimeOffset = (DateTimeOffset)getValue(paramInt, JDBCType.DATETIMEOFFSET);
/* 2516 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", localDateTimeOffset);
/* 2517 */     return localDateTimeOffset;
/*      */   }
/*      */ 
/*      */   public DateTimeOffset getDateTimeOffset(String paramString) throws SQLException
/*      */   {
/* 2522 */     loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", paramString);
/* 2523 */     checkClosed();
/*      */ 
/* 2526 */     if (!this.stmt.connection.isKatmaiOrLater()) {
/* 2527 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/* 2533 */     DateTimeOffset localDateTimeOffset = (DateTimeOffset)getValue(findColumn(paramString), JDBCType.DATETIMEOFFSET);
/* 2534 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", localDateTimeOffset);
/* 2535 */     return localDateTimeOffset;
/*      */   }
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLServerException {
/* 2540 */     loggerExternal.entering(getClassNameLogging(), "getUnicodeStream", Integer.valueOf(paramInt));
/* 2541 */     NotImplemented();
/* 2542 */     return null;
/*      */   }
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLServerException {
/* 2547 */     loggerExternal.entering(getClassNameLogging(), "getUnicodeStream", paramString);
/* 2548 */     NotImplemented();
/* 2549 */     return null;
/*      */   }
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLServerException
/*      */   {
/* 2554 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2555 */       loggerExternal.entering(getClassNameLogging(), "getObject", new Object[] { Integer.valueOf(paramInt), paramMap });
/* 2556 */     NotImplemented();
/* 2557 */     return null;
/*      */   }
/*      */ 
/*      */   public Ref getRef(int paramInt) throws SQLServerException
/*      */   {
/* 2562 */     loggerExternal.entering(getClassNameLogging(), "getRef");
/* 2563 */     NotImplemented();
/* 2564 */     return null;
/*      */   }
/*      */ 
/*      */   public Blob getBlob(int paramInt) throws SQLServerException
/*      */   {
/* 2569 */     loggerExternal.entering(getClassNameLogging(), "getBlob", Integer.valueOf(paramInt));
/* 2570 */     checkClosed();
/* 2571 */     Blob localBlob = (Blob)getValue(paramInt, JDBCType.BLOB);
/* 2572 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", localBlob);
/* 2573 */     return localBlob;
/*      */   }
/*      */ 
/*      */   public Blob getBlob(String paramString) throws SQLServerException
/*      */   {
/* 2578 */     loggerExternal.entering(getClassNameLogging(), "getBlob", paramString);
/* 2579 */     checkClosed();
/* 2580 */     Blob localBlob = (Blob)getValue(findColumn(paramString), JDBCType.BLOB);
/* 2581 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", localBlob);
/* 2582 */     return localBlob;
/*      */   }
/*      */ 
/*      */   public Clob getClob(int paramInt) throws SQLServerException
/*      */   {
/* 2587 */     loggerExternal.entering(getClassNameLogging(), "getClob", Integer.valueOf(paramInt));
/* 2588 */     checkClosed();
/* 2589 */     Clob localClob = (Clob)getValue(paramInt, JDBCType.CLOB);
/* 2590 */     loggerExternal.exiting(getClassNameLogging(), "getClob", localClob);
/* 2591 */     return localClob;
/*      */   }
/*      */ 
/*      */   public Clob getClob(String paramString) throws SQLServerException
/*      */   {
/* 2596 */     loggerExternal.entering(getClassNameLogging(), "getClob", paramString);
/* 2597 */     checkClosed();
/* 2598 */     Clob localClob = (Clob)getValue(findColumn(paramString), JDBCType.CLOB);
/* 2599 */     loggerExternal.exiting(getClassNameLogging(), "getClob", localClob);
/* 2600 */     return localClob;
/*      */   }
/*      */ 
/*      */   public NClob getNClob(int paramInt) throws SQLException
/*      */   {
/* 2605 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2606 */     loggerExternal.entering(getClassNameLogging(), "getNClob", Integer.valueOf(paramInt));
/* 2607 */     checkClosed();
/* 2608 */     NClob localNClob = (NClob)getValue(paramInt, JDBCType.NCLOB);
/* 2609 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", localNClob);
/* 2610 */     return localNClob;
/*      */   }
/*      */ 
/*      */   public NClob getNClob(String paramString) throws SQLException
/*      */   {
/* 2615 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2616 */     loggerExternal.entering(getClassNameLogging(), "getNClob", paramString);
/* 2617 */     checkClosed();
/* 2618 */     NClob localNClob = (NClob)getValue(findColumn(paramString), JDBCType.NCLOB);
/* 2619 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", localNClob);
/* 2620 */     return localNClob;
/*      */   }
/*      */ 
/*      */   public Array getArray(int paramInt) throws SQLServerException
/*      */   {
/* 2625 */     NotImplemented();
/* 2626 */     return null;
/*      */   }
/*      */ 
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLServerException
/*      */   {
/* 2631 */     NotImplemented();
/* 2632 */     return null;
/*      */   }
/*      */ 
/*      */   public Ref getRef(String paramString) throws SQLServerException
/*      */   {
/* 2637 */     NotImplemented();
/* 2638 */     return null;
/*      */   }
/*      */ 
/*      */   public Array getArray(String paramString) throws SQLServerException
/*      */   {
/* 2643 */     NotImplemented();
/* 2644 */     return null;
/*      */   }
/*      */ 
/*      */   public String getCursorName() throws SQLServerException
/*      */   {
/* 2649 */     loggerExternal.entering(getClassNameLogging(), "getCursorName");
/* 2650 */     SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_positionedUpdatesNotSupported"), null, false);
/* 2651 */     loggerExternal.exiting(getClassNameLogging(), "getCursorName", null);
/* 2652 */     return null;
/*      */   }
/*      */ 
/*      */   public Reader getCharacterStream(int paramInt) throws SQLServerException
/*      */   {
/* 2657 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", Integer.valueOf(paramInt));
/* 2658 */     checkClosed();
/* 2659 */     Reader localReader = (Reader)getStream(paramInt, StreamType.CHARACTER);
/* 2660 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", localReader);
/* 2661 */     return localReader;
/*      */   }
/*      */ 
/*      */   public Reader getCharacterStream(String paramString) throws SQLServerException
/*      */   {
/* 2666 */     checkClosed();
/* 2667 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", paramString);
/* 2668 */     Reader localReader = (Reader)getStream(findColumn(paramString), StreamType.CHARACTER);
/* 2669 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", localReader);
/* 2670 */     return localReader;
/*      */   }
/*      */ 
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException
/*      */   {
/* 2675 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2676 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", Integer.valueOf(paramInt));
/* 2677 */     checkClosed();
/* 2678 */     Reader localReader = (Reader)getStream(paramInt, StreamType.NCHARACTER);
/* 2679 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", localReader);
/* 2680 */     return localReader;
/*      */   }
/*      */ 
/*      */   public Reader getNCharacterStream(String paramString) throws SQLException
/*      */   {
/* 2685 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2686 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", paramString);
/* 2687 */     checkClosed();
/* 2688 */     Reader localReader = (Reader)getStream(findColumn(paramString), StreamType.NCHARACTER);
/* 2689 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", localReader);
/* 2690 */     return localReader;
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLServerException
/*      */   {
/* 2695 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", Integer.valueOf(paramInt));
/* 2696 */     checkClosed();
/* 2697 */     BigDecimal localBigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
/* 2698 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", localBigDecimal);
/* 2699 */     return localBigDecimal;
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLServerException
/*      */   {
/* 2704 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", paramString);
/* 2705 */     checkClosed();
/* 2706 */     BigDecimal localBigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/* 2707 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", localBigDecimal);
/* 2708 */     return localBigDecimal;
/*      */   }
/*      */ 
/*      */   public RowId getRowId(int paramInt) throws SQLException
/*      */   {
/* 2713 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 2716 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public RowId getRowId(String paramString) throws SQLException
/*      */   {
/* 2721 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 2724 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException
/*      */   {
/* 2729 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2730 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", Integer.valueOf(paramInt));
/* 2731 */     SQLXML localSQLXML = getSQLXMLInternal(paramInt);
/* 2732 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", localSQLXML);
/* 2733 */     return localSQLXML;
/*      */   }
/*      */ 
/*      */   public SQLXML getSQLXML(String paramString) throws SQLException
/*      */   {
/* 2738 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2739 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", paramString);
/* 2740 */     SQLXML localSQLXML = getSQLXMLInternal(findColumn(paramString));
/* 2741 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", localSQLXML);
/* 2742 */     return localSQLXML;
/*      */   }
/*      */ 
/*      */   public boolean rowUpdated() throws SQLServerException
/*      */   {
/* 2747 */     loggerExternal.entering(getClassNameLogging(), "rowUpdated");
/* 2748 */     checkClosed();
/*      */ 
/* 2751 */     verifyResultSetIsUpdatable();
/*      */ 
/* 2755 */     loggerExternal.exiting(getClassNameLogging(), "rowUpdated", Boolean.valueOf(false));
/* 2756 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean rowInserted() throws SQLServerException
/*      */   {
/* 2761 */     loggerExternal.entering(getClassNameLogging(), "rowInserted");
/* 2762 */     checkClosed();
/*      */ 
/* 2766 */     verifyResultSetIsUpdatable();
/*      */ 
/* 2770 */     loggerExternal.exiting(getClassNameLogging(), "rowInserted", Boolean.valueOf(false));
/* 2771 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean rowDeleted() throws SQLServerException
/*      */   {
/* 2776 */     loggerExternal.entering(getClassNameLogging(), "rowDeleted");
/* 2777 */     checkClosed();
/*      */ 
/* 2781 */     verifyResultSetIsUpdatable();
/*      */ 
/* 2783 */     if ((this.isOnInsertRow) || (!hasCurrentRow())) {
/* 2784 */       return false;
/*      */     }
/* 2786 */     boolean bool = currentRowDeleted();
/* 2787 */     loggerExternal.exiting(getClassNameLogging(), "rowDeleted", Boolean.valueOf(bool));
/* 2788 */     return bool;
/*      */   }
/*      */ 
/*      */   private final boolean currentRowDeleted()
/*      */     throws SQLServerException
/*      */   {
/* 2801 */     assert (hasCurrentRow());
/*      */ 
/* 2804 */     assert (null != this.tdsReader);
/*      */ 
/* 2806 */     return (this.deletedCurrentRow) || ((0 != this.serverCursorId) && (2 == loadColumn(this.columns.length).getInt(this.tdsReader)));
/*      */   }
/*      */ 
/*      */   private final Column updaterGetColumn(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2823 */     verifyResultSetIsUpdatable();
/*      */ 
/* 2825 */     verifyValidColumnIndex(paramInt);
/*      */ 
/* 2828 */     if (!this.columns[(paramInt - 1)].isUpdatable())
/*      */     {
/* 2830 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_cantUpdateColumn"), "07009", false);
/*      */     }
/*      */ 
/* 2840 */     if (!this.isOnInsertRow)
/*      */     {
/* 2846 */       if (!hasCurrentRow())
/*      */       {
/* 2848 */         SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_resultsetNoCurrentRow"), null, true);
/*      */       }
/*      */ 
/* 2858 */       verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */     }
/*      */ 
/* 2861 */     return getColumn(paramInt);
/*      */   }
/*      */ 
/*      */   private void updateValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType)
/*      */     throws SQLServerException
/*      */   {
/* 2870 */     updaterGetColumn(paramInt).updateValue(paramJDBCType, paramObject, paramJavaType, null, null, null, this.stmt.connection);
/*      */   }
/*      */ 
/*      */   private void updateValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Calendar paramCalendar)
/*      */     throws SQLServerException
/*      */   {
/* 2887 */     updaterGetColumn(paramInt).updateValue(paramJDBCType, paramObject, paramJavaType, null, paramCalendar, null, this.stmt.connection);
/*      */   }
/*      */ 
/*      */   private void updateStream(int paramInt, StreamType paramStreamType, Object paramObject, JavaType paramJavaType, long paramLong)
/*      */     throws SQLServerException
/*      */   {
/* 2904 */     updaterGetColumn(paramInt).updateValue(paramStreamType.getJDBCType(), paramObject, paramJavaType, new StreamSetterArgs(paramStreamType, paramLong), null, null, this.stmt.connection);
/*      */   }
/*      */ 
/*      */   private final void updateSQLXMLInternal(int paramInt, SQLXML paramSQLXML)
/*      */     throws SQLServerException
/*      */   {
/* 2916 */     updaterGetColumn(paramInt).updateValue(JDBCType.SQLXML, paramSQLXML, JavaType.SQLXML, new StreamSetterArgs(StreamType.SQLXML, -1L), null, null, this.stmt.connection);
/*      */   }
/*      */ 
/*      */   public void updateNull(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2928 */     loggerExternal.entering(getClassNameLogging(), "updateNull", Integer.valueOf(paramInt));
/*      */ 
/* 2930 */     checkClosed();
/* 2931 */     updateValue(paramInt, updaterGetColumn(paramInt).getTypeInfo().getSSType().getJDBCType(), null, JavaType.OBJECT);
/*      */ 
/* 2937 */     loggerExternal.exiting(getClassNameLogging(), "updateNull");
/*      */   }
/*      */ 
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean) throws SQLServerException
/*      */   {
/* 2942 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2943 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/* 2944 */     checkClosed();
/* 2945 */     updateValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN);
/*      */ 
/* 2951 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   public void updateByte(int paramInt, byte paramByte) throws SQLServerException
/*      */   {
/* 2956 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2957 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte) });
/*      */     }
/* 2959 */     checkClosed();
/* 2960 */     updateValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE);
/*      */ 
/* 2966 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   public void updateShort(int paramInt, short paramShort) throws SQLServerException
/*      */   {
/* 2971 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2972 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort) });
/*      */     }
/* 2974 */     checkClosed();
/* 2975 */     updateValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT);
/*      */ 
/* 2981 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   public void updateInt(int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 2986 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2987 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/*      */     }
/* 2989 */     checkClosed();
/* 2990 */     updateValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER);
/*      */ 
/* 2996 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   public void updateLong(int paramInt, long paramLong) throws SQLServerException
/*      */   {
/* 3001 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3002 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong) });
/*      */     }
/* 3004 */     checkClosed();
/* 3005 */     updateValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG);
/*      */ 
/* 3011 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   public void updateFloat(int paramInt, float paramFloat) throws SQLServerException
/*      */   {
/* 3016 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3017 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat) });
/*      */     }
/* 3019 */     checkClosed();
/* 3020 */     updateValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT);
/*      */ 
/* 3026 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   public void updateDouble(int paramInt, double paramDouble) throws SQLServerException
/*      */   {
/* 3031 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3032 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble) });
/*      */     }
/* 3034 */     checkClosed();
/* 3035 */     updateValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE);
/*      */ 
/* 3041 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException
/*      */   {
/* 3046 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3047 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal });
/*      */     }
/* 3049 */     checkClosed();
/* 3050 */     updateValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL);
/*      */ 
/* 3056 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   public void updateString(int paramInt, String paramString) throws SQLServerException
/*      */   {
/* 3061 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3062 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { Integer.valueOf(paramInt), paramString });
/*      */     }
/* 3064 */     checkClosed();
/* 3065 */     updateValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING);
/*      */ 
/* 3071 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   public void updateNString(int paramInt, String paramString) throws SQLException
/*      */   {
/* 3076 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3077 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { Integer.valueOf(paramInt), paramString });
/*      */     }
/* 3079 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3080 */     checkClosed();
/* 3081 */     updateValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING);
/*      */ 
/* 3087 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   public void updateNString(String paramString1, String paramString2) throws SQLException
/*      */   {
/* 3092 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3093 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { paramString1, paramString2 });
/*      */     }
/* 3095 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3096 */     checkClosed();
/* 3097 */     updateValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING);
/*      */ 
/* 3103 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfByte) throws SQLServerException
/*      */   {
/* 3108 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3109 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfByte });
/*      */     }
/* 3111 */     checkClosed();
/* 3112 */     updateValue(paramInt, JDBCType.BINARY, paramArrayOfByte, JavaType.BYTEARRAY);
/*      */ 
/* 3118 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   public void updateDate(int paramInt, Date paramDate) throws SQLServerException
/*      */   {
/* 3123 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3124 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { Integer.valueOf(paramInt), paramDate });
/*      */     }
/* 3126 */     checkClosed();
/* 3127 */     updateValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE);
/*      */ 
/* 3133 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   public void updateTime(int paramInt, Time paramTime) throws SQLServerException
/*      */   {
/* 3138 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3139 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(paramInt), paramTime });
/*      */     }
/* 3141 */     checkClosed();
/* 3142 */     updateValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME);
/*      */ 
/* 3148 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLServerException
/*      */   {
/* 3153 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3154 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp });
/*      */     }
/* 3156 */     checkClosed();
/* 3157 */     updateValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP);
/*      */ 
/* 3163 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   public void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLException
/*      */   {
/* 3168 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3169 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset });
/*      */     }
/* 3171 */     checkClosed();
/* 3172 */     updateValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET);
/*      */ 
/* 3178 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException
/*      */   {
/* 3183 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3184 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3185 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream });
/*      */     }
/* 3187 */     checkClosed();
/* 3188 */     updateStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/* 3195 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLServerException
/*      */   {
/* 3200 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3201 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) });
/*      */     }
/* 3203 */     checkClosed();
/* 3204 */     updateStream(paramInt1, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
/*      */ 
/* 3211 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 3216 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3217 */     loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
/*      */ 
/* 3219 */     checkClosed();
/* 3220 */     updateStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/* 3227 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream) throws SQLException
/*      */   {
/* 3232 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3233 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3234 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { paramString, paramInputStream });
/*      */     }
/* 3236 */     checkClosed();
/* 3237 */     updateStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/* 3244 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLServerException
/*      */   {
/* 3249 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3250 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) });
/*      */     }
/* 3252 */     checkClosed();
/* 3253 */     updateStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt);
/*      */ 
/* 3260 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 3265 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3266 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3267 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 3269 */     checkClosed();
/* 3270 */     updateStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/* 3277 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException
/*      */   {
/* 3282 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3283 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3284 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(paramInt), paramInputStream });
/*      */     }
/* 3286 */     checkClosed();
/* 3287 */     updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/* 3294 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException
/*      */   {
/* 3299 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3300 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) });
/*      */     }
/* 3302 */     checkClosed();
/* 3303 */     updateStream(paramInt1, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
/*      */ 
/* 3310 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 3315 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3316 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3317 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 3319 */     checkClosed();
/* 3320 */     updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/* 3327 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream) throws SQLException
/*      */   {
/* 3332 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3333 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3334 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { paramString, paramInputStream });
/*      */     }
/* 3336 */     checkClosed();
/* 3337 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/* 3344 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException
/*      */   {
/* 3349 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3350 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) });
/*      */     }
/* 3352 */     checkClosed();
/* 3353 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt);
/*      */ 
/* 3360 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 3365 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3366 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3367 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 3369 */     checkClosed();
/* 3370 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/* 3377 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader) throws SQLException
/*      */   {
/* 3382 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3383 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3384 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader });
/*      */     }
/* 3386 */     checkClosed();
/* 3387 */     updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/* 3394 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLServerException
/*      */   {
/* 3399 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3400 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(paramInt1), paramReader, Integer.valueOf(paramInt2) });
/*      */     }
/* 3402 */     checkClosed();
/* 3403 */     updateStream(paramInt1, StreamType.CHARACTER, paramReader, JavaType.READER, paramInt2);
/*      */ 
/* 3410 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 3415 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3416 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3417 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 3419 */     checkClosed();
/* 3420 */     updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/* 3427 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(String paramString, Reader paramReader) throws SQLException
/*      */   {
/* 3432 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3433 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3434 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { paramString, paramReader });
/*      */     }
/* 3436 */     checkClosed();
/* 3437 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/* 3444 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLServerException
/*      */   {
/* 3449 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3450 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { paramString, paramReader, Integer.valueOf(paramInt) });
/*      */     }
/* 3452 */     checkClosed();
/* 3453 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramInt);
/*      */ 
/* 3460 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 3465 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3466 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3467 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 3469 */     checkClosed();
/* 3470 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/* 3477 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader) throws SQLException
/*      */   {
/* 3482 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3483 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3484 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader });
/*      */     }
/* 3486 */     checkClosed();
/* 3487 */     updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/* 3494 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 3499 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3500 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3501 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 3503 */     checkClosed();
/* 3504 */     updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/* 3511 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateNCharacterStream(String paramString, Reader paramReader) throws SQLException
/*      */   {
/* 3516 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3517 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3518 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { paramString, paramReader });
/*      */     }
/* 3520 */     checkClosed();
/* 3521 */     updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/* 3528 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 3533 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3534 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3535 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 3537 */     checkClosed();
/* 3538 */     updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/* 3545 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   public void updateObject(int paramInt, Object paramObject) throws SQLServerException
/*      */   {
/* 3550 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3551 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt), paramObject });
/*      */     }
/* 3553 */     checkClosed();
/* 3554 */     updateObject(paramInt, paramObject, null);
/*      */ 
/* 3556 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLServerException
/*      */   {
/* 3561 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3562 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2) });
/*      */     }
/* 3564 */     checkClosed();
/* 3565 */     updateObject(paramInt1, paramObject, new Integer(paramInt2));
/*      */ 
/* 3567 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   private final void updateObject(int paramInt, Object paramObject, Integer paramInteger) throws SQLServerException
/*      */   {
/* 3572 */     Column localColumn = updaterGetColumn(paramInt);
/* 3573 */     SSType localSSType = localColumn.getTypeInfo().getSSType();
/*      */ 
/* 3575 */     if (null == paramObject)
/*      */     {
/* 3577 */       localColumn.updateValue(localSSType.getJDBCType(), paramObject, JavaType.OBJECT, null, null, paramInteger, this.stmt.connection);
/*      */     }
/*      */     else
/*      */     {
/* 3588 */       JavaType localJavaType = JavaType.of(paramObject);
/* 3589 */       JDBCType localJDBCType = localJavaType.getJDBCType(localSSType, localSSType.getJDBCType());
/*      */ 
/* 3591 */       StreamSetterArgs localStreamSetterArgs = null;
/* 3592 */       switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$JavaType[localJavaType.ordinal()])
/*      */       {
/*      */       case 1:
/* 3595 */         localStreamSetterArgs = new StreamSetterArgs(StreamType.CHARACTER, -1L);
/*      */ 
/* 3598 */         break;
/*      */       case 2:
/* 3601 */         localStreamSetterArgs = new StreamSetterArgs(localJDBCType.isTextual() ? StreamType.CHARACTER : StreamType.BINARY, -1L);
/*      */ 
/* 3604 */         break;
/*      */       case 3:
/* 3607 */         localStreamSetterArgs = new StreamSetterArgs(StreamType.SQLXML, -1L);
/*      */       }
/*      */ 
/* 3613 */       localColumn.updateValue(localJDBCType, paramObject, localJavaType, localStreamSetterArgs, null, paramInteger, this.stmt.connection);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateNull(String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 3626 */     loggerExternal.entering(getClassNameLogging(), "updateNull", paramString);
/*      */ 
/* 3628 */     checkClosed();
/* 3629 */     int i = findColumn(paramString);
/* 3630 */     updateValue(i, updaterGetColumn(i).getTypeInfo().getSSType().getJDBCType(), null, JavaType.OBJECT);
/*      */ 
/* 3636 */     loggerExternal.exiting(getClassNameLogging(), "updateNull");
/*      */   }
/*      */ 
/*      */   public void updateBoolean(String paramString, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3642 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3643 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3645 */     checkClosed();
/* 3646 */     updateValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN);
/*      */ 
/* 3652 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   public void updateByte(String paramString, byte paramByte) throws SQLServerException
/*      */   {
/* 3657 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3658 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { paramString, Byte.valueOf(paramByte) });
/*      */     }
/* 3660 */     checkClosed();
/* 3661 */     updateValue(findColumn(paramString), JDBCType.BINARY, Byte.valueOf(paramByte), JavaType.BYTE);
/*      */ 
/* 3667 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   public void updateShort(String paramString, short paramShort) throws SQLServerException
/*      */   {
/* 3672 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3673 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { paramString, Short.valueOf(paramShort) });
/*      */     }
/* 3675 */     checkClosed();
/* 3676 */     updateValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT);
/*      */ 
/* 3682 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   public void updateInt(String paramString, int paramInt) throws SQLServerException
/*      */   {
/* 3687 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3688 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { paramString, Integer.valueOf(paramInt) });
/*      */     }
/* 3690 */     checkClosed();
/* 3691 */     updateValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER);
/*      */ 
/* 3697 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   public void updateLong(String paramString, long paramLong) throws SQLServerException
/*      */   {
/* 3702 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3703 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { paramString, Long.valueOf(paramLong) });
/*      */     }
/* 3705 */     checkClosed();
/* 3706 */     updateValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG);
/*      */ 
/* 3712 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   public void updateFloat(String paramString, float paramFloat) throws SQLServerException
/*      */   {
/* 3717 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3718 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { paramString, Float.valueOf(paramFloat) });
/*      */     }
/* 3720 */     checkClosed();
/* 3721 */     updateValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT);
/*      */ 
/* 3727 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   public void updateDouble(String paramString, double paramDouble) throws SQLServerException
/*      */   {
/* 3732 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3733 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { paramString, Double.valueOf(paramDouble) });
/*      */     }
/* 3735 */     checkClosed();
/* 3736 */     updateValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE);
/*      */ 
/* 3742 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLServerException
/*      */   {
/* 3747 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3748 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { paramString, paramBigDecimal });
/*      */     }
/* 3750 */     checkClosed();
/* 3751 */     updateValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL);
/*      */ 
/* 3757 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   public void updateString(String paramString1, String paramString2) throws SQLServerException
/*      */   {
/* 3762 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3763 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { paramString1, paramString2 });
/*      */     }
/* 3765 */     checkClosed();
/* 3766 */     updateValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING);
/*      */ 
/* 3772 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   public void updateBytes(String paramString, byte[] paramArrayOfByte) throws SQLServerException
/*      */   {
/* 3777 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3778 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { paramString, paramArrayOfByte });
/*      */     }
/* 3780 */     checkClosed();
/* 3781 */     updateValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfByte, JavaType.BYTEARRAY);
/*      */ 
/* 3787 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   public void updateDate(String paramString, Date paramDate) throws SQLServerException
/*      */   {
/* 3792 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3793 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { paramString, paramDate });
/*      */     }
/* 3795 */     checkClosed();
/* 3796 */     updateValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE);
/*      */ 
/* 3802 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   public void updateTime(String paramString, Time paramTime) throws SQLServerException
/*      */   {
/* 3807 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3808 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { paramString, paramTime });
/*      */     }
/* 3810 */     checkClosed();
/* 3811 */     updateValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME);
/*      */ 
/* 3817 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   public void updateTimestamp(String paramString, Timestamp paramTimestamp) throws SQLServerException
/*      */   {
/* 3822 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3823 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { paramString, paramTimestamp });
/*      */     }
/* 3825 */     checkClosed();
/* 3826 */     updateValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP);
/*      */ 
/* 3832 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   public void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset) throws SQLException
/*      */   {
/* 3837 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3838 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { paramString, paramDateTimeOffset });
/*      */     }
/* 3840 */     checkClosed();
/* 3841 */     updateValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET);
/*      */ 
/* 3847 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   public void updateObject(String paramString, Object paramObject, int paramInt) throws SQLServerException
/*      */   {
/* 3852 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3853 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt) });
/*      */     }
/* 3855 */     checkClosed();
/* 3856 */     updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt));
/*      */ 
/* 3861 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   public void updateObject(String paramString, Object paramObject) throws SQLServerException
/*      */   {
/* 3866 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3867 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject });
/*      */     }
/* 3869 */     checkClosed();
/* 3870 */     updateObject(findColumn(paramString), paramObject, null);
/*      */ 
/* 3875 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   public void updateRowId(int paramInt, RowId paramRowId) throws SQLException
/*      */   {
/* 3880 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 3883 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public void updateRowId(String paramString, RowId paramRowId) throws SQLException
/*      */   {
/* 3888 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 3891 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public void updateSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException
/*      */   {
/* 3896 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3897 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3898 */       loggerExternal.entering(getClassNameLogging(), "updateSQLXML", new Object[] { Integer.valueOf(paramInt), paramSQLXML });
/* 3899 */     updateSQLXMLInternal(paramInt, paramSQLXML);
/* 3900 */     loggerExternal.exiting(getClassNameLogging(), "updateSQLXML");
/*      */   }
/*      */ 
/*      */   public void updateSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException
/*      */   {
/* 3905 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3906 */       loggerExternal.entering(getClassNameLogging(), "updateSQLXML", new Object[] { paramString, paramSQLXML });
/* 3907 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3908 */     updateSQLXMLInternal(findColumn(paramString), paramSQLXML);
/* 3909 */     loggerExternal.exiting(getClassNameLogging(), "updateSQLXML");
/*      */   }
/*      */ 
/*      */   public int getHoldability() throws SQLException
/*      */   {
/* 3914 */     loggerExternal.entering(getClassNameLogging(), "getHoldability");
/*      */ 
/* 3916 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3917 */     checkClosed();
/*      */ 
/* 3919 */     int i = 0 == this.stmt.getServerCursorId() ? 1 : this.stmt.getExecProps().getHoldability();
/*      */ 
/* 3930 */     loggerExternal.exiting(getClassNameLogging(), "getHoldability", Integer.valueOf(i));
/*      */ 
/* 3932 */     return i;
/*      */   }
/*      */ 
/*      */   public void insertRow()
/*      */     throws SQLServerException
/*      */   {
/* 3939 */     loggerExternal.entering(getClassNameLogging(), "insertRow");
/* 3940 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 3942 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */ 
/* 3962 */     if (logger.isLoggable(Level.FINER)) {
/* 3963 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 3965 */     checkClosed();
/*      */ 
/* 3969 */     verifyResultSetIsUpdatable();
/*      */ 
/* 3971 */     if (!this.isOnInsertRow)
/*      */     {
/* 3973 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_mustBeOnInsertRow"), null, true);
/*      */     }
/*      */ 
/* 3996 */     Column localColumn = null;
/* 3997 */     for (int i = 0; i < this.columns.length; i++)
/*      */     {
/* 3999 */       if (this.columns[i].hasUpdates())
/*      */       {
/* 4001 */         localColumn = this.columns[i];
/* 4002 */         break;
/*      */       }
/*      */ 
/* 4005 */       if ((null == localColumn) && (this.columns[i].isUpdatable())) {
/* 4006 */         localColumn = this.columns[i];
/*      */       }
/*      */     }
/* 4009 */     if (null == localColumn)
/*      */     {
/* 4011 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_noColumnParameterValue"), null, true);
/*      */     }
/*      */ 
/* 4019 */     assert (localColumn.isUpdatable());
/* 4020 */     assert (null != localColumn.getTableName());
/*      */ 
/* 4022 */     this.stmt.executeCommand(new TDSCommand(localColumn.getTableName().asEscapedString())
/*      */     {
/*      */       final String tableName;
/*      */ 
/*      */       final boolean doExecute()
/*      */         throws SQLServerException
/*      */       {
/* 3957 */         SQLServerResultSet.this.doInsertRowRPC(this, this.tableName);
/* 3958 */         return true;
/*      */       }
/*      */     });
/* 4024 */     if (-3 != this.rowCount)
/* 4025 */       this.rowCount += 1;
/* 4026 */     loggerExternal.exiting(getClassNameLogging(), "insertRow");
/*      */   }
/*      */ 
/*      */   private final void doInsertRowRPC(TDSCommand paramTDSCommand, String paramString) throws SQLServerException
/*      */   {
/* 4031 */     assert (0 != this.serverCursorId);
/* 4032 */     assert (null != paramString);
/* 4033 */     assert (paramString.length() > 0);
/*      */ 
/* 4035 */     TDSWriter localTDSWriter = paramTDSCommand.startRequest(3);
/* 4036 */     localTDSWriter.writeShort(-1);
/* 4037 */     localTDSWriter.writeShort(1);
/* 4038 */     localTDSWriter.writeByte(0);
/* 4039 */     localTDSWriter.writeByte(0);
/* 4040 */     localTDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
/* 4041 */     localTDSWriter.writeRPCInt(null, new Integer(4), false);
/* 4042 */     localTDSWriter.writeRPCInt(null, new Integer(fetchBufferGetRow()), false);
/*      */ 
/* 4044 */     if (hasUpdatedColumns())
/*      */     {
/* 4046 */       localTDSWriter.writeRPCStringUnicode(paramString);
/*      */ 
/* 4048 */       for (int i = 0; i < this.columns.length; i++)
/* 4049 */         this.columns[i].sendByRPC(localTDSWriter, this.stmt.connection);
/*      */     }
/*      */     else
/*      */     {
/* 4053 */       localTDSWriter.writeRPCStringUnicode("");
/* 4054 */       localTDSWriter.writeRPCStringUnicode("INSERT INTO " + paramString + " DEFAULT VALUES");
/*      */     }
/*      */ 
/* 4057 */     TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
/*      */   }
/*      */ 
/*      */   public void updateRow()
/*      */     throws SQLServerException
/*      */   {
/* 4063 */     loggerExternal.entering(getClassNameLogging(), "updateRow");
/* 4064 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 4066 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */ 
/* 4082 */     if (logger.isLoggable(Level.FINER)) {
/* 4083 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 4085 */     checkClosed();
/*      */ 
/* 4089 */     verifyResultSetIsUpdatable();
/*      */ 
/* 4094 */     verifyResultSetIsNotOnInsertRow();
/* 4095 */     verifyResultSetHasCurrentRow();
/*      */ 
/* 4098 */     verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */ 
/* 4100 */     if (!hasUpdatedColumns())
/*      */     {
/* 4102 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_noColumnParameterValue"), null, true);
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 4113 */       this.stmt.executeCommand(new TDSCommand()
/*      */       {
/*      */         final boolean doExecute()
/*      */           throws SQLServerException
/*      */         {
/* 4077 */           SQLServerResultSet.this.doUpdateRowRPC(this);
/* 4078 */           return true;
/*      */         }
/*      */ 
/*      */       });
/*      */     }
/*      */     finally
/*      */     {
/* 4117 */       cancelUpdates();
/*      */     }
/*      */ 
/* 4120 */     this.updatedCurrentRow = true;
/* 4121 */     loggerExternal.exiting(getClassNameLogging(), "updateRow");
/*      */   }
/*      */ 
/*      */   private final void doUpdateRowRPC(TDSCommand paramTDSCommand) throws SQLServerException
/*      */   {
/* 4126 */     assert (0 != this.serverCursorId);
/*      */ 
/* 4128 */     TDSWriter localTDSWriter = paramTDSCommand.startRequest(3);
/* 4129 */     localTDSWriter.writeShort(-1);
/* 4130 */     localTDSWriter.writeShort(1);
/* 4131 */     localTDSWriter.writeByte(0);
/* 4132 */     localTDSWriter.writeByte(0);
/* 4133 */     localTDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
/* 4134 */     localTDSWriter.writeRPCInt(null, new Integer(33), false);
/* 4135 */     localTDSWriter.writeRPCInt(null, new Integer(fetchBufferGetRow()), false);
/* 4136 */     localTDSWriter.writeRPCStringUnicode("");
/*      */ 
/* 4138 */     assert (hasUpdatedColumns());
/*      */ 
/* 4140 */     for (int i = 0; i < this.columns.length; i++) {
/* 4141 */       this.columns[i].sendByRPC(localTDSWriter, this.stmt.connection);
/*      */     }
/* 4143 */     TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
/*      */   }
/*      */ 
/*      */   final boolean hasUpdatedColumns()
/*      */   {
/* 4149 */     for (int i = 0; i < this.columns.length; i++) {
/* 4150 */       if (this.columns[i].hasUpdates())
/* 4151 */         return true;
/*      */     }
/* 4153 */     return false;
/*      */   }
/*      */ 
/*      */   public void deleteRow() throws SQLServerException
/*      */   {
/* 4158 */     loggerExternal.entering(getClassNameLogging(), "deleteRow");
/* 4159 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 4161 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */ 
/* 4177 */     if (logger.isLoggable(Level.FINER)) {
/* 4178 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 4180 */     checkClosed();
/*      */ 
/* 4184 */     verifyResultSetIsUpdatable();
/*      */ 
/* 4187 */     verifyResultSetIsNotOnInsertRow();
/* 4188 */     verifyResultSetHasCurrentRow();
/*      */ 
/* 4191 */     verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */     try
/*      */     {
/* 4195 */       this.stmt.executeCommand(new TDSCommand()
/*      */       {
/*      */         final boolean doExecute()
/*      */           throws SQLServerException
/*      */         {
/* 4172 */           SQLServerResultSet.this.doDeleteRowRPC(this);
/* 4173 */           return true;
/*      */         }
/*      */ 
/*      */       });
/*      */     }
/*      */     finally
/*      */     {
/* 4199 */       cancelUpdates();
/*      */     }
/*      */ 
/* 4202 */     this.deletedCurrentRow = true;
/* 4203 */     loggerExternal.exiting(getClassNameLogging(), "deleteRow");
/*      */   }
/*      */ 
/*      */   private final void doDeleteRowRPC(TDSCommand paramTDSCommand) throws SQLServerException
/*      */   {
/* 4208 */     assert (0 != this.serverCursorId);
/*      */ 
/* 4210 */     TDSWriter localTDSWriter = paramTDSCommand.startRequest(3);
/* 4211 */     localTDSWriter.writeShort(-1);
/* 4212 */     localTDSWriter.writeShort(1);
/* 4213 */     localTDSWriter.writeByte(0);
/* 4214 */     localTDSWriter.writeByte(0);
/* 4215 */     localTDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
/* 4216 */     localTDSWriter.writeRPCInt(null, new Integer(34), false);
/* 4217 */     localTDSWriter.writeRPCInt(null, new Integer(fetchBufferGetRow()), false);
/* 4218 */     localTDSWriter.writeRPCStringUnicode("");
/*      */ 
/* 4220 */     TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
/*      */   }
/*      */ 
/*      */   public void refreshRow() throws SQLServerException
/*      */   {
/* 4225 */     loggerExternal.entering(getClassNameLogging(), "refreshRow");
/* 4226 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 4228 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */ 
/* 4231 */     if (logger.isLoggable(Level.FINER)) {
/* 4232 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 4234 */     checkClosed();
/*      */ 
/* 4238 */     verifyResultSetIsScrollable();
/*      */ 
/* 4242 */     verifyResultSetIsUpdatable();
/*      */ 
/* 4246 */     verifyResultSetIsNotOnInsertRow();
/*      */ 
/* 4249 */     verifyResultSetHasCurrentRow();
/* 4250 */     verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */ 
/* 4257 */     if ((1004 == this.stmt.getResultSetType()) || (0 == this.serverCursorId)) {
/* 4258 */       return;
/*      */     }
/*      */ 
/* 4263 */     cancelUpdates();
/*      */ 
/* 4265 */     doRefreshRow();
/* 4266 */     loggerExternal.exiting(getClassNameLogging(), "refreshRow");
/*      */   }
/*      */ 
/*      */   private void doRefreshRow() throws SQLServerException
/*      */   {
/* 4271 */     assert (hasCurrentRow());
/*      */ 
/* 4275 */     int i = fetchBufferGetRow();
/*      */ 
/* 4279 */     doServerFetch(128, 0, 0);
/*      */ 
/* 4285 */     int j = 0;
/* 4286 */     while ((j < i) && (isForwardOnly() ? fetchBufferNext() : this.scrollWindow.next(this)))
/*      */     {
/* 4289 */       j++;
/*      */     }
/*      */ 
/* 4292 */     if (j < i)
/*      */     {
/* 4294 */       this.currentRow = -1;
/* 4295 */       return;
/*      */     }
/*      */ 
/* 4300 */     this.updatedCurrentRow = false;
/*      */   }
/*      */ 
/*      */   private final void cancelUpdates()
/*      */   {
/* 4305 */     if (!this.isOnInsertRow)
/* 4306 */       clearColumnsValues();
/*      */   }
/*      */ 
/*      */   public void cancelRowUpdates() throws SQLServerException
/*      */   {
/* 4311 */     loggerExternal.entering(getClassNameLogging(), "cancelRowUpdates");
/* 4312 */     checkClosed();
/*      */ 
/* 4317 */     verifyResultSetIsUpdatable();
/* 4318 */     verifyResultSetIsNotOnInsertRow();
/*      */ 
/* 4320 */     cancelUpdates();
/* 4321 */     loggerExternal.exiting(getClassNameLogging(), "cancelRowUpdates");
/*      */   }
/*      */ 
/*      */   public void moveToInsertRow() throws SQLServerException
/*      */   {
/* 4326 */     loggerExternal.entering(getClassNameLogging(), "moveToInsertRow");
/* 4327 */     if (logger.isLoggable(Level.FINER)) {
/* 4328 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 4330 */     checkClosed();
/*      */ 
/* 4334 */     verifyResultSetIsUpdatable();
/*      */ 
/* 4336 */     cancelUpdates();
/* 4337 */     this.isOnInsertRow = true;
/* 4338 */     loggerExternal.exiting(getClassNameLogging(), "moveToInsertRow");
/*      */   }
/*      */ 
/*      */   public void moveToCurrentRow() throws SQLServerException
/*      */   {
/* 4343 */     loggerExternal.entering(getClassNameLogging(), "moveToCurrentRow");
/* 4344 */     if (logger.isLoggable(Level.FINER)) {
/* 4345 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 4347 */     checkClosed();
/*      */ 
/* 4351 */     verifyResultSetIsUpdatable();
/*      */ 
/* 4357 */     cancelInsert();
/* 4358 */     loggerExternal.exiting(getClassNameLogging(), "moveToCurrentRow");
/*      */   }
/*      */ 
/*      */   public Statement getStatement()
/*      */     throws SQLServerException
/*      */   {
/* 4364 */     loggerExternal.entering(getClassNameLogging(), "getStatement");
/* 4365 */     checkClosed();
/* 4366 */     loggerExternal.exiting(getClassNameLogging(), "getStatement", this.stmt);
/* 4367 */     return this.stmt;
/*      */   }
/*      */ 
/*      */   public void updateClob(int paramInt, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 4374 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4375 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramClob });
/*      */     }
/* 4377 */     checkClosed();
/* 4378 */     updateValue(paramInt, JDBCType.CLOB, paramClob, JavaType.CLOB);
/*      */ 
/* 4384 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   public void updateClob(int paramInt, Reader paramReader) throws SQLException
/*      */   {
/* 4389 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4390 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4391 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramReader });
/*      */     }
/* 4393 */     checkClosed();
/* 4394 */     updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/* 4401 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   public void updateClob(int paramInt, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 4406 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4407 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4408 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 4410 */     checkClosed();
/* 4411 */     updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/* 4418 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   public void updateClob(String paramString, Clob paramClob) throws SQLException
/*      */   {
/* 4423 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4424 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { paramString, paramClob });
/*      */     }
/* 4426 */     checkClosed();
/* 4427 */     updateValue(findColumn(paramString), JDBCType.CLOB, paramClob, JavaType.CLOB);
/*      */ 
/* 4433 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   public void updateClob(String paramString, Reader paramReader) throws SQLException
/*      */   {
/* 4438 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4439 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4440 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { paramString, paramReader });
/*      */     }
/* 4442 */     checkClosed();
/* 4443 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/* 4450 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   public void updateClob(String paramString, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 4455 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4456 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4457 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 4459 */     checkClosed();
/* 4460 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/* 4467 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   public void updateNClob(int paramInt, NClob paramNClob) throws SQLException
/*      */   {
/* 4472 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4473 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4474 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramNClob });
/*      */     }
/* 4476 */     checkClosed();
/* 4477 */     updateValue(paramInt, JDBCType.NCLOB, paramNClob, JavaType.NCLOB);
/*      */ 
/* 4483 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   public void updateNClob(int paramInt, Reader paramReader) throws SQLException
/*      */   {
/* 4488 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4489 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4490 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { Integer.valueOf(paramInt), paramReader });
/*      */     }
/* 4492 */     checkClosed();
/* 4493 */     updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/* 4500 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   public void updateNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 4505 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4506 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4507 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 4509 */     checkClosed();
/* 4510 */     updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/* 4517 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   public void updateNClob(String paramString, NClob paramNClob) throws SQLException
/*      */   {
/* 4522 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4523 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4524 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { paramString, paramNClob });
/*      */     }
/* 4526 */     checkClosed();
/* 4527 */     updateValue(findColumn(paramString), JDBCType.NCLOB, paramNClob, JavaType.NCLOB);
/*      */ 
/* 4533 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   public void updateNClob(String paramString, Reader paramReader) throws SQLException
/*      */   {
/* 4538 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4539 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4540 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { paramString, paramReader });
/*      */     }
/* 4542 */     checkClosed();
/* 4543 */     updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/* 4550 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   public void updateNClob(String paramString, Reader paramReader, long paramLong) throws SQLException
/*      */   {
/* 4555 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4556 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4557 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 4559 */     checkClosed();
/* 4560 */     updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/* 4567 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   public void updateBlob(int paramInt, Blob paramBlob) throws SQLException
/*      */   {
/* 4572 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4573 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(paramInt), paramBlob });
/*      */     }
/* 4575 */     checkClosed();
/* 4576 */     updateValue(paramInt, JDBCType.BLOB, paramBlob, JavaType.BLOB);
/*      */ 
/* 4582 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream) throws SQLException
/*      */   {
/* 4587 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4588 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4589 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream });
/*      */     }
/* 4591 */     checkClosed();
/* 4592 */     updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/* 4599 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 4604 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4605 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4606 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 4608 */     checkClosed();
/* 4609 */     updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/* 4616 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   public void updateBlob(String paramString, Blob paramBlob) throws SQLException
/*      */   {
/* 4621 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4622 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { paramString, paramBlob });
/*      */     }
/* 4624 */     checkClosed();
/* 4625 */     updateValue(findColumn(paramString), JDBCType.BLOB, paramBlob, JavaType.BLOB);
/*      */ 
/* 4631 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   public void updateBlob(String paramString, InputStream paramInputStream) throws SQLException
/*      */   {
/* 4636 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4637 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4638 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { paramString, paramInputStream });
/*      */     }
/* 4640 */     checkClosed();
/* 4641 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/* 4648 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   public void updateBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException
/*      */   {
/* 4653 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4654 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4655 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 4657 */     checkClosed();
/* 4658 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/* 4665 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   public void updateArray(int paramInt, Array paramArray) throws SQLServerException {
/* 4669 */     this.stmt.NotImplemented();
/*      */   }
/*      */   public void updateArray(String paramString, Array paramArray) throws SQLServerException {
/* 4672 */     this.stmt.NotImplemented();
/*      */   }
/*      */   public void updateRef(int paramInt, Ref paramRef) throws SQLServerException {
/* 4675 */     this.stmt.NotImplemented();
/*      */   }
/*      */   public void updateRef(String paramString, Ref paramRef) throws SQLServerException {
/* 4678 */     this.stmt.NotImplemented();
/*      */   }
/*      */   public URL getURL(int paramInt) throws SQLServerException {
/* 4681 */     this.stmt.NotImplemented();
/* 4682 */     return null;
/*      */   }
/*      */   public URL getURL(String paramString) throws SQLServerException {
/* 4685 */     this.stmt.NotImplemented();
/* 4686 */     return null;
/*      */   }
/*      */ 
/*      */   final void doServerFetch(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLServerException
/*      */   {
/* 4929 */     if (logger.isLoggable(Level.FINER)) {
/* 4930 */       logger.finer(toString() + " fetchType:" + paramInt1 + " startRow:" + paramInt2 + " numRows:" + paramInt3);
/*      */     }
/*      */ 
/* 4933 */     discardFetchBuffer();
/*      */ 
/* 4936 */     this.fetchBuffer.init();
/*      */ 
/* 4939 */     CursorFetchCommand localCursorFetchCommand = new CursorFetchCommand(this.serverCursorId, paramInt1, paramInt2, paramInt3);
/* 4940 */     this.stmt.executeCommand(localCursorFetchCommand);
/*      */ 
/* 4942 */     this.numFetchedRows = 0;
/* 4943 */     this.resultSetCurrentRowType = RowType.UNKNOWN;
/* 4944 */     this.areNullCompressedColumnsInitialized = false;
/* 4945 */     this.lastColumnIndex = 0;
/*      */ 
/* 4948 */     if ((null != this.scrollWindow) && (128 != paramInt1)) {
/* 4949 */       this.scrollWindow.resize(this.fetchSize);
/*      */     }
/*      */ 
/* 4958 */     if ((paramInt3 < 0) || (paramInt2 < 0))
/*      */     {
/*      */       try
/*      */       {
/* 4963 */         while (this.scrollWindow.next(this));
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/* 4971 */         if (logger.isLoggable(Level.FINER)) {
/* 4972 */           logger.finer(toString() + " Ignored exception from row error during server cursor fixup: " + localSQLException.getMessage());
/*      */         }
/*      */       }
/*      */ 
/* 4976 */       if (this.fetchBuffer.needsServerCursorFixup())
/*      */       {
/* 4978 */         doServerFetch(1, 0, 0);
/* 4979 */         return;
/*      */       }
/*      */ 
/* 4983 */       this.scrollWindow.reset();
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void discardFetchBuffer()
/*      */   {
/* 5004 */     this.fetchBuffer.clearStartMark();
/*      */ 
/* 5007 */     if (null != this.scrollWindow) {
/* 5008 */       this.scrollWindow.clear();
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 5014 */       while (fetchBufferNext());
/*      */     }
/*      */     catch (SQLServerException localSQLServerException)
/*      */     {
/* 5019 */       if (logger.isLoggable(Level.FINER))
/* 5020 */         logger.finer(this + " Encountered exception discarding fetch buffer: " + localSQLServerException.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   final void closeServerCursor()
/*      */   {
/* 5031 */     if (0 == this.serverCursorId) {
/* 5032 */       return;
/*      */     }
/*      */ 
/* 5036 */     if (this.stmt.connection.isSessionUnAvailable())
/*      */     {
/* 5038 */       if (logger.isLoggable(Level.FINER))
/* 5039 */         logger.finer(this + ": Not closing cursor:" + this.serverCursorId + "; connection is already closed.");
/*      */     }
/*      */     else
/*      */     {
/* 5043 */       if (logger.isLoggable(Level.FINER)) {
/* 5044 */         logger.finer(toString() + " Closing cursor:" + this.serverCursorId);
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 5069 */         this.stmt.executeCommand(new UninterruptableTDSCommand()
/*      */         {
/*      */           final boolean doExecute()
/*      */             throws SQLServerException
/*      */           {
/* 5055 */             TDSWriter localTDSWriter = startRequest(3);
/* 5056 */             localTDSWriter.writeShort(-1);
/* 5057 */             localTDSWriter.writeShort(9);
/* 5058 */             localTDSWriter.writeByte(0);
/* 5059 */             localTDSWriter.writeByte(0);
/* 5060 */             localTDSWriter.writeRPCInt(null, new Integer(SQLServerResultSet.this.serverCursorId), false);
/* 5061 */             TDSParser.parse(startResponse(), getLogContext());
/* 5062 */             return true;
/*      */           }
/*      */ 
/*      */         });
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/* 5073 */         if (logger.isLoggable(Level.FINER)) {
/* 5074 */           logger.finer(toString() + " Ignored error closing cursor:" + this.serverCursorId + " " + localSQLServerException.getMessage());
/*      */         }
/*      */       }
/* 5077 */       if (logger.isLoggable(Level.FINER))
/* 5078 */         logger.finer(toString() + " Closed cursor:" + this.serverCursorId);
/*      */     }
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   32 */     lastResultSetID = 0;
/*      */ 
/*   35 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerResultSet");
/*      */ 
/*   38 */     loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.ResultSet");
/*      */   }
/*      */ 
/*      */   private final class CursorFetchCommand extends TDSCommand
/*      */   {
/*      */     private final int serverCursorId;
/*      */     private int fetchType;
/*      */     private int startRow;
/*      */     private int numRows;
/*      */ 
/*      */     CursorFetchCommand(int paramInt1, int paramInt2, int paramInt3, int arg5)
/*      */     {
/* 4878 */       super(SQLServerResultSet.this.stmt.queryTimeout);
/* 4879 */       this.serverCursorId = paramInt1;
/* 4880 */       this.fetchType = paramInt2;
/* 4881 */       this.startRow = paramInt3;
/*      */       int i;
/* 4882 */       this.numRows = i;
/*      */     }
/*      */ 
/*      */     final boolean doExecute() throws SQLServerException
/*      */     {
/* 4887 */       TDSWriter localTDSWriter = startRequest(3);
/* 4888 */       localTDSWriter.writeShort(-1);
/* 4889 */       localTDSWriter.writeShort(7);
/* 4890 */       localTDSWriter.writeByte(2);
/* 4891 */       localTDSWriter.writeByte(0);
/* 4892 */       localTDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
/* 4893 */       localTDSWriter.writeRPCInt(null, new Integer(this.fetchType), false);
/* 4894 */       localTDSWriter.writeRPCInt(null, new Integer(this.startRow), false);
/* 4895 */       localTDSWriter.writeRPCInt(null, new Integer(this.numRows), false);
/*      */ 
/* 4903 */       SQLServerResultSet.access$802(SQLServerResultSet.this, startResponse((SQLServerResultSet.this.isForwardOnly()) && (1007 != SQLServerResultSet.this.stmt.resultSetConcurrency) && (SQLServerResultSet.this.stmt.getExecProps().wasResponseBufferingSet()) && (SQLServerResultSet.this.stmt.getExecProps().isResponseBufferingAdaptive())));
/*      */ 
/* 4909 */       return false;
/*      */     }
/*      */ 
/*      */     final void processResponse(TDSReader paramTDSReader) throws SQLServerException
/*      */     {
/* 4914 */       SQLServerResultSet.access$802(SQLServerResultSet.this, paramTDSReader);
/* 4915 */       SQLServerResultSet.this.discardFetchBuffer();
/*      */     }
/*      */   }
/*      */ 
/*      */   private final class FetchBuffer
/*      */   {
/* 4788 */     private final FetchBufferTokenHandler fetchBufferTokenHandler = new FetchBufferTokenHandler();
/*      */     private TDSReaderMark startMark;
/* 4794 */     private RowType fetchBufferCurrentRowType = RowType.UNKNOWN;
/*      */     private boolean done;
/*      */     private boolean needsServerCursorFixup;
/*      */ 
/*      */     final void clearStartMark()
/*      */     {
/* 4792 */       this.startMark = null;
/*      */     }
/*      */ 
/*      */     final boolean needsServerCursorFixup()
/*      */     {
/* 4797 */       return this.needsServerCursorFixup;
/*      */     }
/*      */ 
/*      */     FetchBuffer() {
/* 4801 */       init();
/*      */     }
/*      */ 
/*      */     final void ensureStartMark()
/*      */     {
/* 4806 */       if ((null == this.startMark) && (!SQLServerResultSet.this.isForwardOnly()))
/*      */       {
/* 4808 */         if (SQLServerResultSet.logger.isLoggable(Level.FINEST)) {
/* 4809 */           SQLServerResultSet.logger.finest(toString() + " Setting fetch buffer start mark");
/*      */         }
/* 4811 */         this.startMark = SQLServerResultSet.this.tdsReader.mark();
/*      */       }
/*      */     }
/*      */ 
/*      */     final void reset()
/*      */     {
/* 4820 */       assert (null != SQLServerResultSet.this.tdsReader);
/* 4821 */       assert (null != this.startMark);
/*      */ 
/* 4823 */       SQLServerResultSet.this.tdsReader.reset(this.startMark);
/* 4824 */       this.fetchBufferCurrentRowType = RowType.UNKNOWN;
/* 4825 */       this.done = false;
/*      */     }
/*      */ 
/*      */     final void init()
/*      */     {
/* 4835 */       this.startMark = ((0 == SQLServerResultSet.this.serverCursorId) && (!SQLServerResultSet.this.isForwardOnly()) ? SQLServerResultSet.this.tdsReader.mark() : null);
/* 4836 */       this.fetchBufferCurrentRowType = RowType.UNKNOWN;
/* 4837 */       this.done = false;
/* 4838 */       this.needsServerCursorFixup = false;
/*      */     }
/*      */ 
/*      */     final RowType nextRow()
/*      */       throws SQLServerException
/*      */     {
/* 4846 */       this.fetchBufferCurrentRowType = RowType.UNKNOWN;
/*      */ 
/* 4848 */       while ((null != SQLServerResultSet.this.tdsReader) && (!this.done) && (this.fetchBufferCurrentRowType.equals(RowType.UNKNOWN))) {
/* 4849 */         TDSParser.parse(SQLServerResultSet.this.tdsReader, this.fetchBufferTokenHandler);
/*      */       }
/* 4851 */       if ((this.fetchBufferCurrentRowType.equals(RowType.UNKNOWN)) && (null != this.fetchBufferTokenHandler.getDatabaseError()))
/*      */       {
/* 4853 */         SQLServerException.makeFromDatabaseError(SQLServerResultSet.this.stmt.connection, null, this.fetchBufferTokenHandler.getDatabaseError().getMessage(), this.fetchBufferTokenHandler.getDatabaseError(), false);
/*      */       }
/*      */ 
/* 4861 */       return this.fetchBufferCurrentRowType;
/*      */     }
/*      */ 
/*      */     private final class FetchBufferTokenHandler extends TDSTokenHandler
/*      */     {
/*      */       FetchBufferTokenHandler()
/*      */       {
/* 4719 */         super();
/*      */       }
/*      */ 
/*      */       boolean onColMetaData(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/* 4727 */         new StreamColumns().setFromTDS(paramTDSReader);
/* 4728 */         return true;
/*      */       }
/*      */ 
/*      */       boolean onRow(TDSReader paramTDSReader) throws SQLServerException
/*      */       {
/* 4733 */         SQLServerResultSet.FetchBuffer.this.ensureStartMark();
/*      */ 
/* 4737 */         if ((209 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/* 4738 */         SQLServerResultSet.FetchBuffer.access$302(SQLServerResultSet.FetchBuffer.this, RowType.ROW);
/* 4739 */         return false;
/*      */       }
/*      */ 
/*      */       boolean onNBCRow(TDSReader paramTDSReader) throws SQLServerException
/*      */       {
/* 4744 */         SQLServerResultSet.FetchBuffer.this.ensureStartMark();
/*      */ 
/* 4748 */         if ((210 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/*      */ 
/* 4750 */         SQLServerResultSet.FetchBuffer.access$302(SQLServerResultSet.FetchBuffer.this, RowType.NBCROW);
/* 4751 */         return false;
/*      */       }
/*      */ 
/*      */       boolean onDone(TDSReader paramTDSReader) throws SQLServerException
/*      */       {
/* 4756 */         SQLServerResultSet.FetchBuffer.this.ensureStartMark();
/*      */ 
/* 4759 */         StreamDone localStreamDone = new StreamDone();
/* 4760 */         localStreamDone.setFromTDS(paramTDSReader);
/*      */ 
/* 4765 */         SQLServerResultSet.FetchBuffer.access$402(SQLServerResultSet.FetchBuffer.this, true);
/* 4766 */         return 0 != SQLServerResultSet.this.serverCursorId;
/*      */       }
/*      */ 
/*      */       boolean onRetStatus(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/* 4774 */         StreamRetStatus localStreamRetStatus = new StreamRetStatus();
/* 4775 */         localStreamRetStatus.setFromTDS(paramTDSReader);
/* 4776 */         SQLServerResultSet.FetchBuffer.access$602(SQLServerResultSet.FetchBuffer.this, 2 == localStreamRetStatus.getStatus());
/* 4777 */         return true;
/*      */       }
/*      */ 
/*      */       void onEOF(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/* 4783 */         super.onEOF(paramTDSReader);
/* 4784 */         SQLServerResultSet.FetchBuffer.access$402(SQLServerResultSet.FetchBuffer.this, true);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerResultSet
 * JD-Core Version:    0.6.0
 */