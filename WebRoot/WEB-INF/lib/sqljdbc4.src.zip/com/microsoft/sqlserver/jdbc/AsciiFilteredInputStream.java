/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ final class AsciiFilteredInputStream extends InputStream
/*      */ {
/*      */   private final InputStream containedStream;
/*      */   private static final byte[] ASCII_FILTER;
/*      */ 
/*      */   AsciiFilteredInputStream(BaseInputStream paramBaseInputStream)
/*      */     throws SQLServerException
/*      */   {
/*  995 */     if (BaseInputStream.logger.isLoggable(Level.FINER))
/*  996 */       BaseInputStream.logger.finer(paramBaseInputStream.toString() + " wrapping in AsciiFilteredInputStream");
/*  997 */     this.containedStream = paramBaseInputStream;
/*      */   }
/*      */ 
/*      */   public void close() throws IOException
/*      */   {
/* 1002 */     this.containedStream.close();
/*      */   }
/*      */ 
/*      */   public long skip(long paramLong) throws IOException
/*      */   {
/* 1007 */     return this.containedStream.skip(paramLong);
/*      */   }
/*      */ 
/*      */   public int available() throws IOException
/*      */   {
/* 1012 */     return this.containedStream.available();
/*      */   }
/*      */ 
/*      */   public int read() throws IOException
/*      */   {
/* 1017 */     int i = this.containedStream.read();
/* 1018 */     if ((i >= 0) && (i <= 255))
/* 1019 */       return ASCII_FILTER[i];
/* 1020 */     return i;
/*      */   }
/*      */ 
/*      */   public int read(byte[] paramArrayOfByte) throws IOException
/*      */   {
/* 1025 */     int i = this.containedStream.read(paramArrayOfByte);
/* 1026 */     if (i > 0)
/*      */     {
/* 1028 */       assert (i <= paramArrayOfByte.length);
/* 1029 */       for (int j = 0; j < i; j++)
/* 1030 */         paramArrayOfByte[j] = ASCII_FILTER[(paramArrayOfByte[j] & 0xFF)];
/*      */     }
/* 1032 */     return i;
/*      */   }
/*      */ 
/*      */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */   {
/* 1037 */     int i = this.containedStream.read(paramArrayOfByte, paramInt1, paramInt2);
/* 1038 */     if (i > 0)
/*      */     {
/* 1040 */       assert (paramInt1 + i <= paramArrayOfByte.length);
/* 1041 */       for (int j = 0; j < i; j++)
/* 1042 */         paramArrayOfByte[(paramInt1 + j)] = ASCII_FILTER[(paramArrayOfByte[(paramInt1 + j)] & 0xFF)];
/*      */     }
/* 1044 */     return i;
/*      */   }
/*      */ 
/*      */   public boolean markSupported()
/*      */   {
/* 1049 */     return this.containedStream.markSupported();
/*      */   }
/*      */ 
/*      */   public void mark(int paramInt)
/*      */   {
/* 1054 */     this.containedStream.mark(paramInt);
/*      */   }
/*      */ 
/*      */   public void reset() throws IOException
/*      */   {
/* 1059 */     this.containedStream.reset();
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  982 */     ASCII_FILTER = new byte[256];
/*      */ 
/*  985 */     for (int i = 0; i < 128; i++) {
/*  986 */       ASCII_FILTER[i] = (byte)i;
/*      */     }
/*      */ 
/*  989 */     for (i = 128; i < 256; i++)
/*  990 */       ASCII_FILTER[i] = 63;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.AsciiFilteredInputStream
 * JD-Core Version:    0.6.0
 */