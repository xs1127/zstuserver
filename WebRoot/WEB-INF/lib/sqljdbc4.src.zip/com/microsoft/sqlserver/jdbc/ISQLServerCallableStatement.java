package com.microsoft.sqlserver.jdbc;

import java.sql.CallableStatement;
import java.sql.SQLException;
import microsoft.sql.DateTimeOffset;

public abstract interface ISQLServerCallableStatement extends CallableStatement, ISQLServerPreparedStatement
{
  public abstract void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset)
    throws SQLException;

  public abstract DateTimeOffset getDateTimeOffset(int paramInt)
    throws SQLException;

  public abstract DateTimeOffset getDateTimeOffset(String paramString)
    throws SQLException;
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ISQLServerCallableStatement
 * JD-Core Version:    0.6.0
 */