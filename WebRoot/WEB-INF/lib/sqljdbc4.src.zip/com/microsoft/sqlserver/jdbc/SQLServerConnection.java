/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.DatagramPacket;
/*      */ import java.net.DatagramSocket;
/*      */ import java.net.InetAddress;
/*      */ import java.net.SocketException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.NClob;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLClientInfoException;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Struct;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.UUID;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.sql.XAConnection;
/*      */ 
/*      */ public class SQLServerConnection
/*      */   implements ISQLServerConnection
/*      */ {
/*      */   private static final float TIMEOUTSTEP = 0.08F;
/*   66 */   private boolean isRoutedInCurrentAttempt = false;
/*      */ 
/*   69 */   private ServerPortPlaceHolder routingInfo = null;
/*      */ 
/*   72 */   private boolean sendStringParametersAsUnicode = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue();
/*      */   private boolean lastUpdateCount;
/*      */   private boolean multiSubnetFailover;
/*   84 */   private ApplicationIntent applicationIntent = null;
/*      */   private int nLockTimeout;
/*      */   private String selectMethod;
/*      */   private String responseBuffering;
/*   96 */   private boolean sendTimeAsDatetime = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue();
/*      */ 
/*  108 */   private byte requestedEncryptionLevel = -1;
/*      */   private boolean trustServerCertificate;
/*  119 */   private byte negotiatedEncryptionLevel = -1;
/*      */   Properties activeConnectionProperties;
/*  127 */   private boolean integratedSecurity = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.getDefaultValue();
/*  128 */   private AuthenticationScheme intAuthScheme = AuthenticationScheme.nativeAuthentication;
/*      */ 
/*  130 */   ServerPortPlaceHolder currentConnectPlaceHolder = null;
/*      */   String sqlServerVersion;
/*      */   boolean xopenStates;
/*      */   private boolean databaseAutoCommitMode;
/*  135 */   private boolean inXATransaction = false;
/*  136 */   private byte[] transactionDescriptor = new byte[8];
/*      */   private boolean rolledBackTransaction;
/*  143 */   private State state = State.Initialized;
/*      */   static final int maxDecimalPrecision = 38;
/*      */   final String traceID;
/*      */   private int maxFieldSize;
/*      */   private int maxRows;
/*      */   private SQLCollation databaseCollation;
/*      */   private static int baseConnectionID;
/*  213 */   private String sCatalog = "master";
/*      */ 
/*  215 */   private String originalCatalog = "master";
/*      */   private int transactionIsolationLevel;
/*      */   private SQLServerPooledConnection pooledConnectionParent;
/*      */   private DatabaseMetaData databaseMetaData;
/*  220 */   private int nNextSavePointId = 10000;
/*      */   private static final Logger connectionlogger;
/*      */   private static final Logger loggerExternal;
/*      */   private final String loggingClassName;
/*  231 */   private String failoverPartnerServerProvided = null;
/*      */   private int holdability;
/*  239 */   private int tdsPacketSize = 4096;
/*  240 */   private int requestedPacketSize = 8000;
/*      */   private TDSChannel tdsChannel;
/*  245 */   private TDSCommand currentCommand = null;
/*      */ 
/*  247 */   private int tdsVersion = 0;
/*      */   private int serverMajorVersion;
/*      */   private SQLServerConnectionPoolProxy proxy;
/*  265 */   private UUID clientConnectionId = null;
/*      */   static final int MAX_SQL_LOGIN_NAME_WCHARS = 128;
/*      */   static final int DEFAULTPORT;
/* 1692 */   private final Object schedulerLock = new Object();
/*      */   volatile SQLWarning sqlWarnings;
/* 2109 */   Integer warningSynchronization = new Integer(1);
/*      */   private static final int ENVCHANGE_DATABASE = 1;
/*      */   private static final int ENVCHANGE_LANGUAGE = 2;
/*      */   private static final int ENVCHANGE_CHARSET = 3;
/*      */   private static final int ENVCHANGE_PACKETSIZE = 4;
/*      */   private static final int ENVCHANGE_SORTLOCALEID = 5;
/*      */   private static final int ENVCHANGE_SORTFLAGS = 6;
/*      */   private static final int ENVCHANGE_SQLCOLLATION = 7;
/*      */   private static final int ENVCHANGE_XACT_BEGIN = 8;
/*      */   private static final int ENVCHANGE_XACT_COMMIT = 9;
/*      */   private static final int ENVCHANGE_XACT_ROLLBACK = 10;
/*      */   private static final int ENVCHANGE_DTC_ENLIST = 11;
/*      */   private static final int ENVCHANGE_DTC_DEFECT = 12;
/*      */   private static final int ENVCHANGE_CHANGE_MIRROR = 13;
/*      */   private static final int ENVCHANGE_UNUSED_14 = 14;
/*      */   private static final int ENVCHANGE_DTC_PROMOTE = 15;
/*      */   private static final int ENVCHANGE_DTC_MGR_ADDR = 16;
/*      */   private static final int ENVCHANGE_XACT_ENDED = 17;
/*      */   private static final int ENVCHANGE_RESET_COMPLETE = 18;
/*      */   private static final int ENVCHANGE_USER_INFO = 19;
/*      */   private static final int ENVCHANGE_ROUTING = 20;
/*      */   static final char[] OUT;
/*      */   private static final int BROWSER_PORT = 1434;
/*      */ 
/*      */   boolean sendStringParametersAsUnicode()
/*      */   {
/*   73 */     return this.sendStringParametersAsUnicode;
/*      */   }
/*   75 */   final boolean useLastUpdateCount() { return this.lastUpdateCount;
/*      */   }
/*      */ 
/*      */   final boolean getMultiSubnetFailover()
/*      */   {
/*   81 */     return this.multiSubnetFailover;
/*      */   }
/*      */ 
/*      */   final ApplicationIntent getApplicationIntent()
/*      */   {
/*   87 */     return this.applicationIntent;
/*      */   }
/*      */ 
/*      */   final String getSelectMethod()
/*      */   {
/*   92 */     return this.selectMethod;
/*      */   }
/*   94 */   final String getResponseBuffering() { return this.responseBuffering;
/*      */   }
/*      */ 
/*      */   final boolean sendTimeAsDatetime()
/*      */   {
/*  100 */     return (!isKatmaiOrLater()) || (this.sendTimeAsDatetime);
/*      */   }
/*      */ 
/*      */   final int baseYear()
/*      */   {
/*  105 */     return sendTimeAsDatetime() ? 1970 : 1900;
/*      */   }
/*      */ 
/*      */   final byte getRequestedEncryptionLevel()
/*      */   {
/*  111 */     assert (-1 != this.requestedEncryptionLevel);
/*  112 */     return this.requestedEncryptionLevel;
/*      */   }
/*      */ 
/*      */   final boolean trustServerCertificate()
/*      */   {
/*  117 */     return this.trustServerCertificate;
/*      */   }
/*      */ 
/*      */   final byte getNegotiatedEncryptionLevel()
/*      */   {
/*  122 */     assert (-1 != this.negotiatedEncryptionLevel);
/*  123 */     return this.negotiatedEncryptionLevel;
/*      */   }
/*      */ 
/*      */   final boolean rolledBackTransaction()
/*      */   {
/*  141 */     return this.rolledBackTransaction;
/*      */   }
/*      */ 
/*      */   private void setState(State paramState)
/*      */   {
/*  147 */     this.state = paramState;
/*      */   }
/*      */ 
/*      */   final boolean isSessionUnAvailable()
/*      */   {
/*  153 */     return !this.state.equals(State.Opened);
/*      */   }
/*      */ 
/*      */   final void setMaxFieldSize(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  164 */     if (this.maxFieldSize != paramInt)
/*      */     {
/*  166 */       if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */       {
/*  168 */         loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */       }
/*      */ 
/*  171 */       connectionCommand(new StringBuilder().append("SET TEXTSIZE ").append(0 == paramInt ? 2147483647 : paramInt).toString(), "setMaxFieldSize");
/*  172 */       this.maxFieldSize = paramInt;
/*      */     }
/*      */   }
/*      */ 
/*      */   final void initResettableValues()
/*      */   {
/*  180 */     this.rolledBackTransaction = false;
/*  181 */     this.transactionIsolationLevel = 2;
/*  182 */     this.maxFieldSize = 0;
/*  183 */     this.maxRows = 0;
/*  184 */     this.nLockTimeout = -1;
/*  185 */     this.databaseAutoCommitMode = true;
/*  186 */     this.holdability = 1;
/*  187 */     this.sqlWarnings = null;
/*  188 */     this.sCatalog = this.originalCatalog;
/*  189 */     this.databaseMetaData = null;
/*      */   }
/*      */ 
/*      */   final void setMaxRows(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  197 */     if (this.maxRows != paramInt)
/*      */     {
/*  199 */       if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */       {
/*  201 */         loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */       }
/*  203 */       connectionCommand(new StringBuilder().append("SET ROWCOUNT ").append(paramInt).toString(), "setMaxRows");
/*  204 */       this.maxRows = paramInt;
/*      */     }
/*      */   }
/*      */ 
/*      */   final SQLCollation getDatabaseCollation() {
/*  209 */     return this.databaseCollation;
/*      */   }
/*      */ 
/*      */   final int getHoldabilityInternal()
/*      */   {
/*  234 */     return this.holdability;
/*      */   }
/*      */ 
/*      */   final int getTDSPacketSize()
/*      */   {
/*  241 */     return this.tdsPacketSize;
/*      */   }
/*      */ 
/*      */   final boolean isKatmaiOrLater()
/*      */   {
/*  251 */     assert (0 != this.tdsVersion);
/*  252 */     assert (this.tdsVersion >= 1913192450);
/*  253 */     return this.tdsVersion >= 1930100739;
/*      */   }
/*      */ 
/*      */   final boolean isDenaliOrLater()
/*      */   {
/*  258 */     return this.tdsVersion >= 1946157060;
/*      */   }
/*      */ 
/*      */   public UUID getClientConnectionId()
/*      */     throws SQLServerException
/*      */   {
/*  271 */     checkClosed();
/*  272 */     return this.clientConnectionId;
/*      */   }
/*      */ 
/*      */   final UUID getClientConIdInternal()
/*      */   {
/*  279 */     return this.clientConnectionId;
/*      */   }
/*      */ 
/*      */   final boolean attachConnId()
/*      */   {
/*  284 */     return this.state.equals(State.Connected);
/*      */   }
/*      */ 
/*      */   SQLServerConnection(String paramString)
/*      */   {
/*  290 */     int i = nextConnectionID();
/*  291 */     this.traceID = new StringBuilder().append("ConnectionID:").append(i).toString();
/*  292 */     this.loggingClassName = new StringBuilder().append("com.microsoft.sqlserver.jdbc.SQLServerConnection:").append(i).toString();
/*  293 */     if (connectionlogger.isLoggable(Level.FINE))
/*  294 */       connectionlogger.fine(new StringBuilder().append(toString()).append(" created by (").append(paramString).append(")").toString());
/*  295 */     initResettableValues();
/*      */   }
/*      */ 
/*      */   void setFailoverPartnerServerProvided(String paramString)
/*      */   {
/*  310 */     this.failoverPartnerServerProvided = paramString;
/*      */   }
/*      */ 
/*      */   final void setAssociatedProxy(SQLServerConnectionPoolProxy paramSQLServerConnectionPoolProxy)
/*      */   {
/*  316 */     this.proxy = paramSQLServerConnectionPoolProxy;
/*      */   }
/*      */ 
/*      */   final Connection getConnection()
/*      */   {
/*  327 */     if (null != this.proxy) {
/*  328 */       return this.proxy;
/*      */     }
/*  330 */     return this;
/*      */   }
/*      */ 
/*      */   final void resetPooledConnection()
/*      */   {
/*  335 */     this.tdsChannel.resetPooledConnection();
/*  336 */     initResettableValues();
/*      */   }
/*      */ 
/*      */   private static synchronized int nextConnectionID()
/*      */   {
/*  345 */     baseConnectionID += 1;
/*  346 */     return baseConnectionID;
/*      */   }
/*      */ 
/*      */   Logger getConnectionLogger() {
/*  350 */     return connectionlogger;
/*      */   }
/*      */ 
/*      */   String getClassNameLogging()
/*      */   {
/*  355 */     return this.loggingClassName;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  364 */     if (null != this.clientConnectionId) {
/*  365 */       return new StringBuilder().append(this.traceID).append(" ClientConnectionId: ").append(this.clientConnectionId.toString()).toString();
/*      */     }
/*  367 */     return this.traceID;
/*      */   }
/*      */ 
/*      */   void NotImplemented()
/*      */     throws SQLServerException
/*      */   {
/*  377 */     SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_notSupported"), null, false);
/*      */   }
/*      */ 
/*      */   void checkClosed()
/*      */     throws SQLServerException
/*      */   {
/*  386 */     if (isSessionUnAvailable())
/*      */     {
/*  388 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), null, false);
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean booleanPropertyOn(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/*  402 */     if (null == paramString2) return false;
/*  403 */     String str = paramString2.toLowerCase(Locale.US);
/*      */ 
/*  405 */     if (str.equals("true")) return true;
/*  406 */     if (str.equals("false")) return false;
/*  407 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidBooleanValue"));
/*  408 */     Object[] arrayOfObject = { new String(paramString1) };
/*  409 */     SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(arrayOfObject), null, false);
/*      */ 
/*  411 */     return false;
/*      */   }
/*      */ 
/*      */   void ValidateMaxSQLLoginName(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/*  427 */     if ((paramString2 != null) && (paramString2.length() > 128))
/*      */     {
/*  429 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_propertyMaximumExceedsChars"));
/*  430 */       Object[] arrayOfObject = { paramString1, Integer.toString(128) };
/*  431 */       SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(arrayOfObject), null, false);
/*      */     }
/*      */   }
/*      */ 
/*      */   Connection connect(Properties paramProperties, SQLServerPooledConnection paramSQLServerPooledConnection)
/*      */     throws SQLServerException
/*      */   {
/*      */     try
/*      */     {
/*  451 */       String str1 = "";
/*      */ 
/*  454 */       this.activeConnectionProperties = ((Properties)paramProperties.clone());
/*      */ 
/*  456 */       this.pooledConnectionParent = paramSQLServerPooledConnection;
/*      */ 
/*  458 */       String str2 = null;
/*  459 */       String str3 = null;
/*      */ 
/*  461 */       str2 = SQLServerDriverStringProperty.USER.toString();
/*  462 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  463 */       if (str3 == null)
/*      */       {
/*  465 */         str3 = SQLServerDriverStringProperty.USER.getDefaultValue();
/*  466 */         this.activeConnectionProperties.setProperty(str2, str3);
/*      */       }
/*  468 */       ValidateMaxSQLLoginName(str2, str3);
/*      */ 
/*  471 */       str2 = SQLServerDriverStringProperty.PASSWORD.toString();
/*  472 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  473 */       if (str3 == null)
/*      */       {
/*  475 */         str3 = SQLServerDriverStringProperty.PASSWORD.getDefaultValue();
/*  476 */         this.activeConnectionProperties.setProperty(str2, str3);
/*      */       }
/*  478 */       ValidateMaxSQLLoginName(str2, str3);
/*      */ 
/*  480 */       str2 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/*  481 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  482 */       ValidateMaxSQLLoginName(str2, str3);
/*      */ 
/*  485 */       int i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*  486 */       str3 = this.activeConnectionProperties.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
/*  487 */       if ((null != str3) && (str3.length() > 0))
/*      */       {
/*      */         try
/*      */         {
/*  491 */           i = Integer.parseInt(str3);
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException1)
/*      */         {
/*  495 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
/*  496 */           Object[] arrayOfObject1 = { str3 };
/*  497 */           SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject2).format(arrayOfObject1), null, false);
/*      */         }
/*      */ 
/*  500 */         if ((i < 0) || (i > 65535))
/*      */         {
/*  502 */           localObject1 = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
/*  503 */           localObject2 = new Object[] { str3 };
/*  504 */           SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject1).format(localObject2), null, false);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  512 */       str2 = SQLServerDriverStringProperty.SERVER_NAME.toString();
/*  513 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  514 */       if (str3 == null)
/*      */       {
/*  516 */         str3 = "localhost";
/*      */       }
/*      */ 
/*  519 */       Object localObject1 = SQLServerDriverIntProperty.PORT_NUMBER.toString();
/*  520 */       Object localObject2 = this.activeConnectionProperties.getProperty((String)localObject1);
/*      */ 
/*  522 */       int j = str3.indexOf(92);
/*  523 */       Object localObject3 = null;
/*  524 */       Object localObject4 = null;
/*      */ 
/*  526 */       String str4 = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
/*      */ 
/*  528 */       if (j >= 0)
/*      */       {
/*  530 */         localObject4 = str3.substring(j + 1, str3.length());
/*  531 */         ValidateMaxSQLLoginName(str4, (String)localObject4);
/*  532 */         str3 = str3.substring(0, j);
/*      */       }
/*  534 */       this.activeConnectionProperties.setProperty(str2, str3);
/*      */ 
/*  536 */       String str5 = this.activeConnectionProperties.getProperty(str4);
/*      */ 
/*  538 */       if (null != str5) {
/*  539 */         localObject4 = str5;
/*      */       }
/*  541 */       if (localObject4 != null)
/*      */       {
/*  543 */         ValidateMaxSQLLoginName(str4, (String)localObject4);
/*      */ 
/*  545 */         this.activeConnectionProperties.setProperty(str4, (String)localObject4);
/*      */       }
/*      */ 
/*  548 */       str2 = SQLServerDriverStringProperty.APPLICATION_NAME.toString();
/*  549 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  550 */       if (str3 != null)
/*  551 */         ValidateMaxSQLLoginName(str2, str3);
/*      */       else {
/*  553 */         this.activeConnectionProperties.setProperty(str2, "Microsoft JDBC Driver for SQL Server");
/*      */       }
/*  555 */       str2 = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
/*  556 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  557 */       if (str3 == null)
/*      */       {
/*  559 */         str3 = Boolean.toString(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue());
/*  560 */         this.activeConnectionProperties.setProperty(str2, str3);
/*      */       }
/*      */ 
/*  563 */       str2 = SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString();
/*  564 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  565 */       if (str3 == null)
/*      */       {
/*  567 */         str3 = Boolean.toString(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue());
/*  568 */         this.activeConnectionProperties.setProperty(str2, str3);
/*      */       }
/*  570 */       this.multiSubnetFailover = booleanPropertyOn(str2, str3);
/*      */ 
/*  572 */       str2 = SQLServerDriverBooleanProperty.ENCRYPT.toString();
/*  573 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  574 */       if (str3 == null)
/*      */       {
/*  576 */         str3 = Boolean.toString(SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue());
/*  577 */         this.activeConnectionProperties.setProperty(str2, str3);
/*      */       }
/*      */ 
/*  581 */       this.requestedEncryptionLevel = (booleanPropertyOn(str2, str3) ? 1 : 0);
/*      */ 
/*  583 */       str2 = SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString();
/*  584 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  585 */       if (str3 == null)
/*      */       {
/*  587 */         str3 = Boolean.toString(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue());
/*  588 */         this.activeConnectionProperties.setProperty(str2, str3);
/*      */       }
/*      */ 
/*  591 */       this.trustServerCertificate = booleanPropertyOn(str2, str3);
/*      */ 
/*  593 */       str2 = SQLServerDriverStringProperty.SELECT_METHOD.toString();
/*  594 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  595 */       if (str3 == null) str3 = SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue();
/*      */       MessageFormat localMessageFormat1;
/*      */       Object localObject5;
/*  596 */       if ((str3.equalsIgnoreCase("cursor")) || (str3.equalsIgnoreCase("direct")))
/*      */       {
/*  598 */         this.activeConnectionProperties.setProperty(str2, str3.toLowerCase());
/*      */       }
/*      */       else
/*      */       {
/*  602 */         localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidselectMethod"));
/*  603 */         localObject5 = new Object[] { new String(str3) };
/*  604 */         SQLServerException.makeFromDriverError(this, this, localMessageFormat1.format(localObject5), null, false);
/*      */       }
/*      */ 
/*  607 */       str2 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
/*  608 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  609 */       if (str3 == null) str3 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue();
/*  610 */       if ((str3.equalsIgnoreCase("full")) || (str3.equalsIgnoreCase("adaptive")))
/*      */       {
/*  612 */         this.activeConnectionProperties.setProperty(str2, str3.toLowerCase());
/*      */       }
/*      */       else
/*      */       {
/*  616 */         localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidresponseBuffering"));
/*  617 */         localObject5 = new Object[] { new String(str3) };
/*  618 */         SQLServerException.makeFromDriverError(this, this, localMessageFormat1.format(localObject5), null, false);
/*      */       }
/*      */ 
/*  622 */       str2 = SQLServerDriverStringProperty.APPLICATION_INTENT.toString();
/*  623 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  624 */       if (str3 == null) str3 = SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue();
/*  625 */       this.applicationIntent = ApplicationIntent.valueOfString(str3);
/*  626 */       this.activeConnectionProperties.setProperty(str2, this.applicationIntent.toString());
/*      */ 
/*  628 */       str2 = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString();
/*  629 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  630 */       if (str3 == null)
/*      */       {
/*  632 */         str3 = Boolean.toString(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue());
/*  633 */         this.activeConnectionProperties.setProperty(str2, str3);
/*      */       }
/*      */ 
/*  636 */       this.sendTimeAsDatetime = booleanPropertyOn(str2, str3);
/*      */ 
/*  638 */       str2 = SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString();
/*  639 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  640 */       if ((str3 != null) && 
/*  641 */         (false == booleanPropertyOn(str2, str3)))
/*      */       {
/*  643 */         localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invaliddisableStatementPooling"));
/*  644 */         localObject5 = new Object[] { new String(str3) };
/*  645 */         SQLServerException.makeFromDriverError(this, this, localMessageFormat1.format(localObject5), null, false);
/*      */       }
/*      */ 
/*  648 */       str2 = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString();
/*  649 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  650 */       if (str3 != null)
/*      */       {
/*  652 */         this.integratedSecurity = booleanPropertyOn(str2, str3);
/*      */       }
/*      */ 
/*  656 */       if (this.integratedSecurity)
/*      */       {
/*  658 */         str2 = SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString();
/*  659 */         str3 = this.activeConnectionProperties.getProperty(str2);
/*  660 */         if (str3 != null)
/*      */         {
/*  662 */           this.intAuthScheme = AuthenticationScheme.valueOfString(str3); }  } 
/*      */ str2 = SQLServerDriverStringProperty.WORKSTATION_ID.toString();
/*  667 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  668 */       ValidateMaxSQLLoginName(str2, str3);
/*      */ 
/*  670 */       int k = 0;
/*  671 */       str2 = SQLServerDriverIntProperty.PORT_NUMBER.toString();
/*      */       Object localObject6;
/*      */       try { localObject5 = this.activeConnectionProperties.getProperty(str2);
/*  675 */         if (null != localObject5)
/*      */         {
/*  677 */           k = new Integer((String)localObject5).intValue();
/*      */ 
/*  679 */           if ((k < 0) || (k > 65535))
/*      */           {
/*  681 */             localObject6 = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/*  682 */             localObject7 = new Object[] { Integer.toString(k) };
/*  683 */             SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject6).format(localObject7), null, false);
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (NumberFormatException localNumberFormatException2)
/*      */       {
/*  689 */         localObject6 = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/*  690 */         localObject7 = new Object[] { this.activeConnectionProperties.getProperty(str2) };
/*  691 */         SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject6).format(localObject7), null, false);
/*      */       }
/*      */ 
/*  695 */       str2 = SQLServerDriverIntProperty.PACKET_SIZE.toString();
/*  696 */       str3 = this.activeConnectionProperties.getProperty(str2);
/*  697 */       if ((null != str3) && (str3.length() > 0))
/*      */       {
/*      */         try
/*      */         {
/*  701 */           this.requestedPacketSize = Integer.parseInt(str3);
/*      */ 
/*  704 */           if (-1 == this.requestedPacketSize) {
/*  705 */             this.requestedPacketSize = 0;
/*      */           }
/*  708 */           else if (0 == this.requestedPacketSize) {
/*  709 */             this.requestedPacketSize = 32767;
/*      */           }
/*      */ 
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException3)
/*      */         {
/*  715 */           this.requestedPacketSize = -1;
/*      */         }
/*      */ 
/*  718 */         if (0 != this.requestedPacketSize)
/*      */         {
/*  721 */           if ((this.requestedPacketSize < 512) || (this.requestedPacketSize > 32767))
/*      */           {
/*  723 */             MessageFormat localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_invalidPacketSize"));
/*  724 */             localObject6 = new Object[] { str3 };
/*  725 */             SQLServerException.makeFromDriverError(this, this, localMessageFormat2.format(localObject6), null, false);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  734 */       str2 = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString();
/*  735 */       if (null == this.activeConnectionProperties.getProperty(str2))
/*      */       {
/*  737 */         this.sendStringParametersAsUnicode = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue();
/*      */       }
/*      */       else
/*      */       {
/*  741 */         this.sendStringParametersAsUnicode = booleanPropertyOn(str2, this.activeConnectionProperties.getProperty(str2));
/*      */       }
/*      */ 
/*  744 */       str2 = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
/*  745 */       this.lastUpdateCount = booleanPropertyOn(str2, this.activeConnectionProperties.getProperty(str2));
/*  746 */       str2 = SQLServerDriverBooleanProperty.XOPEN_STATES.toString();
/*  747 */       this.xopenStates = booleanPropertyOn(str2, this.activeConnectionProperties.getProperty(str2));
/*      */ 
/*  749 */       str2 = SQLServerDriverStringProperty.SELECT_METHOD.toString();
/*  750 */       this.selectMethod = null;
/*  751 */       if ((this.activeConnectionProperties.getProperty(str2) != null) && (this.activeConnectionProperties.getProperty(str2).length() > 0))
/*      */       {
/*  754 */         this.selectMethod = this.activeConnectionProperties.getProperty(str2);
/*      */       }
/*      */ 
/*  757 */       str2 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
/*  758 */       this.responseBuffering = null;
/*  759 */       if ((this.activeConnectionProperties.getProperty(str2) != null) && (this.activeConnectionProperties.getProperty(str2).length() > 0))
/*      */       {
/*  762 */         this.responseBuffering = this.activeConnectionProperties.getProperty(str2);
/*      */       }
/*      */ 
/*  765 */       str2 = SQLServerDriverIntProperty.LOCK_TIMEOUT.toString();
/*  766 */       int m = SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue();
/*  767 */       this.nLockTimeout = m;
/*  768 */       if ((this.activeConnectionProperties.getProperty(str2) != null) && (this.activeConnectionProperties.getProperty(str2).length() > 0))
/*      */       {
/*      */         try
/*      */         {
/*  773 */           int n = new Integer(this.activeConnectionProperties.getProperty(str2)).intValue();
/*  774 */           if (n >= m) {
/*  775 */             this.nLockTimeout = n;
/*      */           }
/*      */           else {
/*  778 */             localObject7 = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
/*  779 */             localObject8 = new Object[] { this.activeConnectionProperties.getProperty(str2) };
/*  780 */             SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject7).format(localObject8), null, false);
/*      */           }
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException4)
/*      */         {
/*  785 */           localObject7 = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
/*  786 */           localObject8 = new Object[] { this.activeConnectionProperties.getProperty(str2) };
/*  787 */           SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject7).format(localObject8), null, false);
/*      */         }
/*      */       }
/*  790 */       FailoverInfo localFailoverInfo = null;
/*  791 */       Object localObject7 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/*  792 */       Object localObject8 = SQLServerDriverStringProperty.SERVER_NAME.toString();
/*  793 */       String str6 = SQLServerDriverStringProperty.FAILOVER_PARTNER.toString();
/*  794 */       String str7 = this.activeConnectionProperties.getProperty(str6);
/*      */ 
/*  797 */       if ((this.multiSubnetFailover) && (str7 != null))
/*      */       {
/*  799 */         SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover"), null, false);
/*      */       }
/*      */ 
/*  803 */       if ((this.applicationIntent != null) && (this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) && (str7 != null))
/*      */       {
/*  805 */         SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent"), null, false);
/*      */       }
/*      */ 
/*  809 */       if (null != this.activeConnectionProperties.getProperty((String)localObject7))
/*      */       {
/*  812 */         localFailoverInfo = FailoverMapSingleton.getFailoverInfo(this, this.activeConnectionProperties.getProperty((String)localObject8), this.activeConnectionProperties.getProperty(str4), this.activeConnectionProperties.getProperty((String)localObject7));
/*      */       }
/*  818 */       else if (null != str7) {
/*  819 */         SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_failoverPartnerWithoutDB"), null, true);
/*      */       }
/*      */ 
/*  822 */       String str8 = null;
/*  823 */       if (null == localFailoverInfo) {
/*  824 */         str8 = str7;
/*      */       }
/*  826 */       long l = System.currentTimeMillis();
/*  827 */       login(this.activeConnectionProperties.getProperty((String)localObject8), (String)localObject4, k, str8, localFailoverInfo, i, l);
/*      */ 
/*  831 */       if ((1 == this.negotiatedEncryptionLevel) || (3 == this.negotiatedEncryptionLevel))
/*      */       {
/*  834 */         int i1 = Util.isIBM() ? 8192 : 16384;
/*      */ 
/*  836 */         if (this.tdsPacketSize > i1)
/*      */         {
/*  838 */           connectionlogger.finer(new StringBuilder().append(toString()).append(" Negotiated tdsPacketSize ").append(this.tdsPacketSize).append(" is too large for SSL with JRE ").append(Util.SYSTEM_JRE).append(" (max size is ").append(i1).append(")").toString());
/*  839 */           MessageFormat localMessageFormat3 = new MessageFormat(SQLServerException.getErrString("R_packetSizeTooBigForSSL"));
/*  840 */           Object[] arrayOfObject2 = { Integer.toString(i1) };
/*  841 */           terminate(6, localMessageFormat3.format(arrayOfObject2));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  846 */       this.state = State.Opened;
/*      */ 
/*  849 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/*  851 */         connectionlogger.finer(new StringBuilder().append(toString()).append(" End of connect").toString());
/*      */       }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*  858 */       if (!this.state.equals(State.Opened))
/*      */       {
/*  861 */         if (!this.state.equals(State.Closed)) {
/*  862 */           close();
/*      */         }
/*      */       }
/*      */     }
/*  866 */     return (Connection)(Connection)(Connection)(Connection)(Connection)(Connection)(Connection)this;
/*      */   }
/*      */ 
/*      */   private void login(String paramString1, String paramString2, int paramInt1, String paramString3, FailoverInfo paramFailoverInfo, int paramInt2, long paramLong)
/*      */     throws SQLServerException
/*      */   {
/*  880 */     int i = (null == paramString3) && (null == paramFailoverInfo) ? 0 : 1;
/*      */ 
/*  882 */     int j = 100;
/*      */ 
/*  885 */     boolean bool1 = false;
/*  886 */     FailoverInfo localFailoverInfo = null;
/*      */ 
/*  888 */     ServerPortPlaceHolder localServerPortPlaceHolder1 = null;
/*      */ 
/*  890 */     ServerPortPlaceHolder localServerPortPlaceHolder2 = null;
/*      */ 
/*  892 */     if (null != paramFailoverInfo)
/*      */     {
/*  894 */       localFailoverInfo = paramFailoverInfo;
/*  895 */       bool1 = paramFailoverInfo.getUseFailoverPartner();
/*      */     }
/*  899 */     else if (i != 0)
/*      */     {
/*  901 */       localFailoverInfo = new FailoverInfo(paramString3, this, false);
/*      */     }
/*      */ 
/*  907 */     boolean bool2 = getMultiSubnetFailover();
/*      */ 
/*  911 */     if (0 == paramInt2)
/*      */     {
/*  913 */       paramInt2 = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*      */     }
/*  915 */     long l4 = paramInt2 * 1000;
/*  916 */     long l1 = paramLong + l4;
/*      */     long l2;
/*  919 */     if ((i != 0) || (bool2))
/*      */     {
/*  921 */       l2 = ()(0.08F * (float)l4);
/*      */     }
/*      */     else
/*      */     {
/*  925 */       l2 = l4;
/*      */     }
/*  927 */     long l3 = paramLong + l2;
/*      */ 
/*  929 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/*  931 */       connectionlogger.finer(new StringBuilder().append(toString()).append(" Start time: ").append(paramLong).append(" Time out time: ").append(l1).append(" Timeout Unit Interval: ").append(l2).toString());
/*      */     }
/*      */ 
/*  935 */     int m = 0;
/*      */ 
/*  938 */     int n = 0;
/*      */     Object localObject3;
/*      */     while (true)
/*      */     {
/*  949 */       this.clientConnectionId = null;
/*  950 */       this.state = State.Initialized;
/*      */       try
/*      */       {
/*  954 */         if ((i != 0) && (bool1))
/*      */         {
/*  957 */           if (null == localServerPortPlaceHolder1)
/*      */           {
/*  960 */             localServerPortPlaceHolder1 = localFailoverInfo.failoverPermissionCheck(this, this.integratedSecurity);
/*      */           }
/*  962 */           this.currentConnectPlaceHolder = localServerPortPlaceHolder1;
/*      */         }
/*      */         else
/*      */         {
/*  966 */           if (this.routingInfo != null)
/*      */           {
/*  968 */             localServerPortPlaceHolder2 = this.routingInfo;
/*      */           }
/*  970 */           else if (null == localServerPortPlaceHolder2)
/*      */           {
/*  972 */             localServerPortPlaceHolder2 = primaryPermissionCheck(paramString1, paramString2, paramInt1);
/*      */           }
/*  974 */           this.currentConnectPlaceHolder = localServerPortPlaceHolder2;
/*      */         }
/*      */ 
/*  978 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/*  980 */           connectionlogger.fine(new StringBuilder().append(toString()).append(" This attempt server name: ").append(this.currentConnectPlaceHolder.getServerName()).append(" port: ").append(this.currentConnectPlaceHolder.getPortNumber()).append(" InstanceName: ").append(this.currentConnectPlaceHolder.getInstanceName()).append(" useParallel: ").append(bool2).toString());
/*      */ 
/*  984 */           connectionlogger.fine(new StringBuilder().append(toString()).append(" This attempt endtime: ").append(l3).toString());
/*  985 */           connectionlogger.fine(new StringBuilder().append(toString()).append(" This attempt No: ").append(m).toString());
/*      */         }
/*      */ 
/*  991 */         connectHelper(this.currentConnectPlaceHolder, TimerRemaining(l3), paramInt2, bool2);
/*      */ 
/*  994 */         if (this.isRoutedInCurrentAttempt)
/*      */         {
/*      */           Object localObject1;
/*  998 */           if (i != 0)
/*      */           {
/* 1000 */             localObject1 = SQLServerException.getErrString("R_invalidRoutingInfo");
/* 1001 */             terminate(6, (String)localObject1);
/*      */           }
/*      */ 
/* 1004 */           n++;
/*      */ 
/* 1006 */           if (n > 1)
/*      */           {
/* 1008 */             localObject1 = SQLServerException.getErrString("R_multipleRedirections");
/* 1009 */             terminate(6, (String)localObject1);
/*      */           }
/*      */ 
/* 1013 */           if (this.tdsChannel != null) {
/* 1014 */             this.tdsChannel.close();
/*      */           }
/* 1016 */           initResettableValues();
/*      */ 
/* 1020 */           resetNonRoutingEnvchangeValues();
/*      */ 
/* 1026 */           m++;
/*      */ 
/* 1029 */           this.isRoutedInCurrentAttempt = false;
/*      */ 
/* 1032 */           bool2 = false;
/*      */ 
/* 1035 */           l3 = l1;
/*      */ 
/* 1038 */           if (timerHasExpired(l1))
/*      */           {
/* 1040 */             localObject1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 1041 */             Object[] arrayOfObject = { this.currentConnectPlaceHolder.getServerName(), Integer.toString(this.currentConnectPlaceHolder.getPortNumber()), SQLServerException.getErrString("R_timedOutBeforeRouting") };
/* 1042 */             localObject3 = ((MessageFormat)localObject1).format(arrayOfObject);
/* 1043 */             terminate(6, (String)localObject3);
/*      */           }
/*      */           else
/*      */           {
/* 1047 */             continue;
/*      */           }
/*      */         }
/*      */         else {
/* 1051 */           break;
/*      */         }
/*      */       }
/*      */       catch (SQLServerException localSQLServerException) {
/* 1055 */         if ((18456 == localSQLServerException.getErrorCode()) || (18488 == localSQLServerException.getErrorCode()) || (4 == localSQLServerException.getDriverErrorCode()) || (5 == localSQLServerException.getDriverErrorCode()) || (6 == localSQLServerException.getDriverErrorCode()) || (timerHasExpired(l1)) || ((this.state.equals(State.Connected)) && (i == 0)))
/*      */         {
/* 1067 */           close();
/* 1068 */           throw localSQLServerException;
/*      */         }
/*      */ 
/* 1074 */         if (null != this.tdsChannel) {
/* 1075 */           this.tdsChannel.close();
/*      */         }
/*      */ 
/* 1080 */         if ((i == 0) || (1 == m % 2))
/*      */         {
/* 1084 */           long l5 = TimerRemaining(l1);
/* 1085 */           if (l5 <= j)
/*      */           {
/* 1087 */             throw localSQLServerException;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1097 */       if ((i == 0) || (1 == m % 2))
/*      */       {
/* 1099 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/* 1101 */           connectionlogger.fine(new StringBuilder().append(toString()).append(" sleeping milisec: ").append(j).toString());
/*      */         }
/*      */         try
/*      */         {
/* 1105 */           Thread.sleep(j);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException)
/*      */         {
/*      */         }
/* 1110 */         int k = j < 500 ? j * 2 : 1000;
/*      */       }
/*      */ 
/* 1114 */       m++;
/*      */ 
/* 1116 */       if (bool2)
/*      */       {
/* 1118 */         l3 = System.currentTimeMillis() + l2 * (m + 1);
/*      */       }
/* 1120 */       else if (i != 0)
/*      */       {
/* 1122 */         l3 = System.currentTimeMillis() + l2 * (m / 2 + 1);
/*      */       }
/*      */       else {
/* 1125 */         l3 = l1;
/*      */       }
/*      */ 
/* 1128 */       if (l3 > l1)
/*      */       {
/* 1130 */         l3 = l1;
/*      */       }
/*      */ 
/* 1133 */       if (i != 0)
/* 1134 */         bool1 = !bool1;
/*      */     }
/*      */     String str;
/*      */     Object localObject2;
/* 1139 */     if ((bool1) && (null == this.failoverPartnerServerProvided))
/*      */     {
/* 1141 */       str = this.currentConnectPlaceHolder.getServerName();
/* 1142 */       if (null != localServerPortPlaceHolder1.getInstanceName())
/*      */       {
/* 1144 */         str = new StringBuilder().append(str).append("\\").toString();
/* 1145 */         str = new StringBuilder().append(str).append(localServerPortPlaceHolder1.getInstanceName()).toString();
/*      */       }
/* 1147 */       localObject2 = new MessageFormat(SQLServerException.getErrString("R_invalidPartnerConfiguration"));
/* 1148 */       localObject3 = new Object[] { new String(this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString())), str };
/*      */ 
/* 1150 */       terminate(6, ((MessageFormat)localObject2).format(localObject3));
/*      */     }
/*      */ 
/* 1153 */     if (null != this.failoverPartnerServerProvided)
/*      */     {
/* 1156 */       if (this.multiSubnetFailover)
/*      */       {
/* 1158 */         str = SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover");
/* 1159 */         terminate(6, str);
/*      */       }
/*      */ 
/* 1163 */       if ((this.applicationIntent != null) && (this.applicationIntent.equals(ApplicationIntent.READ_ONLY)))
/*      */       {
/* 1165 */         str = SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent");
/* 1166 */         terminate(6, str);
/*      */       }
/*      */ 
/* 1170 */       if (null == localFailoverInfo) {
/* 1171 */         localFailoverInfo = new FailoverInfo(this.failoverPartnerServerProvided, this, false);
/*      */       }
/* 1173 */       if (null != paramFailoverInfo)
/*      */       {
/* 1178 */         paramFailoverInfo.failoverAdd(this, bool1, this.failoverPartnerServerProvided);
/*      */       }
/*      */       else
/*      */       {
/* 1182 */         str = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/* 1183 */         localObject2 = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
/* 1184 */         localObject3 = SQLServerDriverStringProperty.SERVER_NAME.toString();
/*      */ 
/* 1186 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/* 1188 */           connectionlogger.fine(new StringBuilder().append(toString()).append(" adding new failover info server: ").append(this.activeConnectionProperties.getProperty((String)localObject3)).append(" instance: ").append(this.activeConnectionProperties.getProperty((String)localObject2)).append(" database: ").append(this.activeConnectionProperties.getProperty(str)).append(" server provided failover: ").append(this.failoverPartnerServerProvided).toString());
/*      */         }
/*      */ 
/* 1194 */         localFailoverInfo.failoverAdd(this, bool1, this.failoverPartnerServerProvided);
/* 1195 */         FailoverMapSingleton.putFailoverInfo(this, paramString1, this.activeConnectionProperties.getProperty((String)localObject2), this.activeConnectionProperties.getProperty(str), localFailoverInfo, bool1, this.failoverPartnerServerProvided);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void resetNonRoutingEnvchangeValues()
/*      */   {
/* 1205 */     this.tdsPacketSize = 4096;
/* 1206 */     this.databaseCollation = null;
/* 1207 */     this.rolledBackTransaction = false;
/* 1208 */     Arrays.fill(getTransactionDescriptor(), 0);
/* 1209 */     this.sCatalog = this.originalCatalog;
/* 1210 */     this.failoverPartnerServerProvided = null;
/*      */   }
/*      */ 
/*      */   ServerPortPlaceHolder primaryPermissionCheck(String paramString1, String paramString2, int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1221 */     if (0 == paramInt)
/*      */     {
/* 1223 */       if (null != paramString2)
/*      */       {
/* 1225 */         String str = getInstancePort(paramString1, paramString2);
/* 1226 */         if (connectionlogger.isLoggable(Level.FINER))
/* 1227 */           connectionlogger.fine(new StringBuilder().append(toString()).append("SQL Server port returned by SQL Browser: ").append(str).toString());
/*      */         try
/*      */         {
/* 1230 */           if (null != str)
/*      */           {
/* 1232 */             paramInt = new Integer(str).intValue();
/*      */ 
/* 1234 */             if ((paramInt < 0) || (paramInt > 65535))
/*      */             {
/* 1236 */               MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1237 */               localObject = new Object[] { Integer.toString(paramInt) };
/* 1238 */               SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(localObject), null, false);
/*      */             }
/*      */           }
/*      */           else {
/* 1242 */             paramInt = DEFAULTPORT;
/*      */           }
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException)
/*      */         {
/* 1247 */           Object localObject = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1248 */           Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/* 1249 */           SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject).format(arrayOfObject), null, false);
/*      */         }
/*      */       }
/*      */       else {
/* 1253 */         paramInt = DEFAULTPORT;
/*      */       }
/*      */     }
/*      */ 
/* 1257 */     this.activeConnectionProperties.setProperty(SQLServerDriverIntProperty.PORT_NUMBER.toString(), String.valueOf(paramInt));
/* 1258 */     return (ServerPortPlaceHolder)new ServerPortPlaceHolder(paramString1, paramInt, paramString2, this.integratedSecurity);
/*      */   }
/*      */ 
/*      */   static boolean timerHasExpired(long paramLong)
/*      */   {
/* 1263 */     int i = System.currentTimeMillis() > paramLong ? 1 : 0;
/* 1264 */     return i;
/*      */   }
/*      */ 
/*      */   static int TimerRemaining(long paramLong)
/*      */   {
/* 1269 */     long l1 = System.currentTimeMillis();
/* 1270 */     long l2 = paramLong - l1;
/*      */ 
/* 1272 */     if (l2 > 2147483647L) {
/* 1273 */       l2 = 2147483647L;
/*      */     }
/*      */ 
/* 1276 */     if (l2 <= 0L)
/* 1277 */       l2 = 1L;
/* 1278 */     return (int)l2;
/*      */   }
/*      */ 
/*      */   private void connectHelper(ServerPortPlaceHolder paramServerPortPlaceHolder, int paramInt1, int paramInt2, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 1298 */     if (connectionlogger.isLoggable(Level.FINE))
/*      */     {
/* 1300 */       connectionlogger.fine(new StringBuilder().append(toString()).append(" Connecting with server: ").append(paramServerPortPlaceHolder.getServerName()).append(" port: ").append(paramServerPortPlaceHolder.getPortNumber()).append(" Timeout slice: ").append(paramInt1).append(" Timeout Full: ").append(paramInt2).toString());
/*      */     }
/*      */ 
/* 1305 */     this.tdsChannel = new TDSChannel(this);
/* 1306 */     if (0 == paramInt2)
/* 1307 */       this.tdsChannel.open(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber(), 0, paramBoolean);
/*      */     else {
/* 1309 */       this.tdsChannel.open(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber(), paramInt1, paramBoolean);
/*      */     }
/*      */ 
/* 1312 */     setState(State.Connected);
/*      */ 
/* 1315 */     this.clientConnectionId = UUID.randomUUID();
/* 1316 */     assert (null != this.clientConnectionId);
/*      */ 
/* 1319 */     Prelogin(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber());
/*      */ 
/* 1322 */     if (2 != this.negotiatedEncryptionLevel) {
/* 1323 */       this.tdsChannel.enableSSL(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber());
/*      */     }
/*      */ 
/* 1326 */     executeCommand(new LogonCommand());
/*      */   }
/*      */ 
/*      */   void Prelogin(String paramString, int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1335 */     byte[] arrayOfByte1 = { 18, 1, 0, 67, 0, 0, 0, 0, 0, 0, 16, 0, 6, 1, 0, 22, 0, 1, 5, 0, 23, 0, 36, -1, 0, 0, 0, 0, 0, 0, this.requestedEncryptionLevel, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*      */ 
/* 1372 */     byte[] arrayOfByte2 = new byte[4096];
/* 1373 */     String str = new StringBuilder().append(" Prelogin error: host ").append(paramString).append(" port ").append(paramInt).toString();
/*      */ 
/* 1375 */     ActivityId localActivityId = ActivityCorrelator.getNext();
/* 1376 */     byte[] arrayOfByte3 = Util.asGuidByteArray(localActivityId.getId());
/* 1377 */     byte[] arrayOfByte4 = Util.asGuidByteArray(this.clientConnectionId);
/* 1378 */     int i = arrayOfByte1.length - 36;
/*      */ 
/* 1381 */     System.arraycopy(arrayOfByte4, 0, arrayOfByte1, i, arrayOfByte4.length);
/* 1382 */     i += arrayOfByte4.length;
/*      */ 
/* 1385 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte1, i, arrayOfByte3.length);
/* 1386 */     i += arrayOfByte3.length;
/* 1387 */     long l = localActivityId.getSequence();
/* 1388 */     Util.writeInt((int)l, arrayOfByte1, i);
/* 1389 */     i += 4;
/*      */ 
/* 1391 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 1393 */       connectionlogger.finer(new StringBuilder().append(toString()).append(" Requesting encryption level:").append(TDS.getEncryptionLevel(this.requestedEncryptionLevel)).toString());
/* 1394 */       connectionlogger.finer(new StringBuilder().append(toString()).append(" ActivityId ").append(localActivityId.toString()).toString());
/*      */     }
/*      */ 
/* 1398 */     if (this.tdsChannel.isLoggingPackets()) {
/* 1399 */       this.tdsChannel.logPacket(arrayOfByte1, 0, arrayOfByte1.length, new StringBuilder().append(toString()).append(" Prelogin request").toString());
/*      */     }
/*      */     try
/*      */     {
/* 1403 */       this.tdsChannel.write(arrayOfByte1, 0, arrayOfByte1.length);
/* 1404 */       this.tdsChannel.flush();
/*      */     }
/*      */     catch (SQLServerException localSQLServerException1)
/*      */     {
/* 1408 */       connectionlogger.warning(new StringBuilder().append(toString()).append(str).append(" Error sending prelogin request: ").append(localSQLServerException1.getMessage()).toString());
/* 1409 */       throw localSQLServerException1;
/*      */     }
/*      */ 
/* 1412 */     ActivityCorrelator.setCurrentActivityIdSentFlag();
/*      */ 
/* 1415 */     int j = arrayOfByte2.length;
/* 1416 */     int k = 0;
/* 1417 */     int m = 0;
/* 1418 */     while (k < j)
/*      */     {
/*      */       try
/*      */       {
/* 1424 */         n = this.tdsChannel.read(arrayOfByte2, k, j - k);
/*      */       }
/*      */       catch (SQLServerException localSQLServerException2)
/*      */       {
/* 1428 */         connectionlogger.warning(new StringBuilder().append(toString()).append(str).append(" Error reading prelogin response: ").append(localSQLServerException2.getMessage()).toString());
/* 1429 */         throw localSQLServerException2;
/*      */       }
/*      */       MessageFormat localMessageFormat1;
/*      */       Object[] arrayOfObject1;
/* 1437 */       if (-1 == n)
/*      */       {
/* 1439 */         connectionlogger.warning(new StringBuilder().append(toString()).append(str).append(" Unexpected end of prelogin response after ").append(k).append(" bytes read").toString());
/* 1440 */         localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 1441 */         arrayOfObject1 = new Object[] { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 1442 */         terminate(3, localMessageFormat1.format(arrayOfObject1));
/*      */       }
/*      */ 
/* 1446 */       assert (n >= 0);
/* 1447 */       assert (n <= j - k);
/*      */ 
/* 1449 */       if (this.tdsChannel.isLoggingPackets()) {
/* 1450 */         this.tdsChannel.logPacket(arrayOfByte2, k, n, new StringBuilder().append(toString()).append(" Prelogin response").toString());
/*      */       }
/* 1452 */       k += n;
/*      */ 
/* 1456 */       if ((m == 0) && (k >= 8))
/*      */       {
/* 1459 */         if (4 != arrayOfByte2[0])
/*      */         {
/* 1461 */           connectionlogger.warning(new StringBuilder().append(toString()).append(str).append(" Unexpected response type:").append(arrayOfByte2[0]).toString());
/* 1462 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 1463 */           arrayOfObject1 = new Object[] { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 1464 */           terminate(3, localMessageFormat1.format(arrayOfObject1));
/*      */         }
/*      */ 
/* 1470 */         if (1 != (0x1 & arrayOfByte2[1]))
/*      */         {
/* 1472 */           connectionlogger.warning(new StringBuilder().append(toString()).append(str).append(" Unexpected response status:").append(arrayOfByte2[1]).toString());
/* 1473 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 1474 */           arrayOfObject1 = new Object[] { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 1475 */           terminate(3, localMessageFormat1.format(arrayOfObject1));
/*      */         }
/*      */ 
/* 1479 */         j = Util.readUnsignedShortBigEndian(arrayOfByte2, 2);
/* 1480 */         assert (j >= 0);
/*      */ 
/* 1482 */         if (j >= arrayOfByte2.length)
/*      */         {
/* 1484 */           connectionlogger.warning(new StringBuilder().append(toString()).append(str).append(" Response length:").append(j).append(" is greater than allowed length:").append(arrayOfByte2.length).toString());
/* 1485 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 1486 */           arrayOfObject1 = new Object[] { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 1487 */           terminate(3, localMessageFormat1.format(arrayOfObject1));
/*      */         }
/*      */ 
/* 1490 */         m = 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1496 */     int n = 0;
/* 1497 */     this.negotiatedEncryptionLevel = -1;
/*      */ 
/* 1499 */     int i1 = 8;
/*      */     while (true)
/*      */     {
/* 1503 */       if (i1 >= j)
/*      */       {
/* 1505 */         connectionlogger.warning(new StringBuilder().append(toString()).append(" Option token not found").toString());
/* 1506 */         throwInvalidTDS();
/*      */       }
/* 1508 */       int i2 = arrayOfByte2[(i1++)];
/*      */ 
/* 1511 */       if (-1 == i2)
/*      */       {
/*      */         break;
/*      */       }
/* 1515 */       if (i1 + 4 >= j)
/*      */       {
/* 1517 */         connectionlogger.warning(new StringBuilder().append(toString()).append(" Offset/Length not found for option:").append(i2).toString());
/* 1518 */         throwInvalidTDS();
/*      */       }
/*      */ 
/* 1521 */       int i3 = Util.readUnsignedShortBigEndian(arrayOfByte2, i1) + 8;
/* 1522 */       i1 += 2;
/* 1523 */       assert (i3 >= 0);
/*      */ 
/* 1525 */       int i4 = Util.readUnsignedShortBigEndian(arrayOfByte2, i1);
/* 1526 */       i1 += 2;
/* 1527 */       assert (i4 >= 0);
/*      */ 
/* 1529 */       if (i3 + i4 > j)
/*      */       {
/* 1531 */         connectionlogger.warning(new StringBuilder().append(toString()).append(" Offset:").append(i3).append(" and length:").append(i4).append(" exceed response length:").append(j).toString());
/* 1532 */         throwInvalidTDS();
/*      */       }
/*      */ 
/* 1535 */       switch (i2)
/*      */       {
/*      */       case 0:
/* 1538 */         if (n != 0)
/*      */         {
/* 1540 */           connectionlogger.warning(new StringBuilder().append(toString()).append(" Version option already received").toString());
/* 1541 */           throwInvalidTDS();
/*      */         }
/*      */ 
/* 1544 */         if (6 != i4)
/*      */         {
/* 1546 */           connectionlogger.warning(new StringBuilder().append(toString()).append(" Version option length:").append(i4).append(" is incorrect.  Correct value is 6.").toString());
/* 1547 */           throwInvalidTDS();
/*      */         }
/*      */ 
/* 1550 */         this.serverMajorVersion = arrayOfByte2[i3];
/* 1551 */         if (this.serverMajorVersion < 9)
/*      */         {
/* 1553 */           connectionlogger.warning(new StringBuilder().append(toString()).append(" Server major version:").append(this.serverMajorVersion).append(" is not supported by this driver.").toString());
/* 1554 */           MessageFormat localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_unsupportedServerVersion"));
/* 1555 */           Object[] arrayOfObject2 = { Integer.toString(arrayOfByte2[i3]) };
/* 1556 */           terminate(6, localMessageFormat2.format(arrayOfObject2));
/*      */         }
/*      */ 
/* 1559 */         if (connectionlogger.isLoggable(Level.FINE)) {
/* 1560 */           connectionlogger.fine(new StringBuilder().append(toString()).append(" Server returned major version:").append(arrayOfByte2[i3]).toString());
/*      */         }
/* 1562 */         n = 1;
/* 1563 */         break;
/*      */       case 1:
/* 1566 */         if (-1 != this.negotiatedEncryptionLevel)
/*      */         {
/* 1568 */           connectionlogger.warning(new StringBuilder().append(toString()).append(" Encryption option already received").toString());
/* 1569 */           throwInvalidTDS();
/*      */         }
/*      */ 
/* 1572 */         if (1 != i4)
/*      */         {
/* 1574 */           connectionlogger.warning(new StringBuilder().append(toString()).append(" Encryption option length:").append(i4).append(" is incorrect.  Correct value is 1.").toString());
/* 1575 */           throwInvalidTDS();
/*      */         }
/*      */ 
/* 1578 */         this.negotiatedEncryptionLevel = arrayOfByte2[i3];
/*      */ 
/* 1581 */         if ((0 != this.negotiatedEncryptionLevel) && (1 != this.negotiatedEncryptionLevel) && (3 != this.negotiatedEncryptionLevel) && (2 != this.negotiatedEncryptionLevel))
/*      */         {
/* 1586 */           connectionlogger.warning(new StringBuilder().append(toString()).append(" Server returned ").append(TDS.getEncryptionLevel(this.negotiatedEncryptionLevel)).toString());
/* 1587 */           throwInvalidTDS();
/*      */         }
/*      */ 
/* 1590 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 1591 */           connectionlogger.finer(new StringBuilder().append(toString()).append(" Negotiated encryption level:").append(TDS.getEncryptionLevel(this.negotiatedEncryptionLevel)).toString());
/*      */         }
/*      */ 
/* 1594 */         if ((1 == this.requestedEncryptionLevel) && (1 != this.negotiatedEncryptionLevel) && (3 != this.negotiatedEncryptionLevel))
/*      */         {
/* 1598 */           terminate(5, SQLServerException.getErrString("R_sslRequiredNoServerSupport"));
/*      */         }
/*      */ 
/* 1603 */         if ((2 != this.requestedEncryptionLevel) || (2 == this.negotiatedEncryptionLevel))
/*      */         {
/*      */           break;
/*      */         }
/* 1607 */         if (3 == this.negotiatedEncryptionLevel) {
/* 1608 */           terminate(5, SQLServerException.getErrString("R_sslRequiredByServer"));
/*      */         }
/* 1610 */         connectionlogger.warning(new StringBuilder().append(toString()).append(" Client requested encryption level: ").append(TDS.getEncryptionLevel(this.requestedEncryptionLevel)).append(" Server returned unexpected encryption level: ").append(TDS.getEncryptionLevel(this.negotiatedEncryptionLevel)).toString());
/*      */ 
/* 1613 */         throwInvalidTDS(); break;
/*      */       default:
/* 1619 */         if (!connectionlogger.isLoggable(Level.FINER)) break;
/* 1620 */         connectionlogger.finer(new StringBuilder().append(toString()).append(" Ignoring prelogin response option:").append(i2).toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1626 */     if ((n == 0) || (-1 == this.negotiatedEncryptionLevel))
/*      */     {
/* 1628 */       connectionlogger.warning(new StringBuilder().append(toString()).append(" Prelogin response is missing version and/or encryption option.").toString());
/* 1629 */       throwInvalidTDS();
/*      */     }
/*      */   }
/*      */ 
/*      */   final void throwInvalidTDS() throws SQLServerException
/*      */   {
/* 1635 */     terminate(4, SQLServerException.getErrString("R_invalidTDS"));
/*      */   }
/*      */ 
/*      */   final void throwInvalidTDSToken(String paramString) throws SQLServerException
/*      */   {
/* 1640 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unexpectedToken"));
/* 1641 */     Object[] arrayOfObject = { paramString };
/* 1642 */     String str = new StringBuilder().append(SQLServerException.getErrString("R_invalidTDS")).append(localMessageFormat.format(arrayOfObject)).toString();
/* 1643 */     terminate(4, str);
/*      */   }
/*      */ 
/*      */   final void terminate(int paramInt, String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 1654 */     terminate(paramInt, paramString, null);
/*      */   }
/*      */ 
/*      */   final void terminate(int paramInt, String paramString, Throwable paramThrowable) throws SQLServerException
/*      */   {
/* 1659 */     String str = this.state.equals(State.Opened) ? "08006" : "08001";
/*      */ 
/* 1664 */     if (!this.xopenStates) {
/* 1665 */       str = SQLServerException.mapFromXopen(str);
/*      */     }
/* 1667 */     SQLServerException localSQLServerException = new SQLServerException(this, SQLServerException.checkAndAppendClientConnId(paramString, this), str, 0, true);
/*      */ 
/* 1675 */     if (null != paramThrowable) {
/* 1676 */       localSQLServerException.initCause(paramThrowable);
/*      */     }
/* 1678 */     localSQLServerException.setDriverErrorCode(paramInt);
/*      */ 
/* 1680 */     notifyPooledConnection(localSQLServerException);
/*      */ 
/* 1682 */     close();
/*      */ 
/* 1684 */     throw localSQLServerException;
/*      */   }
/*      */ 
/*      */   boolean executeCommand(TDSCommand paramTDSCommand)
/*      */     throws SQLServerException
/*      */   {
/* 1695 */     synchronized (this.schedulerLock)
/*      */     {
/* 1702 */       if (null != this.currentCommand)
/*      */       {
/* 1704 */         this.currentCommand.detach();
/* 1705 */         this.currentCommand = null;
/*      */       }
/*      */ 
/* 1712 */       boolean bool = false;
/*      */       try
/*      */       {
/* 1715 */         bool = paramTDSCommand.execute(this.tdsChannel.getWriter(), this.tdsChannel.getReader(paramTDSCommand));
/*      */       }
/*      */       finally
/*      */       {
/* 1722 */         assert (null == this.currentCommand);
/*      */ 
/* 1728 */         if ((!bool) && (!isSessionUnAvailable())) {
/* 1729 */           this.currentCommand = paramTDSCommand;
/*      */         }
/*      */       }
/* 1732 */       return bool;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void connectionCommand(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/* 1761 */     executeCommand(new UninterruptableTDSCommand(paramString1, paramString2)
/*      */     {
/*      */       final String sql;
/*      */ 
/*      */       final boolean doExecute()
/*      */         throws SQLServerException
/*      */       {
/* 1755 */         startRequest(1).writeString(this.sql);
/* 1756 */         TDSParser.parse(startResponse(), getLogContext());
/* 1757 */         return true;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private String sqlStatementToInitialize()
/*      */   {
/* 1769 */     String str = null;
/* 1770 */     if (this.nLockTimeout > -1)
/* 1771 */       str = new StringBuilder().append(" set lock_timeout ").append(this.nLockTimeout).toString();
/* 1772 */     return str;
/*      */   }
/*      */ 
/*      */   void setCatalogName(String paramString)
/*      */   {
/* 1782 */     if (paramString != null)
/*      */     {
/* 1784 */       if (paramString.length() > 0)
/*      */       {
/* 1786 */         this.sCatalog = paramString;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   String sqlStatementToSetTransactionIsolationLevel()
/*      */     throws SQLServerException
/*      */   {
/* 1796 */     String str = "set transaction isolation level ";
/*      */ 
/* 1798 */     switch (this.transactionIsolationLevel) {
/*      */     case 1:
/* 1800 */       str = new StringBuilder().append(str).append(" read uncommitted ").toString();
/* 1801 */       break;
/*      */     case 2:
/* 1804 */       str = new StringBuilder().append(str).append(" read committed ").toString();
/* 1805 */       break;
/*      */     case 4:
/* 1808 */       str = new StringBuilder().append(str).append(" repeatable read ").toString();
/* 1809 */       break;
/*      */     case 8:
/* 1812 */       str = new StringBuilder().append(str).append(" serializable ").toString();
/* 1813 */       break;
/*      */     case 4096:
/* 1817 */       str = new StringBuilder().append(str).append(" snapshot ").toString();
/* 1818 */       break;
/*      */     default:
/* 1821 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidTransactionLevel"));
/* 1822 */       Object[] arrayOfObject = { Integer.toString(this.transactionIsolationLevel) };
/* 1823 */       SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(arrayOfObject), null, false);
/*      */     }
/*      */ 
/* 1827 */     return str;
/*      */   }
/*      */ 
/*      */   static String sqlStatementToSetCommit(boolean paramBoolean)
/*      */   {
/* 1836 */     return true == paramBoolean ? "set implicit_transactions off " : "set implicit_transactions on ";
/*      */   }
/*      */ 
/*      */   public Statement createStatement()
/*      */     throws SQLServerException
/*      */   {
/* 1844 */     loggerExternal.entering(getClassNameLogging(), "createStatement");
/* 1845 */     Statement localStatement = createStatement(1003, 1007);
/* 1846 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", localStatement);
/* 1847 */     return localStatement;
/*      */   }
/*      */ 
/*      */   public PreparedStatement prepareStatement(String paramString) throws SQLServerException
/*      */   {
/* 1852 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", paramString);
/* 1853 */     PreparedStatement localPreparedStatement = prepareStatement(paramString, 1003, 1007);
/* 1854 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localPreparedStatement);
/* 1855 */     return localPreparedStatement;
/*      */   }
/*      */ 
/*      */   public CallableStatement prepareCall(String paramString) throws SQLServerException
/*      */   {
/* 1860 */     loggerExternal.entering(getClassNameLogging(), "prepareCall", paramString);
/* 1861 */     CallableStatement localCallableStatement = prepareCall(paramString, 1003, 1007);
/* 1862 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", localCallableStatement);
/* 1863 */     return localCallableStatement;
/*      */   }
/*      */ 
/*      */   public String nativeSQL(String paramString) throws SQLServerException
/*      */   {
/* 1868 */     loggerExternal.entering(getClassNameLogging(), "nativeSQL", paramString);
/* 1869 */     checkClosed();
/* 1870 */     loggerExternal.exiting(getClassNameLogging(), "nativeSQL", paramString);
/* 1871 */     return paramString;
/*      */   }
/*      */ 
/*      */   public void setAutoCommit(boolean paramBoolean) throws SQLServerException
/*      */   {
/* 1876 */     if (loggerExternal.isLoggable(Level.FINER))
/*      */     {
/* 1878 */       loggerExternal.entering(getClassNameLogging(), "setAutoCommit", Boolean.valueOf(paramBoolean));
/* 1879 */       if (Util.IsActivityTraceOn())
/* 1880 */         loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1882 */     String str = "";
/* 1883 */     checkClosed();
/*      */ 
/* 1885 */     if (paramBoolean == this.databaseAutoCommitMode) {
/* 1886 */       return;
/*      */     }
/*      */ 
/* 1890 */     if (paramBoolean == true) {
/* 1891 */       str = "IF @@TRANCOUNT > 0 COMMIT TRAN ";
/*      */     }
/* 1893 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 1895 */       connectionlogger.finer(new StringBuilder().append(toString()).append(" Autocommitmode current :").append(this.databaseAutoCommitMode).append(" new: ").append(paramBoolean).toString());
/*      */     }
/*      */ 
/* 1900 */     this.rolledBackTransaction = false;
/* 1901 */     connectionCommand(new StringBuilder().append(str).append(sqlStatementToSetCommit(paramBoolean)).toString(), "setAutoCommit");
/* 1902 */     this.databaseAutoCommitMode = paramBoolean;
/* 1903 */     loggerExternal.exiting(getClassNameLogging(), "setAutoCommit");
/*      */   }
/*      */ 
/*      */   public boolean getAutoCommit() throws SQLServerException
/*      */   {
/* 1908 */     loggerExternal.entering(getClassNameLogging(), "getAutoCommit");
/* 1909 */     checkClosed();
/* 1910 */     boolean bool = (!this.inXATransaction) && (this.databaseAutoCommitMode);
/* 1911 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1912 */       loggerExternal.exiting(getClassNameLogging(), "getAutoCommit", Boolean.valueOf(bool));
/* 1913 */     return bool;
/*      */   }
/*      */ 
/*      */   final byte[] getTransactionDescriptor()
/*      */   {
/* 1919 */     return this.transactionDescriptor;
/*      */   }
/*      */ 
/*      */   public void commit()
/*      */     throws SQLServerException
/*      */   {
/* 1930 */     loggerExternal.entering(getClassNameLogging(), "commit");
/* 1931 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1933 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/*      */ 
/* 1936 */     checkClosed();
/* 1937 */     if (!this.databaseAutoCommitMode)
/* 1938 */       connectionCommand("IF @@TRANCOUNT > 0 COMMIT TRAN", "Connection.commit");
/* 1939 */     loggerExternal.exiting(getClassNameLogging(), "commit");
/*      */   }
/*      */ 
/*      */   public void rollback()
/*      */     throws SQLServerException
/*      */   {
/* 1949 */     loggerExternal.entering(getClassNameLogging(), "rollback");
/* 1950 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1952 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 1954 */     checkClosed();
/*      */ 
/* 1956 */     if (this.databaseAutoCommitMode)
/*      */     {
/* 1958 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), null, true);
/*      */     }
/*      */     else
/*      */     {
/* 1964 */       connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "Connection.rollback");
/* 1965 */     }loggerExternal.exiting(getClassNameLogging(), "rollback");
/*      */   }
/*      */ 
/*      */   public void close() throws SQLServerException
/*      */   {
/* 1970 */     loggerExternal.entering(getClassNameLogging(), "close");
/*      */ 
/* 1975 */     setState(State.Closed);
/*      */ 
/* 1980 */     if (null != this.tdsChannel)
/*      */     {
/* 1982 */       this.tdsChannel.close();
/*      */     }
/* 1984 */     loggerExternal.exiting(getClassNameLogging(), "close");
/*      */   }
/*      */ 
/*      */   final void poolCloseEventNotify()
/*      */     throws SQLServerException
/*      */   {
/* 1991 */     if ((this.state.equals(State.Opened)) && (null != this.pooledConnectionParent))
/*      */     {
/* 2001 */       if ((!this.databaseAutoCommitMode) && (!(this.pooledConnectionParent instanceof XAConnection)))
/*      */       {
/* 2003 */         connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "close connection");
/*      */       }
/*      */ 
/* 2006 */       notifyPooledConnection(null);
/* 2007 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/* 2009 */         connectionlogger.finer(new StringBuilder().append(toString()).append(" Connection closed and returned to connection pool").toString());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isClosed()
/*      */     throws SQLServerException
/*      */   {
/* 2018 */     loggerExternal.entering(getClassNameLogging(), "isClosed");
/* 2019 */     loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(isSessionUnAvailable()));
/* 2020 */     return isSessionUnAvailable();
/*      */   }
/*      */ 
/*      */   public DatabaseMetaData getMetaData() throws SQLServerException
/*      */   {
/* 2025 */     loggerExternal.entering(getClassNameLogging(), "getMetaData");
/* 2026 */     checkClosed();
/* 2027 */     if (this.databaseMetaData == null)
/*      */     {
/* 2029 */       this.databaseMetaData = new SQLServerDatabaseMetaData(this);
/*      */     }
/* 2031 */     loggerExternal.exiting(getClassNameLogging(), "getMetaData", this.databaseMetaData);
/* 2032 */     return this.databaseMetaData;
/*      */   }
/*      */ 
/*      */   public void setReadOnly(boolean paramBoolean) throws SQLServerException
/*      */   {
/* 2037 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2038 */       loggerExternal.entering(getClassNameLogging(), "setReadOnly", Boolean.valueOf(paramBoolean));
/* 2039 */     checkClosed();
/*      */ 
/* 2041 */     loggerExternal.exiting(getClassNameLogging(), "setReadOnly");
/*      */   }
/*      */ 
/*      */   public boolean isReadOnly() throws SQLServerException
/*      */   {
/* 2046 */     loggerExternal.entering(getClassNameLogging(), "isReadOnly");
/* 2047 */     checkClosed();
/* 2048 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2049 */       loggerExternal.exiting(getClassNameLogging(), "isReadOnly", Boolean.valueOf(false));
/* 2050 */     return false;
/*      */   }
/*      */ 
/*      */   public void setCatalog(String paramString) throws SQLServerException
/*      */   {
/* 2055 */     loggerExternal.entering(getClassNameLogging(), "setCatalog", paramString);
/* 2056 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2058 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 2060 */     checkClosed();
/* 2061 */     if (paramString != null)
/*      */     {
/* 2063 */       connectionCommand(new StringBuilder().append("use ").append(Util.escapeSQLId(paramString)).toString(), "setCatalog");
/* 2064 */       this.sCatalog = paramString;
/*      */     }
/* 2066 */     loggerExternal.exiting(getClassNameLogging(), "setCatalog");
/*      */   }
/*      */ 
/*      */   public String getCatalog() throws SQLServerException
/*      */   {
/* 2071 */     loggerExternal.entering(getClassNameLogging(), "getCatalog");
/* 2072 */     checkClosed();
/* 2073 */     loggerExternal.exiting(getClassNameLogging(), "getCatalog", this.sCatalog);
/* 2074 */     return this.sCatalog;
/*      */   }
/*      */ 
/*      */   public void setTransactionIsolation(int paramInt) throws SQLServerException
/*      */   {
/* 2079 */     if (loggerExternal.isLoggable(Level.FINER))
/*      */     {
/* 2081 */       loggerExternal.entering(getClassNameLogging(), "setTransactionIsolation", new Integer(paramInt));
/* 2082 */       if (Util.IsActivityTraceOn())
/*      */       {
/* 2084 */         loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */       }
/*      */     }
/*      */ 
/* 2088 */     checkClosed();
/* 2089 */     if (paramInt == 0) {
/* 2090 */       return;
/*      */     }
/*      */ 
/* 2093 */     this.transactionIsolationLevel = paramInt;
/* 2094 */     String str = sqlStatementToSetTransactionIsolationLevel();
/* 2095 */     connectionCommand(str, "setTransactionIsolation");
/* 2096 */     loggerExternal.exiting(getClassNameLogging(), "setTransactionIsolation");
/*      */   }
/*      */ 
/*      */   public int getTransactionIsolation() throws SQLServerException
/*      */   {
/* 2101 */     loggerExternal.entering(getClassNameLogging(), "getTransactionIsolation");
/* 2102 */     checkClosed();
/* 2103 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2104 */       loggerExternal.exiting(getClassNameLogging(), "getTransactionIsolation", new Integer(this.transactionIsolationLevel));
/* 2105 */     return this.transactionIsolationLevel;
/*      */   }
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLServerException
/*      */   {
/* 2114 */     loggerExternal.entering(getClassNameLogging(), "getWarnings");
/* 2115 */     checkClosed();
/*      */ 
/* 2117 */     loggerExternal.exiting(getClassNameLogging(), "getWarnings", this.sqlWarnings);
/* 2118 */     return this.sqlWarnings;
/*      */   }
/*      */ 
/*      */   private void addWarning(String paramString)
/*      */   {
/* 2124 */     synchronized (this.warningSynchronization)
/*      */     {
/* 2126 */       SQLWarning localSQLWarning = new SQLWarning(paramString);
/*      */ 
/* 2129 */       if (null == this.sqlWarnings)
/*      */       {
/* 2131 */         this.sqlWarnings = localSQLWarning;
/*      */       }
/*      */       else
/*      */       {
/* 2135 */         this.sqlWarnings.setNextWarning(localSQLWarning);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void clearWarnings() throws SQLServerException
/*      */   {
/* 2142 */     synchronized (this.warningSynchronization)
/*      */     {
/* 2144 */       loggerExternal.entering(getClassNameLogging(), "clearWarnings");
/* 2145 */       checkClosed();
/* 2146 */       this.sqlWarnings = null;
/* 2147 */       loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
/*      */     }
/*      */   }
/*      */ 
/*      */   public Statement createStatement(int paramInt1, int paramInt2)
/*      */     throws SQLServerException
/*      */   {
/* 2154 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2155 */       loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2) });
/* 2156 */     checkClosed();
/* 2157 */     SQLServerStatement localSQLServerStatement = new SQLServerStatement(this, paramInt1, paramInt2);
/* 2158 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", localSQLServerStatement);
/* 2159 */     return localSQLServerStatement;
/*      */   }
/*      */ 
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 2164 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2165 */       loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) });
/* 2166 */     checkClosed();
/* 2167 */     SQLServerPreparedStatement localSQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2);
/* 2168 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 2169 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 2174 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2175 */       loggerExternal.entering(getClassNameLogging(), "prepareCall", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) });
/* 2176 */     checkClosed();
/* 2177 */     SQLServerCallableStatement localSQLServerCallableStatement = new SQLServerCallableStatement(this, paramString, paramInt1, paramInt2);
/* 2178 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", localSQLServerCallableStatement);
/* 2179 */     return localSQLServerCallableStatement;
/*      */   }
/*      */ 
/*      */   public void setTypeMap(Map paramMap) throws SQLServerException
/*      */   {
/* 2184 */     loggerExternal.entering(getClassNameLogging(), "setTypeMap", paramMap);
/* 2185 */     checkClosed();
/* 2186 */     if ((paramMap != null) && ((paramMap instanceof HashMap)))
/*      */     {
/* 2189 */       if (paramMap.isEmpty())
/*      */       {
/* 2191 */         loggerExternal.exiting(getClassNameLogging(), "setTypeMap");
/* 2192 */         return;
/*      */       }
/*      */     }
/*      */ 
/* 2196 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   public Map<String, Class<?>> getTypeMap() throws SQLServerException
/*      */   {
/* 2201 */     loggerExternal.entering(getClassNameLogging(), "getTypeMap");
/* 2202 */     checkClosed();
/* 2203 */     HashMap localHashMap = new HashMap();
/* 2204 */     loggerExternal.exiting(getClassNameLogging(), "getTypeMap", localHashMap);
/* 2205 */     return localHashMap;
/*      */   }
/*      */ 
/*      */   private final void logon(LogonCommand paramLogonCommand)
/*      */     throws SQLServerException
/*      */   {
/* 2227 */     Object localObject1 = null;
/* 2228 */     if ((this.integratedSecurity) && (AuthenticationScheme.nativeAuthentication == this.intAuthScheme))
/* 2229 */       localObject1 = new AuthenticationJNI(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber());
/* 2230 */     if ((this.integratedSecurity) && (AuthenticationScheme.javaKerberos == this.intAuthScheme))
/* 2231 */       localObject1 = new KerbAuthentication(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber());
/*      */     try
/*      */     {
/* 2234 */       sendLogon(paramLogonCommand, (SSPIAuthentication)localObject1);
/*      */ 
/* 2239 */       if (!this.isRoutedInCurrentAttempt)
/*      */       {
/* 2241 */         this.originalCatalog = this.sCatalog;
/* 2242 */         String str = sqlStatementToInitialize();
/* 2243 */         if (str != null)
/*      */         {
/* 2245 */           connectionCommand(str, "Change Settings");
/*      */         }
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 2251 */       if (this.integratedSecurity)
/*      */       {
/* 2253 */         if (null != localObject1)
/* 2254 */           ((SSPIAuthentication)localObject1).ReleaseClientContext();
/* 2255 */         localObject1 = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   final void processEnvChange(TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 2284 */     paramTDSReader.readUnsignedByte();
/* 2285 */     int i = paramTDSReader.readUnsignedShort();
/*      */ 
/* 2287 */     TDSReaderMark localTDSReaderMark = paramTDSReader.mark();
/* 2288 */     int j = paramTDSReader.readUnsignedByte();
/* 2289 */     switch (j)
/*      */     {
/*      */     case 4:
/*      */       try
/*      */       {
/* 2295 */         this.tdsPacketSize = Integer.parseInt(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
/*      */       }
/*      */       catch (NumberFormatException localNumberFormatException)
/*      */       {
/* 2299 */         paramTDSReader.throwInvalidTDS();
/*      */       }
/* 2301 */       if (!connectionlogger.isLoggable(Level.FINER)) break;
/* 2302 */       connectionlogger.finer(new StringBuilder().append(toString()).append(" Network packet size is ").append(this.tdsPacketSize).append(" bytes").toString()); break;
/*      */     case 7:
/* 2306 */       if (SQLCollation.tdsLength() != paramTDSReader.readUnsignedByte()) {
/* 2307 */         paramTDSReader.throwInvalidTDS();
/*      */       }
/*      */       try
/*      */       {
/* 2311 */         this.databaseCollation = new SQLCollation(paramTDSReader);
/*      */       }
/*      */       catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */       {
/* 2315 */         terminate(4, localUnsupportedEncodingException.getMessage(), localUnsupportedEncodingException);
/*      */       }
/*      */ 
/*      */     case 8:
/*      */     case 11:
/* 2322 */       this.rolledBackTransaction = false;
/* 2323 */       byte[] arrayOfByte = getTransactionDescriptor();
/*      */ 
/* 2325 */       if (arrayOfByte.length != paramTDSReader.readUnsignedByte()) {
/* 2326 */         paramTDSReader.throwInvalidTDS();
/*      */       }
/* 2328 */       paramTDSReader.readBytes(arrayOfByte, 0, arrayOfByte.length);
/*      */ 
/* 2330 */       if (!connectionlogger.isLoggable(Level.FINER))
/*      */         break;
/*      */       String str1;
/* 2333 */       if (8 == j)
/* 2334 */         str1 = " started";
/*      */       else {
/* 2336 */         str1 = " enlisted";
/*      */       }
/* 2338 */       connectionlogger.finer(new StringBuilder().append(toString()).append(str1).toString());
/*      */ 
/* 2340 */       break;
/*      */     case 10:
/* 2344 */       this.rolledBackTransaction = true;
/*      */ 
/* 2346 */       if (this.inXATransaction)
/*      */       {
/* 2348 */         if (!connectionlogger.isLoggable(Level.FINER)) break;
/* 2349 */         connectionlogger.finer(new StringBuilder().append(toString()).append(" rolled back. (DTC)").toString());
/*      */       }
/*      */       else
/*      */       {
/* 2358 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 2359 */           connectionlogger.finer(new StringBuilder().append(toString()).append(" rolled back").toString());
/*      */         }
/*      */ 
/* 2362 */         Arrays.fill(getTransactionDescriptor(), 0);
/*      */       }
/*      */ 
/* 2365 */       break;
/*      */     case 9:
/* 2368 */       if (connectionlogger.isLoggable(Level.FINER)) {
/* 2369 */         connectionlogger.finer(new StringBuilder().append(toString()).append(" committed").toString());
/*      */       }
/* 2371 */       Arrays.fill(getTransactionDescriptor(), 0);
/*      */ 
/* 2373 */       break;
/*      */     case 12:
/* 2376 */       if (connectionlogger.isLoggable(Level.FINER)) {
/* 2377 */         connectionlogger.finer(new StringBuilder().append(toString()).append(" defected").toString());
/*      */       }
/* 2379 */       Arrays.fill(getTransactionDescriptor(), 0);
/*      */ 
/* 2381 */       break;
/*      */     case 1:
/* 2384 */       setCatalogName(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
/* 2385 */       break;
/*      */     case 13:
/* 2388 */       setFailoverPartnerServerProvided(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
/* 2389 */       break;
/*      */     case 2:
/*      */     case 3:
/*      */     case 5:
/*      */     case 6:
/*      */     case 15:
/*      */     case 16:
/*      */     case 17:
/*      */     case 18:
/*      */     case 19:
/* 2400 */       if (!connectionlogger.isLoggable(Level.FINER)) break;
/* 2401 */       connectionlogger.finer(new StringBuilder().append(toString()).append(" Ignored env change: ").append(j).toString()); break;
/*      */     case 20:
/*      */       int i1;
/*      */       int n;
/*      */       int m;
/* 2407 */       int k = m = n = i1 = -1;
/*      */ 
/* 2409 */       String str2 = null;
/*      */       try
/*      */       {
/* 2413 */         k = paramTDSReader.readUnsignedShort();
/* 2414 */         if (k <= 5)
/*      */         {
/* 2416 */           throwInvalidTDS();
/*      */         }
/*      */ 
/* 2419 */         m = paramTDSReader.readUnsignedByte();
/* 2420 */         if (m != 0)
/*      */         {
/* 2422 */           throwInvalidTDS();
/*      */         }
/*      */ 
/* 2425 */         n = paramTDSReader.readUnsignedShort();
/* 2426 */         if ((n <= 0) || (n > 65535))
/*      */         {
/* 2428 */           throwInvalidTDS();
/*      */         }
/*      */ 
/* 2431 */         i1 = paramTDSReader.readUnsignedShort();
/* 2432 */         if ((i1 <= 0) || (i1 > 1024))
/*      */         {
/* 2434 */           throwInvalidTDS();
/*      */         }
/*      */ 
/* 2437 */         str2 = paramTDSReader.readUnicodeString(i1);
/* 2438 */         if ((!$assertionsDisabled) && (str2 == null)) throw new AssertionError();
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/* 2443 */         if (connectionlogger.isLoggable(Level.FINER))
/*      */         {
/* 2445 */           connectionlogger.finer(new StringBuilder().append(toString()).append(" Received routing ENVCHANGE with the following values.").append(" routingDataValueLength:").append(k).append(" protocol:").append(m).append(" portNumber:").append(n).append(" serverNameLength:").append(i1).append(" serverName:").append(str2 != null ? str2 : "null").toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2455 */       this.isRoutedInCurrentAttempt = true;
/* 2456 */       this.routingInfo = new ServerPortPlaceHolder(str2, n, null, this.integratedSecurity);
/*      */ 
/* 2458 */       break;
/*      */     case 14:
/*      */     default:
/* 2462 */       connectionlogger.warning(new StringBuilder().append(toString()).append(" Unknown environment change: ").append(j).toString());
/* 2463 */       throwInvalidTDS();
/*      */     }
/*      */ 
/* 2469 */     paramTDSReader.reset(localTDSReaderMark);
/* 2470 */     paramTDSReader.readBytes(new byte[i], 0, i);
/*      */   }
/*      */ 
/*      */   private final void executeDTCCommand(int paramInt, byte[] paramArrayOfByte, String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 2514 */     executeCommand(new UninterruptableTDSCommand(paramInt, paramArrayOfByte, paramString)
/*      */     {
/*      */       private final int requestType;
/*      */       private final byte[] payload;
/*      */ 
/*      */       final boolean doExecute()
/*      */         throws SQLServerException
/*      */       {
/* 2495 */         TDSWriter localTDSWriter = startRequest(14);
/*      */ 
/* 2497 */         localTDSWriter.writeShort((short)this.requestType);
/* 2498 */         if (null == this.payload)
/*      */         {
/* 2500 */           localTDSWriter.writeShort(0);
/*      */         }
/*      */         else
/*      */         {
/* 2504 */           assert (this.payload.length <= 32767);
/* 2505 */           localTDSWriter.writeShort((short)this.payload.length);
/* 2506 */           localTDSWriter.writeBytes(this.payload);
/*      */         }
/*      */ 
/* 2509 */         TDSParser.parse(startResponse(), getLogContext());
/* 2510 */         return true;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   final void JTAUnenlistConnection()
/*      */     throws SQLServerException
/*      */   {
/* 2524 */     executeDTCCommand(1, null, "MS_DTC unenlist connection");
/* 2525 */     this.inXATransaction = false;
/*      */   }
/*      */ 
/*      */   final void JTAEnlistConnection(byte[] paramArrayOfByte)
/*      */     throws SQLServerException
/*      */   {
/* 2536 */     executeDTCCommand(1, paramArrayOfByte, "MS_DTC enlist connection");
/*      */ 
/* 2540 */     connectionCommand(sqlStatementToSetTransactionIsolationLevel(), "JTAEnlistConnection");
/* 2541 */     this.inXATransaction = true;
/*      */   }
/*      */ 
/*      */   private byte[] toUCS16(String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 2554 */     if (paramString == null)
/* 2555 */       return new byte[0];
/* 2556 */     int i = paramString.length();
/* 2557 */     byte[] arrayOfByte = new byte[i * 2];
/* 2558 */     int j = 0;
/* 2559 */     for (int k = 0; k < i; k++) {
/* 2560 */       int m = paramString.charAt(k);
/* 2561 */       int n = (byte)(m & 0xFF);
/* 2562 */       arrayOfByte[(j++)] = n;
/* 2563 */       arrayOfByte[(j++)] = (byte)(m >> 8 & 0xFF);
/*      */     }
/* 2565 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   private byte[] encryptPassword(String paramString)
/*      */   {
/* 2575 */     if (paramString == null) paramString = "";
/* 2576 */     int i = paramString.length();
/* 2577 */     byte[] arrayOfByte = new byte[i * 2];
/* 2578 */     for (int j = 0; j < i; j++) {
/* 2579 */       int k = paramString.charAt(j) ^ 0x5A5A;
/* 2580 */       k = (k & 0xF) << 4 | (k & 0xF0) >> 4 | (k & 0xF00) << 4 | (k & 0xF000) >> 4;
/* 2581 */       int m = (byte)((k & 0xFF00) >> 8);
/* 2582 */       arrayOfByte[(j * 2 + 1)] = m;
/* 2583 */       int n = (byte)(k & 0xFF);
/* 2584 */       arrayOfByte[(j * 2 + 0)] = n;
/*      */     }
/* 2586 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   private void sendLogon(LogonCommand paramLogonCommand, SSPIAuthentication paramSSPIAuthentication)
/*      */     throws SQLServerException
/*      */   {
/* 2671 */     String str1 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.WORKSTATION_ID.toString());
/* 2672 */     String str2 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString());
/* 2673 */     String str3 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString());
/* 2674 */     String str4 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.APPLICATION_NAME.toString());
/* 2675 */     String str5 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString());
/* 2676 */     String str6 = "Microsoft JDBC Driver 4.0";
/* 2677 */     String str7 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString());
/*      */ 
/* 2679 */     if ((str5 != null) && (str5.length() > 128)) {
/* 2680 */       str5 = str5.substring(0, 128);
/*      */     }
/* 2682 */     if ((str1 == null) || (str1.length() == 0))
/*      */     {
/* 2684 */       str1 = Util.lookupHostName();
/*      */     }
/*      */ 
/* 2687 */     byte[] arrayOfByte1 = new byte[0];
/* 2688 */     boolean[] arrayOfBoolean = { false };
/* 2689 */     if (null != paramSSPIAuthentication)
/*      */     {
/* 2691 */       arrayOfByte1 = paramSSPIAuthentication.GenerateClientContext(arrayOfByte1, arrayOfBoolean);
/* 2692 */       str2 = null;
/* 2693 */       str3 = null;
/*      */     }
/*      */ 
/* 2696 */     byte[] arrayOfByte2 = toUCS16(str1);
/* 2697 */     byte[] arrayOfByte3 = toUCS16(str2);
/* 2698 */     byte[] arrayOfByte4 = encryptPassword(str3);
/* 2699 */     int i = arrayOfByte4 != null ? arrayOfByte4.length : 0;
/* 2700 */     byte[] arrayOfByte5 = toUCS16(str4);
/* 2701 */     byte[] arrayOfByte6 = toUCS16(str5);
/* 2702 */     byte[] arrayOfByte7 = toUCS16(str6);
/* 2703 */     byte[] arrayOfByte8 = toUCS16(str7);
/* 2704 */     byte[] arrayOfByte9 = new byte[6];
/* 2705 */     int j = 0;
/* 2706 */     int k = 0;
/*      */ 
/* 2710 */     if (this.serverMajorVersion >= 11)
/*      */     {
/* 2712 */       this.tdsVersion = 1946157060;
/*      */     }
/* 2714 */     else if (this.serverMajorVersion >= 10)
/*      */     {
/* 2716 */       this.tdsVersion = 1930100739;
/*      */     }
/* 2719 */     else if (this.serverMajorVersion >= 9)
/*      */     {
/* 2721 */       this.tdsVersion = 1913192450;
/*      */     }
/* 2725 */     else if (!$assertionsDisabled) throw new AssertionError(new StringBuilder().append("prelogin did not disconnect for the old version: ").append(this.serverMajorVersion).toString());
/*      */ 
/* 2728 */     j = i + arrayOfByte2.length + arrayOfByte3.length + arrayOfByte5.length + arrayOfByte6.length + arrayOfByte7.length + arrayOfByte8.length + 94 + arrayOfByte1.length;
/*      */ 
/* 2739 */     TDSWriter localTDSWriter = paramLogonCommand.startRequest(16);
/*      */ 
/* 2742 */     localTDSWriter.writeInt(j);
/* 2743 */     localTDSWriter.writeInt(this.tdsVersion);
/* 2744 */     localTDSWriter.writeInt(this.requestedPacketSize);
/* 2745 */     localTDSWriter.writeInt(0);
/* 2746 */     localTDSWriter.writeInt(0);
/* 2747 */     localTDSWriter.writeInt(0);
/*      */ 
/* 2749 */     localTDSWriter.writeByte(-32);
/*      */ 
/* 2759 */     localTDSWriter.writeByte((byte)(0x3 | (this.integratedSecurity ? -128 : 0)));
/*      */ 
/* 2768 */     localTDSWriter.writeByte((byte)(0x0 | ((this.applicationIntent != null) && (this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) ? 32 : 0)));
/*      */ 
/* 2779 */     localTDSWriter.writeByte((byte)(0x0 | (this.serverMajorVersion >= 10 ? 8 : 0)));
/*      */ 
/* 2784 */     localTDSWriter.writeInt(0);
/* 2785 */     localTDSWriter.writeInt(0);
/*      */ 
/* 2787 */     localTDSWriter.writeShort(94);
/*      */ 
/* 2790 */     localTDSWriter.writeShort((short)(str1 == null ? 0 : str1.length()));
/* 2791 */     k += arrayOfByte2.length;
/*      */ 
/* 2793 */     if (!this.integratedSecurity)
/*      */     {
/* 2796 */       localTDSWriter.writeShort((short)(94 + k));
/* 2797 */       localTDSWriter.writeShort((short)(str2 == null ? 0 : str2.length()));
/* 2798 */       k += arrayOfByte3.length;
/*      */ 
/* 2800 */       localTDSWriter.writeShort((short)(94 + k));
/* 2801 */       localTDSWriter.writeShort((short)(str3 == null ? 0 : str3.length()));
/* 2802 */       k += i;
/*      */     }
/*      */     else
/*      */     {
/* 2808 */       localTDSWriter.writeShort(0);
/* 2809 */       localTDSWriter.writeShort(0);
/* 2810 */       localTDSWriter.writeShort(0);
/* 2811 */       localTDSWriter.writeShort(0);
/*      */     }
/*      */ 
/* 2815 */     localTDSWriter.writeShort((short)(94 + k));
/* 2816 */     localTDSWriter.writeShort((short)(str4 == null ? 0 : str4.length()));
/* 2817 */     k += arrayOfByte5.length;
/*      */ 
/* 2820 */     localTDSWriter.writeShort((short)(94 + k));
/* 2821 */     localTDSWriter.writeShort((short)(str5 == null ? 0 : str5.length()));
/* 2822 */     k += arrayOfByte6.length;
/*      */ 
/* 2825 */     localTDSWriter.writeShort(0);
/* 2826 */     localTDSWriter.writeShort(0);
/*      */ 
/* 2829 */     assert (null != str6);
/* 2830 */     localTDSWriter.writeShort((short)(94 + k));
/* 2831 */     localTDSWriter.writeShort((short)str6.length());
/* 2832 */     k += arrayOfByte7.length;
/*      */ 
/* 2835 */     localTDSWriter.writeShort(0);
/* 2836 */     localTDSWriter.writeShort(0);
/*      */ 
/* 2839 */     localTDSWriter.writeShort((short)(94 + k));
/* 2840 */     localTDSWriter.writeShort((short)(str7 == null ? 0 : str7.length()));
/* 2841 */     k += arrayOfByte8.length;
/*      */ 
/* 2844 */     localTDSWriter.writeBytes(arrayOfByte9);
/*      */ 
/* 2848 */     if (!this.integratedSecurity)
/*      */     {
/* 2850 */       localTDSWriter.writeShort(0);
/* 2851 */       localTDSWriter.writeShort(0);
/*      */     }
/*      */     else
/*      */     {
/* 2855 */       localTDSWriter.writeShort((short)(94 + k));
/* 2856 */       if (65535 <= arrayOfByte1.length)
/*      */       {
/* 2858 */         localTDSWriter.writeShort(-1);
/*      */       }
/*      */       else {
/* 2861 */         localTDSWriter.writeShort((short)arrayOfByte1.length);
/*      */       }
/*      */     }
/*      */ 
/* 2865 */     localTDSWriter.writeShort(0);
/* 2866 */     localTDSWriter.writeShort(0);
/*      */ 
/* 2868 */     if (this.tdsVersion >= 1913192450)
/*      */     {
/* 2871 */       localTDSWriter.writeShort(0);
/* 2872 */       localTDSWriter.writeShort(0);
/*      */ 
/* 2875 */       if (65535 <= arrayOfByte1.length)
/* 2876 */         localTDSWriter.writeInt(arrayOfByte1.length);
/*      */       else {
/* 2878 */         localTDSWriter.writeInt(0);
/*      */       }
/*      */     }
/* 2881 */     localTDSWriter.writeBytes(arrayOfByte2);
/*      */ 
/* 2884 */     localTDSWriter.setDataLoggable(false);
/* 2885 */     if (!this.integratedSecurity)
/*      */     {
/* 2887 */       localTDSWriter.writeBytes(arrayOfByte3);
/* 2888 */       localTDSWriter.writeBytes(arrayOfByte4);
/*      */     }
/* 2890 */     localTDSWriter.setDataLoggable(true);
/*      */ 
/* 2892 */     localTDSWriter.writeBytes(arrayOfByte5);
/* 2893 */     localTDSWriter.writeBytes(arrayOfByte6);
/* 2894 */     localTDSWriter.writeBytes(arrayOfByte7);
/* 2895 */     localTDSWriter.writeBytes(arrayOfByte8);
/*      */ 
/* 2898 */     localTDSWriter.setDataLoggable(false);
/* 2899 */     if (this.integratedSecurity)
/* 2900 */       localTDSWriter.writeBytes(arrayOfByte1, 0, arrayOfByte1.length);
/* 2901 */     localTDSWriter.setDataLoggable(true);
/*      */ 
/* 2903 */     1LogonProcessor local1LogonProcessor = new TDSTokenHandler(paramSSPIAuthentication)
/*      */     {
/*      */       private final SSPIAuthentication auth;
/* 2608 */       private byte[] secBlobOut = null;
/*      */       StreamLoginAck loginAckToken;
/*      */ 
/*      */       boolean onSSPI(TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/* 2620 */         StreamSSPI localStreamSSPI = new StreamSSPI();
/* 2621 */         localStreamSSPI.setFromTDS(paramTDSReader);
/*      */ 
/* 2626 */         boolean[] arrayOfBoolean = { false };
/* 2627 */         this.secBlobOut = this.auth.GenerateClientContext(localStreamSSPI.sspiBlob, arrayOfBoolean);
/* 2628 */         return true;
/*      */       }
/*      */ 
/*      */       boolean onLoginAck(TDSReader paramTDSReader) throws SQLServerException
/*      */       {
/* 2633 */         this.loginAckToken = new StreamLoginAck();
/* 2634 */         this.loginAckToken.setFromTDS(paramTDSReader);
/* 2635 */         SQLServerConnection.this.sqlServerVersion = this.loginAckToken.sSQLServerVersion;
/* 2636 */         SQLServerConnection.access$102(SQLServerConnection.this, this.loginAckToken.tdsVersion);
/* 2637 */         return true;
/*      */       }
/*      */ 
/*      */       final boolean complete(SQLServerConnection.LogonCommand paramLogonCommand, TDSReader paramTDSReader)
/*      */         throws SQLServerException
/*      */       {
/* 2643 */         if (null != this.loginAckToken) {
/* 2644 */           return true;
/*      */         }
/*      */ 
/* 2647 */         if ((null != this.secBlobOut) && (0 != this.secBlobOut.length))
/*      */         {
/* 2651 */           paramLogonCommand.startRequest(17).writeBytes(this.secBlobOut, 0, this.secBlobOut.length);
/* 2652 */           return false;
/*      */         }
/*      */ 
/* 2661 */         paramLogonCommand.startRequest(17);
/* 2662 */         paramLogonCommand.onRequestComplete();
/* 2663 */         SQLServerConnection.this.tdsChannel.numMsgsSent += 1;
/*      */ 
/* 2665 */         TDSParser.parse(paramTDSReader, this);
/* 2666 */         return true;
/*      */       }
/*      */ 
/*      */     };
/*      */     TDSReader localTDSReader;
/*      */     do
/*      */     {
/* 2907 */       localTDSReader = paramLogonCommand.startResponse();
/* 2908 */       TDSParser.parse(localTDSReader, local1LogonProcessor);
/*      */     }
/* 2910 */     while (!local1LogonProcessor.complete(paramLogonCommand, localTDSReader));
/*      */   }
/*      */ 
/*      */   private void checkValidHoldability(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2921 */     if ((paramInt != 1) && (paramInt != 2))
/*      */     {
/* 2924 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidHoldability"));
/* 2925 */       SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(new Object[] { Integer.valueOf(paramInt) }), null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkMatchesCurrentHoldability(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2944 */     if (paramInt != this.holdability)
/*      */     {
/* 2946 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_sqlServerHoldability"), null, false);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLServerException
/*      */   {
/* 2955 */     loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
/* 2956 */     checkClosed();
/* 2957 */     checkValidHoldability(paramInt3);
/* 2958 */     checkMatchesCurrentHoldability(paramInt3);
/* 2959 */     Statement localStatement = createStatement(paramInt1, paramInt2);
/* 2960 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", localStatement);
/* 2961 */     return localStatement;
/*      */   }
/*      */ 
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*      */   {
/* 2966 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
/* 2967 */     checkClosed();
/* 2968 */     checkValidHoldability(paramInt3);
/* 2969 */     checkMatchesCurrentHoldability(paramInt3);
/* 2970 */     PreparedStatement localPreparedStatement = prepareStatement(paramString, paramInt1, paramInt2);
/* 2971 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localPreparedStatement);
/* 2972 */     return localPreparedStatement;
/*      */   }
/*      */ 
/*      */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*      */   {
/* 2977 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
/* 2978 */     checkClosed();
/* 2979 */     checkValidHoldability(paramInt3);
/* 2980 */     checkMatchesCurrentHoldability(paramInt3);
/* 2981 */     CallableStatement localCallableStatement = prepareCall(paramString, paramInt1, paramInt2);
/* 2982 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", localCallableStatement);
/* 2983 */     return localCallableStatement;
/*      */   }
/*      */ 
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2990 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt) });
/* 2991 */     checkClosed();
/* 2992 */     SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString);
/* 2993 */     localSQLServerPreparedStatement.bRequestedGeneratedKeys = (paramInt == 1);
/* 2994 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 2995 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfInt) throws SQLServerException
/*      */   {
/* 3000 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfInt });
/* 3001 */     checkClosed();
/* 3002 */     if ((paramArrayOfInt == null) || (paramArrayOfInt.length != 1)) {
/* 3003 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), null, false);
/*      */     }
/*      */ 
/* 3006 */     SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString);
/* 3007 */     localSQLServerPreparedStatement.bRequestedGeneratedKeys = true;
/* 3008 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 3009 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLServerException
/*      */   {
/* 3014 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfString });
/* 3015 */     checkClosed();
/* 3016 */     if ((paramArrayOfString == null) || (paramArrayOfString.length != 1))
/*      */     {
/* 3018 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), null, false);
/*      */     }
/*      */ 
/* 3021 */     SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString);
/* 3022 */     localSQLServerPreparedStatement.bRequestedGeneratedKeys = true;
/* 3023 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 3024 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   public void releaseSavepoint(Savepoint paramSavepoint)
/*      */     throws SQLServerException
/*      */   {
/* 3031 */     loggerExternal.entering(getClassNameLogging(), "releaseSavepoint", paramSavepoint);
/* 3032 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   private final Savepoint setNamedSavepoint(String paramString) throws SQLServerException
/*      */   {
/* 3037 */     if (true == this.databaseAutoCommitMode)
/*      */     {
/* 3039 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantSetSavepoint"), null, false);
/*      */     }
/*      */ 
/* 3047 */     SQLServerSavepoint localSQLServerSavepoint = new SQLServerSavepoint(this, paramString);
/*      */ 
/* 3056 */     connectionCommand(new StringBuilder().append("IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN IF @@TRANCOUNT = 2 COMMIT TRAN END SAVE TRAN ").append(Util.escapeSQLId(localSQLServerSavepoint.getLabel())).toString(), "setSavepoint");
/*      */ 
/* 3060 */     return localSQLServerSavepoint;
/*      */   }
/*      */ 
/*      */   public Savepoint setSavepoint(String paramString) throws SQLServerException
/*      */   {
/* 3065 */     loggerExternal.entering(getClassNameLogging(), "setSavepoint", paramString);
/* 3066 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 3068 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 3070 */     checkClosed();
/* 3071 */     Savepoint localSavepoint = setNamedSavepoint(paramString);
/* 3072 */     loggerExternal.exiting(getClassNameLogging(), "setSavepoint", localSavepoint);
/* 3073 */     return localSavepoint;
/*      */   }
/*      */ 
/*      */   public Savepoint setSavepoint() throws SQLServerException
/*      */   {
/* 3078 */     loggerExternal.entering(getClassNameLogging(), "setSavepoint");
/* 3079 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 3081 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 3083 */     checkClosed();
/* 3084 */     Savepoint localSavepoint = setNamedSavepoint(null);
/* 3085 */     loggerExternal.exiting(getClassNameLogging(), "setSavepoint", localSavepoint);
/* 3086 */     return localSavepoint;
/*      */   }
/*      */ 
/*      */   public void rollback(Savepoint paramSavepoint) throws SQLServerException
/*      */   {
/* 3091 */     loggerExternal.entering(getClassNameLogging(), "rollback", paramSavepoint);
/* 3092 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 3094 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 3096 */     checkClosed();
/* 3097 */     if (true == this.databaseAutoCommitMode)
/*      */     {
/* 3099 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), null, false);
/*      */     }
/*      */ 
/* 3106 */     connectionCommand(new StringBuilder().append("IF @@TRANCOUNT > 0 ROLLBACK TRAN ").append(Util.escapeSQLId(((SQLServerSavepoint)paramSavepoint).getLabel())).toString(), "rollbackSavepoint");
/*      */ 
/* 3109 */     loggerExternal.exiting(getClassNameLogging(), "rollback");
/*      */   }
/*      */ 
/*      */   public int getHoldability() throws SQLServerException
/*      */   {
/* 3114 */     loggerExternal.entering(getClassNameLogging(), "getHoldability");
/* 3115 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3116 */       loggerExternal.exiting(getClassNameLogging(), "getHoldability", Integer.valueOf(this.holdability));
/* 3117 */     return this.holdability;
/*      */   }
/*      */ 
/*      */   public void setHoldability(int paramInt) throws SQLServerException
/*      */   {
/* 3122 */     loggerExternal.entering(getClassNameLogging(), "setHoldability", Integer.valueOf(paramInt));
/*      */ 
/* 3124 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 3126 */       loggerExternal.finer(new StringBuilder().append(toString()).append(" ActivityId: ").append(ActivityCorrelator.getNext().toString()).toString());
/*      */     }
/* 3128 */     checkValidHoldability(paramInt);
/* 3129 */     checkClosed();
/*      */ 
/* 3131 */     if (this.holdability != paramInt)
/*      */     {
/* 3136 */       assert ((1 == paramInt) || (2 == paramInt)) : new StringBuilder().append("invalid holdability ").append(paramInt).toString();
/*      */ 
/* 3138 */       connectionCommand(paramInt == 2 ? "SET CURSOR_CLOSE_ON_COMMIT ON" : "SET CURSOR_CLOSE_ON_COMMIT OFF", "setHoldability");
/*      */ 
/* 3144 */       this.holdability = paramInt;
/*      */     }
/*      */ 
/* 3147 */     loggerExternal.exiting(getClassNameLogging(), "setHoldability");
/*      */   }
/*      */ 
/*      */   public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException
/*      */   {
/* 3152 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 3155 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public Blob createBlob() throws SQLException
/*      */   {
/* 3160 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3161 */     checkClosed();
/* 3162 */     return new SQLServerBlob(this);
/*      */   }
/*      */ 
/*      */   public Clob createClob() throws SQLException
/*      */   {
/* 3167 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3168 */     checkClosed();
/* 3169 */     return new SQLServerClob(this);
/*      */   }
/*      */ 
/*      */   public NClob createNClob() throws SQLException
/*      */   {
/* 3174 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3175 */     checkClosed();
/* 3176 */     return new SQLServerNClob(this);
/*      */   }
/*      */ 
/*      */   public SQLXML createSQLXML() throws SQLException
/*      */   {
/* 3181 */     loggerExternal.entering(getClassNameLogging(), "createSQLXML");
/* 3182 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3183 */     SQLServerSQLXML localSQLServerSQLXML = null;
/* 3184 */     localSQLServerSQLXML = new SQLServerSQLXML(this);
/*      */ 
/* 3186 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3187 */       loggerExternal.exiting(getClassNameLogging(), "createSQLXML", localSQLServerSQLXML);
/* 3188 */     return localSQLServerSQLXML;
/*      */   }
/*      */ 
/*      */   public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException
/*      */   {
/* 3193 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/* 3196 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   public Properties getClientInfo() throws SQLException
/*      */   {
/* 3201 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3202 */     loggerExternal.entering(getClassNameLogging(), "getClientInfo");
/* 3203 */     checkClosed();
/* 3204 */     Properties localProperties = new Properties();
/* 3205 */     loggerExternal.exiting(getClassNameLogging(), "getClientInfo", localProperties);
/* 3206 */     return localProperties;
/*      */   }
/*      */ 
/*      */   public String getClientInfo(String paramString) throws SQLException
/*      */   {
/* 3211 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3212 */     loggerExternal.entering(getClassNameLogging(), "getClientInfo", paramString);
/* 3213 */     checkClosed();
/* 3214 */     loggerExternal.exiting(getClassNameLogging(), "getClientInfo", null);
/* 3215 */     return null;
/*      */   }
/*      */ 
/*      */   public void setClientInfo(Properties paramProperties) throws SQLClientInfoException {
/* 3220 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3221 */     loggerExternal.entering(getClassNameLogging(), "setClientInfo", paramProperties);
/*      */     Object localObject;
/*      */     try {
/* 3226 */       checkClosed();
/*      */     }
/*      */     catch (SQLServerException localSQLServerException) {
/* 3229 */       localObject = new SQLClientInfoException();
/* 3230 */       ((SQLClientInfoException)localObject).initCause(localSQLServerException);
/* 3231 */       throw ((Throwable)localObject);
/*      */     }
/*      */ 
/* 3234 */     if (!paramProperties.isEmpty())
/*      */     {
/* 3236 */       Enumeration localEnumeration = paramProperties.keys();
/* 3237 */       while (localEnumeration.hasMoreElements())
/*      */       {
/* 3239 */         localObject = new MessageFormat(SQLServerException.getErrString("R_invalidProperty"));
/* 3240 */         Object[] arrayOfObject = { localEnumeration.nextElement() };
/* 3241 */         addWarning(((MessageFormat)localObject).format(arrayOfObject));
/*      */       }
/*      */     }
/* 3244 */     loggerExternal.exiting(getClassNameLogging(), "setClientInfo");
/*      */   }
/*      */ 
/*      */   public void setClientInfo(String paramString1, String paramString2) throws SQLClientInfoException
/*      */   {
/* 3249 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3250 */     loggerExternal.entering(getClassNameLogging(), "setClientInfo", new Object[] { paramString1, paramString2 });
/*      */     try
/*      */     {
/* 3255 */       checkClosed();
/*      */     }
/*      */     catch (SQLServerException localSQLServerException) {
/* 3258 */       localObject = new SQLClientInfoException();
/* 3259 */       ((SQLClientInfoException)localObject).initCause(localSQLServerException);
/* 3260 */       throw ((Throwable)localObject);
/*      */     }
/* 3262 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidProperty"));
/* 3263 */     Object localObject = { paramString1 };
/* 3264 */     addWarning(localMessageFormat.format(localObject));
/* 3265 */     loggerExternal.exiting(getClassNameLogging(), "setClientInfo");
/*      */   }
/*      */ 
/*      */   public boolean isValid(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3289 */     boolean bool = false;
/*      */ 
/* 3291 */     loggerExternal.entering(getClassNameLogging(), "isValid", Integer.valueOf(paramInt));
/*      */ 
/* 3293 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     Object localObject;
/* 3296 */     if (paramInt < 0)
/*      */     {
/* 3298 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeOutValue"));
/* 3299 */       Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/* 3300 */       SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*      */     }
/*      */ 
/* 3304 */     if (isSessionUnAvailable()) {
/* 3305 */       return false;
/*      */     }
/*      */     try
/*      */     {
/* 3309 */       localObject = new SQLServerStatement(this, 1003, 1007);
/*      */ 
/* 3312 */       if (0 != paramInt) {
/* 3313 */         ((SQLServerStatement)localObject).setQueryTimeout(paramInt);
/*      */       }
/*      */ 
/* 3319 */       ((SQLServerStatement)localObject).executeQueryInternal("SELECT 1");
/* 3320 */       ((SQLServerStatement)localObject).close();
/* 3321 */       bool = true;
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/* 3328 */       connectionlogger.fine(new StringBuilder().append(toString()).append(" Exception checking connection validity: ").append(localSQLException.getMessage()).toString());
/*      */     }
/*      */ 
/* 3331 */     loggerExternal.exiting(getClassNameLogging(), "isValid", Boolean.valueOf(bool));
/* 3332 */     return bool;
/*      */   }
/*      */ 
/*      */   public boolean isWrapperFor(Class paramClass) throws SQLException
/*      */   {
/* 3337 */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor", paramClass);
/* 3338 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3339 */     boolean bool = paramClass.isInstance(this);
/* 3340 */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
/* 3341 */     return bool;
/*      */   }
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/* 3346 */     loggerExternal.entering(getClassNameLogging(), "unwrap", paramClass);
/* 3347 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     Object localObject;
/*      */     try { localObject = paramClass.cast(this);
/*      */     }
/*      */     catch (ClassCastException localClassCastException)
/*      */     {
/* 3355 */       SQLServerException localSQLServerException = new SQLServerException(localClassCastException.getMessage(), localClassCastException);
/* 3356 */       throw localSQLServerException;
/*      */     }
/* 3358 */     loggerExternal.exiting(getClassNameLogging(), "unwrap", localObject);
/* 3359 */     return localObject;
/*      */   }
/*      */ 
/*      */   String replaceParameterMarkers(String paramString, Parameter[] paramArrayOfParameter, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 3374 */     char[] arrayOfChar = new char[paramString.length() + paramArrayOfParameter.length * (6 + OUT.length)];
/* 3375 */     int i = 0;
/* 3376 */     int j = 0;
/* 3377 */     int k = 0;
/*      */ 
/* 3379 */     int m = 0;
/*      */     while (true)
/*      */     {
/* 3382 */       int n = ParameterUtils.scanSQLForChar('?', paramString, j);
/* 3383 */       paramString.getChars(j, n, arrayOfChar, i);
/* 3384 */       i += n - j;
/*      */ 
/* 3386 */       if (paramString.length() == n) {
/*      */         break;
/*      */       }
/* 3389 */       i += makeParamName(k++, arrayOfChar, i);
/* 3390 */       j = n + 1;
/*      */ 
/* 3392 */       if (paramArrayOfParameter[(m++)].isOutput())
/*      */       {
/* 3394 */         if ((!paramBoolean) || (m > 1))
/*      */         {
/* 3396 */           System.arraycopy(OUT, 0, arrayOfChar, i, OUT.length);
/* 3397 */           i += OUT.length;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 3402 */     while (i < arrayOfChar.length) {
/* 3403 */       arrayOfChar[(i++)] = ' ';
/*      */     }
/* 3405 */     return new String(arrayOfChar);
/*      */   }
/*      */ 
/*      */   static int makeParamName(int paramInt1, char[] paramArrayOfChar, int paramInt2)
/*      */   {
/* 3416 */     paramArrayOfChar[(paramInt2 + 0)] = '@';
/* 3417 */     paramArrayOfChar[(paramInt2 + 1)] = 'P';
/* 3418 */     if (paramInt1 < 10)
/*      */     {
/* 3420 */       paramArrayOfChar[(paramInt2 + 2)] = (char)(48 + paramInt1);
/* 3421 */       return 3;
/*      */     }
/*      */ 
/* 3425 */     if (paramInt1 < 100)
/*      */     {
/* 3427 */       int i = 2;
/*      */       while (true)
/*      */       {
/* 3430 */         if (paramInt1 < i * 10)
/*      */         {
/* 3432 */           paramArrayOfChar[(paramInt2 + 2)] = (char)(48 + (i - 1));
/* 3433 */           paramArrayOfChar[(paramInt2 + 3)] = (char)(48 + (paramInt1 - (i - 1) * 10));
/* 3434 */           return 4;
/*      */         }
/* 3436 */         i++;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3441 */     String str = new StringBuilder().append("").append(paramInt1).toString();
/* 3442 */     str.getChars(0, str.length(), paramArrayOfChar, paramInt2 + 2);
/* 3443 */     return 2 + str.length();
/*      */   }
/*      */ 
/*      */   void notifyPooledConnection(SQLServerException paramSQLServerException)
/*      */   {
/* 3456 */     synchronized (this)
/*      */     {
/* 3458 */       if (null != this.pooledConnectionParent)
/*      */       {
/* 3460 */         this.pooledConnectionParent.notifyEvent(paramSQLServerException);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void DetachFromPool()
/*      */   {
/* 3469 */     synchronized (this)
/*      */     {
/* 3471 */       this.pooledConnectionParent = null;
/*      */     }
/*      */   }
/*      */   String getInstancePort(String paramString1, String paramString2) throws SQLServerException {
/* 3486 */     String str1 = null;
/* 3487 */     DatagramSocket localDatagramSocket = null;
/* 3488 */     String str2 = null;
/*      */     Object localObject4;
/*      */     Object localObject3;
/*      */     try { str2 = new StringBuilder().append("Failed to determine instance for the : ").append(paramString1).append(" instance:").append(paramString2).toString();
/*      */ 
/* 3495 */       if (null == localDatagramSocket)
/*      */       {
/*      */         try
/*      */         {
/* 3499 */           localDatagramSocket = new DatagramSocket();
/* 3500 */           localDatagramSocket.setSoTimeout(1000);
/*      */         }
/*      */         catch (SocketException localSocketException)
/*      */         {
/* 3506 */           str2 = "Unable to create local datagram socket";
/* 3507 */           throw localSocketException;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3515 */       assert (null != localDatagramSocket);
/*      */       try
/*      */       {
/*      */         Object localObject1;
/* 3518 */         if (this.multiSubnetFailover)
/*      */         {
/* 3521 */           localObject1 = InetAddress.getAllByName(paramString1);
/* 3522 */           assert (null != localObject1);
/* 3523 */           for (InetAddress localInetAddress : localObject1)
/*      */           {
/*      */             try
/*      */             {
/* 3528 */               byte[] arrayOfByte2 = new StringBuilder().append(" ").append(paramString2).toString().getBytes();
/* 3529 */               arrayOfByte2[0] = 4;
/* 3530 */               DatagramPacket localDatagramPacket = new DatagramPacket(arrayOfByte2, arrayOfByte2.length, localInetAddress, 1434);
/* 3531 */               localDatagramSocket.send(localDatagramPacket);
/*      */             }
/*      */             catch (IOException localIOException4)
/*      */             {
/* 3535 */               str2 = new StringBuilder().append("Error sending SQL Server Browser Service UDP request to address: ").append(localInetAddress).append(", port: ").append(1434).toString();
/* 3536 */               throw localIOException4;
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 3543 */           localObject1 = InetAddress.getByName(paramString1);
/*      */ 
/* 3545 */           assert (null != localObject1);
/*      */           try
/*      */           {
/* 3549 */             ??? = new StringBuilder().append(" ").append(paramString2).toString().getBytes();
/* 3550 */             ???[0] = 4;
/* 3551 */             localObject4 = new DatagramPacket(???, ???.length, (InetAddress)localObject1, 1434);
/* 3552 */             localDatagramSocket.send((DatagramPacket)localObject4);
/*      */           }
/*      */           catch (IOException localIOException3)
/*      */           {
/* 3556 */             str2 = new StringBuilder().append("Error sending SQL Server Browser Service UDP request to address: ").append(localObject1).append(", port: ").append(1434).toString();
/* 3557 */             throw localIOException3;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (UnknownHostException localUnknownHostException)
/*      */       {
/* 3563 */         str2 = new StringBuilder().append("Unable to determine IP address of host: ").append(paramString1).toString();
/* 3564 */         throw localUnknownHostException;
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 3570 */         byte[] arrayOfByte1 = new byte[4096];
/* 3571 */         localObject3 = new DatagramPacket(arrayOfByte1, arrayOfByte1.length);
/* 3572 */         localDatagramSocket.receive((DatagramPacket)localObject3);
/* 3573 */         str1 = new String(arrayOfByte1, 3, arrayOfByte1.length - 3);
/* 3574 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 3575 */           connectionlogger.fine(new StringBuilder().append(toString()).append("Received SSRP UDP response from IP address: ").append(((DatagramPacket)localObject3).getAddress().getHostAddress().toString()).toString());
/*      */         }
/*      */       }
/*      */       catch (IOException localIOException1)
/*      */       {
/* 3580 */         str2 = new StringBuilder().append("Error receiving SQL Server Browser Service UDP response from server: ").append(paramString1).toString();
/* 3581 */         throw localIOException1;
/*      */       }
/*      */ 
/* 3593 */       if (null != localDatagramSocket)
/* 3594 */         localDatagramSocket.close();
/*      */     }
/*      */     catch (IOException localIOException2)
/*      */     {
/* 3586 */       localObject3 = new MessageFormat(SQLServerException.getErrString("R_sqlBrowserFailed"));
/* 3587 */       localObject4 = new Object[] { paramString1, paramString2, localIOException2.toString() };
/* 3588 */       connectionlogger.log(Level.FINE, new StringBuilder().append(toString()).append(" ").append(str2).toString(), localIOException2);
/* 3589 */       SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject3).format(localObject4), "08001", false);
/*      */ 
/* 3593 */       if (null != localDatagramSocket)
/* 3594 */         localDatagramSocket.close();
/*      */     }
/*      */     finally
/*      */     {
/* 3593 */       if (null != localDatagramSocket)
/* 3594 */         localDatagramSocket.close();
/*      */     }
/* 3596 */     assert (null != str1);
/*      */ 
/* 3598 */     int i = str1.indexOf("tcp;");
/* 3599 */     if (-1 == i)
/*      */     {
/* 3601 */       localObject3 = new MessageFormat(SQLServerException.getErrString("R_notConfiguredToListentcpip"));
/* 3602 */       localObject4 = new Object[] { paramString2 };
/* 3603 */       SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject3).format(localObject4), "08001", false);
/*      */     }
/*      */ 
/* 3606 */     int j = i + 4;
/* 3607 */     int m = str1.indexOf(59, j);
/* 3608 */     return (String)(String)(String)(String)str1.substring(j, m);
/*      */   }
/*      */ 
/*      */   int getNextSavepointId() {
/* 3612 */     this.nNextSavePointId += 1;
/* 3613 */     return this.nNextSavePointId;
/*      */   }
/*      */ 
/*      */   void doSecurityCheck()
/*      */   {
/* 3620 */     assert (null != this.currentConnectPlaceHolder);
/* 3621 */     this.currentConnectPlaceHolder.doSecurityCheck();
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  211 */     baseConnectionID = 0;
/*      */ 
/*  222 */     connectionlogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerConnection");
/*      */ 
/*  224 */     loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Connection");
/*      */ 
/* 1213 */     DEFAULTPORT = SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue();
/*      */ 
/* 3370 */     OUT = new char[] { ' ', 'O', 'U', 'T' };
/*      */   }
/*      */ 
/*      */   private final class LogonCommand extends UninterruptableTDSCommand
/*      */   {
/*      */     LogonCommand()
/*      */     {
/* 2215 */       super();
/*      */     }
/*      */ 
/*      */     final boolean doExecute() throws SQLServerException
/*      */     {
/* 2220 */       SQLServerConnection.this.logon(this);
/* 2221 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static enum State
/*      */   {
/*   50 */     Initialized, 
/*   51 */     Connected, 
/*   52 */     Opened, 
/*   53 */     Closed;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerConnection
 * JD-Core Version:    0.6.0
 */