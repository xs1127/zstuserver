/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ 
/*     */  enum AuthenticationScheme
/*     */ {
/* 665 */   nativeAuthentication, 
/* 666 */   javaKerberos;
/*     */ 
/*     */   static AuthenticationScheme valueOfString(String paramString)
/*     */     throws SQLServerException
/*     */   {
/*     */     AuthenticationScheme localAuthenticationScheme;
/* 670 */     if (paramString.toLowerCase(Locale.US).equalsIgnoreCase(javaKerberos.toString()))
/*     */     {
/* 672 */       localAuthenticationScheme = javaKerberos;
/*     */     }
/* 675 */     else if (paramString.toLowerCase(Locale.US).equalsIgnoreCase(nativeAuthentication.toString()))
/*     */     {
/* 677 */       localAuthenticationScheme = nativeAuthentication;
/*     */     }
/*     */     else
/*     */     {
/* 681 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidAuthenticationScheme"));
/* 682 */       Object[] arrayOfObject = { paramString };
/* 683 */       throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */     }
/* 685 */     return localAuthenticationScheme;
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.AuthenticationScheme
 * JD-Core Version:    0.6.0
 */