/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ class Nanos
/*     */ {
/*     */   static final int PER_SECOND = 1000000000;
/* 326 */   static final int PER_MAX_SCALE_INTERVAL = 1000000000 / (int)Math.pow(10.0D, 7.0D);
/*     */   static final int PER_MILLISECOND = 1000000;
/*     */   static final long PER_DAY = 86400000000000L;
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.Nanos
 * JD-Core Version:    0.6.0
 */