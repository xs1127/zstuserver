/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class StreamSSPI extends StreamPacket
/*    */ {
/*    */   byte[] sspiBlob;
/*    */ 
/*    */   StreamSSPI()
/*    */   {
/* 16 */     super(237);
/*    */   }
/*    */ 
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 21 */     if ((237 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/* 22 */     int i = paramTDSReader.readUnsignedShort();
/* 23 */     this.sspiBlob = new byte[i];
/* 24 */     paramTDSReader.readBytes(this.sspiBlob, 0, i);
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.StreamSSPI
 * JD-Core Version:    0.6.0
 */