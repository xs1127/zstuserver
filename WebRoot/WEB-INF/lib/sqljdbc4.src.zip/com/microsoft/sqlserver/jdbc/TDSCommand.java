/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ abstract class TDSCommand
/*      */ {
/*      */   static final Logger logger;
/*      */   private final String logContext;
/*      */   private String traceID;
/*      */   private final TimeoutTimer timeoutTimer;
/*      */   private volatile TDSWriter tdsWriter;
/*      */   private volatile TDSReader tdsReader;
/* 5625 */   private final Object interruptLock = new Object();
/*      */ 
/* 5632 */   private volatile boolean interruptsEnabled = false;
/*      */ 
/* 5635 */   private volatile boolean wasInterrupted = false;
/*      */ 
/* 5639 */   private volatile String interruptReason = null;
/*      */   private volatile boolean requestComplete;
/* 5650 */   private volatile boolean attentionPending = false;
/*      */   private volatile boolean processedResponse;
/*      */   private volatile boolean readingResponse;
/* 5903 */   private boolean interruptChecked = false;
/*      */ 
/*      */   abstract boolean doExecute()
/*      */     throws SQLServerException;
/*      */ 
/*      */   final String getLogContext()
/*      */   {
/* 5603 */     return this.logContext;
/*      */   }
/*      */ 
/*      */   public final String toString() {
/* 5607 */     if (this.traceID == null)
/* 5608 */       this.traceID = ("TDSCommand@" + Integer.toHexString(hashCode()) + " (" + this.logContext + ")");
/* 5609 */     return this.traceID;
/*      */   }
/* 5611 */   final void log(Level paramLevel, String paramString) { logger.log(paramLevel, toString() + ": " + paramString);
/*      */   }
/*      */ 
/*      */   private final boolean wasInterrupted()
/*      */   {
/* 5636 */     return this.wasInterrupted;
/*      */   }
/*      */ 
/*      */   boolean attentionPending()
/*      */   {
/* 5651 */     return this.attentionPending;
/*      */   }
/*      */ 
/*      */   final boolean readingResponse()
/*      */   {
/* 5663 */     return this.readingResponse;
/*      */   }
/*      */ 
/*      */   TDSCommand(String paramString, int paramInt)
/*      */   {
/* 5675 */     this.logContext = paramString;
/* 5676 */     this.timeoutTimer = (paramInt > 0 ? new TimeoutTimer(paramInt, this) : null);
/*      */   }
/*      */ 
/*      */   boolean execute(TDSWriter paramTDSWriter, TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 5691 */     this.tdsWriter = paramTDSWriter;
/* 5692 */     this.tdsReader = paramTDSReader;
/* 5693 */     assert (null != paramTDSReader);
/*      */     try
/*      */     {
/* 5696 */       return doExecute();
/*      */     }
/*      */     catch (SQLServerException localSQLServerException1)
/*      */     {
/*      */       try
/*      */       {
/* 5707 */         if ((!this.requestComplete) && (!paramTDSReader.getConnection().isClosed()))
/*      */         {
/* 5709 */           interrupt(localSQLServerException1.getMessage());
/* 5710 */           onRequestComplete();
/* 5711 */           close();
/*      */         }
/*      */       }
/*      */       catch (SQLServerException localSQLServerException2)
/*      */       {
/* 5716 */         if (logger.isLoggable(Level.FINE)) {
/* 5717 */           logger.fine(toString() + ": Ignoring error in sending attention: " + localSQLServerException2.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 5722 */     throw localSQLServerException1;
/*      */   }
/*      */ 
/*      */   void processResponse(TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 5733 */     if (logger.isLoggable(Level.FINEST))
/* 5734 */       logger.finest(toString() + ": Processing response");
/*      */     try
/*      */     {
/* 5737 */       TDSParser.parse(paramTDSReader, getLogContext());
/*      */     }
/*      */     catch (SQLServerException localSQLServerException)
/*      */     {
/* 5741 */       if (2 != localSQLServerException.getDriverErrorCode()) {
/* 5742 */         throw localSQLServerException;
/*      */       }
/* 5744 */       if (logger.isLoggable(Level.FINEST))
/* 5745 */         logger.finest(toString() + ": Ignoring error from database: " + localSQLServerException.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   final void detach()
/*      */     throws SQLServerException
/*      */   {
/* 5757 */     if (logger.isLoggable(Level.FINEST)) {
/* 5758 */       logger.finest(this + ": detaching...");
/*      */     }
/*      */ 
/* 5762 */     while (this.tdsReader.readPacket());
/* 5766 */     assert (!this.readingResponse);
/*      */   }
/*      */ 
/*      */   final void close()
/*      */   {
/* 5771 */     if (logger.isLoggable(Level.FINEST)) {
/* 5772 */       logger.finest(this + ": closing...");
/*      */     }
/* 5774 */     if (logger.isLoggable(Level.FINEST)) {
/* 5775 */       logger.finest(this + ": processing response...");
/*      */     }
/* 5777 */     while (!this.processedResponse)
/*      */     {
/*      */       try
/*      */       {
/* 5781 */         processResponse(this.tdsReader);
/*      */       }
/*      */       catch (SQLServerException localSQLServerException1)
/*      */       {
/* 5785 */         if (logger.isLoggable(Level.FINEST)) {
/* 5786 */           logger.finest(this + ": close ignoring error processing response: " + localSQLServerException1.getMessage());
/*      */         }
/* 5788 */         if (this.tdsReader.getConnection().isSessionUnAvailable())
/*      */         {
/* 5790 */           this.processedResponse = true;
/* 5791 */           this.attentionPending = false;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 5796 */     if (this.attentionPending)
/*      */     {
/* 5798 */       if (logger.isLoggable(Level.FINEST)) {
/* 5799 */         logger.finest(this + ": processing attention ack...");
/*      */       }
/*      */       try
/*      */       {
/* 5803 */         TDSParser.parse(this.tdsReader, "attention ack");
/*      */       }
/*      */       catch (SQLServerException localSQLServerException2)
/*      */       {
/* 5807 */         if (this.tdsReader.getConnection().isSessionUnAvailable())
/*      */         {
/* 5809 */           if (logger.isLoggable(Level.FINEST))
/* 5810 */             logger.finest(this + ": giving up on attention ack after connection closed by exception: " + localSQLServerException2);
/* 5811 */           this.attentionPending = false;
/*      */         }
/* 5815 */         else if (logger.isLoggable(Level.FINEST)) {
/* 5816 */           logger.finest(this + ": ignored exception: " + localSQLServerException2);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 5823 */       if (this.attentionPending)
/*      */       {
/* 5825 */         logger.severe(this + ": expected attn ack missing or not processed; terminating connection...");
/*      */         try
/*      */         {
/* 5829 */           this.tdsReader.throwInvalidTDS();
/*      */         }
/*      */         catch (SQLServerException localSQLServerException3)
/*      */         {
/* 5833 */           if (logger.isLoggable(Level.FINEST)) {
/* 5834 */             logger.finest(this + ": ignored expected invalid TDS exception: " + localSQLServerException3);
/*      */           }
/* 5836 */           assert (this.tdsReader.getConnection().isSessionUnAvailable());
/* 5837 */           this.attentionPending = false;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 5845 */     assert ((this.processedResponse) && (!this.attentionPending));
/*      */   }
/*      */ 
/*      */   void interrupt(String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 5868 */     synchronized (this.interruptLock)
/*      */     {
/* 5870 */       if ((this.interruptsEnabled) && (!wasInterrupted()))
/*      */       {
/* 5872 */         if (logger.isLoggable(Level.FINEST)) {
/* 5873 */           logger.finest(this + ": Raising interrupt for reason:" + paramString);
/*      */         }
/* 5875 */         this.wasInterrupted = true;
/* 5876 */         this.interruptReason = paramString;
/* 5877 */         if (this.requestComplete)
/* 5878 */           this.attentionPending = this.tdsWriter.sendAttention();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   final void checkForInterrupt()
/*      */     throws SQLServerException
/*      */   {
/* 5911 */     if ((wasInterrupted()) && (!this.interruptChecked))
/*      */     {
/* 5913 */       this.interruptChecked = true;
/*      */ 
/* 5915 */       if (logger.isLoggable(Level.FINEST)) {
/* 5916 */         logger.finest(this + ": throwing interrupt exception, reason: " + this.interruptReason);
/*      */       }
/* 5918 */       throw new SQLServerException(this.interruptReason, SQLState.STATEMENT_CANCELED, DriverError.NOT_SET, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   final void onRequestComplete()
/*      */     throws SQLServerException
/*      */   {
/* 5938 */     assert (!this.requestComplete);
/*      */ 
/* 5940 */     if (logger.isLoggable(Level.FINEST)) {
/* 5941 */       logger.finest(this + ": request complete");
/*      */     }
/* 5943 */     synchronized (this.interruptLock)
/*      */     {
/* 5945 */       this.requestComplete = true;
/*      */ 
/* 5952 */       if (!this.interruptsEnabled)
/*      */       {
/* 5954 */         assert (!this.attentionPending);
/* 5955 */         assert (!this.processedResponse);
/* 5956 */         assert (!this.readingResponse);
/* 5957 */         this.processedResponse = true;
/*      */       }
/* 5959 */       else if (wasInterrupted())
/*      */       {
/* 5962 */         if (this.tdsWriter.isEOMSent())
/*      */         {
/* 5964 */           this.attentionPending = this.tdsWriter.sendAttention();
/* 5965 */           this.readingResponse = this.attentionPending;
/*      */         }
/*      */         else
/*      */         {
/* 5969 */           assert (!this.attentionPending);
/* 5970 */           this.readingResponse = this.tdsWriter.ignoreMessage();
/*      */         }
/*      */ 
/* 5973 */         this.processedResponse = (!this.readingResponse);
/*      */       }
/*      */       else
/*      */       {
/* 5977 */         assert (!this.attentionPending);
/* 5978 */         assert (!this.processedResponse);
/* 5979 */         this.readingResponse = true;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   final void onResponseEOM()
/*      */     throws SQLServerException
/*      */   {
/* 5999 */     boolean bool = false;
/*      */ 
/* 6003 */     synchronized (this.interruptLock)
/*      */     {
/* 6005 */       if (this.interruptsEnabled)
/*      */       {
/* 6007 */         if (logger.isLoggable(Level.FINEST)) {
/* 6008 */           logger.finest(this + ": disabling interrupts");
/*      */         }
/*      */ 
/* 6015 */         bool = this.attentionPending;
/*      */ 
/* 6017 */         this.interruptsEnabled = false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 6028 */     if (bool) {
/* 6029 */       this.tdsReader.readPacket();
/*      */     }
/* 6031 */     this.readingResponse = false;
/*      */   }
/*      */ 
/*      */   final void onTokenEOF()
/*      */   {
/* 6041 */     this.processedResponse = true;
/*      */   }
/*      */ 
/*      */   final void onAttentionAck()
/*      */   {
/* 6052 */     assert (this.attentionPending);
/* 6053 */     this.attentionPending = false;
/*      */   }
/*      */ 
/*      */   final TDSWriter startRequest(byte paramByte)
/*      */     throws SQLServerException
/*      */   {
/* 6065 */     if (logger.isLoggable(Level.FINEST)) {
/* 6066 */       logger.finest(this + ": starting request...");
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 6071 */       this.tdsWriter.startMessage(this, paramByte);
/*      */     }
/*      */     catch (SQLServerException localSQLServerException)
/*      */     {
/* 6075 */       if (logger.isLoggable(Level.FINEST)) {
/* 6076 */         logger.finest(this + ": starting request: exception: " + localSQLServerException.getMessage());
/*      */       }
/* 6078 */       throw localSQLServerException;
/*      */     }
/*      */ 
/* 6084 */     synchronized (this.interruptLock)
/*      */     {
/* 6086 */       this.requestComplete = false;
/* 6087 */       this.readingResponse = false;
/* 6088 */       this.processedResponse = false;
/* 6089 */       this.attentionPending = false;
/* 6090 */       this.wasInterrupted = false;
/* 6091 */       this.interruptReason = null;
/* 6092 */       this.interruptsEnabled = true;
/*      */     }
/*      */ 
/* 6095 */     return this.tdsWriter;
/*      */   }
/*      */ 
/*      */   final TDSReader startResponse()
/*      */     throws SQLServerException
/*      */   {
/* 6106 */     return startResponse(false);
/*      */   }
/*      */ 
/*      */   final TDSReader startResponse(boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 6115 */     if (logger.isLoggable(Level.FINEST)) {
/* 6116 */       logger.finest(this + ": finishing request");
/*      */     }
/*      */     try
/*      */     {
/* 6120 */       this.tdsWriter.endMessage();
/*      */     }
/*      */     catch (SQLServerException localSQLServerException1)
/*      */     {
/* 6124 */       if (logger.isLoggable(Level.FINEST)) {
/* 6125 */         logger.finest(this + ": finishing request: endMessage threw exception: " + localSQLServerException1.getMessage());
/*      */       }
/* 6127 */       throw localSQLServerException1;
/*      */     }
/*      */ 
/* 6132 */     if (null != this.timeoutTimer)
/*      */     {
/* 6134 */       if (logger.isLoggable(Level.FINEST)) {
/* 6135 */         logger.finest(toString() + ": Starting timer...");
/*      */       }
/* 6137 */       this.timeoutTimer.start();
/*      */     }
/*      */ 
/* 6140 */     if (logger.isLoggable(Level.FINEST)) {
/* 6141 */       logger.finest(toString() + ": Reading response...");
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 6148 */       if (paramBoolean)
/*      */       {
/* 6150 */         this.tdsReader.readPacket();
/*      */       }
/*      */       else
/*      */       {
/* 6154 */         while (this.tdsReader.readPacket());
/*      */       }
/*      */ 
/* 6169 */       if (null != this.timeoutTimer)
/*      */       {
/* 6171 */         if (logger.isLoggable(Level.FINEST)) {
/* 6172 */           logger.finest(toString() + ": Stopping timer...");
/*      */         }
/* 6174 */         this.timeoutTimer.stop();
/*      */       }
/*      */     }
/*      */     catch (SQLServerException localSQLServerException2)
/*      */     {
/* 6160 */       if (logger.isLoggable(Level.FINEST)) {
/* 6161 */         logger.finest(toString() + ": Exception reading response: " + localSQLServerException2.getMessage());
/*      */       }
/* 6163 */       throw localSQLServerException2;
/*      */     }
/*      */     finally
/*      */     {
/* 6169 */       if (null != this.timeoutTimer)
/*      */       {
/* 6171 */         if (logger.isLoggable(Level.FINEST)) {
/* 6172 */           logger.finest(toString() + ": Stopping timer...");
/*      */         }
/* 6174 */         this.timeoutTimer.stop();
/*      */       }
/*      */     }
/*      */ 
/* 6178 */     return this.tdsReader;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 5601 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.Command");
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TDSCommand
 * JD-Core Version:    0.6.0
 */