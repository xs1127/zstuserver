package com.microsoft.sqlserver.jdbc;

abstract class ColumnFilter
{
  abstract Object apply(Object paramObject, JDBCType paramJDBCType)
    throws SQLServerException;
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.ColumnFilter
 * JD-Core Version:    0.6.0
 */