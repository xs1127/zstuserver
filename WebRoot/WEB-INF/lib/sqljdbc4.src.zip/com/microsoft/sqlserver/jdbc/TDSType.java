/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */  enum TDSType
/*    */ {
/* 18 */   BIT1(50), 
/* 19 */   INT8(127), 
/* 20 */   INT4(56), 
/* 21 */   INT2(52), 
/* 22 */   INT1(48), 
/* 23 */   FLOAT4(59), 
/* 24 */   FLOAT8(62), 
/* 25 */   DATETIME4(58), 
/* 26 */   DATETIME8(61), 
/* 27 */   MONEY4(122), 
/* 28 */   MONEY8(60), 
/*    */ 
/* 31 */   BITN(104), 
/* 32 */   INTN(38), 
/* 33 */   DECIMALN(106), 
/* 34 */   NUMERICN(108), 
/* 35 */   FLOATN(109), 
/* 36 */   MONEYN(110), 
/* 37 */   DATETIMEN(111), 
/* 38 */   GUID(36), 
/* 39 */   DATEN(40), 
/* 40 */   TIMEN(41), 
/* 41 */   DATETIME2N(42), 
/* 42 */   DATETIMEOFFSETN(43), 
/*    */ 
/* 45 */   BIGCHAR(175), 
/* 46 */   BIGVARCHAR(167), 
/* 47 */   BIGBINARY(173), 
/* 48 */   BIGVARBINARY(165), 
/* 49 */   NCHAR(239), 
/* 50 */   NVARCHAR(231), 
/*    */ 
/* 53 */   IMAGE(34), 
/* 54 */   TEXT(35), 
/* 55 */   NTEXT(99), 
/* 56 */   UDT(240), 
/* 57 */   XML(241), 
/*    */ 
/* 60 */   SQL_VARIANT(98);
/*    */ 
/*    */   private final int intValue;
/*    */   private static final int MAXELEMENTS = 256;
/*    */   private static final TDSType[] valuesTypes;
/*    */ 
/* 67 */   byte byteValue() { return (byte)this.intValue;
/*    */   }
/*    */ 
/*    */   private TDSType(int paramInt)
/*    */   {
/* 77 */     this.intValue = paramInt;
/*    */   }
/*    */ 
/*    */   static TDSType valueOf(int paramInt)
/*    */     throws IllegalArgumentException
/*    */   {
/*    */     TDSType localTDSType;
/* 84 */     if ((0 > paramInt) || (paramInt >= valuesTypes.length) || (null == (localTDSType = valuesTypes[paramInt])))
/*    */     {
/* 87 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownSSType"));
/* 88 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 89 */       throw new IllegalArgumentException(localMessageFormat.format(arrayOfObject));
/*    */     }
/*    */ 
/* 92 */     return localTDSType;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 65 */     valuesTypes = new TDSType[256];
/*    */ 
/* 71 */     for (TDSType localTDSType : values())
/* 72 */       valuesTypes[localTDSType.intValue] = localTDSType;
/*    */   }
/*    */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TDSType
 * JD-Core Version:    0.6.0
 */