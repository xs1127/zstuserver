/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.naming.Reference;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.sql.XADataSource;
/*     */ 
/*     */ public final class SQLServerXADataSource extends SQLServerConnectionPoolDataSource
/*     */   implements XADataSource
/*     */ {
/*  45 */   static Logger xaLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.XA");
/*     */ 
/*     */   public XAConnection getXAConnection(String paramString1, String paramString2) throws SQLException
/*     */   {
/*  49 */     if (loggerExternal.isLoggable(Level.FINER))
/*  50 */       loggerExternal.entering(getClassNameLogging(), "getXAConnection", new Object[] { paramString1, "Password not traced" });
/*  51 */     SQLServerXAConnection localSQLServerXAConnection = new SQLServerXAConnection(this, paramString1, paramString2);
/*     */ 
/*  53 */     if (xaLogger.isLoggable(Level.FINER)) {
/*  54 */       xaLogger.finer(toString() + " user:" + paramString1 + localSQLServerXAConnection.toString());
/*     */     }
/*     */ 
/*  61 */     if (xaLogger.isLoggable(Level.FINER))
/*  62 */       xaLogger.finer(toString() + " Start get physical connection.");
/*  63 */     SQLServerConnection localSQLServerConnection = localSQLServerXAConnection.getPhysicalConnection();
/*  64 */     if (xaLogger.isLoggable(Level.FINE))
/*  65 */       xaLogger.fine(toString() + " End get physical connection, " + localSQLServerConnection.toString());
/*  66 */     if (loggerExternal.isLoggable(Level.FINER))
/*  67 */       loggerExternal.exiting(getClassNameLogging(), "getXAConnection", localSQLServerXAConnection);
/*  68 */     return localSQLServerXAConnection;
/*     */   }
/*     */ 
/*     */   public XAConnection getXAConnection()
/*     */     throws SQLException
/*     */   {
/*  82 */     if (loggerExternal.isLoggable(Level.FINER))
/*  83 */       loggerExternal.entering(getClassNameLogging(), "getXAConnection");
/*  84 */     return getXAConnection(getUser(), getPassword());
/*     */   }
/*     */ 
/*     */   public Reference getReference()
/*     */   {
/*  91 */     if (loggerExternal.isLoggable(Level.FINER))
/*  92 */       loggerExternal.entering(getClassNameLogging(), "getReference");
/*  93 */     Reference localReference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerXADataSource");
/*  94 */     if (loggerExternal.isLoggable(Level.FINER))
/*  95 */       loggerExternal.exiting(getClassNameLogging(), "getReference", localReference);
/*  96 */     return localReference;
/*     */   }
/*     */ 
/*     */   private Object writeReplace() throws ObjectStreamException {
/* 100 */     return new SerializationProxy(this);
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream paramObjectInputStream)
/*     */     throws InvalidObjectException
/*     */   {
/* 110 */     throw new InvalidObjectException("");
/*     */   }
/*     */ 
/*     */   private static class SerializationProxy
/*     */     implements Serializable
/*     */   {
/*     */     private final Reference ref;
/*     */     private static final long serialVersionUID = 454661379842314126L;
/*     */ 
/*     */     SerializationProxy(SQLServerXADataSource paramSQLServerXADataSource)
/*     */     {
/* 124 */       this.ref = paramSQLServerXADataSource.getReferenceInternal(null);
/*     */     }
/*     */ 
/*     */     private Object readResolve() {
/* 128 */       SQLServerXADataSource localSQLServerXADataSource = new SQLServerXADataSource();
/* 129 */       localSQLServerXADataSource.initializeFromReference(this.ref);
/* 130 */       return localSQLServerXADataSource;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SQLServerXADataSource
 * JD-Core Version:    0.6.0
 */