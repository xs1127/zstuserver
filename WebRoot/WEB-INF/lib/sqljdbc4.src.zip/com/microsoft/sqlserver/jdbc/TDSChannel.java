/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.SocketException;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.security.KeyStore;
/*      */ import java.security.Provider;
/*      */ import java.security.Security;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Properties;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLSocket;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ import javax.net.ssl.TrustManager;
/*      */ import javax.net.ssl.TrustManagerFactory;
/*      */ import javax.net.ssl.X509TrustManager;
/*      */ import javax.security.auth.x500.X500Principal;
/*      */ 
/*      */ final class TDSChannel
/*      */ {
/*      */   private static final Logger logger;
/*      */   private final String traceID;
/*      */   private final SQLServerConnection con;
/*      */   private final TDSWriter tdsWriter;
/*      */   private Socket tcpSocket;
/*      */   private SSLSocket sslSocket;
/*      */   private Socket channelSocket;
/*  439 */   ProxySocket proxySocket = null;
/*      */   private InputStream tcpInputStream;
/*      */   private OutputStream tcpOutputStream;
/*      */   private InputStream inputStream;
/*      */   private OutputStream outputStream;
/*      */   private static Logger packetLogger;
/*  454 */   private final boolean isLoggingPackets = packetLogger.isLoggable(Level.FINEST);
/*      */ 
/*  458 */   int numMsgsSent = 0;
/*  459 */   int numMsgsRcvd = 0;
/*      */ 
/*  463 */   private int spid = 0;
/*      */   private static final String SEPARATOR;
/*      */   private static final String JAVA_HOME;
/*      */   private static final String JAVA_SECURITY;
/*      */   private static final String JSSECACERTS;
/*      */   private static final String CACERTS;
/*      */ 
/*      */   final Logger getLogger()
/*      */   {
/*  414 */     return logger;
/*      */   }
/*  416 */   public final String toString() { return this.traceID;
/*      */   }
/*      */ 
/*      */   final TDSWriter getWriter()
/*      */   {
/*  421 */     return this.tdsWriter; } 
/*  422 */   final TDSReader getReader(TDSCommand paramTDSCommand) { return new TDSReader(this, this.con, paramTDSCommand);
/*      */   }
/*      */ 
/*      */   final boolean isLoggingPackets()
/*      */   {
/*  455 */     return this.isLoggingPackets;
/*      */   }
/*      */ 
/*      */   void setSPID(int paramInt)
/*      */   {
/*  464 */     this.spid = paramInt; } 
/*  465 */   int getSPID() { return this.spid; } 
/*  466 */   void resetPooledConnection() { this.tdsWriter.resetPooledConnection(); }
/*      */ 
/*      */   TDSChannel(SQLServerConnection paramSQLServerConnection)
/*      */   {
/*  470 */     this.con = paramSQLServerConnection;
/*  471 */     this.traceID = new StringBuilder().append("TDSChannel (").append(paramSQLServerConnection.toString()).append(")").toString();
/*  472 */     this.tcpSocket = null;
/*  473 */     this.sslSocket = null;
/*  474 */     this.channelSocket = null;
/*  475 */     this.tcpInputStream = null;
/*  476 */     this.tcpOutputStream = null;
/*  477 */     this.inputStream = null;
/*  478 */     this.outputStream = null;
/*  479 */     this.tdsWriter = new TDSWriter(this, paramSQLServerConnection);
/*      */   }
/*      */ 
/*      */   final void open(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/*  487 */     if (logger.isLoggable(Level.FINER)) {
/*  488 */       logger.finer(new StringBuilder().append(toString()).append(": Opening TCP socket...").toString());
/*      */     }
/*  490 */     SocketFinder localSocketFinder = new SocketFinder(this.traceID, this.con);
/*  491 */     this.channelSocket = (this.tcpSocket = localSocketFinder.findSocket(paramString, paramInt1, paramInt2, paramBoolean));
/*      */     try
/*      */     {
/*  497 */       this.tcpSocket.setTcpNoDelay(true);
/*  498 */       this.tcpSocket.setKeepAlive(true);
/*      */ 
/*  500 */       this.inputStream = (this.tcpInputStream = this.tcpSocket.getInputStream());
/*  501 */       this.outputStream = (this.tcpOutputStream = this.tcpSocket.getOutputStream());
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  505 */       SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.con, localIOException);
/*      */     }
/*      */   }
/*      */ 
/*      */   void disableSSL()
/*      */   {
/*  514 */     if (logger.isLoggable(Level.FINER)) {
/*  515 */       logger.finer(new StringBuilder().append(toString()).append(" Disabling SSL...").toString());
/*      */     }
/*      */ 
/*  534 */     ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(new byte[0]);
/*      */     try
/*      */     {
/*  537 */       localByteArrayInputStream.close();
/*      */     }
/*      */     catch (IOException localIOException1)
/*      */     {
/*  543 */       logger.fine(new StringBuilder().append("Ignored error closing InputStream: ").append(localIOException1.getMessage()).toString());
/*      */     }
/*      */ 
/*  546 */     ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*      */     try
/*      */     {
/*  549 */       localByteArrayOutputStream.close();
/*      */     }
/*      */     catch (IOException localIOException2)
/*      */     {
/*  555 */       logger.fine(new StringBuilder().append("Ignored error closing OutputStream: ").append(localIOException2.getMessage()).toString());
/*      */     }
/*      */ 
/*  559 */     if (logger.isLoggable(Level.FINEST))
/*  560 */       logger.finest(new StringBuilder().append(toString()).append(" Rewiring proxy streams for SSL socket close").toString());
/*  561 */     this.proxySocket.setStreams(localByteArrayInputStream, localByteArrayOutputStream);
/*      */     try
/*      */     {
/*  567 */       if (logger.isLoggable(Level.FINER)) {
/*  568 */         logger.finer(new StringBuilder().append(toString()).append(" Closing SSL socket").toString());
/*      */       }
/*  570 */       this.sslSocket.close();
/*      */     }
/*      */     catch (IOException localIOException3)
/*      */     {
/*  575 */       logger.fine(new StringBuilder().append("Ignored error closing SSLSocket: ").append(localIOException3.getMessage()).toString());
/*      */     }
/*      */ 
/*  581 */     this.proxySocket = null;
/*      */ 
/*  585 */     this.inputStream = this.tcpInputStream;
/*  586 */     this.outputStream = this.tcpOutputStream;
/*  587 */     this.channelSocket = this.tcpSocket;
/*  588 */     this.sslSocket = null;
/*      */ 
/*  590 */     if (logger.isLoggable(Level.FINER))
/*  591 */       logger.finer(new StringBuilder().append(toString()).append(" SSL disabled").toString());
/*      */   }
/*      */ 
/*      */   void enableSSL(String paramString, int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1445 */     Provider localProvider1 = null;
/* 1446 */     Provider localProvider2 = null;
/* 1447 */     Provider localProvider3 = null;
/* 1448 */     String str1 = null;
/*      */     try
/*      */     {
/* 1453 */       if (logger.isLoggable(Level.FINER)) {
/* 1454 */         logger.finer(new StringBuilder().append(toString()).append(" Enabling SSL...").toString());
/*      */       }
/* 1456 */       String str2 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE.toString());
/* 1457 */       localObject1 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/* 1458 */       localObject2 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString());
/*      */ 
/* 1460 */       assert ((0 == this.con.getRequestedEncryptionLevel()) || (1 == this.con.getRequestedEncryptionLevel()));
/*      */ 
/* 1464 */       assert ((0 == this.con.getNegotiatedEncryptionLevel()) || (1 == this.con.getNegotiatedEncryptionLevel()) || (3 == this.con.getNegotiatedEncryptionLevel()));
/*      */ 
/* 1472 */       TrustManager[] arrayOfTrustManager = null;
/* 1473 */       if ((0 == this.con.getRequestedEncryptionLevel()) || ((1 == this.con.getRequestedEncryptionLevel()) && (this.con.trustServerCertificate())))
/*      */       {
/* 1476 */         if (logger.isLoggable(Level.FINER)) {
/* 1477 */           logger.finer(new StringBuilder().append(toString()).append(" SSL handshake will trust any certificate").toString());
/*      */         }
/* 1479 */         arrayOfTrustManager = new TrustManager[] { new PermissiveX509TrustManager(this) };
/*      */       }
/*      */       else
/*      */       {
/* 1486 */         if (logger.isLoggable(Level.FINER)) {
/* 1487 */           logger.finer(new StringBuilder().append(toString()).append(" SSL handshake will validate server certificate").toString());
/*      */         }
/* 1489 */         localObject3 = null;
/*      */ 
/* 1494 */         if ((null == str2) && (null == localObject1))
/*      */         {
/* 1496 */           if (logger.isLoggable(Level.FINER)) {
/* 1497 */             logger.finer(new StringBuilder().append(toString()).append(" Using system default trust store and password").toString());
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1506 */           if (logger.isLoggable(Level.FINEST)) {
/* 1507 */             logger.finest(new StringBuilder().append(toString()).append(" Finding key store interface").toString());
/*      */           }
/* 1509 */           localObject3 = KeyStore.getInstance("JKS");
/* 1510 */           localProvider3 = ((KeyStore)localObject3).getProvider();
/*      */ 
/* 1516 */           localObject4 = loadTrustStore(str2);
/*      */ 
/* 1520 */           if (logger.isLoggable(Level.FINEST)) {
/* 1521 */             logger.finest(new StringBuilder().append(toString()).append(" Loading key store").toString());
/*      */           }
/*      */           try
/*      */           {
/* 1525 */             ((KeyStore)localObject3).load((InputStream)localObject4, null == localObject1 ? null : ((String)localObject1).toCharArray());
/*      */ 
/* 1530 */             this.con.activeConnectionProperties.remove(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/*      */ 
/* 1533 */             if (null != localObject4)
/*      */             {
/*      */               try
/*      */               {
/* 1537 */                 ((InputStream)localObject4).close();
/*      */               }
/*      */               catch (IOException localIOException1)
/*      */               {
/* 1541 */                 if (logger.isLoggable(Level.FINE))
/* 1542 */                   logger.fine(new StringBuilder().append(toString()).append(" Ignoring error closing trust material InputStream...").toString());
/*      */               }
/*      */             }
/*      */           }
/*      */           finally
/*      */           {
/* 1530 */             this.con.activeConnectionProperties.remove(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/*      */ 
/* 1533 */             if (null != localObject4)
/*      */             {
/*      */               try
/*      */               {
/* 1537 */                 ((InputStream)localObject4).close();
/*      */               }
/*      */               catch (IOException localIOException2)
/*      */               {
/* 1541 */                 if (logger.isLoggable(Level.FINE)) {
/* 1542 */                   logger.fine(new StringBuilder().append(toString()).append(" Ignoring error closing trust material InputStream...").toString());
/*      */                 }
/*      */ 
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1555 */         Object localObject4 = null;
/*      */ 
/* 1557 */         if (logger.isLoggable(Level.FINEST)) {
/* 1558 */           logger.finest(new StringBuilder().append(toString()).append(" Locating X.509 trust manager factory").toString());
/*      */         }
/* 1560 */         str1 = TrustManagerFactory.getDefaultAlgorithm();
/* 1561 */         localObject4 = TrustManagerFactory.getInstance(str1);
/* 1562 */         localProvider1 = ((TrustManagerFactory)localObject4).getProvider();
/*      */ 
/* 1566 */         if (logger.isLoggable(Level.FINEST)) {
/* 1567 */           logger.finest(new StringBuilder().append(toString()).append(" Getting trust manager").toString());
/*      */         }
/* 1569 */         ((TrustManagerFactory)localObject4).init((KeyStore)localObject3);
/* 1570 */         arrayOfTrustManager = ((TrustManagerFactory)localObject4).getTrustManagers();
/*      */ 
/* 1573 */         if (null != localObject2)
/*      */         {
/* 1575 */           arrayOfTrustManager = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)arrayOfTrustManager[0], (String)localObject2) };
/*      */         }
/*      */         else
/*      */         {
/* 1579 */           arrayOfTrustManager = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)arrayOfTrustManager[0], paramString) };
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1585 */       Object localObject3 = null;
/*      */ 
/* 1587 */       if (logger.isLoggable(Level.FINEST)) {
/* 1588 */         logger.finest(new StringBuilder().append(toString()).append(" Getting TLS or better SSL context").toString());
/*      */       }
/* 1590 */       localObject3 = SSLContext.getInstance("TLS");
/* 1591 */       localProvider2 = ((SSLContext)localObject3).getProvider();
/*      */ 
/* 1593 */       if (logger.isLoggable(Level.FINEST)) {
/* 1594 */         logger.finest(new StringBuilder().append(toString()).append(" Initializing SSL context").toString());
/*      */       }
/* 1596 */       ((SSLContext)localObject3).init(null, arrayOfTrustManager, null);
/*      */ 
/* 1601 */       this.proxySocket = new ProxySocket(this);
/*      */ 
/* 1603 */       if (logger.isLoggable(Level.FINEST)) {
/* 1604 */         logger.finest(new StringBuilder().append(toString()).append(" Creating SSL socket").toString());
/*      */       }
/* 1606 */       this.sslSocket = ((SSLSocket)((SSLContext)localObject3).getSocketFactory().createSocket(this.proxySocket, paramString, paramInt, false));
/*      */ 
/* 1615 */       if (logger.isLoggable(Level.FINER)) {
/* 1616 */         logger.finer(new StringBuilder().append(toString()).append(" Starting SSL handshake").toString());
/*      */       }
/* 1618 */       this.sslSocket.startHandshake();
/*      */ 
/* 1621 */       if (logger.isLoggable(Level.FINEST)) {
/* 1622 */         logger.finest(new StringBuilder().append(toString()).append(" Rewiring proxy streams after handshake").toString());
/*      */       }
/* 1624 */       this.proxySocket.setStreams(this.inputStream, this.outputStream);
/*      */ 
/* 1627 */       if (logger.isLoggable(Level.FINEST)) {
/* 1628 */         logger.finest(new StringBuilder().append(toString()).append(" Getting SSL InputStream").toString());
/*      */       }
/* 1630 */       this.inputStream = this.sslSocket.getInputStream();
/*      */ 
/* 1632 */       if (logger.isLoggable(Level.FINEST)) {
/* 1633 */         logger.finest(new StringBuilder().append(toString()).append(" Getting SSL OutputStream").toString());
/*      */       }
/* 1635 */       this.outputStream = this.sslSocket.getOutputStream();
/*      */ 
/* 1638 */       this.channelSocket = this.sslSocket;
/*      */ 
/* 1640 */       if (logger.isLoggable(Level.FINER)) {
/* 1641 */         logger.finer(new StringBuilder().append(toString()).append(" SSL enabled").toString());
/*      */       }
/*      */     }
/*      */     catch (Exception localException)
/*      */     {
/* 1646 */       if (logger.isLoggable(Level.FINER)) {
/* 1647 */         logger.log(Level.FINER, localException.getMessage(), localException);
/*      */       }
/*      */ 
/* 1650 */       if (logger.isLoggable(Level.INFO)) {
/* 1651 */         logger.log(Level.INFO, new StringBuilder().append("java.security path: ").append(JAVA_SECURITY).append("\n").append("Security providers: ").append(Arrays.asList(Security.getProviders())).append("\n").append(null != localProvider2 ? new StringBuilder().append("SSLContext provider info: ").append(localProvider2.getInfo()).append("\n").append("SSLContext provider services:\n").append(localProvider2.getServices()).append("\n").toString() : "").append(null != localProvider1 ? new StringBuilder().append("TrustManagerFactory provider info: ").append(localProvider1.getInfo()).append("\n").toString() : "").append(null != str1 ? new StringBuilder().append("TrustManagerFactory default algorithm: ").append(str1).append("\n").toString() : "").append(null != localProvider3 ? new StringBuilder().append("KeyStore provider info: ").append(localProvider3.getInfo()).append("\n").toString() : "").append("java.ext.dirs: ").append(System.getProperty("java.ext.dirs")).toString());
/*      */       }
/*      */ 
/* 1666 */       Object localObject1 = new MessageFormat(SQLServerException.getErrString("R_sslFailed"));
/* 1667 */       Object localObject2 = { localException.getMessage() };
/* 1668 */       this.con.terminate(5, ((MessageFormat)localObject1).format(localObject2), localException);
/*      */     }
/*      */   }
/*      */ 
/*      */   final InputStream loadTrustStore(String paramString)
/*      */   {
/* 1694 */     FileInputStream localFileInputStream = null;
/*      */ 
/* 1697 */     if (null != paramString)
/*      */     {
/*      */       try
/*      */       {
/* 1701 */         if (logger.isLoggable(Level.FINEST)) {
/* 1702 */           logger.finest(new StringBuilder().append(toString()).append(" Opening specified trust store: ").append(paramString).toString());
/*      */         }
/* 1704 */         localFileInputStream = new FileInputStream(paramString);
/*      */       }
/*      */       catch (FileNotFoundException localFileNotFoundException1)
/*      */       {
/* 1708 */         if (logger.isLoggable(Level.FINE)) {
/* 1709 */           logger.fine(new StringBuilder().append(toString()).append(" Trust store not found: ").append(localFileNotFoundException1.getMessage()).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/* 1718 */     else if (null != (paramString = System.getProperty("javax.net.ssl.trustStore")))
/*      */     {
/*      */       try
/*      */       {
/* 1722 */         if (logger.isLoggable(Level.FINEST)) {
/* 1723 */           logger.finest(new StringBuilder().append(toString()).append(" Opening default trust store (from javax.net.ssl.trustStore): ").append(paramString).toString());
/*      */         }
/* 1725 */         localFileInputStream = new FileInputStream(paramString);
/*      */       }
/*      */       catch (FileNotFoundException localFileNotFoundException2)
/*      */       {
/* 1729 */         if (logger.isLoggable(Level.FINE)) {
/* 1730 */           logger.fine(new StringBuilder().append(toString()).append(" Trust store not found: ").append(localFileNotFoundException2.getMessage()).toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */       try
/*      */       {
/* 1743 */         if (logger.isLoggable(Level.FINEST)) {
/* 1744 */           logger.finest(new StringBuilder().append(toString()).append(" Opening default trust store: ").append(JSSECACERTS).toString());
/*      */         }
/* 1746 */         localFileInputStream = new FileInputStream(JSSECACERTS);
/*      */       }
/*      */       catch (FileNotFoundException localFileNotFoundException3)
/*      */       {
/* 1750 */         if (logger.isLoggable(Level.FINE)) {
/* 1751 */           logger.fine(new StringBuilder().append(toString()).append(" Trust store not found: ").append(localFileNotFoundException3.getMessage()).toString());
/*      */         }
/*      */       }
/*      */ 
/* 1755 */       if (null == localFileInputStream)
/*      */       {
/*      */         try
/*      */         {
/* 1759 */           if (logger.isLoggable(Level.FINEST)) {
/* 1760 */             logger.finest(new StringBuilder().append(toString()).append(" Opening default trust store: ").append(CACERTS).toString());
/*      */           }
/* 1762 */           localFileInputStream = new FileInputStream(CACERTS);
/*      */         }
/*      */         catch (FileNotFoundException localFileNotFoundException4)
/*      */         {
/* 1766 */           if (logger.isLoggable(Level.FINE)) {
/* 1767 */             logger.fine(new StringBuilder().append(toString()).append(" Trust store not found: ").append(localFileNotFoundException4.getMessage()).toString());
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1775 */     return localFileInputStream;
/*      */   }
/*      */ 
/*      */   final int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/*      */     try
/*      */     {
/* 1782 */       return this.inputStream.read(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1786 */       if (logger.isLoggable(Level.FINE)) {
/* 1787 */         logger.fine(new StringBuilder().append(toString()).append(" read failed:").append(localIOException.getMessage()).toString());
/*      */       }
/* 1789 */       this.con.terminate(3, localIOException.getMessage());
/* 1790 */     }return 0;
/*      */   }
/*      */ 
/*      */   final void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws SQLServerException
/*      */   {
/*      */     try
/*      */     {
/* 1798 */       this.outputStream.write(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1802 */       if (logger.isLoggable(Level.FINER)) {
/* 1803 */         logger.finer(new StringBuilder().append(toString()).append(" write failed:").append(localIOException.getMessage()).toString());
/*      */       }
/* 1805 */       this.con.terminate(3, localIOException.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   final void flush() throws SQLServerException
/*      */   {
/*      */     try
/*      */     {
/* 1813 */       this.outputStream.flush();
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1817 */       if (logger.isLoggable(Level.FINER)) {
/* 1818 */         logger.finer(new StringBuilder().append(toString()).append(" flush failed:").append(localIOException.getMessage()).toString());
/*      */       }
/* 1820 */       this.con.terminate(3, localIOException.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   final void close()
/*      */   {
/* 1826 */     if (null != this.sslSocket) {
/* 1827 */       disableSSL();
/*      */     }
/* 1829 */     if (null != this.inputStream)
/*      */     {
/* 1831 */       if (logger.isLoggable(Level.FINEST)) {
/* 1832 */         logger.finest(new StringBuilder().append(toString()).append(": Closing inputStream...").toString());
/*      */       }
/*      */       try
/*      */       {
/* 1836 */         this.inputStream.close();
/*      */       }
/*      */       catch (IOException localIOException1)
/*      */       {
/* 1840 */         if (logger.isLoggable(Level.FINE)) {
/* 1841 */           logger.log(Level.FINE, new StringBuilder().append(toString()).append(": Ignored error closing inputStream").toString(), localIOException1);
/*      */         }
/*      */       }
/*      */     }
/* 1845 */     if (null != this.outputStream)
/*      */     {
/* 1847 */       if (logger.isLoggable(Level.FINEST)) {
/* 1848 */         logger.finest(new StringBuilder().append(toString()).append(": Closing outputStream...").toString());
/*      */       }
/*      */       try
/*      */       {
/* 1852 */         this.outputStream.close();
/*      */       }
/*      */       catch (IOException localIOException2)
/*      */       {
/* 1856 */         if (logger.isLoggable(Level.FINE)) {
/* 1857 */           logger.log(Level.FINE, new StringBuilder().append(toString()).append(": Ignored error closing outputStream").toString(), localIOException2);
/*      */         }
/*      */       }
/*      */     }
/* 1861 */     if (null != this.tcpSocket)
/*      */     {
/* 1863 */       if (logger.isLoggable(Level.FINER)) {
/* 1864 */         logger.finer(new StringBuilder().append(toString()).append(": Closing TCP socket...").toString());
/*      */       }
/*      */       try
/*      */       {
/* 1868 */         this.tcpSocket.close();
/*      */       }
/*      */       catch (IOException localIOException3)
/*      */       {
/* 1872 */         if (logger.isLoggable(Level.FINE))
/* 1873 */           logger.log(Level.FINE, new StringBuilder().append(toString()).append(": Ignored error closing socket").toString(), localIOException3);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void logPacket(byte[] paramArrayOfByte, int paramInt1, int paramInt2, String paramString)
/*      */   {
/* 1888 */     assert ((0 <= paramInt2) && (paramInt2 <= paramArrayOfByte.length));
/* 1889 */     assert ((0 <= paramInt1) && (paramInt1 <= paramArrayOfByte.length));
/*      */ 
/* 1891 */     char[] arrayOfChar1 = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*      */ 
/* 1897 */     char[] arrayOfChar2 = { '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };
/*      */ 
/* 1923 */     char[] arrayOfChar3 = { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };
/*      */ 
/* 1936 */     char[] arrayOfChar4 = new char[arrayOfChar3.length];
/* 1937 */     System.arraycopy(arrayOfChar3, 0, arrayOfChar4, 0, arrayOfChar3.length);
/*      */ 
/* 1942 */     StringBuilder localStringBuilder = new StringBuilder(paramString.length() + 4 * paramInt2 + 4 * (1 + paramInt2 / 16) + 80);
/*      */ 
/* 1953 */     localStringBuilder.append(new StringBuilder().append(this.tcpSocket.getLocalAddress().toString()).append(":").append(this.tcpSocket.getLocalPort()).append(" SPID:").append(this.spid).append(" ").append(paramString).append("\r\n").toString());
/*      */ 
/* 1956 */     int i = 0;
/*      */     while (true)
/*      */     {
/* 1961 */       int j = 0;
/* 1962 */       while ((j < 16) && (i < paramInt2))
/*      */       {
/* 1965 */         k = (paramArrayOfByte[(paramInt1 + i)] + 256) % 256;
/* 1966 */         arrayOfChar4[(3 * j)] = arrayOfChar1[(k / 16)];
/* 1967 */         arrayOfChar4[(3 * j + 1)] = arrayOfChar1[(k % 16)];
/* 1968 */         arrayOfChar4[(50 + j)] = arrayOfChar2[k];
/*      */ 
/* 1963 */         j++; i++;
/*      */       }
/*      */ 
/* 1972 */       int k = j;
/* 1973 */       for (; k < 16; k++)
/*      */       {
/* 1975 */         arrayOfChar4[(3 * k)] = ' ';
/* 1976 */         arrayOfChar4[(3 * k + 1)] = ' ';
/*      */       }
/*      */ 
/* 1979 */       localStringBuilder.append(arrayOfChar4, 0, 50 + j);
/* 1980 */       if (i == paramInt2) {
/*      */         break;
/*      */       }
/* 1983 */       localStringBuilder.append("\r\n");
/*      */     }
/*      */ 
/* 1986 */     packetLogger.finest(localStringBuilder.toString());
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  413 */     logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.Channel");
/*      */ 
/*  453 */     packetLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.DATA");
/*      */ 
/* 1687 */     SEPARATOR = System.getProperty("file.separator");
/* 1688 */     JAVA_HOME = System.getProperty("java.home");
/* 1689 */     JAVA_SECURITY = new StringBuilder().append(JAVA_HOME).append(SEPARATOR).append("lib").append(SEPARATOR).append("security").toString();
/* 1690 */     JSSECACERTS = new StringBuilder().append(JAVA_SECURITY).append(SEPARATOR).append("jssecacerts").toString();
/* 1691 */     CACERTS = new StringBuilder().append(JAVA_SECURITY).append(SEPARATOR).append("cacerts").toString();
/*      */   }
/*      */ 
/*      */   private final class HostNameOverrideX509TrustManager
/*      */     implements X509TrustManager
/*      */   {
/*      */     private final Logger logger;
/*      */     private final String logContext;
/*      */     private final X509TrustManager defaultTrustManager;
/*      */     private String hostName;
/*      */ 
/*      */     HostNameOverrideX509TrustManager(TDSChannel paramX509TrustManager, X509TrustManager paramString, String arg4)
/*      */     {
/* 1239 */       this.logger = paramX509TrustManager.getLogger();
/* 1240 */       this.logContext = new StringBuilder().append(paramX509TrustManager.toString()).append(" (HostNameOverrideX509TrustManager):").toString();
/* 1241 */       this.defaultTrustManager = paramString;
/*      */       Object localObject;
/* 1243 */       this.hostName = localObject.toLowerCase();
/*      */     }
/*      */ 
/*      */     private String parseCommonName(String paramString)
/*      */     {
/* 1254 */       int i = paramString.indexOf("cn=");
/* 1255 */       if (i == -1)
/*      */       {
/* 1257 */         return null;
/*      */       }
/* 1259 */       paramString = paramString.substring(i + 3);
/*      */ 
/* 1263 */       for (i = 0; i < paramString.length(); i++)
/*      */       {
/* 1265 */         if (paramString.charAt(i) == ',')
/*      */         {
/*      */           break;
/*      */         }
/*      */       }
/* 1270 */       String str = paramString.substring(0, i);
/*      */ 
/* 1272 */       if ((str.length() > 1) && ('"' == str.charAt(0)))
/*      */       {
/* 1274 */         if ('"' == str.charAt(str.length() - 1)) {
/* 1275 */           str = str.substring(1, str.length() - 1);
/*      */         }
/*      */         else
/*      */         {
/* 1279 */           str = null;
/*      */         }
/*      */       }
/* 1282 */       return str;
/*      */     }
/*      */ 
/*      */     private boolean validateServerName(String paramString)
/*      */       throws CertificateException
/*      */     {
/* 1288 */       if (null == paramString)
/*      */       {
/* 1290 */         if (this.logger.isLoggable(Level.FINER))
/* 1291 */           this.logger.finer(new StringBuilder().append(this.logContext).append(" Failed to parse the name from the certificate or name is empty.").toString());
/* 1292 */         return false;
/*      */       }
/*      */ 
/* 1296 */       if (!paramString.equals(this.hostName))
/*      */       {
/* 1298 */         if (this.logger.isLoggable(Level.FINER))
/* 1299 */           this.logger.finer(new StringBuilder().append(this.logContext).append(" The name in certificate ").append(paramString).append(" does not match with the server name ").append(this.hostName).append(".").toString());
/* 1300 */         return false;
/*      */       }
/*      */ 
/* 1303 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1304 */         this.logger.finer(new StringBuilder().append(this.logContext).append(" The name in certificate:").append(paramString).append(" validated against server name ").append(this.hostName).append(".").toString());
/*      */       }
/* 1306 */       return true;
/*      */     }
/*      */ 
/*      */     public void checkClientTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws CertificateException
/*      */     {
/* 1311 */       if (this.logger.isLoggable(Level.FINEST))
/* 1312 */         this.logger.finest(new StringBuilder().append(this.logContext).append(" Forwarding ClientTrusted.").toString());
/* 1313 */       this.defaultTrustManager.checkClientTrusted(paramArrayOfX509Certificate, paramString);
/*      */     }
/*      */ 
/*      */     public void checkServerTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws CertificateException
/*      */     {
/* 1318 */       if (this.logger.isLoggable(Level.FINEST))
/* 1319 */         this.logger.finest(new StringBuilder().append(this.logContext).append(" Forwarding Trusting server certificate").toString());
/* 1320 */       this.defaultTrustManager.checkServerTrusted(paramArrayOfX509Certificate, paramString);
/* 1321 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1322 */         this.logger.finest(new StringBuilder().append(this.logContext).append(" default serverTrusted succeeded proceeding with server name validation").toString());
/*      */       }
/* 1324 */       validateServerNameInCertificate(paramArrayOfX509Certificate[0]);
/*      */     }
/*      */ 
/*      */     private void validateServerNameInCertificate(X509Certificate paramX509Certificate) throws CertificateException
/*      */     {
/* 1329 */       String str1 = paramX509Certificate.getSubjectX500Principal().getName("canonical");
/* 1330 */       if (this.logger.isLoggable(Level.FINER))
/*      */       {
/* 1332 */         this.logger.finer(new StringBuilder().append(this.logContext).append(" Validating the server name:").append(this.hostName).toString());
/* 1333 */         this.logger.finer(new StringBuilder().append(this.logContext).append(" The DN name in certificate:").append(str1).toString());
/*      */       }
/*      */ 
/* 1336 */       boolean bool = false;
/*      */ 
/* 1339 */       String str2 = parseCommonName(str1);
/*      */ 
/* 1341 */       bool = validateServerName(str2);
/*      */       Object localObject1;
/* 1343 */       if (!bool)
/*      */       {
/* 1346 */         localObject1 = paramX509Certificate.getSubjectAlternativeNames();
/*      */ 
/* 1348 */         if (localObject1 != null)
/*      */         {
/* 1351 */           for (List localList : (Collection)localObject1)
/*      */           {
/* 1354 */             if ((localList != null) && (localList.size() >= 2))
/*      */             {
/* 1356 */               Object localObject2 = localList.get(0);
/* 1357 */               Object localObject3 = localList.get(1);
/*      */ 
/* 1359 */               if (this.logger.isLoggable(Level.FINER))
/*      */               {
/* 1361 */                 this.logger.finer(new StringBuilder().append(this.logContext).append("Key: ").append(localObject2).append("; KeyClass:").append(localObject2 != null ? localObject2.getClass() : null).append(";value: ").append(localObject3).append("; valueClass:").append(localObject3 != null ? localObject3.getClass() : null).toString());
/*      */               }
/*      */ 
/* 1375 */               if ((localObject2 != null) && ((localObject2 instanceof Integer)) && (((Integer)localObject2).intValue() == 2))
/*      */               {
/* 1383 */                 if ((localObject3 != null) && ((localObject3 instanceof String)))
/*      */                 {
/* 1385 */                   String str3 = (String)localObject3;
/*      */ 
/* 1392 */                   str3 = str3.toUpperCase(Locale.US);
/* 1393 */                   str3 = str3.toLowerCase(Locale.US);
/*      */ 
/* 1395 */                   bool = validateServerName(str3);
/*      */ 
/* 1397 */                   if (bool)
/*      */                   {
/* 1399 */                     if (!this.logger.isLoggable(Level.FINER))
/*      */                       break;
/* 1401 */                     this.logger.finer(new StringBuilder().append(this.logContext).append(" found a valid name in certificate: ").append(str3).toString()); break;
/*      */                   }
/*      */ 
/*      */                 }
/*      */ 
/* 1408 */                 if (this.logger.isLoggable(Level.FINER))
/*      */                 {
/* 1410 */                   this.logger.finer(new StringBuilder().append(this.logContext).append(" the following name in certificate does not match the serverName: ").append(localObject3).toString());
/*      */                 }
/*      */ 
/*      */               }
/*      */ 
/*      */             }
/* 1418 */             else if (this.logger.isLoggable(Level.FINER))
/*      */             {
/* 1420 */               this.logger.finer(new StringBuilder().append(this.logContext).append(" found an invalid san entry: ").append(localList).toString());
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1428 */       if (!bool)
/*      */       {
/* 1430 */         localObject1 = SQLServerException.getErrString("R_certNameFailed");
/* 1431 */         throw new CertificateException((String)localObject1);
/*      */       }
/*      */     }
/*      */ 
/*      */     public X509Certificate[] getAcceptedIssuers()
/*      */     {
/* 1437 */       return this.defaultTrustManager.getAcceptedIssuers();
/*      */     }
/*      */   }
/*      */ 
/*      */   private final class PermissiveX509TrustManager
/*      */     implements X509TrustManager
/*      */   {
/*      */     private final TDSChannel tdsChannel;
/*      */     private final Logger logger;
/*      */     private final String logContext;
/*      */ 
/*      */     PermissiveX509TrustManager(TDSChannel arg2)
/*      */     {
/*      */       Object localObject;
/* 1203 */       this.tdsChannel = localObject;
/* 1204 */       this.logger = localObject.getLogger();
/* 1205 */       this.logContext = (localObject.toString() + " (PermissiveX509TrustManager):");
/*      */     }
/*      */ 
/*      */     public void checkClientTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws CertificateException
/*      */     {
/* 1210 */       if (this.logger.isLoggable(Level.FINER))
/* 1211 */         this.logger.finer(this.logContext + " Trusting client certificate (!)");
/*      */     }
/*      */ 
/*      */     public void checkServerTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws CertificateException
/*      */     {
/* 1216 */       if (this.logger.isLoggable(Level.FINER))
/* 1217 */         this.logger.finer(this.logContext + " Trusting server certificate");
/*      */     }
/*      */ 
/*      */     public X509Certificate[] getAcceptedIssuers()
/*      */     {
/* 1222 */       return new X509Certificate[0];
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ProxySocket extends Socket
/*      */   {
/*      */     private final TDSChannel tdsChannel;
/*      */     private final Logger logger;
/*      */     private final String logContext;
/*      */     private final TDSChannel.ProxyInputStream proxyInputStream;
/*      */     private final TDSChannel.ProxyOutputStream proxyOutputStream;
/*      */ 
/*      */     ProxySocket(TDSChannel arg2)
/*      */     {
/*      */       TDSChannel localTDSChannel;
/* 1032 */       this.tdsChannel = localTDSChannel;
/* 1033 */       this.logger = localTDSChannel.getLogger();
/* 1034 */       this.logContext = (localTDSChannel.toString() + " (ProxySocket):");
/*      */ 
/* 1037 */       TDSChannel.SSLHandshakeOutputStream localSSLHandshakeOutputStream = new TDSChannel.SSLHandshakeOutputStream(TDSChannel.this, localTDSChannel);
/* 1038 */       TDSChannel.SSLHandshakeInputStream localSSLHandshakeInputStream = new TDSChannel.SSLHandshakeInputStream(TDSChannel.this, localTDSChannel, localSSLHandshakeOutputStream);
/* 1039 */       this.proxyOutputStream = new TDSChannel.ProxyOutputStream(TDSChannel.this, localSSLHandshakeOutputStream);
/* 1040 */       this.proxyInputStream = new TDSChannel.ProxyInputStream(TDSChannel.this, localSSLHandshakeInputStream);
/*      */     }
/*      */ 
/*      */     void setStreams(InputStream paramInputStream, OutputStream paramOutputStream)
/*      */     {
/* 1045 */       this.proxyInputStream.setFilteredStream(paramInputStream);
/* 1046 */       this.proxyOutputStream.setFilteredStream(paramOutputStream);
/*      */     }
/*      */ 
/*      */     public InputStream getInputStream() throws IOException
/*      */     {
/* 1051 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1052 */         this.logger.finest(this.logContext + " Getting input stream");
/*      */       }
/* 1054 */       return this.proxyInputStream;
/*      */     }
/*      */ 
/*      */     public OutputStream getOutputStream() throws IOException
/*      */     {
/* 1059 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1060 */         this.logger.finest(this.logContext + " Getting output stream");
/*      */       }
/* 1062 */       return this.proxyOutputStream;
/*      */     }
/*      */ 
/*      */     public InetAddress getInetAddress() {
/* 1066 */       return this.tdsChannel.tcpSocket.getInetAddress(); } 
/* 1067 */     public boolean getKeepAlive() throws SocketException { return this.tdsChannel.tcpSocket.getKeepAlive(); } 
/* 1068 */     public InetAddress getLocalAddress() { return this.tdsChannel.tcpSocket.getLocalAddress(); } 
/* 1069 */     public int getLocalPort() { return this.tdsChannel.tcpSocket.getLocalPort(); } 
/* 1070 */     public SocketAddress getLocalSocketAddress() { return this.tdsChannel.tcpSocket.getLocalSocketAddress(); } 
/* 1071 */     public boolean getOOBInline() throws SocketException { return this.tdsChannel.tcpSocket.getOOBInline(); } 
/* 1072 */     public int getPort() { return this.tdsChannel.tcpSocket.getPort(); } 
/* 1073 */     public int getReceiveBufferSize() throws SocketException { return this.tdsChannel.tcpSocket.getReceiveBufferSize(); } 
/* 1074 */     public SocketAddress getRemoteSocketAddress() { return this.tdsChannel.tcpSocket.getRemoteSocketAddress(); } 
/* 1075 */     public boolean getReuseAddress() throws SocketException { return this.tdsChannel.tcpSocket.getReuseAddress(); } 
/* 1076 */     public int getSendBufferSize() throws SocketException { return this.tdsChannel.tcpSocket.getSendBufferSize(); } 
/* 1077 */     public int getSoLinger() throws SocketException { return this.tdsChannel.tcpSocket.getSoLinger(); } 
/* 1078 */     public int getSoTimeout() throws SocketException { return this.tdsChannel.tcpSocket.getSoTimeout(); } 
/* 1079 */     public boolean getTcpNoDelay() throws SocketException { return this.tdsChannel.tcpSocket.getTcpNoDelay(); } 
/* 1080 */     public int getTrafficClass() throws SocketException { return this.tdsChannel.tcpSocket.getTrafficClass(); } 
/* 1081 */     public boolean isBound() { return true; } 
/* 1082 */     public boolean isClosed() { return false; } 
/* 1083 */     public boolean isConnected() { return true; } 
/* 1084 */     public boolean isInputShutdown() { return false; } 
/* 1085 */     public boolean isOutputShutdown() { return false; } 
/* 1086 */     public String toString() { return this.tdsChannel.tcpSocket.toString(); } 
/* 1087 */     public SocketChannel getChannel() { return null; }
/*      */ 
/*      */     public void bind(SocketAddress paramSocketAddress)
/*      */       throws IOException
/*      */     {
/* 1092 */       this.logger.finer(this.logContext + " Disallowed call to bind.  Throwing IOException.");
/* 1093 */       throw new IOException();
/*      */     }
/*      */ 
/*      */     public void connect(SocketAddress paramSocketAddress) throws IOException
/*      */     {
/* 1098 */       this.logger.finer(this.logContext + " Disallowed call to connect (without timeout).  Throwing IOException.");
/* 1099 */       throw new IOException();
/*      */     }
/*      */ 
/*      */     public void connect(SocketAddress paramSocketAddress, int paramInt) throws IOException
/*      */     {
/* 1104 */       this.logger.finer(this.logContext + " Disallowed call to connect (with timeout).  Throwing IOException.");
/* 1105 */       throw new IOException();
/*      */     }
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/* 1112 */       if (this.logger.isLoggable(Level.FINER))
/* 1113 */         this.logger.finer(this.logContext + " Ignoring close");
/*      */     }
/*      */ 
/*      */     public void setReceiveBufferSize(int paramInt) throws SocketException
/*      */     {
/* 1118 */       if (this.logger.isLoggable(Level.FINER))
/* 1119 */         this.logger.finer(toString() + " Ignoring setReceiveBufferSize size:" + paramInt);
/*      */     }
/*      */ 
/*      */     public void setSendBufferSize(int paramInt) throws SocketException
/*      */     {
/* 1124 */       if (this.logger.isLoggable(Level.FINER))
/* 1125 */         this.logger.finer(toString() + " Ignoring setSendBufferSize size:" + paramInt);
/*      */     }
/*      */ 
/*      */     public void setReuseAddress(boolean paramBoolean) throws SocketException
/*      */     {
/* 1130 */       if (this.logger.isLoggable(Level.FINER))
/* 1131 */         this.logger.finer(toString() + " Ignoring setReuseAddress");
/*      */     }
/*      */ 
/*      */     public void setSoLinger(boolean paramBoolean, int paramInt) throws SocketException
/*      */     {
/* 1136 */       if (this.logger.isLoggable(Level.FINER))
/* 1137 */         this.logger.finer(toString() + " Ignoring setSoLinger");
/*      */     }
/*      */ 
/*      */     public void setSoTimeout(int paramInt) throws SocketException
/*      */     {
/* 1142 */       if (this.logger.isLoggable(Level.FINER))
/* 1143 */         this.logger.finer(toString() + " Ignoring setSoTimeout");
/*      */     }
/*      */ 
/*      */     public void setTcpNoDelay(boolean paramBoolean) throws SocketException
/*      */     {
/* 1148 */       if (this.logger.isLoggable(Level.FINER))
/* 1149 */         this.logger.finer(toString() + " Ignoring setTcpNoDelay");
/*      */     }
/*      */ 
/*      */     public void setTrafficClass(int paramInt) throws SocketException
/*      */     {
/* 1154 */       if (this.logger.isLoggable(Level.FINER))
/* 1155 */         this.logger.finer(toString() + " Ignoring setTrafficClass");
/*      */     }
/*      */ 
/*      */     public void shutdownInput() throws IOException
/*      */     {
/* 1160 */       if (this.logger.isLoggable(Level.FINER))
/* 1161 */         this.logger.finer(toString() + " Ignoring shutdownInput");
/*      */     }
/*      */ 
/*      */     public void shutdownOutput() throws IOException
/*      */     {
/* 1166 */       if (this.logger.isLoggable(Level.FINER))
/* 1167 */         this.logger.finer(toString() + " Ignoring shutdownOutput");
/*      */     }
/*      */ 
/*      */     public void sendUrgentData(int paramInt) throws IOException
/*      */     {
/* 1172 */       if (this.logger.isLoggable(Level.FINER))
/* 1173 */         this.logger.finer(toString() + " Ignoring sendUrgentData");
/*      */     }
/*      */ 
/*      */     public void setKeepAlive(boolean paramBoolean) throws SocketException
/*      */     {
/* 1178 */       if (this.logger.isLoggable(Level.FINER))
/* 1179 */         this.logger.finer(toString() + " Ignoring setKeepAlive");
/*      */     }
/*      */ 
/*      */     public void setOOBInline(boolean paramBoolean) throws SocketException
/*      */     {
/* 1184 */       if (this.logger.isLoggable(Level.FINER))
/* 1185 */         this.logger.finer(toString() + " Ignoring setOOBInline");
/*      */     }
/*      */   }
/*      */ 
/*      */   final class ProxyOutputStream extends OutputStream
/*      */   {
/*      */     private OutputStream filteredStream;
/*  983 */     private final byte[] singleByte = new byte[1];
/*      */ 
/*      */     ProxyOutputStream(OutputStream arg2)
/*      */     {
/*      */       Object localObject;
/*  959 */       this.filteredStream = localObject;
/*      */     }
/*      */ 
/*      */     final void setFilteredStream(OutputStream paramOutputStream)
/*      */     {
/*  964 */       this.filteredStream = paramOutputStream;
/*      */     }
/*      */ 
/*      */     public void close() throws IOException
/*      */     {
/*  969 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  970 */         TDSChannel.logger.finest(toString() + " Closing");
/*      */       }
/*  972 */       this.filteredStream.close();
/*      */     }
/*      */ 
/*      */     public void flush() throws IOException
/*      */     {
/*  977 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  978 */         TDSChannel.logger.finest(toString() + " Flushing");
/*      */       }
/*  980 */       this.filteredStream.flush();
/*      */     }
/*      */ 
/*      */     public void write(int paramInt)
/*      */       throws IOException
/*      */     {
/*  986 */       this.singleByte[0] = (byte)(paramInt & 0xFF);
/*  987 */       writeInternal(this.singleByte, 0, this.singleByte.length);
/*      */     }
/*      */ 
/*      */     public void write(byte[] paramArrayOfByte) throws IOException
/*      */     {
/*  992 */       writeInternal(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */     }
/*      */ 
/*      */     public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/*  997 */       writeInternal(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */ 
/*      */     private void writeInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/* 1002 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1003 */         TDSChannel.logger.finest(toString() + " Writing " + paramInt2 + " bytes");
/*      */       }
/* 1005 */       this.filteredStream.write(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final class ProxyInputStream extends InputStream
/*      */   {
/*      */     private InputStream filteredStream;
/*  864 */     private final byte[] oneByte = new byte[1];
/*      */ 
/*      */     ProxyInputStream(InputStream arg2)
/*      */     {
/*      */       Object localObject;
/*  831 */       this.filteredStream = localObject;
/*      */     }
/*      */ 
/*      */     final void setFilteredStream(InputStream paramInputStream)
/*      */     {
/*  836 */       this.filteredStream = paramInputStream;
/*      */     }
/*      */ 
/*      */     public long skip(long paramLong)
/*      */       throws IOException
/*      */     {
/*  843 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  844 */         TDSChannel.logger.finest(toString() + " Skipping " + paramLong + " bytes");
/*      */       }
/*  846 */       long l = this.filteredStream.skip(paramLong);
/*      */ 
/*  848 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  849 */         TDSChannel.logger.finest(toString() + " Skipped " + paramLong + " bytes");
/*      */       }
/*  851 */       return l;
/*      */     }
/*      */ 
/*      */     public int available() throws IOException
/*      */     {
/*  856 */       int i = this.filteredStream.available();
/*      */ 
/*  858 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  859 */         TDSChannel.logger.finest(toString() + " " + i + " bytes available");
/*      */       }
/*  861 */       return i;
/*      */     }
/*      */ 
/*      */     public int read()
/*      */       throws IOException
/*      */     {
/*      */       int i;
/*  869 */       while (0 == (i = readInternal(this.oneByte, 0, this.oneByte.length)));
/*  872 */       assert ((1 == i) || (-1 == i));
/*  873 */       return 1 == i ? this.oneByte[0] : -1;
/*      */     }
/*      */ 
/*      */     public int read(byte[] paramArrayOfByte) throws IOException
/*      */     {
/*  878 */       return readInternal(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */     }
/*      */ 
/*      */     public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/*  883 */       return readInternal(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */ 
/*      */     private int readInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */       throws IOException
/*      */     {
/*  890 */       if (TDSChannel.logger.isLoggable(Level.FINEST))
/*  891 */         TDSChannel.logger.finest(toString() + " Reading " + paramInt2 + " bytes");
/*      */       int i;
/*      */       try {
/*  895 */         i = this.filteredStream.read(paramArrayOfByte, paramInt1, paramInt2);
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*  899 */         if (TDSChannel.logger.isLoggable(Level.FINER)) {
/*  900 */           TDSChannel.logger.finer(toString() + " " + localIOException.getMessage());
/*      */         }
/*  902 */         TDSChannel.logger.finer(toString() + " Reading bytes threw exception:" + localIOException.getMessage());
/*  903 */         throw localIOException;
/*      */       }
/*      */ 
/*  906 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  907 */         TDSChannel.logger.finest(toString() + " Read " + i + " bytes");
/*      */       }
/*  909 */       return i;
/*      */     }
/*      */ 
/*      */     public boolean markSupported()
/*      */     {
/*  914 */       boolean bool = this.filteredStream.markSupported();
/*      */ 
/*  916 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  917 */         TDSChannel.logger.finest(toString() + " Returning markSupported: " + bool);
/*      */       }
/*  919 */       return bool;
/*      */     }
/*      */ 
/*      */     public void mark(int paramInt)
/*      */     {
/*  924 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  925 */         TDSChannel.logger.finest(toString() + " Marking next " + paramInt + " bytes");
/*      */       }
/*  927 */       this.filteredStream.mark(paramInt);
/*      */     }
/*      */ 
/*      */     public void reset() throws IOException
/*      */     {
/*  932 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  933 */         TDSChannel.logger.finest(toString() + " Resetting to previous mark");
/*      */       }
/*  935 */       this.filteredStream.reset();
/*      */     }
/*      */ 
/*      */     public void close() throws IOException
/*      */     {
/*  940 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  941 */         TDSChannel.logger.finest(toString() + " Closing");
/*      */       }
/*  943 */       this.filteredStream.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class SSLHandshakeOutputStream extends OutputStream
/*      */   {
/*      */     private final TDSWriter tdsWriter;
/*      */     private boolean messageStarted;
/*      */     private final Logger logger;
/*      */     private final String logContext;
/*  774 */     private final byte[] singleByte = new byte[1];
/*      */ 
/*      */     SSLHandshakeOutputStream(TDSChannel arg2)
/*      */     {
/*      */       Object localObject;
/*  740 */       this.tdsWriter = localObject.getWriter();
/*  741 */       this.messageStarted = false;
/*  742 */       this.logger = localObject.getLogger();
/*  743 */       this.logContext = (localObject.toString() + " (SSLHandshakeOutputStream):");
/*      */     }
/*      */ 
/*      */     public void flush()
/*      */       throws IOException
/*      */     {
/*  755 */       if (this.logger.isLoggable(Level.FINEST))
/*  756 */         this.logger.finest(this.logContext + " Ignored a request to flush the stream");
/*      */     }
/*      */ 
/*      */     void endMessage()
/*      */       throws SQLServerException
/*      */     {
/*  762 */       assert (this.messageStarted);
/*      */ 
/*  764 */       if (this.logger.isLoggable(Level.FINEST)) {
/*  765 */         this.logger.finest(this.logContext + " Finishing TDS message");
/*      */       }
/*      */ 
/*  770 */       this.tdsWriter.endMessage();
/*  771 */       this.messageStarted = false;
/*      */     }
/*      */ 
/*      */     public void write(int paramInt)
/*      */       throws IOException
/*      */     {
/*  777 */       this.singleByte[0] = (byte)(paramInt & 0xFF);
/*  778 */       writeInternal(this.singleByte, 0, this.singleByte.length);
/*      */     }
/*      */ 
/*      */     public void write(byte[] paramArrayOfByte) throws IOException
/*      */     {
/*  783 */       writeInternal(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */     }
/*      */ 
/*      */     public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/*  788 */       writeInternal(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */ 
/*      */     private void writeInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */       throws IOException
/*      */     {
/*      */       try
/*      */       {
/*  797 */         if (!this.messageStarted)
/*      */         {
/*  799 */           if (this.logger.isLoggable(Level.FINEST)) {
/*  800 */             this.logger.finest(this.logContext + " Starting new TDS packet...");
/*      */           }
/*  802 */           this.tdsWriter.startMessage(null, 18);
/*  803 */           this.messageStarted = true;
/*      */         }
/*      */ 
/*  806 */         if (this.logger.isLoggable(Level.FINEST)) {
/*  807 */           this.logger.finest(this.logContext + " Writing " + paramInt2 + " bytes...");
/*      */         }
/*  809 */         this.tdsWriter.writeBytes(paramArrayOfByte, paramInt1, paramInt2);
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/*  813 */         this.logger.finer(this.logContext + " Writing bytes threw exception:" + localSQLServerException.getMessage());
/*  814 */         throw new IOException(localSQLServerException.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class SSLHandshakeInputStream extends InputStream
/*      */   {
/*      */     private final TDSReader tdsReader;
/*      */     private final TDSChannel.SSLHandshakeOutputStream sslHandshakeOutputStream;
/*      */     private final Logger logger;
/*      */     private final String logContext;
/*  681 */     private final byte[] oneByte = new byte[1];
/*      */ 
/*      */     SSLHandshakeInputStream(TDSChannel paramSSLHandshakeOutputStream, TDSChannel.SSLHandshakeOutputStream arg3)
/*      */     {
/*  610 */       this.tdsReader = paramSSLHandshakeOutputStream.getReader(null);
/*      */       Object localObject;
/*  611 */       this.sslHandshakeOutputStream = localObject;
/*  612 */       this.logger = paramSSLHandshakeOutputStream.getLogger();
/*  613 */       this.logContext = (paramSSLHandshakeOutputStream.toString() + " (SSLHandshakeInputStream):");
/*      */     }
/*      */ 
/*      */     private final void ensureSSLPayload()
/*      */       throws IOException
/*      */     {
/*  626 */       if (0 == this.tdsReader.available())
/*      */       {
/*  628 */         if (this.logger.isLoggable(Level.FINEST)) {
/*  629 */           this.logger.finest(this.logContext + " No handshake response bytes available. Flushing SSL handshake output stream.");
/*      */         }
/*      */         try
/*      */         {
/*  633 */           this.sslHandshakeOutputStream.endMessage();
/*      */         }
/*      */         catch (SQLServerException localSQLServerException1)
/*      */         {
/*  637 */           this.logger.finer(this.logContext + " Ending TDS message threw exception:" + localSQLServerException1.getMessage());
/*  638 */           throw new IOException(localSQLServerException1.getMessage());
/*      */         }
/*      */ 
/*  641 */         if (this.logger.isLoggable(Level.FINEST)) {
/*  642 */           this.logger.finest(this.logContext + " Reading first packet of SSL handshake response");
/*      */         }
/*      */         try
/*      */         {
/*  646 */           this.tdsReader.readPacket();
/*      */         }
/*      */         catch (SQLServerException localSQLServerException2)
/*      */         {
/*  650 */           this.logger.finer(this.logContext + " Reading response packet threw exception:" + localSQLServerException2.getMessage());
/*  651 */           throw new IOException(localSQLServerException2.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public long skip(long paramLong) throws IOException
/*      */     {
/*  658 */       if (this.logger.isLoggable(Level.FINEST)) {
/*  659 */         this.logger.finest(this.logContext + " Skipping " + paramLong + " bytes...");
/*      */       }
/*  661 */       if (paramLong <= 0L) return 0L;
/*      */ 
/*  663 */       if (paramLong > 2147483647L) {
/*  664 */         paramLong = 2147483647L;
/*      */       }
/*  666 */       ensureSSLPayload();
/*      */       try
/*      */       {
/*  670 */         this.tdsReader.skip((int)paramLong);
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/*  674 */         this.logger.finer(this.logContext + " Skipping bytes threw exception:" + localSQLServerException.getMessage());
/*  675 */         throw new IOException(localSQLServerException.getMessage());
/*      */       }
/*      */ 
/*  678 */       return paramLong;
/*      */     }
/*      */ 
/*      */     public int read()
/*      */       throws IOException
/*      */     {
/*      */       int i;
/*  686 */       while (0 == (i = readInternal(this.oneByte, 0, this.oneByte.length)));
/*  689 */       assert ((1 == i) || (-1 == i));
/*  690 */       return 1 == i ? this.oneByte[0] : -1;
/*      */     }
/*      */ 
/*      */     public int read(byte[] paramArrayOfByte) throws IOException
/*      */     {
/*  695 */       return readInternal(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */     }
/*      */ 
/*      */     public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/*  700 */       return readInternal(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */ 
/*      */     private int readInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/*  705 */       if (this.logger.isLoggable(Level.FINEST)) {
/*  706 */         this.logger.finest(this.logContext + " Reading " + paramInt2 + " bytes...");
/*      */       }
/*  708 */       ensureSSLPayload();
/*      */       try
/*      */       {
/*  712 */         this.tdsReader.readBytes(paramArrayOfByte, paramInt1, paramInt2);
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/*  716 */         this.logger.finer(this.logContext + " Reading bytes threw exception:" + localSQLServerException.getMessage());
/*  717 */         throw new IOException(localSQLServerException.getMessage());
/*      */       }
/*      */ 
/*  720 */       return paramInt2;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TDSChannel
 * JD-Core Version:    0.6.0
 */