/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Socket;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ final class SocketConnector
/*      */   implements Runnable
/*      */ {
/*      */   private final Socket socket;
/*      */   private final SocketFinder socketFinder;
/*      */   private final InetSocketAddress inetSocketAddress;
/*      */   private final int timeoutInMilliseconds;
/* 2787 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SocketConnector");
/*      */   private final String traceID;
/*      */   private final String threadID;
/* 2795 */   private static long lastThreadID = 0L;
/*      */ 
/*      */   SocketConnector(Socket paramSocket, InetSocketAddress paramInetSocketAddress, int paramInt, SocketFinder paramSocketFinder)
/*      */   {
/* 2803 */     this.socket = paramSocket;
/* 2804 */     this.inetSocketAddress = paramInetSocketAddress;
/* 2805 */     this.timeoutInMilliseconds = paramInt;
/* 2806 */     this.socketFinder = paramSocketFinder;
/* 2807 */     this.threadID = Long.toString(nextThreadID());
/* 2808 */     this.traceID = ("SocketConnector:" + this.threadID + "(" + paramSocketFinder.toString() + ")");
/*      */   }
/*      */ 
/*      */   public void run()
/*      */   {
/* 2820 */     Object localObject = null;
/*      */ 
/* 2824 */     SocketFinder.Result localResult = this.socketFinder.getResult();
/* 2825 */     if (localResult.equals(SocketFinder.Result.UNKNOWN))
/*      */     {
/*      */       try
/*      */       {
/* 2829 */         if (logger.isLoggable(Level.FINER))
/*      */         {
/* 2831 */           logger.finer(toString() + " connecting to InetSocketAddress:" + this.inetSocketAddress + " with timeout:" + this.timeoutInMilliseconds);
/*      */         }
/*      */ 
/* 2835 */         this.socket.connect(this.inetSocketAddress, this.timeoutInMilliseconds);
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 2839 */         if (logger.isLoggable(Level.FINER))
/*      */         {
/* 2841 */           logger.finer(toString() + " exception:" + localIOException.getClass() + " with message:" + localIOException.getMessage() + " occured while connecting to InetSocketAddress:" + this.inetSocketAddress);
/*      */         }
/*      */ 
/* 2846 */         localObject = localIOException;
/*      */       }
/*      */ 
/* 2849 */       this.socketFinder.updateResult(this.socket, localObject, toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2860 */     return this.traceID;
/*      */   }
/*      */ 
/*      */   private static synchronized long nextThreadID()
/*      */   {
/* 2869 */     if (lastThreadID == 9223372036854775807L)
/*      */     {
/* 2871 */       if (logger.isLoggable(Level.FINER))
/* 2872 */         logger.finer("Resetting the Id count");
/* 2873 */       lastThreadID = 1L;
/*      */     }
/*      */     else
/*      */     {
/* 2877 */       lastThreadID += 1L;
/*      */     }
/* 2879 */     return lastThreadID;
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.SocketConnector
 * JD-Core Version:    0.6.0
 */