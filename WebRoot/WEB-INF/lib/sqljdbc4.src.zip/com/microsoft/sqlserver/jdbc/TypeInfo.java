/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.util.EnumMap;
/*      */ import java.util.Map;
/*      */ 
/*      */ final class TypeInfo
/*      */ {
/*      */   private int maxLength;
/*      */   private SSLenType ssLenType;
/*      */   private int precision;
/*      */   private int displaySize;
/*      */   private int scale;
/*      */   private short flags;
/*      */   private SSType ssType;
/*      */   private int userType;
/*      */   private String udtTypeName;
/*      */   private SQLCollation collation;
/*      */   private String charset;
/*      */   static int UPDATABLE_READ_ONLY;
/*      */   static int UPDATABLE_READ_WRITE;
/*      */   static int UPDATABLE_UNKNOWN;
/*      */   private static final Map<TDSType, Builder> builderMap;
/*      */ 
/*      */   SSType getSSType()
/*      */   {
/* 1601 */     return this.ssType; } 
/* 1602 */   SSLenType getSSLenType() { return this.ssLenType; } 
/* 1603 */   String getSSTypeName() { return SSType.UDT == this.ssType ? this.udtTypeName : this.ssType.toString(); } 
/* 1604 */   int getMaxLength() { return this.maxLength; } 
/* 1605 */   int getPrecision() { return this.precision; } 
/* 1606 */   int getDisplaySize() { return this.displaySize; } 
/* 1607 */   int getScale() { return this.scale; } 
/* 1608 */   SQLCollation getSQLCollation() { return this.collation; } 
/* 1609 */   String getCharset() { return this.charset; } 
/* 1610 */   boolean isNullable() { return 1 == (this.flags & 0x1); } 
/* 1611 */   boolean isCaseSensitive() { return 2 == (this.flags & 0x2); } 
/* 1612 */   boolean isSparseColumnSet() { return 1024 == (this.flags & 0x400);
/*      */   }
/*      */ 
/*      */   int getUpdatability()
/*      */   {
/* 1617 */     return this.flags >> 2 & 0x3;
/*      */   }
/* 1619 */   boolean isIdentity() { return 16 == (this.flags & 0x10);
/*      */   }
/*      */ 
/*      */   boolean supportsFastAsciiConversion()
/*      */   {
/* 2174 */     switch (1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSType[this.ssType.ordinal()])
/*      */     {
/*      */     case 4:
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/* 2180 */       return this.collation.hasAsciiCompatibleSBCS();
/*      */     }
/*      */ 
/* 2183 */     return false;
/*      */   }
/*      */ 
/*      */   static TypeInfo getInstance(TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 2200 */     TypeInfo localTypeInfo = new TypeInfo();
/*      */ 
/* 2203 */     localTypeInfo.userType = paramTDSReader.readInt();
/*      */ 
/* 2206 */     localTypeInfo.flags = paramTDSReader.readShort();
/*      */ 
/* 2208 */     TDSType localTDSType = null;
/*      */     try
/*      */     {
/* 2212 */       localTDSType = TDSType.valueOf(paramTDSReader.readUnsignedByte());
/*      */     }
/*      */     catch (IllegalArgumentException localIllegalArgumentException)
/*      */     {
/* 2216 */       paramTDSReader.getConnection().terminate(4, localIllegalArgumentException.getMessage(), localIllegalArgumentException);
/*      */     }
/*      */ 
/* 2220 */     assert (null != builderMap.get(localTDSType)) : ("Missing TypeInfo builder for TDSType " + localTDSType);
/* 2221 */     return ((Builder)builderMap.get(localTDSType)).build(localTypeInfo, paramTDSReader);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 1614 */     UPDATABLE_READ_ONLY = 0;
/* 1615 */     UPDATABLE_READ_WRITE = 1;
/* 1616 */     UPDATABLE_UNKNOWN = 2;
/*      */ 
/* 2187 */     builderMap = new EnumMap(TDSType.class);
/*      */ 
/* 2192 */     for (Builder localBuilder : Builder.values())
/* 2193 */       builderMap.put(localBuilder.getTDSType(), localBuilder);
/*      */   }
/*      */ 
/*      */   static enum Builder
/*      */   {
/*      */     private final TDSType tdsType;
/*      */     private final Strategy strategy;
/*      */ 
/*      */     private Builder(TDSType paramTDSType, Strategy paramStrategy)
/*      */     {
/* 2150 */       this.tdsType = paramTDSType;
/* 2151 */       this.strategy = paramStrategy;
/*      */     }
/*      */     final TDSType getTDSType() {
/* 2154 */       return this.tdsType;
/*      */     }
/*      */ 
/*      */     final TypeInfo build(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException {
/* 2158 */       this.strategy.apply(paramTypeInfo, paramTDSReader);
/*      */ 
/* 2161 */       assert (null != paramTypeInfo.ssType);
/* 2162 */       assert (null != paramTypeInfo.ssLenType);
/*      */ 
/* 2164 */       return paramTypeInfo;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1626 */       BIT = new Builder("BIT", 0, TDSType.BIT1, new FixedLenStrategy(SSType.BIT, 1, 1, "1".length(), 0));
/*      */ 
/* 1634 */       BIGINT = new Builder("BIGINT", 1, TDSType.INT8, new FixedLenStrategy(SSType.BIGINT, 8, Long.toString(9223372036854775807L).length(), ("-" + Long.toString(9223372036854775807L)).length(), 0));
/*      */ 
/* 1642 */       INTEGER = new Builder("INTEGER", 2, TDSType.INT4, new FixedLenStrategy(SSType.INTEGER, 4, Integer.toString(2147483647).length(), ("-" + Integer.toString(2147483647)).length(), 0));
/*      */ 
/* 1650 */       SMALLINT = new Builder("SMALLINT", 3, TDSType.INT2, new FixedLenStrategy(SSType.SMALLINT, 2, Short.toString(32767).length(), ("-" + Short.toString(32767)).length(), 0));
/*      */ 
/* 1658 */       TINYINT = new Builder("TINYINT", 4, TDSType.INT1, new FixedLenStrategy(SSType.TINYINT, 1, Byte.toString(127).length(), Byte.toString(127).length(), 0));
/*      */ 
/* 1666 */       REAL = new Builder("REAL", 5, TDSType.FLOAT4, new FixedLenStrategy(SSType.REAL, 4, 7, 13, 0));
/*      */ 
/* 1674 */       FLOAT = new Builder("FLOAT", 6, TDSType.FLOAT8, new FixedLenStrategy(SSType.FLOAT, 8, 15, 22, 0));
/*      */ 
/* 1682 */       SMALLDATETIME = new Builder("SMALLDATETIME", 7, TDSType.DATETIME4, new FixedLenStrategy(SSType.SMALLDATETIME, 4, "yyyy-mm-dd hh:mm".length(), "yyyy-mm-dd hh:mm".length(), 0));
/*      */ 
/* 1690 */       DATETIME = new Builder("DATETIME", 8, TDSType.DATETIME8, new FixedLenStrategy(SSType.DATETIME, 8, "yyyy-mm-dd hh:mm:ss.fff".length(), "yyyy-mm-dd hh:mm:ss.fff".length(), 3));
/*      */ 
/* 1698 */       SMALLMONEY = new Builder("SMALLMONEY", 9, TDSType.MONEY4, new FixedLenStrategy(SSType.SMALLMONEY, 4, Integer.toString(2147483647).length(), ("-." + Integer.toString(2147483647)).length(), 4));
/*      */ 
/* 1706 */       MONEY = new Builder("MONEY", 10, TDSType.MONEY8, new FixedLenStrategy(SSType.MONEY, 8, Long.toString(9223372036854775807L).length(), ("-." + Long.toString(9223372036854775807L)).length(), 4));
/*      */ 
/* 1714 */       BITN = new Builder("BITN", 11, TDSType.BITN, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1718 */           if (1 != paramTDSReader.readUnsignedByte()) {
/* 1719 */             paramTDSReader.throwInvalidTDS();
/*      */           }
/* 1721 */           TypeInfo.Builder.BIT.build(paramTypeInfo, paramTDSReader);
/* 1722 */           TypeInfo.access$002(paramTypeInfo, SSLenType.BYTELENTYPE);
/*      */         }
/*      */       });
/* 1726 */       INTN = new Builder("INTN", 12, TDSType.INTN, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1730 */           switch (paramTDSReader.readUnsignedByte()) {
/*      */           case 8:
/* 1732 */             TypeInfo.Builder.BIGINT.build(paramTypeInfo, paramTDSReader); break;
/*      */           case 4:
/* 1733 */             TypeInfo.Builder.INTEGER.build(paramTypeInfo, paramTDSReader); break;
/*      */           case 2:
/* 1734 */             TypeInfo.Builder.SMALLINT.build(paramTypeInfo, paramTDSReader); break;
/*      */           case 1:
/* 1735 */             TypeInfo.Builder.TINYINT.build(paramTypeInfo, paramTDSReader); break;
/*      */           case 3:
/*      */           case 5:
/*      */           case 6:
/*      */           case 7:
/*      */           default:
/* 1736 */             paramTDSReader.throwInvalidTDS();
/*      */           }
/*      */ 
/* 1739 */           TypeInfo.access$002(paramTypeInfo, SSLenType.BYTELENTYPE);
/*      */         }
/*      */       });
/* 1743 */       DECIMAL = new Builder("DECIMAL", 13, TDSType.DECIMALN, new DecimalNumericStrategy(SSType.DECIMAL));
/* 1744 */       NUMERIC = new Builder("NUMERIC", 14, TDSType.NUMERICN, new DecimalNumericStrategy(SSType.NUMERIC));
/* 1745 */       FLOATN = new Builder("FLOATN", 15, TDSType.FLOATN, new BigOrSmallByteLenStrategy(FLOAT, REAL));
/* 1746 */       MONEYN = new Builder("MONEYN", 16, TDSType.MONEYN, new BigOrSmallByteLenStrategy(MONEY, SMALLMONEY));
/* 1747 */       DATETIMEN = new Builder("DATETIMEN", 17, TDSType.DATETIMEN, new BigOrSmallByteLenStrategy(DATETIME, SMALLDATETIME));
/*      */ 
/* 1749 */       TIME = new Builder("TIME", 18, TDSType.TIMEN, new KatmaiScaledTemporalStrategy(SSType.TIME));
/* 1750 */       DATETIME2 = new Builder("DATETIME2", 19, TDSType.DATETIME2N, new KatmaiScaledTemporalStrategy(SSType.DATETIME2));
/* 1751 */       DATETIMEOFFSET = new Builder("DATETIMEOFFSET", 20, TDSType.DATETIMEOFFSETN, new KatmaiScaledTemporalStrategy(SSType.DATETIMEOFFSET));
/*      */ 
/* 1753 */       DATE = new Builder("DATE", 21, TDSType.DATEN, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1757 */           TypeInfo.access$102(paramTypeInfo, SSType.DATE);
/* 1758 */           TypeInfo.access$002(paramTypeInfo, SSLenType.BYTELENTYPE);
/* 1759 */           TypeInfo.access$202(paramTypeInfo, 3);
/* 1760 */           TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, "yyyy-mm-dd".length()));
/*      */         }
/*      */       });
/* 1764 */       BIGBINARY = new Builder("BIGBINARY", 22, TDSType.BIGBINARY, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1768 */           TypeInfo.access$002(paramTypeInfo, SSLenType.USHORTLENTYPE);
/* 1769 */           TypeInfo.access$202(paramTypeInfo, paramTDSReader.readUnsignedShort());
/* 1770 */           if (paramTypeInfo.maxLength > 8000)
/* 1771 */             paramTDSReader.throwInvalidTDS();
/* 1772 */           TypeInfo.access$402(paramTypeInfo, paramTypeInfo.maxLength);
/* 1773 */           TypeInfo.access$302(paramTypeInfo, 2 * paramTypeInfo.maxLength);
/* 1774 */           TypeInfo.access$102(paramTypeInfo, 80 == paramTypeInfo.userType ? SSType.TIMESTAMP : SSType.BINARY);
/*      */         }
/*      */       });
/* 1779 */       BIGVARBINARY = new Builder("BIGVARBINARY", 23, TDSType.BIGVARBINARY, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1783 */           TypeInfo.access$202(paramTypeInfo, paramTDSReader.readUnsignedShort());
/* 1784 */           if (65535 == paramTypeInfo.maxLength)
/*      */           {
/* 1786 */             TypeInfo.access$002(paramTypeInfo, SSLenType.PARTLENTYPE);
/* 1787 */             TypeInfo.access$102(paramTypeInfo, SSType.VARBINARYMAX);
/* 1788 */             TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, 2147483647));
/*      */           }
/* 1790 */           else if (paramTypeInfo.maxLength <= 8000)
/*      */           {
/* 1792 */             TypeInfo.access$002(paramTypeInfo, SSLenType.USHORTLENTYPE);
/* 1793 */             TypeInfo.access$102(paramTypeInfo, SSType.VARBINARY);
/* 1794 */             TypeInfo.access$402(paramTypeInfo, paramTypeInfo.maxLength);
/* 1795 */             TypeInfo.access$302(paramTypeInfo, 2 * paramTypeInfo.maxLength);
/*      */           }
/*      */           else
/*      */           {
/* 1799 */             paramTDSReader.throwInvalidTDS();
/*      */           }
/*      */         }
/*      */       });
/* 1804 */       IMAGE = new Builder("IMAGE", 24, TDSType.IMAGE, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1808 */           TypeInfo.access$002(paramTypeInfo, SSLenType.LONGLENTYPE);
/* 1809 */           TypeInfo.access$202(paramTypeInfo, paramTDSReader.readInt());
/* 1810 */           if (paramTypeInfo.maxLength < 0)
/* 1811 */             paramTDSReader.throwInvalidTDS();
/* 1812 */           TypeInfo.access$102(paramTypeInfo, SSType.IMAGE);
/* 1813 */           TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, 2147483647));
/*      */         }
/*      */       });
/* 1817 */       BIGCHAR = new Builder("BIGCHAR", 25, TDSType.BIGCHAR, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1821 */           TypeInfo.access$002(paramTypeInfo, SSLenType.USHORTLENTYPE);
/* 1822 */           TypeInfo.access$202(paramTypeInfo, paramTDSReader.readUnsignedShort());
/* 1823 */           if (paramTypeInfo.maxLength > 8000)
/* 1824 */             paramTDSReader.throwInvalidTDS();
/* 1825 */           TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, paramTypeInfo.maxLength));
/* 1826 */           TypeInfo.access$102(paramTypeInfo, SSType.CHAR);
/* 1827 */           TypeInfo.access$602(paramTypeInfo, paramTDSReader.readCollation());
/* 1828 */           TypeInfo.access$702(paramTypeInfo, paramTypeInfo.collation.getCharset());
/*      */         }
/*      */       });
/* 1832 */       BIGVARCHAR = new Builder("BIGVARCHAR", 26, TDSType.BIGVARCHAR, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1836 */           TypeInfo.access$202(paramTypeInfo, paramTDSReader.readUnsignedShort());
/* 1837 */           if (65535 == paramTypeInfo.maxLength)
/*      */           {
/* 1839 */             TypeInfo.access$002(paramTypeInfo, SSLenType.PARTLENTYPE);
/* 1840 */             TypeInfo.access$102(paramTypeInfo, SSType.VARCHARMAX);
/* 1841 */             TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, 2147483647));
/*      */           }
/* 1843 */           else if (paramTypeInfo.maxLength <= 8000)
/*      */           {
/* 1845 */             TypeInfo.access$002(paramTypeInfo, SSLenType.USHORTLENTYPE);
/* 1846 */             TypeInfo.access$102(paramTypeInfo, SSType.VARCHAR);
/* 1847 */             TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, paramTypeInfo.maxLength));
/*      */           }
/*      */           else
/*      */           {
/* 1851 */             paramTDSReader.throwInvalidTDS();
/*      */           }
/*      */ 
/* 1854 */           TypeInfo.access$602(paramTypeInfo, paramTDSReader.readCollation());
/* 1855 */           TypeInfo.access$702(paramTypeInfo, paramTypeInfo.collation.getCharset());
/*      */         }
/*      */       });
/* 1859 */       TEXT = new Builder("TEXT", 27, TDSType.TEXT, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1863 */           TypeInfo.access$002(paramTypeInfo, SSLenType.LONGLENTYPE);
/* 1864 */           TypeInfo.access$202(paramTypeInfo, paramTDSReader.readInt());
/* 1865 */           if (paramTypeInfo.maxLength < 0)
/* 1866 */             paramTDSReader.throwInvalidTDS();
/* 1867 */           TypeInfo.access$102(paramTypeInfo, SSType.TEXT);
/* 1868 */           TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, 2147483647));
/* 1869 */           TypeInfo.access$602(paramTypeInfo, paramTDSReader.readCollation());
/* 1870 */           TypeInfo.access$702(paramTypeInfo, paramTypeInfo.collation.getCharset());
/*      */         }
/*      */       });
/* 1874 */       NCHAR = new Builder("NCHAR", 28, TDSType.NCHAR, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1878 */           TypeInfo.access$002(paramTypeInfo, SSLenType.USHORTLENTYPE);
/* 1879 */           TypeInfo.access$202(paramTypeInfo, paramTDSReader.readUnsignedShort());
/* 1880 */           if ((paramTypeInfo.maxLength > 8000) || (0 != paramTypeInfo.maxLength % 2))
/* 1881 */             paramTDSReader.throwInvalidTDS();
/* 1882 */           TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, paramTypeInfo.maxLength / 2));
/* 1883 */           TypeInfo.access$102(paramTypeInfo, SSType.NCHAR);
/* 1884 */           TypeInfo.access$602(paramTypeInfo, paramTDSReader.readCollation());
/* 1885 */           TypeInfo.access$702(paramTypeInfo, Encoding.UNICODE.charsetName());
/*      */         }
/*      */       });
/* 1889 */       NVARCHAR = new Builder("NVARCHAR", 29, TDSType.NVARCHAR, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1893 */           TypeInfo.access$202(paramTypeInfo, paramTDSReader.readUnsignedShort());
/* 1894 */           if (65535 == paramTypeInfo.maxLength)
/*      */           {
/* 1896 */             TypeInfo.access$002(paramTypeInfo, SSLenType.PARTLENTYPE);
/* 1897 */             TypeInfo.access$102(paramTypeInfo, SSType.NVARCHARMAX);
/* 1898 */             TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, 1073741823));
/*      */           }
/* 1900 */           else if ((paramTypeInfo.maxLength <= 8000) && (0 == paramTypeInfo.maxLength % 2))
/*      */           {
/* 1902 */             TypeInfo.access$002(paramTypeInfo, SSLenType.USHORTLENTYPE);
/* 1903 */             TypeInfo.access$102(paramTypeInfo, SSType.NVARCHAR);
/* 1904 */             TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, paramTypeInfo.maxLength / 2));
/*      */           }
/*      */           else
/*      */           {
/* 1908 */             paramTDSReader.throwInvalidTDS();
/*      */           }
/* 1910 */           TypeInfo.access$602(paramTypeInfo, paramTDSReader.readCollation());
/* 1911 */           TypeInfo.access$702(paramTypeInfo, Encoding.UNICODE.charsetName());
/*      */         }
/*      */       });
/* 1915 */       NTEXT = new Builder("NTEXT", 30, TDSType.NTEXT, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1919 */           TypeInfo.access$002(paramTypeInfo, SSLenType.LONGLENTYPE);
/* 1920 */           TypeInfo.access$202(paramTypeInfo, paramTDSReader.readInt());
/* 1921 */           if (paramTypeInfo.maxLength < 0)
/* 1922 */             paramTDSReader.throwInvalidTDS();
/* 1923 */           TypeInfo.access$102(paramTypeInfo, SSType.NTEXT);
/* 1924 */           TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, 1073741823));
/* 1925 */           TypeInfo.access$602(paramTypeInfo, paramTDSReader.readCollation());
/* 1926 */           TypeInfo.access$702(paramTypeInfo, Encoding.UNICODE.charsetName());
/*      */         }
/*      */       });
/* 1930 */       GUID = new Builder("GUID", 31, TDSType.GUID, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1934 */           int i = paramTDSReader.readUnsignedByte();
/* 1935 */           if ((i != 16) && (i != 0)) {
/* 1936 */             paramTDSReader.throwInvalidTDS();
/*      */           }
/* 1938 */           TypeInfo.access$002(paramTypeInfo, SSLenType.BYTELENTYPE);
/* 1939 */           TypeInfo.access$102(paramTypeInfo, SSType.GUID);
/* 1940 */           TypeInfo.access$202(paramTypeInfo, i);
/* 1941 */           TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, "NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN".length()));
/*      */         }
/*      */       });
/* 1946 */       UDT = new Builder("UDT", 32, TDSType.UDT, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1950 */           UDTTDSHeader localUDTTDSHeader = new UDTTDSHeader(paramTDSReader);
/* 1951 */           TypeInfo.access$202(paramTypeInfo, localUDTTDSHeader.getMaxLen());
/* 1952 */           if (65535 == paramTypeInfo.maxLength)
/*      */           {
/* 1954 */             TypeInfo.access$402(paramTypeInfo, 2147483647);
/* 1955 */             TypeInfo.access$302(paramTypeInfo, 2147483647);
/*      */           }
/* 1957 */           else if (paramTypeInfo.maxLength <= 8000)
/*      */           {
/* 1959 */             TypeInfo.access$402(paramTypeInfo, paramTypeInfo.maxLength);
/* 1960 */             TypeInfo.access$302(paramTypeInfo, 2 * paramTypeInfo.maxLength);
/*      */           }
/*      */           else
/*      */           {
/* 1964 */             paramTDSReader.throwInvalidTDS();
/*      */           }
/*      */ 
/* 1967 */           TypeInfo.access$002(paramTypeInfo, SSLenType.PARTLENTYPE);
/* 1968 */           TypeInfo.access$102(paramTypeInfo, SSType.UDT);
/*      */ 
/* 1973 */           TypeInfo.access$802(paramTypeInfo, localUDTTDSHeader.getTypeName());
/*      */         }
/*      */       });
/* 1977 */       XML = new Builder("XML", 33, TDSType.XML, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */         {
/* 1981 */           XMLTDSHeader localXMLTDSHeader = new XMLTDSHeader(paramTDSReader);
/* 1982 */           TypeInfo.access$002(paramTypeInfo, SSLenType.PARTLENTYPE);
/* 1983 */           TypeInfo.access$102(paramTypeInfo, SSType.XML);
/* 1984 */           TypeInfo.access$302(paramTypeInfo, TypeInfo.access$402(paramTypeInfo, 1073741823));
/* 1985 */           TypeInfo.access$702(paramTypeInfo, Encoding.UNICODE.charsetName());
/*      */         }
/*      */       });
/* 1989 */       SQL_VARIANT = new Builder("SQL_VARIANT", 34, TDSType.SQL_VARIANT, new Strategy()
/*      */       {
/*      */         public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader)
/*      */           throws SQLServerException
/*      */         {
/* 1996 */           SQLServerException.makeFromDriverError(paramTDSReader.getConnection(), null, SQLServerException.getErrString("R_variantNotSupported"), "08006", false);
/*      */         }
/*      */       });
/* 1624 */       $VALUES = new Builder[] { BIT, BIGINT, INTEGER, SMALLINT, TINYINT, REAL, FLOAT, SMALLDATETIME, DATETIME, SMALLMONEY, MONEY, BITN, INTN, DECIMAL, NUMERIC, FLOATN, MONEYN, DATETIMEN, TIME, DATETIME2, DATETIMEOFFSET, DATE, BIGBINARY, BIGVARBINARY, IMAGE, BIGCHAR, BIGVARCHAR, TEXT, NCHAR, NVARCHAR, NTEXT, GUID, UDT, XML, SQL_VARIANT };
/*      */     }
/*      */ 
/*      */     private static final class KatmaiScaledTemporalStrategy
/*      */       implements TypeInfo.Builder.Strategy
/*      */     {
/*      */       private final SSType ssType;
/*      */ 
/*      */       KatmaiScaledTemporalStrategy(SSType paramSSType)
/*      */       {
/* 2103 */         this.ssType = paramSSType;
/*      */       }
/*      */ 
/*      */       private int getPrecision(String paramString, int paramInt)
/*      */       {
/* 2110 */         return paramString.length() + (paramInt > 0 ? 1 + paramInt : 0);
/*      */       }
/*      */ 
/*      */       public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */       {
/* 2115 */         TypeInfo.access$902(paramTypeInfo, paramTDSReader.readUnsignedByte());
/* 2116 */         if (paramTypeInfo.scale > 7) {
/* 2117 */           paramTDSReader.throwInvalidTDS();
/*      */         }
/* 2119 */         switch (TypeInfo.1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSType[this.ssType.ordinal()])
/*      */         {
/*      */         case 1:
/* 2122 */           TypeInfo.access$402(paramTypeInfo, getPrecision("hh:mm:ss", paramTypeInfo.scale));
/* 2123 */           TypeInfo.access$202(paramTypeInfo, TDS.timeValueLength(paramTypeInfo.scale));
/* 2124 */           break;
/*      */         case 2:
/* 2127 */           TypeInfo.access$402(paramTypeInfo, getPrecision("yyyy-mm-dd hh:mm:ss", paramTypeInfo.scale));
/* 2128 */           TypeInfo.access$202(paramTypeInfo, TDS.datetime2ValueLength(paramTypeInfo.scale));
/* 2129 */           break;
/*      */         case 3:
/* 2132 */           TypeInfo.access$402(paramTypeInfo, getPrecision("yyyy-mm-dd hh:mm:ss +HH:MM", paramTypeInfo.scale));
/* 2133 */           TypeInfo.access$202(paramTypeInfo, TDS.datetimeoffsetValueLength(paramTypeInfo.scale));
/* 2134 */           break;
/*      */         default:
/* 2137 */           if ($assertionsDisabled) break; throw new AssertionError("Unexpected SSType: " + this.ssType);
/*      */         }
/*      */ 
/* 2140 */         TypeInfo.access$002(paramTypeInfo, SSLenType.BYTELENTYPE);
/* 2141 */         TypeInfo.access$102(paramTypeInfo, this.ssType);
/* 2142 */         TypeInfo.access$302(paramTypeInfo, paramTypeInfo.precision);
/*      */       }
/*      */     }
/*      */ 
/*      */     private static final class BigOrSmallByteLenStrategy
/*      */       implements TypeInfo.Builder.Strategy
/*      */     {
/*      */       private final TypeInfo.Builder bigBuilder;
/*      */       private final TypeInfo.Builder smallBuilder;
/*      */ 
/*      */       BigOrSmallByteLenStrategy(TypeInfo.Builder paramBuilder1, TypeInfo.Builder paramBuilder2)
/*      */       {
/* 2080 */         this.bigBuilder = paramBuilder1;
/* 2081 */         this.smallBuilder = paramBuilder2;
/*      */       }
/*      */ 
/*      */       public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */       {
/* 2086 */         switch (paramTDSReader.readUnsignedByte()) {
/*      */         case 8:
/* 2088 */           this.bigBuilder.build(paramTypeInfo, paramTDSReader); break;
/*      */         case 4:
/* 2089 */           this.smallBuilder.build(paramTypeInfo, paramTDSReader); break;
/*      */         default:
/* 2090 */           paramTDSReader.throwInvalidTDS();
/*      */         }
/*      */ 
/* 2093 */         TypeInfo.access$002(paramTypeInfo, SSLenType.BYTELENTYPE);
/*      */       }
/*      */     }
/*      */ 
/*      */     private static final class DecimalNumericStrategy
/*      */       implements TypeInfo.Builder.Strategy
/*      */     {
/*      */       private final SSType ssType;
/*      */ 
/*      */       DecimalNumericStrategy(SSType paramSSType)
/*      */       {
/* 2052 */         this.ssType = paramSSType;
/*      */       }
/*      */ 
/*      */       public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException
/*      */       {
/* 2057 */         int i = paramTDSReader.readUnsignedByte();
/* 2058 */         int j = paramTDSReader.readUnsignedByte();
/* 2059 */         int k = paramTDSReader.readUnsignedByte();
/*      */ 
/* 2061 */         if (i > 17) {
/* 2062 */           paramTDSReader.throwInvalidTDS();
/*      */         }
/* 2064 */         TypeInfo.access$002(paramTypeInfo, SSLenType.BYTELENTYPE);
/* 2065 */         TypeInfo.access$102(paramTypeInfo, this.ssType);
/* 2066 */         TypeInfo.access$202(paramTypeInfo, i);
/* 2067 */         TypeInfo.access$402(paramTypeInfo, j);
/* 2068 */         TypeInfo.access$302(paramTypeInfo, j + 2);
/* 2069 */         TypeInfo.access$902(paramTypeInfo, k);
/*      */       }
/*      */     }
/*      */ 
/*      */     private static final class FixedLenStrategy
/*      */       implements TypeInfo.Builder.Strategy
/*      */     {
/*      */       private final SSType ssType;
/*      */       private final int maxLength;
/*      */       private final int precision;
/*      */       private final int displaySize;
/*      */       private final int scale;
/*      */ 
/*      */       FixedLenStrategy(SSType paramSSType, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */       {
/* 2028 */         this.ssType = paramSSType;
/* 2029 */         this.maxLength = paramInt1;
/* 2030 */         this.precision = paramInt2;
/* 2031 */         this.displaySize = paramInt3;
/* 2032 */         this.scale = paramInt4;
/*      */       }
/*      */ 
/*      */       public void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader)
/*      */       {
/* 2037 */         TypeInfo.access$002(paramTypeInfo, SSLenType.FIXEDLENTYPE);
/* 2038 */         TypeInfo.access$102(paramTypeInfo, this.ssType);
/* 2039 */         TypeInfo.access$202(paramTypeInfo, this.maxLength);
/* 2040 */         TypeInfo.access$402(paramTypeInfo, this.precision);
/* 2041 */         TypeInfo.access$302(paramTypeInfo, this.displaySize);
/* 2042 */         TypeInfo.access$902(paramTypeInfo, this.scale);
/*      */       }
/*      */     }
/*      */ 
/*      */     private static abstract interface Strategy
/*      */     {
/*      */       public abstract void apply(TypeInfo paramTypeInfo, TDSReader paramTDSReader)
/*      */         throws SQLServerException;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     com.microsoft.sqlserver.jdbc.TypeInfo
 * JD-Core Version:    0.6.0
 */