/*     */ package microsoft.sql;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public final class DateTimeOffset
/*     */   implements Serializable, Comparable<DateTimeOffset>
/*     */ {
/*     */   private static final long serialVersionUID = 541973748553014280L;
/*     */   private final long utcMillis;
/*     */   private final int nanos;
/*     */   private final int minutesOffset;
/*     */   private static final int NANOS_MIN = 0;
/*     */   private static final int NANOS_MAX = 999999999;
/*     */   private static final int MINUTES_OFFSET_MIN = -840;
/*     */   private static final int MINUTES_OFFSET_MAX = 840;
/*     */   private static final int HUNDRED_NANOS_PER_SECOND = 10000000;
/*  88 */   private String formattedValue = null;
/*     */ 
/*     */   private DateTimeOffset(Timestamp paramTimestamp, int paramInt)
/*     */   {
/*  38 */     if ((paramInt < -840) || (paramInt > 840))
/*  39 */       throw new IllegalArgumentException();
/*  40 */     this.minutesOffset = paramInt;
/*     */ 
/*  43 */     int i = paramTimestamp.getNanos();
/*  44 */     if ((i < 0) || (i > 999999999)) {
/*  45 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*  53 */     int j = (i + 50) / 100;
/*  54 */     this.nanos = (100 * (j % 10000000));
/*  55 */     this.utcMillis = (paramTimestamp.getTime() - paramTimestamp.getNanos() / 1000000 + 1000 * (j / 10000000));
/*     */ 
/*  61 */     assert ((this.minutesOffset >= -840) && (this.minutesOffset <= 840)) : ("minutesOffset: " + this.minutesOffset);
/*  62 */     assert ((this.nanos >= 0) && (this.nanos <= 999999999)) : ("nanos: " + this.nanos);
/*  63 */     assert (0 == this.nanos % 100) : ("nanos: " + this.nanos);
/*  64 */     assert (0L == this.utcMillis % 1000L) : ("utcMillis: " + this.utcMillis);
/*     */   }
/*     */ 
/*     */   public static DateTimeOffset valueOf(Timestamp paramTimestamp, int paramInt)
/*     */   {
/*  69 */     return new DateTimeOffset(paramTimestamp, paramInt);
/*     */   }
/*     */ 
/*     */   public static DateTimeOffset valueOf(Timestamp paramTimestamp, Calendar paramCalendar)
/*     */   {
/*  77 */     paramCalendar.setTimeInMillis(paramTimestamp.getTime());
/*     */ 
/*  79 */     return new DateTimeOffset(paramTimestamp, (paramCalendar.get(15) + paramCalendar.get(16)) / 60000);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  94 */     String str1 = this.formattedValue;
/*  95 */     if (null == str1)
/*     */     {
/*  98 */       String str2 = this.minutesOffset < 0 ? String.format(Locale.US, "-%1$02d:%2$02d", new Object[] { Integer.valueOf(-this.minutesOffset / 60), Integer.valueOf(-this.minutesOffset % 60) }) : String.format(Locale.US, "+%1$02d:%2$02d", new Object[] { Integer.valueOf(this.minutesOffset / 60), Integer.valueOf(this.minutesOffset % 60) });
/*     */ 
/* 115 */       Calendar localCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT" + str2), Locale.US);
/*     */ 
/* 120 */       localCalendar.setTimeInMillis(this.utcMillis);
/*     */ 
/* 124 */       assert ((this.nanos >= 0) && (this.nanos <= 999999999));
/*     */ 
/* 127 */       this.formattedValue = (str1 = 0 == this.nanos ? String.format(Locale.US, "%1$tF %1$tT %2$s", new Object[] { localCalendar, str2 }) : String.format(Locale.US, "%1$tF %1$tT.%2$s %3$s", new Object[] { localCalendar, BigDecimal.valueOf(this.nanos, 9).stripTrailingZeros().toPlainString().substring(2), str2 }));
/*     */     }
/*     */ 
/* 146 */     return str1;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object paramObject)
/*     */   {
/* 152 */     if (this == paramObject) {
/* 153 */       return true;
/*     */     }
/*     */ 
/* 156 */     if (!(paramObject instanceof DateTimeOffset)) {
/* 157 */       return false;
/*     */     }
/*     */ 
/* 160 */     DateTimeOffset localDateTimeOffset = (DateTimeOffset)paramObject;
/* 161 */     return (this.utcMillis == localDateTimeOffset.utcMillis) && (this.nanos == localDateTimeOffset.nanos) && (this.minutesOffset == localDateTimeOffset.minutesOffset);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 173 */     assert (0L == this.utcMillis % 1000L);
/* 174 */     long l = this.utcMillis / 1000L;
/*     */ 
/* 176 */     int i = 571;
/* 177 */     i = 2011 * i + (int)l;
/* 178 */     i = 3217 * i + (int)(l / 60L * 60L * 24L * 365L);
/*     */ 
/* 181 */     i = 3919 * i + this.nanos / 100000;
/* 182 */     i = 4463 * i + this.nanos / 1000;
/* 183 */     i = 5227 * i + this.nanos;
/*     */ 
/* 187 */     i = 6689 * i + this.minutesOffset;
/* 188 */     i = 7577 * i + this.minutesOffset / 60;
/*     */ 
/* 193 */     return i;
/*     */   }
/*     */ 
/*     */   public Timestamp getTimestamp()
/*     */   {
/* 205 */     Timestamp localTimestamp = new Timestamp(this.utcMillis);
/* 206 */     localTimestamp.setNanos(this.nanos);
/* 207 */     return localTimestamp;
/*     */   }
/*     */ 
/*     */   public int getMinutesOffset()
/*     */   {
/* 217 */     return this.minutesOffset;
/*     */   }
/*     */ 
/*     */   public int compareTo(DateTimeOffset paramDateTimeOffset)
/*     */   {
/* 238 */     assert (this.nanos >= 0);
/* 239 */     assert (paramDateTimeOffset.nanos >= 0);
/*     */ 
/* 241 */     return this.utcMillis < paramDateTimeOffset.utcMillis ? -1 : this.utcMillis > paramDateTimeOffset.utcMillis ? 1 : this.nanos - paramDateTimeOffset.nanos;
/*     */   }
/*     */ 
/*     */   private Object writeReplace()
/*     */   {
/* 272 */     return new SerializationProxy(this);
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream paramObjectInputStream)
/*     */     throws InvalidObjectException
/*     */   {
/* 283 */     throw new InvalidObjectException("");
/*     */   }
/*     */ 
/*     */   private static class SerializationProxy
/*     */     implements Serializable
/*     */   {
/*     */     private final long utcMillis;
/*     */     private final int nanos;
/*     */     private final int minutesOffset;
/*     */     private static final long serialVersionUID = 664661379547314226L;
/*     */ 
/*     */     SerializationProxy(DateTimeOffset paramDateTimeOffset)
/*     */     {
/* 255 */       this.utcMillis = paramDateTimeOffset.utcMillis;
/* 256 */       this.nanos = paramDateTimeOffset.nanos;
/* 257 */       this.minutesOffset = paramDateTimeOffset.minutesOffset;
/*     */     }
/*     */ 
/*     */     private Object readResolve()
/*     */     {
/* 264 */       Timestamp localTimestamp = new Timestamp(this.utcMillis);
/* 265 */       localTimestamp.setNanos(this.nanos);
/* 266 */       return new DateTimeOffset(localTimestamp, this.minutesOffset, null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     microsoft.sql.DateTimeOffset
 * JD-Core Version:    0.6.0
 */