package microsoft.sql;

public final class Types
{
  public static final int DATETIMEOFFSET = -155;
}

/* Location:           D:\Documents\Downloads\单点登录\Microsoft JDBC Driver 4.1 for SQL Server\sqljdbc_4.1\chs\sqljdbc4.jar
 * Qualified Name:     microsoft.sql.Types
 * JD-Core Version:    0.6.0
 */